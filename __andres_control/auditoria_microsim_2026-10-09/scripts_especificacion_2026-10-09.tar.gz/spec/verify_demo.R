# Independent verification of dossier_insumos_demografia_mortalidad.md (BASE spec).
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
# Writes ONLY aggregates to spec/verify_demo/. Row-level ENPG/DEIS stay in memory.
.t_script <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "verify_demo"); dir.create(OUT, showWarnings = FALSE)
wcsv <- function(x, f) utils::write.csv(x, file.path(OUT, f), row.names = FALSE)
options(width = 200, digits = 7)
hdr <- function(s) cat("\n==== ", s, " ====\n", sep = "")

## 1. kappa: own solver (direct power form, kappa scale, tight tol) + the code's own default ------------
hdr("1 kappa")
kfit <- function(d) stats::uniroot(function(k) sum(d$pop_jan * (1 - (1 - d$qx)^k)) - sum(d$deaths),
  c(0.5, 1.5), tol = 1e-14)$root
mm <- ms_mortality
k_tr <- sapply(c("female", "male"), function(s) kfit(mm[mm$year <= 2020 & mm$sex == s, ]))
k_full <- sapply(c("female", "male"), function(s) kfit(mm[mm$sex == s, ]))
m20 <- ms_fit(2020, trend = TRUE); m24 <- ms_fit(2024, trend = TRUE)
kap <- data.frame(sex = c("female", "male"), own_train2020 = k_tr, code_train2020 = m20$mortality_scale[c("female", "male")],
  own_refit2024 = k_full, code_refit2024 = m24$mortality_scale[c("female", "male")])
print(kap); wcsv(kap, "kappa_verify.csv")
cat("DEIS 15-65 2012-2024 total:", sum(mm$deaths), " by sex:", tapply(mm$deaths, mm$sex, sum), " min cell:", min(mm$deaths), "\n")

## 2. drift: errors, kappa_t, ratios ---------------------------------------------------------------------
hdr("2 drift")
k_code <- m20$mortality_scale
mm$qs <- 1 - (1 - mm$qx)^k_code[mm$sex]
mm$E_hmd <- mm$deaths / mm$mx                       # HMD exposure implied by DEIS deaths (HMD deaths = DEIS within 0.02%)
yr <- do.call(rbind, lapply(split(mm, list(mm$year, mm$sex)), function(d) data.frame(
  year = d$year[1], sex = d$sex[1], D = sum(d$deaths), E1 = sum(d$pop_jan * d$qx), Ek = sum(d$pop_jan * d$qs),
  kappa_t = kfit(d), Njun_m_over_D = sum(d$pop_mid * d$mx) / sum(d$deaths),
  Njan_q_over_Njun_m = sum(d$pop_jan * d$qx) / sum(d$pop_mid * d$mx),
  exposure_gap_expw = sum(d$E_hmd) / sum(d$pop_mid) - 1)))
yr$err <- yr$Ek / yr$D - 1
yr$err_k1 <- yr$E1 / yr$D - 1
yr$approx_err <- k_code[yr$sex] / yr$kappa_t - 1
yr <- yr[order(yr$sex, yr$year), ]
print(yr, digits = 5); wcsv(yr, "drift_verify.csv")
for (s in c("female", "male")) { x <- yr[yr$sex == s, ]
  cat(s, ": slope pp/yr 2012-2024 =", 100 * coef(lm(err ~ year, x))[2],
      "; 2012-2019 =", 100 * coef(lm(err ~ year, x[x$year <= 2019, ]))[2],
      "; kappa_t slope =", coef(lm(kappa_t ~ year, x))[2],
      "; train fit gap =", sum(x$Ek[x$year <= 2020]) / sum(x$D[x$year <= 2020]) - 1,
      "; heldout 2021-24 cum =", sum(x$Ek[x$year > 2020]) / sum(x$D[x$year > 2020]) - 1, "\n") }
cat("range Njan_q/Njun_m:", range(yr$Njan_q_over_Njun_m), "\n")
# parallelogram vs naive with HMD (needs age 66)
hmd <- do.call(rbind, lapply(c("male", "female"), function(sx) {
  z <- utils::read.table(ms_path(ms_demography_files[[paste0("hmd_", sx)]]), header = TRUE, skip = 2L, stringsAsFactors = FALSE)
  z <- z[z$Year %in% 2012:2024 & z$Age %in% as.character(15:66), ]
  data.frame(year = as.integer(z$Year), sex = sx, age = as.integer(z$Age), mx = z$mx, qx = z$qx, ax = z$ax) }))
nx <- hmd; nx$age <- nx$age - 1L; names(nx)[names(nx) == "mx"] <- "mx1"
pm <- merge(mm[c("year", "sex", "age", "pop_jan", "mx", "qx")], nx[c("year", "sex", "age", "mx1")])
pm$qpar <- 1 - exp(-(pm$mx + pm$mx1) / 2)
pr <- stats::aggregate(cbind(Epar = pop_jan * qpar, Enaive = pop_jan * qx) ~ year + sex, pm, sum)
pr$ratio <- pr$Epar / pr$Enaive
cat("par/naive range:", range(pr$ratio), "; naive shortfall 1-1/ratio range:", range(1 - 1 / pr$ratio), "\n")
h65 <- hmd[hmd$age == 65 & hmd$sex == "male", ]
cat("male age 65: (m-q)/m range:", range((h65$mx - h65$qx) / h65$mx), "; m/2 range:", range(h65$mx / 2), "\n")
pw <- c(H_ratio = max(abs(log1p(-mm$qs) / log1p(-mm$qx) - k_code[mm$sex])),
  lin = max(abs(mm$qs - k_code[mm$sex] * mm$qx) / mm$qs), qmax = max(mm$qx)); print(pw)

## 3. MC over 5 seeds (validation model train 2020) ----------------------------------------------------
hdr("3 MC 5 seeds")
runs <- lapply(ms_cfg$seeds, function(sd) ms_simulate(m20, 2012:2024, ms_cfg$n_sim, sd, ms_cfg$rho))
dd <- dplyr::bind_rows(lapply(runs, `[[`, "deaths"))
tot <- stats::aggregate(cbind(deaths, expected_deaths, mc_variance) ~ seed, dd, sum)
tot$z <- (tot$deaths - tot$expected_deaths) / sqrt(tot$mc_variance); print(tot)
ys <- stats::aggregate(cbind(deaths, expected_deaths) ~ year + sex + seed, dd, sum)
ysd <- do.call(rbind, lapply(split(ys, list(ys$year, ys$sex)), function(x) data.frame(year = x$year[1], sex = x$sex[1],
  sd_real = sd(x$deaths), mean_real = mean(x$deaths), expected = x$expected_deaths[1],
  exp_identical = diff(range(x$expected_deaths)) < 1e-6)))
ysd$cv_vs_expected <- ysd$sd_real / ysd$expected; ysd$cv_vs_mean <- ysd$sd_real / ysd$mean_real
ysd$theory_sd_one_seed <- sqrt(stats::aggregate(mc_variance ~ year + sex, dd[dd$seed == ms_cfg$seeds[1], ], sum)$mc_variance[
  match(paste(ysd$year, ysd$sex), paste(stats::aggregate(mc_variance ~ year + sex, dd[dd$seed == ms_cfg$seeds[1], ], sum)$year,
  stats::aggregate(mc_variance ~ year + sex, dd[dd$seed == ms_cfg$seeds[1], ], sum)$sex))])
print(ysd[order(ysd$sex, ysd$year), ], digits = 4); wcsv(ysd, "mc_between_seed_verify.csv")
cat("SD range:", range(ysd$sd_real), "; CV vs expected:", range(ysd$cv_vs_expected), "; CV vs mean realized:", range(ysd$cv_vs_mean),
    "; all expected identical:", all(ysd$exp_identical), "\n")
cat("engine expected vs analytic sum(N_jan q*):", range(merge(stats::aggregate(expected_deaths ~ year + sex, dd[dd$seed == ms_cfg$seeds[1], ], sum),
  yr[c("year", "sex", "Ek")])$expected_deaths / merge(stats::aggregate(expected_deaths ~ year + sex, dd[dd$seed == ms_cfg$seeds[1], ], sum),
  yr[c("year", "sex", "Ek")])$Ek - 1), "\n")
fv <- runs[[1]]$flows; cat("validation run synthetic deaths/yr range:", range(fv$deaths), "\n")

## 4. full refit run 2012-2034 seed 20260917: flows, gross vs net, expected outflow -------------------
hdr("4 flows refit2024")
fr <- ms_simulate(m24, 2012:2034, ms_cfg$n_sim, ms_cfg$seeds[1], ms_cfg$rho)
ff <- fr$flows; w <- ff$unit_weight[1]
cat("w =", w, "; start 2012/2024/2034:", ff$start[ff$year %in% c(2012, 2024, 2034)], "; full-run deaths/yr range:", range(ff$deaths), "\n")
stopifnot(all(ff$end == ff$start - ff$deaths - ff$age_exits - ff$residual_outflow + ff$age_entries + ff$residual_inflow),
  all(head(ff$end, -1) == ff$start[-1]))
st <- ms_population; st$n <- as.integer(round(st$pop_jan / w))
cat("entries == next n_target(15):", all(ff$age_entries[ff$year <= 2033] ==
  sapply(2013:2034, function(y) sum(st$n[st$year == y & st$age == 15]))), "\n")
g <- ff$year <= 2023
cat("gross inflow persons 2012-2023:", sum(ff$residual_inflow[g]) * w, "; outflow:", sum(ff$residual_outflow[g]) * w,
    "; inflow-outflow:", (sum(ff$residual_inflow[g]) - sum(ff$residual_outflow[g])) * w, "\n")
# expected outflow / inflow per (t, s, a): S ~ Bin(n, 1 - q*), target T at (t+1, s, a+1)
k24 <- m24$mortality_scale
st$q <- with(st, { kk <- match(paste(pmin(year, 2024L), sex, age), paste(mm$year, mm$sex, mm$age)); 1 - (1 - mm$qx[kk])^k24[sex] })
eo <- do.call(rbind, lapply(2012:2033, function(y) {
  a <- st[st$year == y & st$age <= 64, ]; b <- st[st$year == y + 1L, ]
  Tn <- b$n[match(paste(a$sex, a$age + 1L), paste(b$sex, b$age))]
  e <- mapply(function(n, p, T) { k <- 0:n; pr <- stats::dbinom(k, n, p); c(sum(pmax(k - T, 0) * pr), sum(pmax(T - k, 0) * pr)) },
    a$n, 1 - a$q, Tn)
  ine_net <- sum(b$pop_jan[match(paste(a$sex, a$age + 1L), paste(b$sex, b$age))] - a$pop_jan * (1 - a$q))
  data.frame(year = y, E_out = sum(e[1, ]), E_in = sum(e[2, ]), cells_T_below_Esurv = sum(Tn < a$n * (1 - a$q)),
    cells = nrow(a), ine_net_persons = ine_net) }))
eo <- merge(eo, ff[c("year", "residual_inflow", "residual_outflow")]); print(eo); wcsv(eo, "flows_expected_verify.csv")
cat("2012-2023: E_out persons", sum(eo$E_out[eo$year <= 2023]) * w, "; E_in persons", sum(eo$E_in[eo$year <= 2023]) * w,
    "; INE net persons", sum(eo$ine_net_persons[eo$year <= 2023]), "; peak", eo$year[which.max(eo$ine_net_persons)], max(eo$ine_net_persons), "\n")

## 5. design SE by hand (2012 strata x PSU; 2020 ids = ~1) ------------------------------------------
hdr("5 design SE by hand")
lin <- function(wave, dom, y, clustered) {
  wd <- wave$weight * dom; yy <- ifelse(dom, y, 0); th <- sum(wd * yy) / sum(wd); z <- wd * (yy - th) / sum(wd)
  if (!clustered) { n <- length(z); return(c(th, sqrt(n / (n - 1) * sum((z - mean(z))^2)))) }
  key <- paste(wave$stratum, wave$psu); zt <- tapply(z, key, sum); sh <- tapply(wave$stratum, key, `[`, 1)
  v <- sum(sapply(split(zt, sh), function(zh) { nh <- length(zh); if (nh > 1) nh / (nh - 1) * sum((zh - mean(zh))^2) else 0 }))
  c(th, sqrt(v)) }
se <- do.call(rbind, lapply(c(2012L, 2016L, 2020L), function(y) {
  wv <- ms_enpg_all[ms_enpg_all$year == y, ]
  do.call(rbind, lapply(seq_len(8), function(i) {
    sx <- rep(c("male", "female"), 4)[i]; ag <- rep(1:4, each = 2)[i]
    cell <- wv$in_domain & wv$sex == sx & wv$age_group == ag
    cu <- !is.na(wv$current) & wv$current == 1
    r <- rbind(lin(wv, cell & !is.na(wv$current), wv$current, y != 2020L),
      lin(wv, cell & cu & is.finite(wv$gpd_survey), wv$gpd_survey, y != 2020L),
      lin(wv, cell & cu & !is.na(wv$hed), wv$hed, y != 2020L))
    t <- ms_targets[ms_targets$year == y & ms_targets$sex == sx & ms_targets$age_group == ag, ]
    data.frame(year = y, sex = sx, age_group = ag, var = c("current", "gpd", "hed"),
      mean_diff = r[, 1] - c(t$current_mean, t$gpd_mean, t$hed_mean),
      se_hand = r[, 2], se_code = c(t$current_se, t$gpd_se, t$hed_se)) })) }))
se$se_rel_diff <- se$se_hand / se$se_code - 1
cat("max |mean diff|:", max(abs(se$mean_diff)), "; max |SE rel diff| by year:\n"); print(tapply(abs(se$se_rel_diff), se$year, max))
wcsv(se, "design_se_by_hand.csv")
print(stats::aggregate(lonely_psu_adjustment_warnings ~ year, ms_targets, sum))
d16 <- ms_design_cache$waves[["2016"]]
cat("2016 PSU short key:", length(unique(paste(d16$commune, d16$psu))), "; rebuilt:",
  length(unique(ms_enpg_all$psu[ms_enpg_all$year == 2016])), "; 2024 strata:", length(unique(ms_enpg_all$stratum[ms_enpg_all$year == 2024])), "\n")
tg <- utils::read.csv(file.path(SPEC, "out_demo", "targets_56_full.csv"))
tg <- merge(tg, ms_targets, by = c("year", "sex", "age_group"), suffixes = c("", ".now"))
cat("targets_56_full vs ms_targets now, max abs diff (mean/se):",
  max(abs(as.matrix(tg[c("current_mean", "current_se", "gpd_mean", "gpd_se", "hed_mean", "hed_se")]) -
    as.matrix(tg[paste0(c("current_mean", "current_se", "gpd_mean", "gpd_se", "hed_mean", "hed_se"), ".now")]))), "\n")

## 6. ENPG g/day, HED, FD diagnostics (15-65 current drinkers) -----------------------------------------
hdr("6 gpd / FD diagnostics")
k <- match(paste(ms_enpg$year, ms_enpg$id), paste(ms_raw$year, as.character(ms_raw$id)))
e <- data.frame(year = ms_enpg$year, sex = ms_enpg$sex, w = ms_enpg$weight, status = ms_enpg$status, g = ms_enpg$gpd_survey, hed = ms_enpg$hed,
  d = suppressWarnings(as.numeric(ms_raw$oh3[k])), ep = suppressWarnings(as.numeric(ms_raw$db[k])),
  q = unname(ms_midpoints[as.character(ms_raw$audit2[k])]), oh2 = as.character(ms_raw$oh2[k]))
cu <- e[e$status == "current", ]; ok <- is.finite(cu$g); b <- ifelse(cu$sex == "male", 5, 4)
hedp <- ok & cu$ep > 0; low <- hedp & cu$q > b
f6 <- c(w_gpd_missing = sum(cu$w[!ok]) / sum(cu$w), w_hed_missing = sum(cu$w[is.na(cu$hed)]) / sum(cu$w),
  w_ep_gt_d = sum(cu$w[ok & cu$ep > cu$d]) / sum(cu$w[ok]), n_ep_gt_30 = sum(ok & cu$ep > 30), max_g = max(cu$g[ok]),
  w_binge_below_typical_of_hed = sum(cu$w[low]) / sum(cu$w[hedp]), n_low = sum(low),
  w_low_and_d_gt_e_of_hed = sum(cu$w[low & cu$d > cu$ep]) / sum(cu$w[hedp]),
  w_low_and_e_ge_d_of_hed = sum(cu$w[low & cu$ep >= cu$d]) / sum(cu$w[hedp]))
print(f6); wcsv(data.frame(stat = names(f6), value = unname(f6)), "gpd_diag_verify.csv")
fd <- do.call(rbind, lapply(ms_wave_years, function(y) { x <- e[e$year == y & e$status != "unknown", ]; f <- x$status == "former"
  data.frame(year = y, share_1_12m_of_FD = sum(x$w[f & x$oh2 == ">30"]) / sum(x$w[f]),
    share_1_12m_of_known = sum(x$w[f & x$oh2 == ">30"]) / sum(x$w)) }))
print(fd); wcsv(fd, "former_split_verify.csv")

## 7. 66+ deaths share (DEIS bundle 15+ and acc_deis 2024) ---------------------------------------------
hdr("7 66+")
old <- py_read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]), c("year", "gender", "age"))
old <- old[old$year %in% 2012:2023 & old$gender %in% c("Hombre", "Mujer") & old$age >= 15, ]
nw <- as.data.frame(acc_deis()); nw <- nw[nw[["A\u00d1O"]] == 2024L & nw$EDAD_TIPO == 1L & nw$EDAD_CANT >= 15 & nw$SEXO_NOMBRE %in% c("Hombre", "Mujer"), ]
stopifnot(names(acc_deis())[1] == "AÑO")
s66 <- rbind(data.frame(sex = old$gender, a66 = old$age >= 66), data.frame(sex = nw$SEXO_NOMBRE, a66 = nw$EDAD_CANT >= 66))
t66 <- tapply(s66$a66, s66$sex, mean); print(t66); rm(old, nw, s66)
wcsv(data.frame(sex = names(t66), share66 = unname(t66)), "share66_verify.csv")
message(sprintf("verify_demo elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t_script, units = "mins"))))
