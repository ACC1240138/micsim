# Held-out coverage of the WLS *prediction* interval (parameter + design + residual wave variance), aggregates only.
.t0 <- Sys.time()
OUT <- "<scratch>/spec/prev_out"
tg <- utils::read.csv(file.path(OUT, "prev_targets_56.csv"))
tg$cell <- factor(paste(tg$sex, tg$age_group, sep = ":")); tg$time <- (tg$year - 2012) / 10
tr <- tg[tg$set == "train", ]; ho <- tg[tg$set == "held-out", ]
lin <- stats::lm(logit_p ~ 0 + cell + cell:time, data = tr, weights = w_current)
s2 <- summary(lin)$sigma^2; q <- stats::qt(0.975, lin$df.residual)
pr <- stats::predict(lin, newdata = ho, se.fit = TRUE)
# Var(new obs) = se.fit^2 (already sigma2-scaled) + sigma2 / w_new  (WLS prediction variance for a new wave)
pv <- pr$se.fit^2 + s2 / ho$w_current
z <- (ho$logit_p - pr$fit) / sqrt(pv)
stopifnot(length(z) == 16L, all(is.finite(z)))
res <- data.frame(year = ho$year, cell = ho$cell, z = round(z, 2), inside = abs(z) <= q)
print(res); cat(sprintf("Held-out inside WLS 95%% prediction interval: %d/16 (sigma2 = %.2f)\n", sum(res$inside), s2))
utils::write.csv(res, file.path(OUT, "prev_heldout_prediction_interval.csv"), row.names = FALSE)
message(sprintf("prev_predictive_interval.R elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
