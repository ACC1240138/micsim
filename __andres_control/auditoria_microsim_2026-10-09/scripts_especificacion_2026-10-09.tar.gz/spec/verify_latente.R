# Independent verification of dossier_latente_historia.md (BASE spec).
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
# Own implementation: wraps the VERBATIM ms_exposure (no rewrite) and overrides `ever` post hoc for V1/V2.
# Writes ONLY aggregates to spec/verify_latente/.
.t0 <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUTV <- file.path(SPEC, "verify_latente"); dir.create(OUTV, showWarnings = FALSE)
w <- function(x, f) utils::write.csv(x, file.path(OUTV, f), row.names = FALSE)
m <- ms_fit(ms_cfg$train_end, trend = TRUE)
stopifnot(isTRUE(all.equal(unname(round(m$mortality_scale, 4)), c(0.9699, 0.9524))))

## 1. p_F with base R (own code) ------------------------------------------------------------------
nc <- ms_enpg[!is.na(ms_enpg$current) & ms_enpg$current == 0 & !is.na(ms_enpg$ever), ]
pw <- function(d) tapply(d$weight * d$ever, list(d$sex, d$age_group), sum) / tapply(d$weight, list(d$sex, d$age_group), sum)
pF_pool <- pw(nc[nc$year <= 2020, ]); pF_2012 <- pw(nc[nc$year == 2012, ])
code_pF <- with(m$shape, tapply(p_ever_noncurrent, list(sex, age_group), sum))
stopifnot(max(abs(pF_pool - code_pF)) < 1e-12)
a15 <- nc[nc$year <= 2020 & nc$age == 15, ]
pF_15 <- tapply(a15$weight * a15$ever, a15$sex, sum) / tapply(a15$weight, a15$sex, sum)
# wave shares pi_w
Wt <- with(nc[nc$year <= 2020, ], tapply(weight, list(paste(sex, age_group), year), sum)); piw <- Wt / rowSums(Wt)
pf_tab <- data.frame(cell = rownames(Wt), pooled = as.vector(t(pF_pool)), w2012 = as.vector(t(pF_2012)))
print(round(pF_pool, 3)); print(round(pF_2012, 3)); print(round(pF_pool - pF_2012, 3)); print(round(pF_15, 3))
print(range(piw))
w(data.frame(sex = rep(rownames(pF_pool), 4), age_group = rep(1:4, each = 2), pooled = as.vector(pF_pool),
  w2012 = as.vector(pF_2012)), "pF_pooled_2012.csv")

## 2. Observed ENPG never/former (point, weighted) ---------------------------------------------------
kn <- ms_enpg[ms_enpg$status != "unknown", ]
obs <- do.call(rbind, lapply(split(kn, list(kn$year, kn$sex, kn$age_group), drop = TRUE), function(d)
  data.frame(year = d$year[1], sex = d$sex[1], age_group = d$age_group[1],
    never = sum(d$weight * (d$status == "never")) / sum(d$weight),
    former = sum(d$weight * (d$status == "former")) / sum(d$weight),
    current = sum(d$weight * (d$status == "current")) / sum(d$weight))))
obs_all <- do.call(rbind, lapply(split(kn, kn$year), function(d) data.frame(year = d$year[1],
  never = sum(d$weight * (d$status == "never")) / sum(d$weight), former = sum(d$weight * (d$status == "former")) / sum(d$weight))))
print(round(100 * obs_all[, -1], 1))

## 3. Runs: verbatim ms_exposure wrapped ---------------------------------------------------------------
orig <- ms_exposure
env <- new.env()
wrap <- function(variant) function(pop, year, drivers) {
  prev <- pop$ever; fresh <- is.na(prev)
  out <- orig(pop, year, drivers)   # verbatim; consumes identical RNG in all variants
  k <- match(paste(year, out$sex, out$age_group, sep = ":"), drivers$key)
  pc <- drivers$p_current[k]; pf <- drivers$p_ever_noncurrent[k]
  uh <- (pnorm(out$z_current) - pc) / (1 - pc)
  if (variant == "V1") out$ever[fresh] <- out$current[fresh] | uh[fresh] <= pf[fresh]
  if (variant == "V2") {
    nev_prev <- fresh | (!is.na(prev) & !prev)
    out$ever[nev_prev] <- out$current[nev_prev] | uh[nev_prev] <= pf[nev_prev]
  }
  if (variant != "V0") out$alc_status <- ifelse(out$current, "current", ifelse(out$ever, "former", "never"))
  stopifnot(!any(out$current & !out$ever), !any(!fresh & prev & !out$ever))
  env$rec[[length(env$rec) + 1L]] <- data.frame(year = year, id = out$id, sex = out$sex, ag = out$age_group,
    zc = out$z_current, za = out$z_amount, zh = out$z_hed, cur = out$current, st = out$alc_status, uh = uh, pf = pf)
  out
}
res <- list()
for (v in c("V0", "V1", "V2")) for (s in ms_cfg$seeds) {
  ms_exposure <- wrap(v); env$rec <- list()
  r <- ms_simulate(m, 2012:2024, ms_cfg$n_sim, s, rho = ms_cfg$rho)
  res[[paste(v, s)]] <- list(v = v, s = s, r = r, x = do.call(rbind, env$rec))
}
ms_exposure <- orig
# V0 wrapper must equal the verbatim engine (spot check one seed, 2012-2016)
ref <- ms_simulate(m, 2012:2016, ms_cfg$n_sim, ms_cfg$seeds[1], rho = ms_cfg$rho)
ms_exposure <- wrap("V0"); env$rec <- list(); chk <- ms_simulate(m, 2012:2016, ms_cfg$n_sim, ms_cfg$seeds[1], rho = ms_cfg$rho)
ms_exposure <- orig
stopifnot(identical(ref$summary, chk$summary), identical(ref$flows, chk$flows))

## 4. Aggregates ---------------------------------------------------------------------------------------
sm <- do.call(rbind, lapply(res, function(z) cbind(z$r$summary, variant = z$v)))
ys <- aggregate(cbind(nv = never * n, fm = former * n, n) ~ variant + seed + year, sm, sum)
ys$never <- ys$nv / ys$n; ys$former <- ys$fm / ys$n
ys_m <- aggregate(cbind(never, former) ~ variant + year, ys, mean)
ys_sd <- aggregate(cbind(never, former) ~ variant + year, ys, sd)
tmp <- ys_m[ys_m$year %in% c(2012, 2024), ]; tmp$never <- round(100 * tmp$never, 2); tmp$former <- round(100 * tmp$former, 2); print(tmp)
cat("max MC sd never/former (pp):", round(100 * max(ys_sd$never), 2), round(100 * max(ys_sd$former), 2), "\n")
# by sex 2012 and 2024
yss <- aggregate(cbind(nv = never * n, fm = former * n, n) ~ variant + seed + year + sex, sm, sum)
yss$never <- yss$nv / yss$n; yss$former <- yss$fm / yss$n
print(aggregate(cbind(never, former) ~ variant + year + sex, yss[yss$year %in% c(2012, 2024), ], function(x) round(100 * mean(x), 1)))
# cells: mean over seeds, compare with observed waves
cm <- aggregate(cbind(never, former) ~ variant + year + sex + age_group, sm, mean)
cmp <- merge(cm, obs, by = c("year", "sex", "age_group"), suffixes = c("_sim", "_obs"))
cmp$period <- ifelse(cmp$year <= 2020, "train", "held-out")
perf <- aggregate(cbind(nb = never_sim - never_obs, nm = abs(never_sim - never_obs), fb = former_sim - former_obs) ~ variant + period,
  cmp, function(x) round(100 * mean(x), 1))
perf$cells <- aggregate(never_sim ~ variant + period, cmp, length)$never_sim
print(perf); w(perf, "perf_never_former.csv")
print(cmp[cmp$year == 2024 & cmp$sex == "female" & cmp$age_group == 4, ])

## 5. Person-level: lag correlations (V0), switching, transitions, U_hist ------------------------------
lag_out <- list(); tr_out <- list(); uh_out <- list()
for (nm in names(res)) {
  z <- res[[nm]]; x <- z$x; key <- paste(x$year, x$id)
  if (z$v == "V0") for (k in c(1, 5, 10)) {
    j <- match(paste(x$year + k, x$id), key); ok <- !is.na(j)
    lag_out[[length(lag_out) + 1]] <- data.frame(seed = z$s, k = k, pairs = sum(ok), zc = cor(x$zc[ok], x$zc[j[ok]]),
      za = cor(x$za[ok], x$za[j[ok]]), zh = cor(x$zh[ok], x$zh[j[ok]]))
  }
  j <- match(paste(x$year + 1, x$id), key); ok <- !is.na(j)
  tr_out[[nm]] <- cbind(as.data.frame(table(from = x$st[ok], to = x$st[j[ok]])), variant = z$v, seed = z$s)
  # U_hist among non-current at t+1 that were never at t
  nx <- ok & x$st == "never"; jj <- j[nx]; nc1 <- !x$cur[jj]
  uh_out[[nm]] <- data.frame(variant = z$v, seed = z$s, year = x$year[nx][nc1] + 1, conv = x$uh[jj][nc1] <= x$pf[jj][nc1]) |>
    dplyr::group_by(variant, seed, year) |> dplyr::summarise(p = mean(conv), .groups = "drop")
}
lag <- do.call(rbind, lag_out); print(aggregate(cbind(zc, za, zh, pairs) ~ k, lag, mean)); print(0.8^c(1, 5, 7.7, 7.693, 10))
tr <- aggregate(Freq ~ variant + from + to, do.call(rbind, tr_out), sum)
tr$rate <- ave(tr$Freq, tr$variant, tr$from, FUN = function(f) f / sum(f)); print(tr[tr$Freq > 0, ])
uh <- do.call(rbind, uh_out); print(range(aggregate(p ~ variant + year, uh[uh$variant == "V2", ], mean)$p))
fl <- do.call(rbind, lapply(res[grep("^V0", names(res))], function(z) z$r$flows))
cat("switch rate V0:", sum(fl$status_changes) / sum(fl$transition_n), "\n")
q <- qnorm(0.45); cat("theory p=0.45:", 2 * (0.45 - mvtnorm::pmvnorm(upper = c(q, q), corr = matrix(c(1, .8, .8, 1), 2))[1]), "\n")
# trace ids: who are they?
st <- ms_population[ms_population$year == 2012, ]; cat("first stock row:", st$sex[1], st$age[1], "\n")
w(tr, "transitions_pooled.csv"); w(aggregate(cbind(zc, za, zh) ~ k, lag, mean), "lag_corr.csv")
message(sprintf("verify_latente elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
