.t0 <- Sys.time()
# Extra arithmetic for the worked example: HMD qx (public life table, no microdata) and the former/never branch.
z <- utils::read.table("<repo>/__andres_control/ine_proyecciones_rebuild/mltper_1x1.txt", header = TRUE, skip = 2L, stringsAsFactors = FALSE)
qx <- function(y, a) as.numeric(z$qx[z$Year == y & z$Age == as.character(a)])
kH <- 0.9524053
for (ya in list(c(2016, 35), c(2017, 36))) {
  q <- qx(ya[1], ya[2]); qs <- -expm1(log1p(-q) * kH)
  cat(sprintf("year %d age %d qx %.6f qstar %.6f ratio %.4f\n", ya[1], ya[2], q, qs, qs / q))
}
pc16 <- 0.610437155422085; pc17 <- 0.612638056044797; pF <- 0.704766068915007
zc16 <- 1.5; eps <- -0.5; zc17 <- 0.8 * zc16 + 0.6 * eps
for (v in list(c(2016, zc16, pc16), c(2017, zc17, pc17))) {
  U <- pnorm(v[2]); uh <- (U - v[3]) / (1 - v[3])
  cat(sprintf("B year %d z %.3f U %.6f pc %.6f current %s Uhist %.6f pF %.6f former_by_rule %s 1-pnever %.6f\n",
    v[1], v[2], U, v[3], U < v[3], uh, pF, uh <= pF, 1 - (1 - v[3]) * (1 - pF)))
}
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
