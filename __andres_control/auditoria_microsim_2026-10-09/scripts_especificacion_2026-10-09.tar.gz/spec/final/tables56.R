# Aggregates only: format 56-cell targets (mean (SE)) with decimal commas.
.t0 <- Sys.time()
x <- read.csv("out_demo/targets_56_full.csv")
lab <- function(s, a) paste(ifelse(s == "female", "M", "H"), c("15–29","30–44","45–59","60–65")[a])
f <- function(m, se, k, d) paste0(formatC(m * k, format = "f", digits = d, decimal.mark = ","), " (",
  formatC(se * k, format = "f", digits = d, decimal.mark = ","), ")")
tab <- function(mc, sc, k, d) {
  cat("| Celda |", paste(sort(unique(x$year)), collapse = " | "), "|\n")
  cat("|---|", paste(rep("---", 7), collapse = "|"), "|\n", sep = "")
  for (s in c("female", "male")) for (a in 1:4) {
    r <- x[x$sex == s & x$age_group == a, ]; r <- r[order(r$year), ]
    cat("|", lab(s, a), "|", paste(f(r[[mc]], r[[sc]], k, d), collapse = " | "), "|\n")
  }
  cat("\n")
}
for (v in list(c("current_mean","current_se",100,1), c("never","never_se",100,1), c("former","former_se",100,1),
               c("gpd_mean","gpd_se",1,2), c("hed_mean","hed_se",100,1))) {
  cat("##", v[1], "\n"); tab(v[1], v[2], as.numeric(v[3]), as.numeric(v[4]))
}
# check never + former + current = 1
stopifnot(max(abs(x$never + x$former + x$current_mean - 1)) < 1e-9)
message(sprintf("elapsed minutes: %.3f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
