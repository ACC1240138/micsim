# Cell ms-survey-inputs L69-71 evaluated verbatim under the session locale, via parse(text=) and via source(); aggregates only.
setwd("<repo>"); source("_tools/acc_data.R")
r <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))
src <- readLines("<scratch>/spec/base_cells/ms-survey-inputs.R", warn = FALSE)[69:71]
ms_ever <- as.character(r$oh1); ms_recency <- as.character(r$oh2); ms_enpg_all <- data.frame(i = seq_len(nrow(r)))
eval(parse(text = src)); a <- table(ms_enpg_all$status, useNA = "ifany")
tf <- tempfile(fileext = ".R"); writeLines(src, tf); ms_enpg_all <- data.frame(i = seq_len(nrow(r))); source(tf); b <- table(ms_enpg_all$status, useNA = "ifany"); unlink(tf)
cat(Sys.getlocale("LC_CTYPE"), "| parse(text):", paste(names(a), a), "| source():", paste(names(b), b), "\n")
