# Aggregate-only check: does the 2020 design cache carry PSU/region values that the BASE code discards?
.t0 <- Sys.time()
setwd("<repo>/__andres_control"); Sys.setlocale("LC_ALL", "C.UTF-8")
source(here::here("_tools", "acc_data.R"))
dc <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/enpg_design_waves_2012_2024_list.RDS"))
for (y in c("2018", "2020", "2022")) { d <- dc$waves[[y]]
  cat(y, "n", nrow(d), "psu non-NA", sum(!is.na(d$psu)), "distinct psu", length(unique(d$psu[!is.na(d$psu)])),
      "region non-NA", sum(!is.na(d$region)), "distinct region", length(unique(d$region)), "\n") }
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
