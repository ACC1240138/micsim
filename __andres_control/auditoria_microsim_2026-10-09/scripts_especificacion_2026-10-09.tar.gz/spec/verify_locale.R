# Locale check under the session locale: status rule level match and DEIS "AÑO" selection. Aggregates only.
.t0 <- Sys.time()
cat("LC_CTYPE:", Sys.getlocale("LC_CTYPE"), "\n")
setwd("<repo>"); source("_tools/acc_data.R")
r <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))
x <- as.character(r$oh2)
cat("former-level matches (escape):", sum(x %in% c(">30", ">1 año")), "; '>1 a\\u00f1o' alone:", sum(x %in% ">1 año"),
    "; Encoding of level:", unique(Encoding(x[!is.na(x) & grepl("^>1", x)])), "\n")
cells <- "<scratch>/spec/base_cells/"
l62 <- readLines(paste0(cells, "ms-demography-inputs.R"))[62]
res <- tryCatch({d <- acc_deis(); y <- eval(parse(text = sub("^\\.ms_new <- ", "", l62))); paste("L62 OK, ncol", ncol(y))},
  error = function(e) paste("L62 ERROR:", conditionMessage(e)))
cat(res, "\n")
res2 <- tryCatch({y <- d[c("AÑO", "SEXO_NOMBRE")]; paste("escaped-name selection OK, ncol", ncol(y))},
  error = function(e) paste("escaped ERROR:", conditionMessage(e)))
cat(res2, "\n")
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
