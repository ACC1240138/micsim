# Dossier "Parametros + seccion 1 (prevalencia de consumo actual) + diseno train/held-out/proyeccion".
# Runs the BASE notebook cells ms-fit-and-check, ms-historical-validation, ms-persistence-sensitivity and
# ms-full-refit-projection verbatim (ms_table is a no-op; no figure cell is run), then adds aggregate checks.
# Writes ONLY cell-level aggregates to spec/prev_out/. Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
.t0_prev <- Sys.time()  # cells overwrite .t0
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "prev_out")
dir.create(OUT, showWarnings = FALSE)
wcsv <- function(x, f) utils::write.csv(x, file.path(OUT, f), row.names = FALSE)
options(width = 200)

# ---- 1. Verbatim notebook cells -------------------------------------------------------------
run_cell("ms-fit-and-check")          # ms_uncalibrated, ms_calibrated, smoke + no-leakage stopifnot()
run_cell("ms-historical-validation")  # 5 seeds x 2012-2024; ms_performance, ms_reference_performance
run_cell("ms-persistence-sensitivity")
run_cell("ms-full-refit-projection")  # ms_full_model = ms_fit(2024); 1 seed 2012-2034
cat("mortality_scale train2020:", round(ms_calibrated$mortality_scale, 5), "\n")
cat("mortality_scale refit2024:", round(ms_full_model$mortality_scale, 5), "\n")

# ---- 2. Targets: 56 cells -------------------------------------------------------------------
tg <- ms_targets[order(ms_targets$sex, ms_targets$age_group, ms_targets$year),
  c("year", "sex", "age_group", "n", "n_current_observed", "n_eff", "current_mean", "current_se",
    "design_status", "lonely_psu_adjustment_warnings")]
tg$set <- ifelse(tg$year <= ms_cfg$train_end, "train", "held-out")
tg$logit_p <- qlogis(tg$current_mean)
tg$se_logit_delta <- tg$current_se / (tg$current_mean * (1 - tg$current_mean))
tg$w_current <- (tg$current_mean * (1 - tg$current_mean) / tg$current_se)^2
stopifnot(nrow(tg) == 56L, sum(tg$set == "train") == 40L, sum(tg$set == "held-out") == 16L,
  isTRUE(all.equal(tg$w_current, 1 / tg$se_logit_delta^2)))
wcsv(tg, "prev_targets_56.csv")
print(tg[, c("year", "sex", "age_group", "n", "current_mean", "current_se", "set", "design_status")], digits = 4)

# Training weight share by year (within each cell, then averaged over the 8 cells).
trw <- tg[tg$set == "train", ]
trw$share <- trw$w_current / ave(trw$w_current, trw$sex, trw$age_group, FUN = sum)
wshare <- aggregate(share ~ year, data = trw, FUN = mean)
print(wshare, digits = 3); wcsv(wshare, "prev_weight_share_by_year.csv")

# ---- 3. Estimator: coefficients, two SE versions, separability, manual WLS -----------------
coef_table <- function(model, fit_name) {
  m <- model$prevalence; s <- summary(m); cf <- s$coefficients
  X <- stats::model.matrix(m); w <- stats::weights(m)
  V_known <- solve(crossprod(X, w * X))  # weights treated as exact inverse variances
  se_known <- sqrt(diag(V_known)); cells <- m$xlevels$cell
  a <- paste0("cell", cells); b <- paste0("cell", cells, ":time")
  data.frame(fit = fit_name, cell = cells, n_obs = as.integer(table(model.frame(m)$cell)[cells]),
    alpha = cf[a, 1], se_alpha_lm = cf[a, 2], se_alpha_known = se_known[a],
    beta = cf[b, 1], se_beta_lm = cf[b, 2], se_beta_known = se_known[b],
    t_beta_lm = cf[b, 3], sigma2 = s$sigma^2, df_resid = m$df.residual,
    wrss = sum(w * stats::residuals(m)^2),
    p_chisq_known = stats::pchisq(sum(w * stats::residuals(m)^2), m$df.residual, lower.tail = FALSE),
    row.names = NULL)
}
ct <- rbind(coef_table(ms_calibrated, "train2020"), coef_table(ms_full_model, "refit2024"))
print(ct, digits = 4); wcsv(ct, "prev_coef.csv")

m <- ms_calibrated$prevalence
X <- stats::model.matrix(m); w <- stats::weights(m); y <- stats::model.response(stats::model.frame(m))
b_manual <- drop(solve(crossprod(X, w * X), crossprod(X, w * y)))
stopifnot(max(abs(b_manual - stats::coef(m))) < 1e-10)
fd <- ms_targets[ms_targets$year <= 2020, ]
fd$cell <- factor(paste(fd$sex, fd$age_group, sep = ":")); fd$time <- (fd$year - 2012) / 10
fd$y <- qlogis(fd$current_mean); fd$w <- (fd$current_mean * (1 - fd$current_mean) / fd$current_se)^2
sep <- t(sapply(levels(fd$cell), function(cl) stats::coef(stats::lm(y ~ time, data = fd[fd$cell == cl, ], weights = w))))
sep_diff <- max(abs(sep[, 1] - stats::coef(m)[paste0("cell", rownames(sep))]),
  abs(sep[, 2] - stats::coef(m)[paste0("cell", rownames(sep), ":time")]))
stopifnot(sep_diff < 1e-10)
cat(sprintf("Manual WLS == lm: max|diff| %.2e; per-cell separate WLS == joint: max|diff| %.2e\n",
  max(abs(b_manual - stats::coef(m))), sep_diff))
# Stored coefficients from the notebook export (read-only repo file).
stored <- utils::read.csv("<repo>/__andres_control/microsim_base_outputs/model_parameters.csv")
st <- stored[stored$fit == "validation_train2020" & stored$component == "prevalence", ]
cat(sprintf("Prevalence coef vs stored export: max|diff| %.2e\n",
  max(abs(st$value - stats::coef(m)[st$parameter]))))
st2 <- stored[stored$fit == "full_refit2024" & stored$component == "prevalence", ]
cat(sprintf("Refit2024 prevalence coef vs stored export: max|diff| %.2e\n",
  max(abs(st2$value - stats::coef(ms_full_model$prevalence)[st2$parameter]))))
cat("Stored mortality_scale:\n"); print(stored[stored$component == "all_cause_mortality", c("fit", "parameter", "value")])

# Standardized training residuals by year (known-variance scale).
fd$z_resid <- (fd$y - stats::fitted(m)) * sqrt(fd$w)
zr <- aggregate(z_resid ~ year, data = fd, FUN = function(v) c(mean = mean(v), rms = sqrt(mean(v^2))))
print(zr, digits = 3)

# ---- 4. Implied pc by year (frozen time), CI, unfrozen contrast ----------------------------
pc_rows <- function(model, fit_name, years = c(2012, 2014, 2016, 2018, 2020, 2022, 2024, 2025, 2034)) {
  g <- expand.grid(year = years, cell = model$prevalence$xlevels$cell, stringsAsFactors = FALSE)
  g$cell <- factor(g$cell, levels = model$prevalence$xlevels$cell)
  g$time <- (pmin(g$year, ms_cfg$observed_end) - ms_cfg$start_year) / 10
  pr <- stats::predict(model$prevalence, newdata = g, se.fit = TRUE)
  q <- stats::qt(0.975, model$prevalence$df.residual)
  g$pc <- plogis(pr$fit); g$lo <- plogis(pr$fit - q * pr$se.fit); g$hi <- plogis(pr$fit + q * pr$se.fit)
  g$fit <- fit_name
  u <- g[g$year == 2034, ]; u$time <- (2034 - ms_cfg$start_year) / 10
  u$pc_unfrozen_2034 <- plogis(stats::predict(model$prevalence, newdata = u))
  g$pc_unfrozen_2034 <- NA_real_; g$pc_unfrozen_2034[g$year == 2034] <- u$pc_unfrozen_2034
  g
}
pc <- rbind(pc_rows(ms_calibrated, "train2020"), pc_rows(ms_full_model, "refit2024"))
pc_wide <- stats::reshape(pc[, c("fit", "cell", "year", "pc")], idvar = c("fit", "cell"), timevar = "year", direction = "wide")
print(cbind(pc_wide[, 1:2], round(100 * pc_wide[, -(1:2)], 2)))
print(cbind(pc[pc$year == 2034, c("fit", "cell")], round(100 * pc[pc$year == 2034, c("pc", "pc_unfrozen_2034")], 2)))
wcsv(pc, "prev_pc_by_year.csv")
# Population-weighted 15-65 national pc (INE 1 Jan stocks of that year).
nat <- function(model, fit_name) {
  yrs <- c(2012, 2016, 2020, 2022, 2024, 2034)
  do.call(rbind, lapply(yrs, function(yy) {
    p <- ms_population[ms_population$year == yy, ]; p$cell <- paste(p$sex, findInterval(p$age, c(15, 30, 45, 60)), sep = ":")
    pw <- aggregate(pop_jan ~ cell, data = p, FUN = sum)
    gg <- data.frame(cell = factor(pw$cell, levels = model$prevalence$xlevels$cell))
    gg$time <- (min(yy, 2024) - 2012) / 10; f <- plogis(stats::predict(model$prevalence, newdata = gg))
    gg$time <- (yy - 2012) / 10; u <- plogis(stats::predict(model$prevalence, newdata = gg))
    data.frame(fit = fit_name, year = yy, pc_frozen = sum(f * pw$pop_jan) / sum(pw$pop_jan),
      pc_unfrozen = sum(u * pw$pop_jan) / sum(pw$pop_jan))
  }))
}
natl <- rbind(nat(ms_calibrated, "train2020"), nat(ms_full_model, "refit2024"))
# Observed national (design-based cell means weighted by INE stock of the wave year), for contrast.
obs_nat <- do.call(rbind, lapply(seq(2012, 2024, 2), function(yy) {
  p <- ms_population[ms_population$year == yy, ]; p$age_group <- findInterval(p$age, c(15, 30, 45, 60))
  pw <- aggregate(pop_jan ~ sex + age_group, data = p, FUN = sum)
  o <- merge(pw, ms_targets[ms_targets$year == yy, c("sex", "age_group", "current_mean")])
  data.frame(year = yy, observed_cells_popweighted = sum(o$current_mean * o$pop_jan) / sum(o$pop_jan))
}))
print(natl, digits = 4); print(obs_nat, digits = 4)
wcsv(natl, "prev_pc_national.csv"); wcsv(obs_nat, "prev_observed_national.csv")

# ---- 5. Freeze confirmed in ms_drivers ------------------------------------------------------
for (mod in list(ms_calibrated, ms_full_model)) {
  dr <- ms_drivers(mod, 2012:2034)
  ok <- tapply(seq_len(nrow(dr)), paste(dr$sex, dr$age_group), function(ix) {
    d <- dr[ix, ]; length(unique(d$p_current[d$year >= 2024])) == 1L &&
      length(unique(d$p_current[d$year <= 2024])) == 13L })
  stopifnot(all(ok))
  hand <- plogis(stats::coef(mod$prevalence)[paste0("cell", dr$cell)] +
    stats::coef(mod$prevalence)[paste0("cell", dr$cell, ":time")] * (pmin(dr$year, 2024) - 2012) / 10)
  cat(sprintf("Freeze check fit %s: OK; drivers vs hand plogis(alpha+beta*t) max|diff| %.2e\n",
    mod$last_year, max(abs(hand - dr$p_current))))
}

# ---- 6. Engine prevalence == analytic pc (within binomial MC error) ------------------------
dr20 <- ms_drivers(ms_calibrated, 2012:2024)
agg <- ms_validation_summary |> dplyr::group_by(year, sex, age_group) |>
  dplyr::summarise(n_tot = sum(n), sim = sum(n * current_mean) / sum(n), .groups = "drop")
agg <- merge(agg, dr20[, c("year", "sex", "age_group", "p_current")])
agg$z <- (agg$sim - agg$p_current) / sqrt(agg$p_current * (1 - agg$p_current) / agg$n_tot)
cat(sprintf("Engine vs analytic pc, 104 year-cells x 5 seeds: max|z| %.2f, mean z %.3f, sd z %.3f\n",
  max(abs(agg$z)), mean(agg$z), stats::sd(agg$z)))
pj <- ms_full_run$summary[ms_full_run$summary$year >= 2025, ]
dr24 <- ms_drivers(ms_full_model, 2025:2034)
pj <- merge(pj, dr24[, c("year", "sex", "age_group", "p_current")])
pj$z <- (pj$current_mean - pj$p_current) / sqrt(pj$p_current * (1 - pj$p_current) / pj$n)
cat(sprintf("Projection 2025-2034 (refit2024, 1 seed): max|z| sim vs frozen pc %.2f over %d year-cells\n",
  max(abs(pj$z)), nrow(pj)))

# ---- 7. Validation metrics: verbatim + counts + per-year + static + analytic ---------------
cov <- ms_comparison |> dplyr::group_by(period, metric) |>
  dplyr::summarise(n_eval_interval = sum(!is.na(in_working_interval)),
    n_in_interval = sum(in_working_interval, na.rm = TRUE), .groups = "drop")
perf <- merge(ms_performance, cov)
print(perf, digits = 4); wcsv(perf, "prev_validation_metrics.csv")
by_year <- ms_comparison |> dplyr::filter(metric == "current") |> dplyr::group_by(year) |>
  dplyr::summarise(bias_pp = 100 * mean(error), rmse_pp = 100 * sqrt(mean(error^2)),
    n_in = sum(in_working_interval), .groups = "drop")
print(by_year, digits = 3); wcsv(by_year, "prev_validation_current_by_year.csv")
cells_cur <- ms_comparison[ms_comparison$metric == "current", ]
cells_cur <- merge(cells_cur, dr20[, c("year", "sex", "age_group", "p_current")])
cells_cur <- cells_cur[order(cells_cur$year, cells_cur$sex, cells_cur$age_group), ]
wcsv(cells_cur, "prev_validation_cells_current.csv")
print(cells_cur[cells_cur$year >= 2022, c("year", "sex", "age_group", "observed", "se", "simulated", "p_current",
  "mc_sd", "error", "standardized_error", "in_working_interval")], digits = 4)
# Static-2012 comparator: full metrics (verbatim cell gives held-out RMSE only).
rc <- ms_reference_compare
rc$period <- ifelse(rc$year <= 2020, "Training 2012-2020", "Held out 2022/2024")
stat <- do.call(rbind, lapply(c("current", "gpd", "hed"), function(mm) {
  e <- rc[[paste0(mm, "_mean_simulated")]] - rc[[paste0(mm, "_mean_observed")]]; se <- rc[[paste0(mm, "_se")]]
  inside <- ifelse(rc$year == 2020, NA, abs(e) <= qnorm(0.975) * se)
  do.call(rbind, lapply(split(seq_along(e), rc$period), function(ix) data.frame(model = "static2012_seed1",
    period = rc$period[ix[1]], metric = mm, cells = length(ix), bias = mean(e[ix]), rmse = sqrt(mean(e[ix]^2)),
    mae = mean(abs(e[ix])), n_in = sum(inside[ix], na.rm = TRUE), n_eval = sum(!is.na(inside[ix])))))
}))
print(stat, digits = 4); wcsv(stat, "prev_static_comparator.csv")
# Analytic (no simulation) WLS prediction of current prevalence.
an <- merge(ms_targets[, c("year", "sex", "age_group", "current_mean", "current_se")], dr20[, c("year", "sex", "age_group", "p_current")])
an$e <- an$p_current - an$current_mean; an$period <- ifelse(an$year <= 2020, "train", "held-out")
an_m <- do.call(rbind, lapply(split(an, an$period), function(d) data.frame(period = d$period[1], cells = nrow(d),
  bias_pp = 100 * mean(d$e), rmse_pp = 100 * sqrt(mean(d$e^2)), mae_pp = 100 * mean(abs(d$e)),
  n_in = sum(abs(d$e[d$year != 2020]) <= qnorm(0.975) * d$current_se[d$year != 2020]), n_eval = sum(d$year != 2020))))
print(an_m, digits = 4); wcsv(an_m, "prev_analytic_metrics.csv")
# Per-seed held-out bias: what 5 seeds measure.
ps <- merge(ms_validation_summary[, c("year", "sex", "age_group", "seed", "current_mean")],
  ms_targets[, c("year", "sex", "age_group", "current_mean")], by = c("year", "sex", "age_group"), suffixes = c("_sim", "_obs"))
ps_b <- aggregate(cbind(e = current_mean_sim - current_mean_obs) ~ seed, data = ps[ps$year >= 2022, ], FUN = mean)
ps_r <- aggregate(cbind(e2 = (current_mean_sim - current_mean_obs)^2) ~ seed, data = ps[ps$year >= 2022, ], FUN = mean)
ps_b$rmse <- sqrt(ps_r$e2); print(ps_b, digits = 4)
cat(sprintf("Held-out current bias across seeds: mean %.4f, sd %.5f; RMSE sd %.5f\n", mean(ps_b$e), stats::sd(ps_b$e), stats::sd(ps_b$rmse)))
wcsv(ps_b, "prev_heldout_bias_by_seed.csv")
# Compare with the stored notebook export (read-only).
sv <- utils::read.csv("<repo>/__andres_control/microsim_base_outputs/validation_metrics.csv")
cmp <- merge(ms_performance[, c("period", "metric", "bias", "rmse", "mae", "working_interval_coverage")],
  sv[, c("period", "metric", "bias", "rmse", "mae", "working_interval_coverage")], by = c("period", "metric"), suffixes = c("_now", "_stored"))
print(cmp, digits = 4); wcsv(cmp, "prev_compare_stored.csv")
ss <- utils::read.csv("<repo>/__andres_control/microsim_base_outputs/static_comparator_metrics.csv")
print(merge(ms_reference_performance, ss, by = "metric", suffixes = c("_now", "_stored")), digits = 4)

# ---- 8. Parameters: unit weight, N, switching, persistence sensitivity, projection ---------
fl <- dplyr::bind_rows(lapply(ms_validation_runs, `[[`, "flows"))
pop12 <- sum(ms_population$pop_jan[ms_population$year == 2012])
cat(sprintf("Sum INE pop_jan 2012 (15-65) %.0f; unit_weight %.5f (= /25000: %.5f)\n", pop12, unique(fl$unit_weight), pop12 / 25000))
print(fl[fl$year %in% c(2012, 2020, 2024), c("seed", "year", "start", "end", "status_changes", "transition_n")])
cat(sprintf("Annual current-status switching (5 seeds, 2012-2023 transitions): %.4f\n", sum(fl$status_changes) / sum(fl$transition_n)))
print(ms_full_run$flows[ms_full_run$flows$year %in% c(2012, 2024, 2034), c("year", "start", "end")])
print(ms_sensitivity, digits = 4); wcsv(ms_sensitivity, "prev_persistence_sensitivity.csv")
print(ms_refit_metrics, digits = 4); wcsv(ms_refit_metrics, "prev_refit_metrics.csv")
print(ms_projection[, c("year", "current_prevalence", "population", "period")], digits = 4)
wcsv(ms_projection, "prev_projection_refit2024_seed1.csv")

# ---- 9. Delta-method numeric check ----------------------------------------------------------
set.seed(1)
dm <- t(sapply(seq_len(nrow(tg)), function(i) { p <- tg$current_mean[i]; s <- tg$current_se[i]
  x <- stats::rnorm(2e5, p, s); stopifnot(all(x > 0 & x < 1)); c(mc = stats::sd(qlogis(x)), delta = s / (p * (1 - p))) }))
cat(sprintf("Delta method SE(logit p) vs MC (2e5 normal draws), 56 cells: max rel. error %.4f, median %.4f\n",
  max(abs(dm[, "delta"] / dm[, "mc"] - 1)), stats::median(abs(dm[, "delta"] / dm[, "mc"] - 1))))
cat(sprintf("Range p %.3f-%.3f; SE %.4f-%.4f; SE/p(1-p) %.4f-%.4f\n", min(tg$current_mean), max(tg$current_mean),
  min(tg$current_se), max(tg$current_se), min(tg$se_logit_delta), max(tg$se_logit_delta)))
message(sprintf("prev_validation.R elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0_prev, units = "mins"))))
