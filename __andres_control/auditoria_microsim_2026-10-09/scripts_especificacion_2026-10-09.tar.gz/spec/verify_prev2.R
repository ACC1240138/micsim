# Follow-up checks for verify_prev.R: individual logistic with normalized weights; 2024 lonely-PSU warnings by variable.
.t0_v2 <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
cellid <- function(s, a) paste(s, a, sep = ":")
lmcf <- stats::coef(ms_fit(2020L)$prevalence)
d <- ms_enpg[ms_enpg$year <= 2020L & !is.na(ms_enpg$current), ]
d$cell <- factor(cellid(d$sex, d$age_group)); d$time <- (d$year - 2012) / 10; d$wn <- d$weight / mean(d$weight)
il <- suppressWarnings(stats::glm(current ~ 0 + cell + cell:time, family = stats::binomial(), weights = wn, data = d,
  control = stats::glm.control(epsilon = 1e-12, maxit = 100)))
stopifnot(il$converged)
cf_il <- stats::coef(il); cf_w <- lmcf[names(cf_il)]; k <- which.max(abs(cf_il - cf_w))
ho <- ms_targets[ms_targets$year > 2020L, ]
nd <- data.frame(cell = factor(cellid(ho$sex, ho$age_group), levels = levels(d$cell)), time = (ho$year - 2012) / 10)
e_il <- plogis(stats::predict(il, newdata = nd)) - ho$current_mean
cat(sprintf("V6 indiv logit (binomial, normalized w): max|coef diff| %.4f at %s (wls %.4f, il %.4f); held-out bias %.2f rmse %.2f\n",
  max(abs(cf_il - cf_w)), names(cf_il)[k], cf_w[k], cf_il[k], 100 * mean(e_il), 100 * sqrt(mean(e_il^2))))
# Score identity: weighted cell-wave sums
W <- aggregate(cbind(W = wn, Wy = wn * current) ~ cell + year, data = d, FUN = sum)
W$time <- (W$year - 2012) / 10; W$pi <- plogis(stats::predict(il, newdata = W))
cat(sprintf("V6 aggregated score max|sum W(p-pi)| %.2e\n", max(abs(tapply(W$Wy - W$W * W$pi, W$cell, sum)))))
# 2024 lonely-PSU warnings per variable (same options and design as ms-survey-inputs L111-128)
op <- options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE)
w24 <- ms_enpg_all[ms_enpg_all$year == 2024L, ]
des <- survey::svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, data = w24, nest = TRUE)
cnt <- c(current = 0L, gpd_survey = 0L, hed = 0L)
for (s in c("male", "female")) for (a in 1:4) {
  cl <- des[w24$in_domain & w24$sex == s & w24$age_group == a, ]
  cur <- !is.na(cl$variables$current) & cl$variables$current == 1
  for (v in names(cnt)) {
    part <- if (v == "current") cl else cl[cur, ]
    withCallingHandlers(survey::svymean(stats::reformulate(v), part, na.rm = TRUE), warning = function(w) {
      if (grepl("has only one PSU at stage 1", conditionMessage(w), fixed = TRUE)) { cnt[v] <<- cnt[v] + 1L; invokeRestart("muffleWarning") } })
  }
}
options(op); print(cnt); cat("total", sum(cnt), "\n")
message(sprintf("verify_prev2.R elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0_v2, units = "mins"))))
