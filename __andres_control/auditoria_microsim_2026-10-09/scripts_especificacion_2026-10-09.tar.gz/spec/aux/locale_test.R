# Locale test: status rule (ms-survey-inputs L69-71) and DEIS "AÑO" selection (ms-demography-inputs L62)
# in a session started under LC_ALL=C vs C.UTF-8. Prints aggregates only.
.t0 <- Sys.time()
cat("locale:", Sys.getlocale("LC_CTYPE"), "\n")
setwd("<repo>"); source("_tools/acc_data.R")
r <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))
cells <- "<scratch>/spec/base_cells/"
src <- readLines(paste0(cells, "ms-survey-inputs.R"))
env <- new.env(); env$ms_ever <- as.character(r$oh1); env$ms_recency <- as.character(r$oh2); env$ms_enpg_all <- data.frame(i = seq_len(nrow(r)))
eval(parse(text = paste(src[69:71], collapse = "\n")), env)
tb <- table(env$ms_enpg_all$status, useNA = "ifany")
cat("status (cell L69-71 parsed here):", paste(names(tb), tb, collapse = " | "), "\n")
src62 <- readLines(paste0(cells, "ms-demography-inputs.R"))[62]
res <- tryCatch({x <- acc_deis(); y <- eval(parse(text = sub("^\\.ms_new <- ", "", src62)))
  paste("AÑO selection OK, cols:", ncol(y))}, error = function(err) paste("AÑO selection ERROR:", conditionMessage(err)))
cat(res, "\n")
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
