#| label: ms-historical-validation
.t0 <- Sys.time()
ms_validation_runs <- base::lapply(ms_cfg$seeds, function(seed)
  ms_simulate(ms_calibrated, 2012:2024, ms_cfg$n_sim, seed, ms_cfg$rho))
ms_reference_run <- ms_simulate(ms_uncalibrated, 2012:2024, ms_cfg$n_sim, ms_cfg$seeds[1], ms_cfg$rho)
ms_validation_summary <- dplyr::bind_rows(base::lapply(ms_validation_runs, `[[`, "summary"))
ms_validation_deaths <- dplyr::bind_rows(base::lapply(ms_validation_runs, `[[`, "deaths"))
ms_sim_mean <- ms_validation_summary |>
  dplyr::group_by(year, sex, age_group) |>
  dplyr::summarise(current_mc_sd = stats::sd(current_mean),
    gpd_mc_sd = stats::sd(gpd_mean), hed_mc_sd = stats::sd(hed_mean),
    current_mean = base::mean(current_mean), gpd_mean = base::mean(gpd_mean),
    hed_mean = base::mean(hed_mean), .groups = "drop")
ms_compare <- dplyr::inner_join(ms_targets, ms_sim_mean,
  by = base::c("year", "sex", "age_group"), suffix = base::c("_observed", "_simulated"))
base::stopifnot(base::nrow(ms_compare) == 56L)
base::stopifnot(base::all(base::is.finite(base::as.matrix(ms_sim_mean[base::c("current_mc_sd", "gpd_mc_sd", "hed_mc_sd")]))))
ms_compare$period <- base::ifelse(ms_compare$year <= ms_cfg$train_end, "Training 2012-2020", "Held out 2022/2024")
ms_error_rows <- base::lapply(base::c("current", "gpd", "hed"), function(metric) {
  base::data.frame(year = ms_compare$year, sex = ms_compare$sex, age_group = ms_compare$age_group,
    period = ms_compare$period, metric = metric,
    observed = ms_compare[[base::paste0(metric, "_mean_observed")]],
    simulated = ms_compare[[base::paste0(metric, "_mean_simulated")]],
    se = ms_compare[[base::paste0(metric, "_se")]],
    mc_sd = ms_compare[[base::paste0(metric, "_mc_sd")]],
    design_status = ms_compare$design_status)
})
ms_comparison <- dplyr::bind_rows(ms_error_rows) |>
  dplyr::mutate(error = simulated - observed, standardized_error = error / se,
    in_working_interval = base::ifelse(year == 2020L, NA,
      base::abs(error) <= stats::qnorm(0.975) * se))
ms_performance <- ms_comparison |>
  dplyr::group_by(period, metric) |>
  dplyr::summarise(cells = dplyr::n(), bias = base::mean(error),
    rmse = base::sqrt(base::mean(error^2)), mae = base::mean(base::abs(error)),
    mean_squared_standardized_error = base::mean(standardized_error^2),
    working_interval_coverage = base::mean(in_working_interval, na.rm = TRUE),
    mean_monte_carlo_sd = base::mean(mc_sd), .groups = "drop")
ms_table(ms_performance, "Predictive performance; probabilities in 0-1 units, intensity in g/day")
# A static-2012 comparator uses the same first seed. Improvement is a result, never an assertion.
ms_reference_compare <- dplyr::inner_join(ms_targets, ms_reference_run$summary,
  by = base::c("year", "sex", "age_group"), suffix = base::c("_observed", "_simulated"))
ms_reference_performance <- base::do.call(base::rbind, base::lapply(base::c("current", "gpd", "hed"), function(m) {
  h <- ms_reference_compare$year > ms_cfg$train_end
  base::data.frame(metric = m, static_2012_holdout_rmse = base::sqrt(base::mean((
    ms_reference_compare[[base::paste0(m, "_mean_simulated")]][h] -
    ms_reference_compare[[base::paste0(m, "_mean_observed")]][h])^2)))
}))
ms_table(ms_reference_performance, "Static-2012 comparator: same first seed, no holdout tuning")
base::message(base::sprintf("ms-historical-validation elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
