#| label: ms-setup
#| results: "hold"
.t0 <- Sys.time()
ms_packages <- base::c("here", "haven", "survey", "dplyr", "readxl", "arrow", "knitr", "IRdisplay", "ggplot2")
ms_missing <- ms_packages[!base::vapply(ms_packages, base::requireNamespace, base::logical(1), quietly = TRUE)]
if (base::length(ms_missing)) base::stop("Missing packages: ", base::paste(ms_missing, collapse = ", "))
base::suppressMessages(here::i_am("__andres_control/microsim_base_ACC_2012_2024.ipynb"))
source(here::here("_tools", "acc_data.R"))
ms_cfg <- base::list(start_year = 2012L, train_end = 2020L, observed_end = 2024L, end_year = 2034L,
  min_age = 15L, max_age = 65L, n_sim = 25000L, seeds = 20260917L + 0:4, rho = 0.8,
  export = TRUE, output_dir = "__andres_control/microsim_base_outputs")
base::stopifnot(ms_cfg$min_age == 15L, ms_cfg$max_age == 65L, ms_cfg$start_year == 2012L,
  ms_cfg$train_end == 2020L, ms_cfg$observed_end == 2024L, ms_cfg$end_year == 2034L,
  base::length(ms_cfg$seeds) >= 2L)
ms_table <- function(x, caption = NULL) {
  IRdisplay::display_html(base::as.character(knitr::kable(x, format = "html", digits = 4,
    row.names = FALSE, caption = caption)))
}
base::message(base::sprintf("ms-setup elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
