#| label: ms-fit-and-check
.t0 <- Sys.time()
ms_uncalibrated <- ms_fit(ms_cfg$train_end, trend = FALSE)
ms_calibrated <- ms_fit(ms_cfg$train_end, trend = TRUE)
base::stopifnot(base::max(ms_calibrated$training_years) == 2020L,
                  !base::any(base::c(2022L, 2024L) %in% ms_calibrated$training_years))
ms_smoke <- ms_simulate(ms_calibrated, 2012:2014, 1500L, 731L, rho = 0.8)
ms_smoke_again <- ms_simulate(ms_calibrated, 2012:2014, 1500L, 731L, rho = 0.8)
ms_smoke_rho0 <- ms_simulate(ms_calibrated, 2012:2014, 1500L, 731L, rho = 0)
base::stopifnot(base::identical(ms_smoke, ms_smoke_again),
  base::identical(ms_smoke$deaths, ms_smoke_rho0$deaths),
  base::setequal(ms_smoke$summary$year, 2012:2014),
  base::all(ms_smoke$flows$end == ms_smoke$flows$start - ms_smoke$flows$deaths -
    ms_smoke$flows$age_exits - ms_smoke$flows$residual_outflow +
    ms_smoke$flows$age_entries + ms_smoke$flows$residual_inflow))
ms_history_check <- ms_smoke$histories |>
  dplyr::group_by(id) |>
  dplyr::arrange(year, .by_group = TRUE) |>
  dplyr::summarise(age_step_ok = base::all(base::diff(age) == base::diff(year)),
    ever_monotone = base::all(base::diff(base::as.integer(ever)) >= 0), .groups = "drop")
base::stopifnot(base::all(ms_history_check$age_step_ok & ms_history_check$ever_monotone),
  base::all(base::abs(ms_smoke$summary$never + ms_smoke$summary$former + ms_smoke$summary$current_mean - 1) < 1e-12),
  base::all(base::abs(ms_smoke$summary$cat1 + ms_smoke$summary$cat2 + ms_smoke$summary$cat3 - ms_smoke$summary$current_mean) < 1e-12))
# A real no-leakage test: alter every held-out exposure outcome and every held-out DEIS count.
# Restore the in-memory input tables even if the test fails; no source file is written.
ms_check_no_leakage <- function() {
  original_enpg <- ms_enpg
  original_targets <- ms_targets
  original_deaths <- ms_mortality
  base::on.exit({ms_enpg <<- original_enpg; ms_targets <<- original_targets;
                 ms_mortality <<- original_deaths}, add = TRUE)
  hold <- ms_enpg$year > ms_cfg$train_end
  ms_enpg$current[hold] <<- 0
  ms_enpg$gpd_survey[hold] <<- 999
  ms_enpg$hed[hold] <<- 1
  ms_targets$current_mean[ms_targets$year > ms_cfg$train_end] <<- 0.999
  ms_targets$gpd_mean[ms_targets$year > ms_cfg$train_end] <<- 999
  ms_mortality$deaths[ms_mortality$year > ms_cfg$train_end] <<- 999999
  changed <- ms_fit(ms_cfg$train_end, trend = TRUE)
  base::stopifnot(base::identical(stats::coef(changed$prevalence), stats::coef(ms_calibrated$prevalence)),
    base::identical(stats::coef(changed$amount), stats::coef(ms_calibrated$amount)),
    base::identical(stats::coef(changed$hed), stats::coef(ms_calibrated$hed)),
    base::identical(changed$shape, ms_calibrated$shape),
    base::identical(changed$mortality_scale, ms_calibrated$mortality_scale))
  TRUE
}
base::stopifnot(ms_check_no_leakage())
ms_table(base::data.frame(check = base::c("Repeatability", "Annual stock identity", "Valid exposure/probabilities",
  "Held-out outcome perturbation"), result = "PASS"), "Runnable engineering checks")
ms_table(base::data.frame(sex = base::names(ms_calibrated$mortality_scale),
  hazard_multiplier = base::unname(ms_calibrated$mortality_scale)), "Mortality calibration using 2012-2020 only")
base::message(base::sprintf("ms-fit-and-check elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
