#| label: ms-calibration-functions
.t0 <- Sys.time()

# These functions calibrate marginal exposure distributions, not observed person transitions.
# Keeping calibration deterministic avoids fitting to noise from a finite microsimulation.
ms_fit <- function(last_year, trend = TRUE) {
  train <- ms_enpg[ms_enpg$year <= last_year, ]
  target <- ms_targets[ms_targets$year <= last_year, ]
  target$cell <- base::factor(base::paste(target$sex, target$age_group, sep = ":"))
  target$time <- (target$year - ms_cfg$start_year) / 10
  base::stopifnot(base::all(target$current_mean > 0 & target$current_mean < 1),
                  base::all(target$gpd_mean > 0))
  # Delta-method inverse variances are working calibration weights, not a full joint likelihood.
  target$y_current <- stats::qlogis(target$current_mean)
  target$y_amount <- base::log(target$gpd_mean)
  target$w_current <- (target$current_mean * (1 - target$current_mean) / target$current_se)^2
  target$w_amount <- (target$gpd_mean / target$gpd_se)^2
  base::stopifnot(base::all(base::is.finite(target$w_current) & target$w_current > 0),
                  base::all(base::is.finite(target$w_amount) & target$w_amount > 0))
  # An uncalibrated comparator holds the 2012 survey means constant within each cell.
  fit_data <- if (trend) target else target[target$year == ms_cfg$start_year, ]
  formula_current <- if (trend) y_current ~ 0 + cell + cell:time else y_current ~ 0 + cell
  formula_amount <- if (trend) y_amount ~ 0 + cell + cell:time else y_amount ~ 0 + cell
  prevalence <- stats::lm(formula_current, data = fit_data, weights = w_current)
  amount <- stats::lm(formula_amount, data = fit_data, weights = w_amount)

  # The Gamma shape reuses the project's survey-weighted moment estimator, now on RAW g/day.
  shape <- train |>
    dplyr::filter(current == 1, base::is.finite(gpd_survey), gpd_survey > 0) |>
    dplyr::group_by(sex, age_group) |>
    dplyr::summarise(mu = stats::weighted.mean(gpd_survey, weight),
      variance = stats::weighted.mean((gpd_survey - mu)^2, weight),
      shape = mu^2 / variance, .groups = "drop")
  zero <- train |>
    dplyr::filter(current == 1, base::is.finite(gpd_survey)) |>
    dplyr::group_by(sex, age_group) |>
    dplyr::summarise(p_zero = stats::weighted.mean(gpd_survey == 0, weight), .groups = "drop")
  former <- train |>
    dplyr::filter(current == 0, !base::is.na(ever)) |>
    dplyr::group_by(sex, age_group) |>
    dplyr::summarise(p_ever_noncurrent = stats::weighted.mean(ever, weight), .groups = "drop")
  shape <- shape |>
    dplyr::left_join(zero, by = base::c("sex", "age_group")) |>
    dplyr::left_join(former, by = base::c("sex", "age_group"))
  base::stopifnot(base::nrow(shape) == 8L, base::all(base::is.finite(shape$shape)),
                  base::all(shape$shape > 0), base::all(shape$p_zero < 1))

  # HED is conditional on current drinking and intensity; questionnaire harmonization remains a caveat.
  hed_data <- train[train$current %in% 1 & base::is.finite(train$gpd_survey) &
                     train$gpd_survey > 0 & !base::is.na(train$hed), ]
  hed_data$cell <- base::factor(base::paste(hed_data$sex, hed_data$age_group, sep = ":"))
  hed_data$w_fit <- hed_data$weight / base::mean(hed_data$weight)
  hed <- stats::glm(hed ~ 0 + cell + base::log1p(gpd_survey), data = hed_data,
                    weights = w_fit, family = stats::quasibinomial())
  base::stopifnot(hed$converged, !base::anyNA(stats::coef(hed)))

  # Calibrate one all-cause hazard multiplier per sex using TRAINING deaths only.
  death_train <- ms_mortality[ms_mortality$year <= last_year, ]
  mortality_scale <- base::vapply(base::c("female", "male"), function(s) {
    d <- death_train[death_train$sex == s, ]
    f <- function(log_scale) base::sum(d$pop_jan *
      (-base::expm1(base::log1p(-d$qx) * base::exp(log_scale)))) - base::sum(d$deaths)
    if (!trend) base::return(1)
    base::exp(stats::uniroot(f, interval = base::c(-3, 3))$root)
  }, base::numeric(1))
  base::list(prevalence = prevalence, amount = amount, shape = shape, hed = hed,
    mortality_scale = mortality_scale, last_year = last_year, trend = trend,
    training_years = base::sort(base::unique(train$year)))
}

ms_drivers <- function(model, years) {
  grid <- base::expand.grid(year = years, sex = base::c("female", "male"), age_group = 1:4,
                           stringsAsFactors = FALSE)
  grid$cell <- base::factor(base::paste(grid$sex, grid$age_group, sep = ":"),
                           levels = model$prevalence$xlevels$cell)
  # ponytail: freeze drivers after 2024; add a forecast process only with defensible future assumptions.
  # Validation extrapolates 2020-trained trends to 2024.
  grid$time <- (base::pmin(grid$year, ms_cfg$observed_end) - ms_cfg$start_year) / 10
  grid$p_current <- stats::plogis(stats::predict(model$prevalence, newdata = grid))
  grid$mu_current <- base::exp(stats::predict(model$amount, newdata = grid))
  grid <- dplyr::left_join(grid, model$shape, by = base::c("sex", "age_group"))
  grid$hed_intercept <- stats::coef(model$hed)[base::paste0("cell", base::as.character(grid$cell))]
  grid$hed_slope <- base::unname(stats::coef(model$hed)["base::log1p(gpd_survey)"])
  base::stopifnot(!base::anyNA(grid), base::all(grid$p_current > 0 & grid$p_current < 1),
                  base::all(grid$mu_current > 0))
  grid$key <- base::paste(grid$year, grid$sex, grid$age_group, sep = ":")
  grid
}
base::message(base::sprintf("ms-calibration-functions elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
