#| label: ms-export-parameters-and-audits
.t0 <- Sys.time()
ms_coefficients <- function(model, fit_name) {
  dplyr::bind_rows(base::lapply(base::c("prevalence", "amount", "hed"), function(component) {
    values <- stats::coef(model[[component]])
    base::data.frame(fit = fit_name, component = component, parameter = base::names(values),
      value = base::unname(values), source = "ENPG survey-weighted working calibration",
      last_fit_year = model$last_year)
  }), base::data.frame(fit = fit_name, component = "all_cause_mortality",
    parameter = base::names(model$mortality_scale), value = base::unname(model$mortality_scale),
    source = "HMD qx and DEIS training deaths", last_fit_year = model$last_year))
}
ms_parameters <- dplyr::bind_rows(ms_coefficients(ms_calibrated, "validation_train2020"),
  ms_coefficients(ms_full_model, "full_refit2024"))
ms_structural_parameters <- base::data.frame(parameter = base::c("rho", "minimum_age", "maximum_age", "n_sim",
  "replicates", "grams_per_drink", "forecast_driver_reference_year"),
  value = base::c(ms_cfg$rho, 15, 65, ms_cfg$n_sim, base::length(ms_cfg$seeds), 12, 2024),
  interpretation = base::c("Unidentified persistence; sensitivity 0 and 0.95",
    "Entry at age 15", "Exit at age 66; older-age benefits excluded", "Synthetic population scale",
    "Monte Carlo repeats, not parameter uncertainty", "Inherited survey measurement convention",
    "Exposure driver and HMD qx held at 2024 for 2025-2034"))
ms_table(ms_structural_parameters, "Structural assumptions to discuss with coauthors")
ms_all_sources <- base::unique(base::c(ms_exposure_files, ms_demography_files,
  "__andres_control/plan_trabajo_post_reunion_ACC_2026-09-17.md"))
ms_provenance <- base::data.frame(file = ms_all_sources,
  md5 = base::unname(tools::md5sum(ms_path(ms_all_sources))))
# SIMAH is cited by DOI (not vendored): its own row, without a file hash.
ms_provenance <- base::rbind(ms_provenance, base::data.frame(
  file = "SIMAH release 0.1.1, doi:10.5281/zenodo.15641639", md5 = NA_character_))
if (ms_cfg$export) {
  base::dir.create(here::here(ms_cfg$output_dir), recursive = TRUE, showWarnings = FALSE)
  ms_exports <- base::list(observed_targets = ms_targets, validation_metrics = ms_performance,
    validation_comparison = ms_comparison, mortality_concordance = ms_mortality_comparison,
    model_parameters = ms_parameters, structural_parameters = ms_structural_parameters,
    gamma_parameters_train2020 = ms_calibrated$shape, gamma_parameters_refit2024 = ms_full_model$shape,
    demographic_accounting = ms_full_run$flows, projection = ms_projection,
    projection_mortality = ms_full_run$deaths, static_comparator_metrics = ms_reference_performance,
    historical_refit_comparison = ms_refit_comparison, historical_refit_metrics = ms_refit_metrics,
    persistence_sensitivity = ms_sensitivity, input_provenance = ms_provenance, data_audit = ms_data_audit)
  for (name in base::names(ms_exports))
    utils::write.csv(ms_exports[[name]], here::here(ms_cfg$output_dir, base::paste0(name, ".csv")),
      row.names = FALSE, fileEncoding = "UTF-8")
  ggplot2::ggsave(here::here(ms_cfg$output_dir, "prevalence_validation.png"), ms_fig_prevalence,
    width = 9, height = 8, dpi = 160)
  ggplot2::ggsave(here::here(ms_cfg$output_dir, "intensity_validation.png"), ms_fig_intensity,
    width = 9, height = 8, dpi = 160)
  base::cat("Aggregate outputs saved to ", ms_cfg$output_dir, ". No survey microdata exported.\n", sep = "")
}
base::print(utils::sessionInfo())
base::message(base::sprintf("ms-export-parameters-and-audits elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
