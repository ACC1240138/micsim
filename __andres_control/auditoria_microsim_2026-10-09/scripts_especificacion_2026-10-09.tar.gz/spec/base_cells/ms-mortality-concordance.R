#| label: ms-mortality-concordance
.t0 <- Sys.time()
ms_mortality_comparison <- ms_validation_deaths |>
  dplyr::group_by(year, sex, seed) |>
  dplyr::summarise(simulated_deaths = base::sum(deaths), expected_deaths = base::sum(expected_deaths),
    .groups = "drop") |>
  dplyr::group_by(year, sex) |>
  dplyr::summarise(mc_sd = stats::sd(simulated_deaths),
    simulated_deaths = base::mean(simulated_deaths),
    expected_deaths = base::mean(expected_deaths), .groups = "drop") |>
  dplyr::left_join(ms_mortality |>
    dplyr::group_by(year, sex) |>
    dplyr::summarise(observed_deaths = base::sum(deaths),
      hmd_mx_expected = base::sum(mx * pop_mid), .groups = "drop"), by = base::c("year", "sex")) |>
  dplyr::mutate(expected_relative_error = expected_deaths / observed_deaths - 1,
    period = base::ifelse(year <= ms_cfg$train_end, "Training", "Temporal comparison"))
ms_table(ms_mortality_comparison, "DEIS concordance; expected and realized deaths kept separate")
base::stopifnot(base::all(base::is.finite(ms_mortality_comparison$mc_sd)))
# Verify random deaths are consistent with their conditional expectation, allowing Monte Carlo variation.
ms_mortality_mc <- ms_validation_deaths |>
  dplyr::group_by(seed) |>
  dplyr::summarise(realized = base::sum(deaths), expected = base::sum(expected_deaths),
    conditional_sd = base::sqrt(base::sum(mc_variance)), .groups = "drop") |>
  dplyr::mutate(z_mc = (realized - expected) / conditional_sd)
ms_table(ms_mortality_mc, "Monte Carlo death diagnostic; not a test of epidemiological validity")
base::message(base::sprintf("ms-mortality-concordance elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
