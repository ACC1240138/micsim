# Dossier: latent propensity (Gaussian copula AR(1)) and former/never history, BASE spec.
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
# Writes ONLY aggregates (cell tables, simulated summaries) to spec/out_latente/. Row-level ENPG objects stay in memory.
.t0 <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "out_latente"); dir.create(OUT, showWarnings = FALSE)
wcsv <- function(x, f) utils::write.csv(x, file.path(OUT, f), row.names = FALSE)
YEARS <- 2012:2024
m <- ms_fit(ms_cfg$train_end, trend = TRUE)
stopifnot(max(m$training_years) == 2020L, isTRUE(all.equal(unname(round(m$mortality_scale, 4)), c(0.9699, 0.9524))))

## 1. p_ever_noncurrent: pooled estimate (as in ms_fit) and per-wave decomposition ---------------------------
nc <- ms_enpg[ms_enpg$current %in% 0 & !is.na(ms_enpg$ever), ]
per_wave <- nc |> dplyr::group_by(year, sex, age_group) |>
  dplyr::summarise(p_wave = stats::weighted.mean(ever, weight), W = sum(weight), n = dplyr::n(), .groups = "drop")
pooled <- per_wave |> dplyr::filter(year <= ms_cfg$train_end) |> dplyr::group_by(sex, age_group) |>
  dplyr::mutate(pi_w = W / sum(W)) |> dplyr::ungroup()
chk <- pooled |> dplyr::group_by(sex, age_group) |> dplyr::summarise(p_pooled = sum(pi_w * p_wave), n_train = sum(n), .groups = "drop")
code_p <- as.data.frame(m$shape[c("sex", "age_group", "p_ever_noncurrent")])
chk <- dplyr::left_join(chk, code_p, by = c("sex", "age_group"))
stopifnot(max(abs(chk$p_pooled - chk$p_ever_noncurrent)) < 1e-12)  # decomposition reproduces ms_fit exactly
wcsv(chk, "p_ever_noncurrent_pooled.csv")
wcsv(dplyr::left_join(per_wave, pooled[c("year", "sex", "age_group", "pi_w")], by = c("year", "sex", "age_group")),
  "p_ever_noncurrent_by_wave.csv")
# Single-age contrast for entrants (age 15) vs the 15-29 group value used for them
age15 <- nc[nc$year <= ms_cfg$train_end & nc$age %in% 15:17, ] |> dplyr::group_by(sex, age) |>
  dplyr::summarise(p_ever_noncurrent = stats::weighted.mean(ever, weight), n = dplyr::n(), .groups = "drop")
wcsv(age15, "p_ever_noncurrent_age15_17_train.csv")

## 2. Observed never/former shares (design-based SE, design as in ms_build_targets) ------------------------
obs_share <- function(by_age) {
  op <- options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE); on.exit(options(op))
  do.call(rbind, lapply(seq(2012L, 2024L, 2L), function(y) {
    w <- ms_enpg_all[ms_enpg_all$year == y, ]
    w$never_i <- as.numeric(w$status == "never"); w$former_i <- as.numeric(w$status == "former")
    w$current_i <- as.numeric(w$status == "current")
    des <- if (y == 2020L) survey::svydesign(ids = ~1, weights = ~weight, data = w) else
      survey::svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, data = w, nest = TRUE)
    grid <- expand.grid(sex = c("female", "male", "both"), age_group = if (by_age) 1:4 else 0L, stringsAsFactors = FALSE)
    do.call(rbind, lapply(seq_len(nrow(grid)), function(i) {
      sel <- w$in_domain & w$status != "unknown" & (grid$sex[i] == "both" | w$sex == grid$sex[i]) &
        (grid$age_group[i] == 0L | w$age_group == grid$age_group[i])
      e <- suppressWarnings(survey::svymean(~never_i + former_i + current_i, des[sel, ]))
      data.frame(year = y, sex = grid$sex[i], age_group = grid$age_group[i], n = sum(sel),
        never = unname(coef(e)[1]), never_se = unname(survey::SE(e)[1]),
        former = unname(coef(e)[2]), former_se = unname(survey::SE(e)[2]),
        current = unname(coef(e)[3]), unknown_excluded = sum(w$in_domain & w$status == "unknown" &
          (grid$sex[i] == "both" | w$sex == grid$sex[i]) & (grid$age_group[i] == 0L | w$age_group == grid$age_group[i])),
        period = if (y <= ms_cfg$train_end) "train" else "held-out")
    }))
  }))
}
obs_ys <- obs_share(FALSE); obs_ysa <- obs_share(TRUE)
wcsv(obs_ys, "observed_never_former_year_sex.csv"); wcsv(obs_ysa, "observed_never_former_year_sex_age.csv")

## 3. Variants of ms_exposure (only lines 30-33 of ms-annual-engine change) ---------------------------------
# All variants consume the same stats::runif(sum(fresh)) draws, so RNG streams stay aligned (common random numbers):
# population, z paths, deaths, stock reconciliation and current status are identical across variants.
ms_exposure_v0 <- ms_exposure
rec <- new.env()
make_exposure <- function(variant) function(pop, year, drivers) {
  pop$age_group <- ms_age_group(pop$age)
  k <- base::match(base::paste(year, pop$sex, pop$age_group, sep = ":"), drivers$key)
  base::stopifnot(!base::anyNA(k))
  d <- drivers[k, ]
  pop$current <- stats::pnorm(pop$z_current) < d$p_current
  u <- stats::pnorm(pop$z_amount)
  positive <- pop$current & u > d$p_zero
  pop$gpd_survey <- 0
  pop$gpd_survey[positive] <- stats::qgamma(
    base::pmin(1 - 1e-12, base::pmax(1e-12, (u[positive] - d$p_zero[positive]) / (1 - d$p_zero[positive]))),
    shape = d$shape[positive], scale = d$mu_current[positive] / ((1 - d$p_zero[positive]) * d$shape[positive]))
  p_hed <- stats::plogis(d$hed_intercept + d$hed_slope * base::log1p(pop$gpd_survey))
  pop$hed <- positive & stats::pnorm(pop$z_hed) < p_hed
  prev_ever <- pop$ever
  fresh <- base::is.na(pop$ever)
  r <- stats::runif(base::sum(fresh))
  u_hist <- (stats::pnorm(pop$z_current) - d$p_current) / (1 - d$p_current)  # user's rescaling; meaningful if !current
  if (variant == "V0") {
    pop$ever[fresh] <- pop$current[fresh] | r < d$p_ever_noncurrent[fresh]
  } else if (variant == "V1") {
    pop$ever[fresh] <- pop$current[fresh] | u_hist[fresh] <= d$p_ever_noncurrent[fresh]
  } else if (variant == "V2") {
    elig <- !pop$current & (fresh | !pop$ever)          # ever_{t-1} == 0 (fresh treated as 0)
    pop$ever[fresh] <- FALSE
    pop$ever[elig] <- u_hist[elig] <= d$p_ever_noncurrent[elig]
  } else stop("unknown variant")
  pop$ever <- pop$ever | pop$current
  pop$alc_status <- base::ifelse(pop$current, "current", base::ifelse(pop$ever, "former", "never"))
  low <- base::ifelse(pop$sex == "female", 20, 40); high <- base::ifelse(pop$sex == "female", 40, 60)
  pop$alc_cat <- base::ifelse(!pop$current, "noncurrent", base::ifelse(pop$gpd_survey < low,
    "cat1", base::ifelse(pop$gpd_survey < high, "cat2", "cat3")))
  base::stopifnot(base::all(base::is.finite(pop$gpd_survey) & pop$gpd_survey >= 0),
                  !base::any(pop$hed & !pop$current), !base::any(pop$current & !pop$ever),
                  !base::any(!base::is.na(prev_ever) & prev_ever & !pop$ever))  # ever is absorbing
  rec$x[[length(rec$x) + 1L]] <- data.frame(year = year, id = pop$id, sex = pop$sex, age_group = pop$age_group,
    z_current = pop$z_current, z_amount = pop$z_amount, z_hed = pop$z_hed, current = pop$current,
    ever = pop$ever, status = pop$alc_status, fresh = fresh, u_hist = u_hist,
    p_current = d$p_current, p_former = d$p_ever_noncurrent)
  pop
}
# Regression: the V0 rewrite must reproduce the verbatim engine bit for bit (hook aside).
ms_exposure <- ms_exposure_v0
ref <- ms_simulate(m, 2012:2014, 2000L, 731L, rho = ms_cfg$rho)
ms_exposure <- make_exposure("V0"); rec$x <- list()
v0chk <- ms_simulate(m, 2012:2014, 2000L, 731L, rho = ms_cfg$rho)
stopifnot(identical(ref$summary, v0chk$summary), identical(ref$deaths, v0chk$deaths), identical(ref$flows, v0chk$flows))

runs <- list(); recs <- list()
for (v in c("V0", "V1", "V2")) for (s in ms_cfg$seeds) {
  ms_exposure <- make_exposure(v); rec$x <- list()
  r <- ms_simulate(m, YEARS, ms_cfg$n_sim, s, rho = ms_cfg$rho)
  x <- dplyr::bind_rows(rec$x)
  runs[[paste(v, s)]] <- list(variant = v, seed = s, run = r)
  recs[[paste(v, s)]] <- x
  message(sprintf("%s seed %d done, %.2f min", v, s, as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
}
# CRN check: current status and population identical across variants for each seed
for (s in ms_cfg$seeds) {
  a <- runs[[paste("V0", s)]]$run; b <- runs[[paste("V2", s)]]$run; c1 <- runs[[paste("V1", s)]]$run
  stopifnot(identical(a$flows, b$flows), identical(a$flows, c1$flows), identical(a$deaths, b$deaths),
            identical(a$summary$current_mean, b$summary$current_mean))
}

## 4. Simulated never/former shares --------------------------------------------------------------------------
sim <- dplyr::bind_rows(lapply(runs, function(z) dplyr::mutate(z$run$summary, variant = z$variant)))
sim_ys_seed <- dplyr::bind_rows(
  sim |> dplyr::group_by(variant, seed, year, sex) |>
    dplyr::summarise(never = stats::weighted.mean(never, n), former = stats::weighted.mean(former, n),
      current = stats::weighted.mean(current_mean, n), .groups = "drop"),
  sim |> dplyr::group_by(variant, seed, year) |>
    dplyr::summarise(never = stats::weighted.mean(never, n), former = stats::weighted.mean(former, n),
      current = stats::weighted.mean(current_mean, n), .groups = "drop") |> dplyr::mutate(sex = "both"))
sim_ys <- sim_ys_seed |> dplyr::group_by(variant, year, sex) |>
  dplyr::summarise(never_sim = mean(never), never_mcsd = sd(never), former_sim = mean(former),
    former_mcsd = sd(former), current_sim = mean(current), .groups = "drop")
cmp_ys <- dplyr::left_join(sim_ys, obs_ys[c("year", "sex", "never", "never_se", "former", "former_se", "current", "period")],
  by = c("year", "sex"))
wcsv(cmp_ys, "sim_vs_obs_never_former_year_sex.csv")
sim_ysa <- sim |> dplyr::group_by(variant, year, sex, age_group) |>
  dplyr::summarise(never_sim = mean(never), never_mcsd = sd(never), former_sim = mean(former),
    former_mcsd = sd(former), current_sim = mean(current_mean), .groups = "drop")
cmp_ysa <- dplyr::left_join(sim_ysa, obs_ysa[c("year", "sex", "age_group", "never", "never_se", "former", "former_se", "current", "period")],
  by = c("year", "sex", "age_group"))
wcsv(cmp_ysa, "sim_vs_obs_never_former_year_sex_age.csv")
perf <- cmp_ysa |> dplyr::filter(year %in% seq(2012, 2024, 2)) |> dplyr::group_by(variant, period) |>
  dplyr::summarise(cells = dplyr::n(), never_bias = mean(never_sim - never), never_mae = mean(abs(never_sim - never)),
    former_bias = mean(former_sim - former), former_mae = mean(abs(former_sim - former)),
    never_within_2se = mean(abs(never_sim - never) <= 2 * never_se), .groups = "drop")
wcsv(perf, "performance_never_former_by_period.csv")

## 5. Person-level transitions, latent checks (from hook records) ---------------------------------------------
flows_all <- list(); lagc <- list(); mom <- list(); uh <- list(); sw <- list()
for (nm in names(recs)) {
  x <- recs[[nm]]; v <- runs[[nm]]$variant; s <- runs[[nm]]$seed
  stopifnot(!anyDuplicated(x[c("year", "id")]))
  for (t in YEARS[-length(YEARS)]) {
    a <- x[x$year == t, ]; b <- x[x$year == t + 1L, ]
    j <- match(a$id, b$id); keep <- !is.na(j)
    tr <- data.frame(sex = a$sex[keep], age_group = a$age_group[keep], from = a$status[keep], to = b$status[j[keep]])
    f <- as.data.frame(table(sex = tr$sex, age_group = tr$age_group, from = tr$from, to = tr$to), stringsAsFactors = FALSE)
    flows_all[[length(flows_all) + 1L]] <- dplyr::mutate(f, year = t, variant = v, seed = s)
    # expected annual switching of current status under the copula (person-level p_t, p_{t+1})
    if (v == "V0") {
      pp <- data.frame(p0 = a$p_current[keep], p1 = b$p_current[j[keep]], c0 = a$current[keep], c1 = b$current[j[keep]])
      up <- unique(pp[c("p0", "p1")])
      up$both <- vapply(seq_len(nrow(up)), function(i) as.numeric(mvtnorm::pmvnorm(upper = qnorm(c(up$p0[i], up$p1[i])),
        corr = matrix(c(1, ms_cfg$rho, ms_cfg$rho, 1), 2))), numeric(1))
      pp <- dplyr::left_join(pp, up, by = c("p0", "p1"))
      sw[[length(sw) + 1L]] <- data.frame(seed = s, year = t, n = nrow(pp), observed_switch = mean(pp$c0 != pp$c1),
        expected_switch = mean(pp$p0 + pp$p1 - 2 * pp$both))
    }
  }
  if (v == "V0") {
    for (kk in 1:12) for (zz in c("z_current", "z_amount", "z_hed")) {
      a <- x[x$year <= 2024 - kk, c("year", "id", zz)]; b <- x[x$year >= 2012 + kk, c("year", "id", zz)]
      b$year <- b$year - kk
      ab <- merge(a, b, by = c("year", "id"))
      lagc[[length(lagc) + 1L]] <- data.frame(seed = s, latent = zz, lag = kk, pairs = nrow(ab),
        corr = stats::cor(ab[[2 + 1]], ab[[2 + 2]]), theory = ms_cfg$rho^kk)
    }
    mom[[length(mom) + 1L]] <- x |> dplyr::group_by(year) |>
      dplyr::summarise(n = dplyr::n(), mean_zc = mean(z_current), var_zc = var(z_current), var_za = var(z_amount),
        var_zh = var(z_hed), cor_zc_za = cor(z_current, z_amount), cor_zc_zh = cor(z_current, z_hed),
        ks_p_U = suppressWarnings(stats::ks.test(pnorm(z_current), "punif")$p.value),
        max_decile_dev = max(abs(tabulate(pmin(10L, 1L + floor(10 * pnorm(z_current))), 10) / dplyr::n() - 0.1)),
        .groups = "drop") |> dplyr::mutate(seed = s)
  }
  # U_hist among non-current: cross-sectional uniformity vs among last-year never (V2 drift diagnostic)
  nc_x <- x[!x$current, ]
  prev_never <- x |> dplyr::filter(status == "never") |> dplyr::transmute(year = year + 1L, id, was_never = TRUE)
  nc_x <- dplyr::left_join(nc_x, prev_never, by = c("year", "id"))
  uh[[length(uh) + 1L]] <- nc_x |> dplyr::group_by(year) |>
    dplyr::summarise(n_noncurrent = dplyr::n(), mean_uhist = mean(u_hist), share_uhist_le_pf = mean(u_hist <= p_former),
      mean_pf = mean(p_former), former_share_of_noncurrent = mean(ever),
      n_prev_never = sum(was_never %in% TRUE), mean_uhist_prev_never = mean(u_hist[was_never %in% TRUE]),
      share_le_pf_prev_never = mean(u_hist[was_never %in% TRUE] <= p_former[was_never %in% TRUE]),
      .groups = "drop") |> dplyr::mutate(variant = v, seed = s)
}
fl <- dplyr::bind_rows(flows_all)
fl_age <- fl |> dplyr::group_by(variant, sex, age_group, from, to) |> dplyr::summarise(Freq = sum(Freq), .groups = "drop") |>
  dplyr::group_by(variant, sex, age_group, from) |> dplyr::mutate(n_from = sum(Freq), rate = Freq / n_from) |> dplyr::ungroup() |>
  dplyr::filter(from == "never")
wcsv(fl_age, "flows_from_never_by_sex_agegroup_pooled_2012_2023.csv")
fl <- fl |> dplyr::group_by(variant, seed, year, sex, from, to) |> dplyr::summarise(Freq = sum(Freq), .groups = "drop")
fl_rates <- fl |> dplyr::group_by(variant, seed, year, sex, from) |> dplyr::mutate(n_from = sum(Freq)) |>
  dplyr::ungroup() |> dplyr::filter(from == "never") |>
  dplyr::group_by(variant, year, sex, to) |>
  dplyr::summarise(rate = mean(Freq / n_from), rate_mcsd = sd(Freq / n_from), n_from_mean = mean(n_from), .groups = "drop")
wcsv(fl_rates, "flows_from_never_by_year_sex.csv")
fl_tot <- fl |> dplyr::group_by(variant, from, to) |> dplyr::summarise(Freq = sum(Freq), .groups = "drop") |>
  dplyr::group_by(variant, from) |> dplyr::mutate(rate = Freq / sum(Freq)) |> dplyr::ungroup()
wcsv(fl_tot, "transition_matrix_2012_2023_pooled.csv")
lag_tab <- dplyr::bind_rows(lagc) |> dplyr::group_by(latent, lag, theory) |>
  dplyr::summarise(corr_mean = mean(corr), corr_min = min(corr), corr_max = max(corr), pairs = mean(pairs), .groups = "drop")
wcsv(lag_tab, "latent_lag_correlations.csv")
mom_tab <- dplyr::bind_rows(mom); wcsv(mom_tab, "latent_moments_by_year_seed.csv")
uh_tab <- dplyr::bind_rows(uh) |> dplyr::group_by(variant, year) |>
  dplyr::summarise(dplyr::across(c(n_noncurrent, mean_uhist, share_uhist_le_pf, mean_pf, former_share_of_noncurrent,
    n_prev_never, mean_uhist_prev_never, share_le_pf_prev_never), mean), .groups = "drop")
wcsv(uh_tab, "u_history_diagnostics.csv")
sw_tab <- dplyr::bind_rows(sw); wcsv(sw_tab, "switching_observed_vs_copula.csv")
flows_engine <- dplyr::bind_rows(lapply(runs[grep("^V0", names(runs))], function(z) z$run$flows))
wcsv(flows_engine, "engine_flows_V0.csv")
theory <- data.frame(lag = c(1, 3.671, 4.022, 5, 7.693, 10), rho_k = ms_cfg$rho^c(1, 3.671, 4.022, 5, 7.693, 10))
theory$switch_p045 <- NA
q <- qnorm(0.45); theory$switch_p045[1] <- 2 * (0.45 - as.numeric(mvtnorm::pmvnorm(upper = c(q, q),
  corr = matrix(c(1, 0.8, 0.8, 1), 2))))
wcsv(theory, "theory_rho_k.csv")

## 5b. First-year (2012) gap decomposition: E[never] = sum_cells n (1 - p_c)(1 - p_F) ---------------------------
s12 <- sim[sim$year == 2012L & sim$variant == "V1", ] |> dplyr::group_by(sex, age_group) |>
  dplyr::summarise(pc_sim = stats::weighted.mean(current_mean, n), never_sim = stats::weighted.mean(never, n), n = sum(n), .groups = "drop")
s12 <- s12 |> dplyr::left_join(code_p, by = c("sex", "age_group")) |>
  dplyr::left_join(per_wave[per_wave$year == 2012L, c("sex", "age_group", "p_wave")], by = c("sex", "age_group")) |>
  dplyr::left_join(obs_ysa[obs_ysa$year == 2012L, c("sex", "age_group", "current", "never")], by = c("sex", "age_group"))
decomp <- s12 |> dplyr::group_by(sex) |> dplyr::summarise(
  sim_never = stats::weighted.mean(never_sim, n),
  exp_simpc_pooledpF = stats::weighted.mean((1 - pc_sim) * (1 - p_ever_noncurrent), n),
  exp_simpc_2012pF = stats::weighted.mean((1 - pc_sim) * (1 - p_wave), n),
  exp_obspc_pooledpF = stats::weighted.mean((1 - current) * (1 - p_ever_noncurrent), n),
  exp_obspc_2012pF = stats::weighted.mean((1 - current) * (1 - p_wave), n),
  obs_never_simweights = stats::weighted.mean(never, n), .groups = "drop")
wcsv(decomp, "first_year_2012_never_decomposition.csv")

## 6. Console summary ---------------------------------------------------------------------------------------
options(width = 200)
print(chk); print(age15)
print(as.data.frame(cmp_ys[cmp_ys$sex == "both", ]), digits = 4)
print(perf, width = 200)
print(as.data.frame(lag_tab[lag_tab$lag %in% c(1, 2, 5, 10, 12), ]), digits = 4)
print(summary(mom_tab[c("mean_zc", "var_zc", "var_za", "var_zh", "cor_zc_za", "cor_zc_zh", "ks_p_U", "max_decile_dev")]))
print(as.data.frame(fl_tot), digits = 4); print(as.data.frame(fl_age), digits = 3); print(as.data.frame(decomp), digits = 4)
print(sw_tab |> dplyr::summarise(obs = sum(observed_switch * n) / sum(n), exp = sum(expected_switch * n) / sum(n)))
print(sum(flows_engine$status_changes) / sum(flows_engine$transition_n))
print(theory)
message(sprintf("dossier_latente_historia elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
