# Independent verification of spec/dossier_intensidad_hed_categorias.md (BASE spec, ms_fit(2020, TRUE)).
# Own formulas (closed-form WLS, manual IRLS, integrate()) instead of the dossier's lm/glm/grid code paths.
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
# Writes ONLY aggregates to spec/out_verify_ihc/. Row-level ENPG stays in memory.
.t0 <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "out_verify_ihc"); dir.create(OUT, showWarnings = FALSE)
wcsv <- function(x, f) utils::write.csv(x, file.path(OUT, f), row.names = FALSE)
options(width = 200, digits = 6)
hdr <- function(s) cat("\n==== ", s, " ====\n", sep = "")
run_cell("ms-fit-and-check"); run_cell("ms-historical-validation")
m <- ms_calibrated
E <- ms_enpg; tg <- as.data.frame(ms_targets)
tg$time <- (tg$year - 2012) / 10; tg$cell <- paste(tg$sex, tg$age_group, sep = ":")
tg$train <- tg$year <= 2020

hdr("V1 gpd target = weighted mean incl. zeros; zero count; min positive")
cur <- E[E$current %in% 1 & is.finite(E$gpd_survey), ]
key <- paste(cur$year, cur$sex, cur$age_group)
wm <- tapply(cur$gpd_survey * cur$weight, key, sum) / tapply(cur$weight, key, sum)
cat("max |target - own weighted mean incl 0| =", max(abs(wm[paste(tg$year, tg$sex, tg$age_group)] - tg$gpd_mean)), "\n")
cat("zeros by year:", tapply(cur$gpd_survey == 0, cur$year, sum), " min positive =", min(cur$gpd_survey[cur$gpd_survey > 0]), "\n")
z14 <- cur[cur$year == 2014, ]; zs <- tapply((z14$gpd_survey == 0) * z14$weight, paste(z14$sex, z14$age_group), sum) / tapply(z14$weight, paste(z14$sex, z14$age_group), sum)
cat("2014 weighted zero share by cell (max):", max(zs), names(which.max(zs)), "\n")

hdr("V2 mu: closed-form per-cell WLS vs additive (normal equations)")
tr <- tg[tg$train, ]; tr$y <- log(tr$gpd_mean); tr$w <- (tr$gpd_mean / tr$gpd_se)^2
cellfit <- do.call(rbind, lapply(split(tr, tr$cell), function(d) {
  xb <- sum(d$w * d$time) / sum(d$w); yb <- sum(d$w * d$y) / sum(d$w); sxx <- sum(d$w * (d$time - xb)^2)
  b <- sum(d$w * (d$time - xb) * (d$y - yb)) / sxx; a <- yb - b * xb
  data.frame(cell = d$cell[1], alpha = a, beta = b, sxx = sxx, rss = sum(d$w * (d$y - a - b * d$time)^2),
    sw = sum(d$w), xb = xb)
}))
s2c <- sum(cellfit$rss) / 24
cellfit$se_beta <- sqrt(s2c / cellfit$sxx); cellfit$t_beta <- cellfit$beta / cellfit$se_beta
cellfit$se_alpha <- sqrt(s2c * (1 / cellfit$sw + cellfit$xb^2 / cellfit$sxx))
print(cellfit[c("cell", "alpha", "se_alpha", "beta", "se_beta", "t_beta")], digits = 5)
cat("max |own - ms_fit| coef:", max(abs(c(cellfit$alpha, cellfit$beta) -
  c(coef(m$amount)[paste0("cell", cellfit$cell)], coef(m$amount)[paste0("cell", cellfit$cell, ":time")]))), "\n")
X <- cbind(1, male = tr$sex == "male", a2 = tr$age_group == 2, a3 = tr$age_group == 3, a4 = tr$age_group == 4, time = tr$time)
W <- diag(tr$w); badd <- solve(t(X) %*% W %*% X, t(X) %*% W %*% tr$y); rss_a <- sum(tr$w * (tr$y - X %*% badd)^2)
rss_c <- sum(cellfit$rss)
Fst <- ((rss_a - rss_c) / 10) / (rss_c / 24)
cat("additive coef:", round(badd, 4), " RSS add =", rss_a, " RSS cell =", rss_c, " s2 cell =", s2c, " s2 add =", rss_a / 34,
    " F =", Fst, " p =", pf(Fst, 10, 24, lower.tail = FALSE), " chi2 p cell =", pchisq(rss_c, 24, lower.tail = FALSE), "\n")
cf <- setNames(cellfit$alpha, cellfit$cell); cb <- setNames(cellfit$beta, cellfit$cell)
tg$mu_c <- exp(cf[tg$cell] + cb[tg$cell] * tg$time)
Xa <- cbind(1, tg$sex == "male", tg$age_group == 2, tg$age_group == 3, tg$age_group == 4, tg$time)
tg$mu_a <- exp(drop(Xa %*% badd))
pf_ <- function(pred, s) { e <- pred[s] - tg$gpd_mean[s]; ok <- tg$year[s] != 2020
  c(bias = mean(e), rmse = sqrt(mean(e^2)), cover = sum(abs(e[ok]) <= 1.959964 * tg$gpd_se[s][ok]), n = sum(ok)) }
amt <- rbind(cell_train = pf_(tg$mu_c, tg$train), add_train = pf_(tg$mu_a, tg$train),
  cell_held = pf_(tg$mu_c, !tg$train), add_held = pf_(tg$mu_a, !tg$train)); print(amt, digits = 4)
he <- tg[!tg$train, c("year", "cell", "gpd_mean", "gpd_se", "mu_c", "mu_a")]; he$err_c <- he$mu_c - he$gpd_mean; he$err_a <- he$mu_a - he$gpd_mean
print(he[order(-abs(he$err_c)), ][1:5, ], digits = 4)
wcsv(cellfit, "v2_amount_cellfit.csv"); wcsv(as.data.frame(amt), "v2_amount_perf.csv")

hdr("V3 Gamma k and p0 pooled 2012-2020 (base aggregate)")
trn <- E[E$year <= 2020 & E$current %in% 1 & is.finite(E$gpd_survey), ]
kp <- do.call(rbind, lapply(split(trn, paste(trn$sex, trn$age_group)), function(d) {
  p <- d[d$gpd_survey > 0, ]; mm <- sum(p$weight * p$gpd_survey) / sum(p$weight)
  v <- sum(p$weight * (p$gpd_survey - mm)^2) / sum(p$weight)
  data.frame(sex = d$sex[1], age_group = d$age_group[1], k = mm^2 / v, p0 = sum(d$weight * (d$gpd_survey == 0)) / sum(d$weight))
}))
print(kp, digits = 4)
mk <- merge(kp, m$shape, by = c("sex", "age_group")); cat("max |k diff| =", max(abs(mk$k - mk$shape)), " max |p0 diff| =", max(abs(mk$p0 - mk$p_zero)), "\n")
wcsv(kp, "v3_gamma_k_p0.csv")

hdr("V4 HED glm by manual IRLS (quasibinomial, normalized weights)")
hd <- E[E$year <= 2020 & E$current %in% 1 & is.finite(E$gpd_survey) & E$gpd_survey > 0 & !is.na(E$hed), ]
cells <- sort(unique(paste(hd$sex, hd$age_group, sep = ":")))
Xh <- cbind(sapply(cells, function(cl) as.numeric(paste(hd$sex, hd$age_group, sep = ":") == cl)), lg = log1p(hd$gpd_survey))
wt <- hd$weight / mean(hd$weight); y <- hd$hed; beta <- rep(0, ncol(Xh))
for (it in 1:50) { eta <- drop(Xh %*% beta); p <- plogis(eta); ww <- wt * p * (1 - p)
  zz <- eta + (y - p) / (p * (1 - p)); bn <- solve(crossprod(Xh, ww * Xh), crossprod(Xh, ww * zz))
  if (max(abs(bn - beta)) < 1e-12) { beta <- drop(bn); break }; beta <- drop(bn) }
p <- plogis(drop(Xh %*% beta)); phi <- sum(wt * (y - p)^2 / (p * (1 - p))) / (nrow(Xh) - ncol(Xh))
se <- sqrt(diag(solve(crossprod(Xh, (wt * p * (1 - p)) * Xh))) * phi)
print(data.frame(term = colnames(Xh), est = beta, se = se), digits = 5)
cat("n =", nrow(hd), " dispersion =", phi, " max |own - glm| =", max(abs(beta - coef(m$hed)[c(paste0("cell", cells), "base::log1p(gpd_survey)")])), "\n")
g_raw <- glm(hed ~ 0 + factor(paste(sex, age_group)) + log1p(gpd_survey), data = hd, weights = weight, family = quasibinomial())
cat("raw (unnormalized) weights: slope se =", summary(g_raw)$coefficients["log1p(gpd_survey)", 2], "(normalized:", se[length(se)], ")\n")
g_y <- glm(hed ~ 0 + factor(paste(sex, age_group)) + log1p(gpd_survey) + factor(year), data = hd, weights = wt, family = quasibinomial())
print(summary(g_y)$coefficients[grep("year", names(coef(g_y))), ], digits = 4)
wcsv(data.frame(term = colnames(Xh), est = beta, se = se, dispersion = phi), "v4_hed_irls.csv")

hdr("V5 HED: T, A, B (observed gpd), C (integrate), S (5 seeds); bias, coverage, decomposition")
drv <- ms_drivers(m, seq(2012, 2024, 2))
drv$scale <- drv$mu_current / ((1 - drv$p_zero) * drv$shape)
Cint <- function(p0, k, th, a, b) (1 - p0) * integrate(function(v) plogis(a + b * log1p(qgamma(v, k, scale = th))), 0, 1,
  rel.tol = 1e-10, subdivisions = 1000L)$value
drv$C <- mapply(Cint, drv$p_zero, drv$shape, drv$scale, drv$hed_intercept, drv$hed_slope)
allh <- E[E$current %in% 1 & !is.na(E$hed), ]
Wt <- aggregate(weight ~ year + sex + age_group, allh, sum); names(Wt)[4] <- "W"
ab <- E[E$current %in% 1 & is.finite(E$gpd_survey) & E$gpd_survey > 0 & !is.na(E$hed), ]
ab$pB <- plogis(beta[paste(ab$sex, ab$age_group, sep = ":")] + beta[["lg"]] * log1p(ab$gpd_survey))
AB <- do.call(rbind, lapply(split(ab, paste(ab$year, ab$sex, ab$age_group)), function(d)
  data.frame(year = d$year[1], sex = d$sex[1], age_group = d$age_group[1],
    A = sum(d$weight * d$hed) / sum(d$weight), B = sum(d$weight * d$pB) / sum(d$weight))))
S <- aggregate(hed_mean ~ year + sex + age_group, as.data.frame(ms_validation_summary), mean); names(S)[4] <- "S"
D <- Reduce(function(x, y) merge(x, y, by = c("year", "sex", "age_group")),
  list(tg[c("year", "sex", "age_group", "train", "hed_mean", "hed_se")], AB, drv[c("year", "sex", "age_group", "C")], S, Wt))
names(D)[names(D) == "hed_mean"] <- "T"
stopifnot(nrow(D) == 56)
for (per in c(TRUE, FALSE)) { d <- D[D$train == per, ]; ok <- d$year != 2020
  cat(if (per) "TRAIN" else "HELD-OUT", ": S-T bias", 100 * mean(d$S - d$T), "rmse", 100 * sqrt(mean((d$S - d$T)^2)),
    "cover", sum(abs(d$S - d$T)[ok] <= 1.959964 * d$hed_se[ok]), "/", sum(ok),
    "| C-T", 100 * mean(d$C - d$T), "rmse", 100 * sqrt(mean((d$C - d$T)^2)),
    "| B-T", 100 * mean(d$B - d$T), "| A-T", 100 * mean(d$A - d$T), "B-A", 100 * mean(d$B - d$A),
    "C-B", 100 * mean(d$C - d$B), "S-C", 100 * mean(d$S - d$C),
    "| pop-weighted S-T", 100 * sum(d$W * (d$S - d$T)) / sum(d$W), "\n") }
cat("C-B<0 in", sum(D$C < D$B), "of 56; C-B by train cell (pp):\n")
print(round(100 * tapply(D$C[D$train] - D$B[D$train], paste(D$sex, D$age_group)[D$train], mean), 2))
cat("C-B train by sex:", round(100 * tapply(D$C[D$train] - D$B[D$train], D$sex[D$train], mean), 2), "\n")
byw <- do.call(rbind, lapply(split(D, D$year), function(d) data.frame(year = d$year[1],
  pooled_S_T = 100 * sum(d$W * (d$S - d$T)) / sum(d$W), B_A = 100 * mean(d$B - d$A), C_B = 100 * mean(d$C - d$B))))
print(byw, digits = 4)
wcsv(D[setdiff(names(D), "W")], "v5_hed_cells.csv"); wcsv(byw, "v5_hed_by_wave.csv")

hdr("V6 low mass: engine analytic vs observed, training cell means by sex")
drv$lt04 <- drv$p_zero + (1 - drv$p_zero) * pgamma(0.4, drv$shape, scale = drv$scale)
drv$lt1 <- drv$p_zero + (1 - drv$p_zero) * pgamma(1, drv$shape, scale = drv$scale)
ob <- do.call(rbind, lapply(split(cur, paste(cur$year, cur$sex, cur$age_group)), function(d)
  data.frame(year = d$year[1], sex = d$sex[1], age_group = d$age_group[1],
    o04 = sum(d$weight * (d$gpd_survey < 0.4)) / sum(d$weight), o1 = sum(d$weight * (d$gpd_survey < 1)) / sum(d$weight))))
lm_ <- merge(drv[c("year", "sex", "age_group", "lt04", "lt1")], ob, by = c("year", "sex", "age_group"))
print(aggregate(cbind(o04, lt04, o1, lt1) ~ sex + I(year <= 2020), lm_, mean), digits = 4)

hdr("V7 categories x factor_CH 2024 (analytic engine, among current) and observed")
fac <- utils::read.csv("<repo>/__andres_control/oms_factor_by_year.csv")
for (yy in c(2016, 2024)) { f <- fac$factor_CH[fac$year == yy]
  d <- drv[drv$year == yy, ]
  Sx <- aggregate(n ~ sex + age_group, as.data.frame(ms_validation_summary)[ms_validation_summary$year == yy, ], mean)
  d <- merge(d, Sx, by = c("sex", "age_group"))
  lo <- ifelse(d$sex == "female", 20, 40); hi <- ifelse(d$sex == "female", 40, 60)
  Fg <- function(x) d$p_zero + (1 - d$p_zero) * pgamma(x, d$shape, scale = d$scale)
  for (s in c("female", "male")) { k <- d$sex == s; wgt <- d$n[k] * d$p_current[k]
    c3 <- sum(wgt * (1 - Fg(hi / f)[k])) / sum(wgt); c2 <- sum(wgt * (Fg(hi / f) - Fg(lo / f))[k]) / sum(wgt)
    c3s <- sum(wgt * (1 - Fg(hi)[k])) / sum(wgt); c2s <- sum(wgt * (Fg(hi) - Fg(lo))[k]) / sum(wgt)
    o <- cur[cur$year == yy & cur$sex == s, ]; L <- if (s == "female") 20 else 40; H <- if (s == "female") 40 else 60
    cat(yy, s, "engine xf: cat2", round(100 * c2, 2), "cat3", round(100 * c3, 2), "| engine survey cat2+3", round(100 * (c2s + c3s), 2),
      "| obs xf cat2", round(100 * sum(o$weight * (o$gpd_survey * f >= L & o$gpd_survey * f < H)) / sum(o$weight), 2),
      "cat3", round(100 * sum(o$weight * (o$gpd_survey * f >= H)) / sum(o$weight), 2),
      "| obs survey cat2+3", round(100 * sum(o$weight * (o$gpd_survey >= L)) / sum(o$weight), 2), "\n") } }

hdr("V8 worked example by direct formulas")
dx <- ms_drivers(m, 2016:2017); dx <- dx[dx$sex == "male" & dx$age_group == 2, ]; dx$scale <- dx$mu_current / ((1 - dx$p_zero) * dx$shape)
zc <- c(-0.6, -0.6 * 0.8 + 0.6 * 0.3); za <- c(0.9, 0.9 * 0.8 + 0.6 * -0.5); zh <- c(-0.3, -0.3 * 0.8 + 0.6 * 1.2)
g <- qgamma(pnorm(za), dx$shape, scale = dx$scale); ph <- plogis(dx$hed_intercept + dx$hed_slope * log1p(g))
cat("pc", dx$p_current, "U", pnorm(zc), "g", g, "pHED", ph, "U_hed", pnorm(zh), "z_hed threshold 2017", qnorm(ph[2]), "\n")
uu <- pnorm(zc) / dx$p_current
cat("U/pc", uu, "-> g", qgamma(uu, dx$shape, scale = dx$scale), "| 1-U/pc -> g", qgamma(1 - uu, dx$shape, scale = dx$scale), "\n")
cat("g*factor2016 =", g[1] * fac$factor_CH[fac$year == 2016], " P(cat2), P(cat3), P(g<1) 2016:",
  diff(pgamma(c(40, 60), dx$shape[1], scale = dx$scale[1])), 1 - pgamma(60, dx$shape[1], scale = dx$scale[1]), pgamma(1, dx$shape[1], scale = dx$scale[1]), "\n")

hdr("V9 convexity of pHED(g): inflection where pHED = (1 - 1/gamma_g)/2; Gamma mass in convex zone (2016)")
pst <- (1 - 1 / beta[["lg"]]) / 2
d16 <- drv[drv$year == 2016, ]
d16$g_infl <- expm1((qlogis(pst) - d16$hed_intercept) / d16$hed_slope)
d16$mass_convex <- d16$p_zero + (1 - d16$p_zero) * pgamma(d16$g_infl, d16$shape, scale = d16$scale)
d16$obs_convex <- mapply(function(s, a, gi) { o <- cur[cur$year == 2016 & cur$sex == s & cur$age_group == a, ]; sum(o$weight * (o$gpd_survey < gi)) / sum(o$weight) },
  d16$sex, d16$age_group, d16$g_infl)
cat("p* =", pst, "\n"); print(d16[c("sex", "age_group", "g_infl", "mass_convex", "obs_convex")], digits = 4)
wcsv(d16[c("sex", "age_group", "g_infl", "mass_convex", "obs_convex")], "v9_convexity_2016.csv")

hdr("V10 rho invariance with 5 seeds: rho = 0 vs 0.8")
r0 <- dplyr::bind_rows(lapply(ms_cfg$seeds, function(s) ms_simulate(m, 2012:2024, ms_cfg$n_sim, s, rho = 0)$summary))
S0 <- aggregate(hed_mean ~ year + sex + age_group, as.data.frame(r0), mean); names(S0)[4] <- "S0"
D0 <- merge(D, S0, by = c("year", "sex", "age_group"))
cat("5-seed mean HED bias (pp): rho0 train", 100 * mean((D0$S0 - D0$T)[D0$train]), " rho0.8 train", 100 * mean((D0$S - D0$T)[D0$train]),
    " | rho0 held", 100 * mean((D0$S0 - D0$T)[!D0$train]), " rho0.8 held", 100 * mean((D0$S - D0$T)[!D0$train]), "\n")

cat(sprintf("\nTotal elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
