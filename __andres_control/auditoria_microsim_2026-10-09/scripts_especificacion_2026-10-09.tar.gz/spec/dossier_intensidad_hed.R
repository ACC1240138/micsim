# Dossier: intensity (Gamma mixture), HED and categories, BASE spec (ms_fit(2020, trend = TRUE)).
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
# Writes ONLY aggregates (cell tables, coefficients, simulated summaries) to spec/out_ihc/. Row-level ENPG stays in memory.
.t0 <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "out_ihc"); dir.create(OUT, showWarnings = FALSE)
wcsv <- function(x, f) utils::write.csv(x, file.path(OUT, f), row.names = FALSE)
options(width = 220, digits = 6)
hdr <- function(s) cat("\n==== ", s, " ====\n", sep = "")

# Literal notebook cells: ms_calibrated = ms_fit(2020, TRUE); 5 seeds x 2012-2024 validation.
run_cell("ms-fit-and-check")
run_cell("ms-historical-validation")
m <- ms_calibrated
stopifnot(max(m$training_years) == 2020L, isTRUE(all.equal(unname(round(m$mortality_scale, 4)), c(0.9699, 0.9524))))
tg <- ms_targets
tg$time <- (tg$year - ms_cfg$start_year) / 10
tg$period <- ifelse(tg$year <= ms_cfg$train_end, "train", "held-out")
tg$cell <- factor(paste(tg$sex, tg$age_group, sep = ":"), levels = m$amount$xlevels$cell)
drv_all <- ms_drivers(m, 2012:2024)

## A. INTENSITY ==========================================================================================
hdr("A0 data audit (counts by wave, 15-65)"); print(ms_data_audit[, 1:10]); wcsv(ms_data_audit, "data_audit.csv")

hdr("A1 target check: gpd_mean includes zero g/day current drinkers; observed low-mass shares")
cur <- ms_enpg[ms_enpg$current %in% 1, ]
a1 <- do.call(rbind, lapply(seq_len(nrow(tg)), function(i) {
  x <- cur[cur$year == tg$year[i] & cur$sex == tg$sex[i] & cur$age_group == tg$age_group[i], ]
  g <- x[is.finite(x$gpd_survey), ]; h <- x[!is.na(x$hed), ]; p <- g[g$gpd_survey > 0, ]
  data.frame(year = tg$year[i], sex = tg$sex[i], age_group = tg$age_group[i],
    gpd_target = tg$gpd_mean[i], wmean_incl0 = weighted.mean(g$gpd_survey, g$weight),
    wmean_pos = weighted.mean(p$gpd_survey, p$weight), n_cur = nrow(x), n_gpd = nrow(g), n_zero = sum(g$gpd_survey == 0),
    obs_lt04 = weighted.mean(g$gpd_survey < 0.4, g$weight), obs_lt1 = weighted.mean(g$gpd_survey < 1, g$weight),
    min_pos = min(p$gpd_survey), hed_target = tg$hed_mean[i], hed_wmean = weighted.mean(h$hed, h$weight),
    W_hed = sum(h$weight))
}))
stopifnot(max(abs(a1$gpd_target - a1$wmean_incl0)) < 1e-8, max(abs(a1$hed_target - a1$hed_wmean)) < 1e-8)
cat("max|target - weighted mean incl. zeros| =", max(abs(a1$gpd_target - a1$wmean_incl0)),
    "; max|target - mean excl. zeros| =", max(abs(a1$gpd_target - a1$wmean_pos)), "; total zero-gpd current drinkers =", sum(a1$n_zero),
    "(by year:", paste(tapply(a1$n_zero, a1$year, sum), collapse = ","), "); min positive gpd =", min(a1$min_pos), "\n")
wcsv(a1[, setdiff(names(a1), c("hed_wmean"))], "targets_check_and_observed_lowmass.csv")

hdr("A2 amount WLS: cell-specific (code) vs additive (user)")
tr <- tg[tg$year <= ms_cfg$train_end, ]
tr$y <- log(tr$gpd_mean); tr$w <- (tr$gpd_mean / tr$gpd_se)^2
am <- m$amount
stopifnot(max(abs(coef(am) - coef(lm(y ~ 0 + cell + cell:time, data = tr, weights = w)))) < 1e-12)
add <- lm(y ~ sex + factor(age_group) + time, data = tr, weights = w)
sa <- summary(am); sad <- summary(add)
coef_amount <- data.frame(model = "cell (code)", term = rownames(sa$coefficients), estimate = sa$coefficients[, 1],
  se_lm = sa$coefficients[, 2], se_sigma1 = sa$coefficients[, 2] / sa$sigma, row.names = NULL)
coef_add <- data.frame(model = "additive (user)", term = rownames(sad$coefficients), estimate = sad$coefficients[, 1],
  se_lm = sad$coefficients[, 2], se_sigma1 = sad$coefficients[, 2] / sad$sigma, row.names = NULL)
print(rbind(coef_amount, coef_add), digits = 4)
cat("cell model: sigma2 =", sa$sigma^2, "df =", am$df.residual, " chi2 = sum w*e^2 =", sum(tr$w * residuals(am)^2), "\n")
cat("additive model: sigma2 =", sad$sigma^2, "df =", add$df.residual, " chi2 =", sum(tr$w * residuals(add)^2), "\n")
print(anova(add, am))
wcsv(rbind(coef_amount, coef_add), "amount_coefficients.csv")
tg$mu_cell <- exp(predict(am, newdata = tg)); tg$mu_add <- exp(predict(add, newdata = tg))
perf <- function(obs, pred, se, year, period) {
  e <- pred - obs; ok <- year != 2020L
  data.frame(period = period, cells = length(e), bias = mean(e), rmse = sqrt(mean(e^2)), mae = mean(abs(e)),
    cover = sum(abs(e[ok]) <= qnorm(0.975) * se[ok]), n_cover = sum(ok))
}
amount_perf <- do.call(rbind, lapply(c("train", "held-out"), function(p) { s <- tg$period == p
  rbind(cbind(model = "cell (code), analytic mu", perf(tg$gpd_mean[s], tg$mu_cell[s], tg$gpd_se[s], tg$year[s], p)),
        cbind(model = "additive (user), analytic mu", perf(tg$gpd_mean[s], tg$mu_add[s], tg$gpd_se[s], tg$year[s], p))) }))
print(amount_perf, digits = 4); wcsv(amount_perf, "amount_performance_cell_vs_additive.csv")
wcsv(tg[c("year", "sex", "age_group", "period", "gpd_mean", "gpd_se", "mu_cell", "mu_add")], "amount_cells_cell_vs_additive.csv")
cat("held-out cells, cell vs additive (obs, cell, add):\n"); print(tg[tg$period == "held-out", c("year", "sex", "age_group", "gpd_mean", "gpd_se", "mu_cell", "mu_add")], digits = 4)

hdr("A3 Gamma shape k and p0 (pooled training waves, time-invariant) + per-wave k")
shp <- as.data.frame(m$shape); print(shp, digits = 4); wcsv(shp, "gamma_shape_p0_train2020.csv")
kw <- ms_enpg[ms_enpg$current %in% 1 & is.finite(ms_enpg$gpd_survey) & ms_enpg$gpd_survey > 0, ] |>
  dplyr::group_by(year, sex, age_group) |>
  dplyr::summarise(mu = weighted.mean(gpd_survey, weight), variance = weighted.mean((gpd_survey - mu)^2, weight),
    shape = mu^2 / variance, .groups = "drop")
print(tidyr_wide <- stats::reshape(as.data.frame(kw[c("year", "sex", "age_group", "shape")]), idvar = c("sex", "age_group"),
  timevar = "year", direction = "wide"), digits = 3)
wcsv(kw, "gamma_shape_by_wave.csv")
d16 <- drv_all[drv_all$year %in% c(2016, 2020, 2024), c("year", "sex", "age_group", "p_current", "mu_current", "p_zero", "shape", "hed_intercept", "hed_slope")]
d16$scale <- d16$mu_current / ((1 - d16$p_zero) * d16$shape)
print(d16, digits = 4); wcsv(d16, "drivers_2016_2020_2024.csv")

hdr("A4 numeric check: 1e6 draws per cell through ms_exposure (engine code), years 2016 and 2024")
hed_exp <- function(p0, k, th, a, b, M = 2e5) { v <- (seq_len(M) - 0.5) / M; (1 - p0) * mean(plogis(a + b * log1p(qgamma(v, k, scale = th)))) }
set.seed(20261009)
a4 <- do.call(rbind, lapply(c(2016L, 2024L), function(y) do.call(rbind, lapply(c("female", "male"), function(s) do.call(rbind, lapply(1:4, function(ag) {
  n <- 1e6; d <- drv_all[drv_all$year == y & drv_all$sex == s & drv_all$age_group == ag, ]; th <- d$mu_current / ((1 - d$p_zero) * d$shape)
  pop <- data.frame(id = seq_len(n), sex = s, age = c(20L, 35L, 50L, 62L)[ag], z_current = -10, z_amount = rnorm(n),
    z_hed = rnorm(n), ever = NA, stringsAsFactors = FALSE)
  pop <- ms_exposure(pop, y, drv_all); stopifnot(all(pop$current))
  g <- pop$gpd_survey
  data.frame(year = y, sex = s, age_group = ag, mu = d$mu_current, sim_mean = mean(g),
    mc_se = sd(g) / sqrt(n), var_theory = (1 - d$p_zero) * d$shape * (d$shape + 1) * th^2 - d$mu_current^2, sim_var = var(g),
    p0 = d$p_zero, sim_zero = mean(g == 0),
    lt04_theory = d$p_zero + (1 - d$p_zero) * pgamma(0.4, d$shape, scale = th), lt04_sim = mean(g < 0.4),
    lt1_theory = d$p_zero + (1 - d$p_zero) * pgamma(1, d$shape, scale = th), lt1_sim = mean(g < 1),
    hed_theory = hed_exp(d$p_zero, d$shape, th, d$hed_intercept, d$hed_slope), hed_sim = mean(pop$hed),
    hed_at_zero_sim = sum(pop$hed & g == 0))
}))))))
print(a4, digits = 4); wcsv(a4, "numeric_check_1e6_draws.csv")
stopifnot(all(abs(a4$sim_mean - a4$mu) < 5 * a4$mc_se), all(abs(a4$hed_sim - a4$hed_theory) < 5 * sqrt(a4$hed_theory * (1 - a4$hed_theory) / 1e6)),
  all(a4$hed_at_zero_sim == 0))

hdr("A5 mass near zero: engine (analytic) vs observed, training waves and held-out")
a5 <- merge(a1[c("year", "sex", "age_group", "obs_lt04", "obs_lt1")],
  transform(drv_all[drv_all$year %in% seq(2012, 2024, 2), c("year", "sex", "age_group", "mu_current", "p_zero", "shape")],
    eng_lt04 = p_zero + (1 - p_zero) * pgamma(0.4, shape, scale = mu_current / ((1 - p_zero) * shape)),
    eng_lt1 = p_zero + (1 - p_zero) * pgamma(1, shape, scale = mu_current / ((1 - p_zero) * shape))), by = c("year", "sex", "age_group"))
a5$period <- ifelse(a5$year <= 2020, "train", "held-out")
a5s <- aggregate(cbind(obs_lt04, eng_lt04, obs_lt1, eng_lt1) ~ period + sex, data = a5, FUN = mean)
print(a5s, digits = 4); wcsv(a5, "lowmass_cells.csv"); wcsv(a5s, "lowmass_by_sex_period.csv")
a5c <- aggregate(cbind(obs_lt04, eng_lt04, obs_lt1, eng_lt1) ~ sex + age_group, data = a5[a5$period == "train", ], FUN = mean)
print(a5c, digits = 4); wcsv(a5c, "lowmass_by_cell_train.csv")

hdr("A6 simulated vs observed intensity (notebook validation, 5 seeds)")
print(as.data.frame(ms_performance), digits = 4); wcsv(ms_performance, "validation_performance_5seeds.csv")
sim_cells <- merge(as.data.frame(ms_sim_mean), tg[c("year", "sex", "age_group", "mu_cell", "gpd_mean", "gpd_se", "hed_mean", "hed_se", "current_mean")],
  by = c("year", "sex", "age_group"), suffixes = c("_sim", "_obs"))
cat("max |sim gpd - analytic mu| over 56 cells =", max(abs(sim_cells$gpd_mean_sim - sim_cells$mu_cell)),
    "; mean MC sd =", mean(sim_cells$gpd_mc_sd), "\n")

hdr("A7 rank persistence of z_amount (Spearman) numeric check")
set.seed(1); z1 <- rnorm(1e6); z2 <- 0.8 * z1 + 0.6 * rnorm(1e6)
cat("Spearman sim =", cor(z1, z2, method = "spearman"), "; theory 6/pi*asin(rho/2) =", 6 / pi * asin(0.4), "\n")

## B. HED ================================================================================================
hdr("B1 HED glm (code) coefficients")
hb <- m$hed; shb <- summary(hb)
coef_hed <- data.frame(term = rownames(shb$coefficients), estimate = shb$coefficients[, 1], se = shb$coefficients[, 2],
  t = shb$coefficients[, 3], row.names = NULL)
print(coef_hed, digits = 4); cat("dispersion =", shb$dispersion, " n =", length(hb$y), " df.resid =", hb$df.residual, "\n")
wcsv(coef_hed, "hed_coefficients.csv")
# Rebuild the glm sample exactly as ms_fit L49-52 (training waves only).
train <- ms_enpg[ms_enpg$year <= ms_cfg$train_end, ]
hd <- train[train$current %in% 1 & is.finite(train$gpd_survey) & train$gpd_survey > 0 & !is.na(train$hed), ]
hd$cell <- factor(paste(hd$sex, hd$age_group, sep = ":")); hd$w_fit <- hd$weight / mean(hd$weight); hd$time <- (hd$year - 2012) / 10
stopifnot(nrow(hd) == length(hb$y))
cat("glm sample by training wave:", paste(names(table(hd$year)), table(hd$year), sep = "=", collapse = ", "), "\n")
hb_add <- glm(hed ~ sex + factor(age_group) + log1p(gpd_survey), data = hd, weights = w_fit, family = quasibinomial())
hb_t <- glm(hed ~ 0 + cell + log1p(gpd_survey) + time, data = hd, weights = w_fit, family = quasibinomial())
hb_y <- glm(hed ~ 0 + cell + log1p(gpd_survey) + factor(year), data = hd, weights = w_fit, family = quasibinomial())
print(summary(hb_add)$coefficients, digits = 4); print(summary(hb_t)$coefficients[c("log1p(gpd_survey)", "time"), ], digits = 4)
print(summary(hb_y)$coefficients[grep("year|log1p", rownames(summary(hb_y)$coefficients)), ], digits = 4)
wcsv(rbind(data.frame(model = "additive (user)", term = rownames(summary(hb_add)$coefficients), summary(hb_add)$coefficients[, 1:2], row.names = NULL),
  data.frame(model = "cell + linear time", term = rownames(summary(hb_t)$coefficients), summary(hb_t)$coefficients[, 1:2], row.names = NULL),
  data.frame(model = "cell + wave factor", term = rownames(summary(hb_y)$coefficients), summary(hb_y)$coefficients[, 1:2], row.names = NULL)),
  "hed_coefficients_alternatives.csv")

hdr("B2 implied pHED at 1,5,10,20,40 g/day (and 0.4, 60)")
gg <- c(0.4, 1, 5, 10, 20, 40, 60)
cf <- coef(hb); cells <- levels(hd$cell)
phed <- do.call(rbind, lapply(cells, function(cl) data.frame(cell = cl, t(setNames(plogis(cf[paste0("cell", cl)] + cf["base::log1p(gpd_survey)"] * log1p(gg)), paste0("g", gg))))))
print(phed, digits = 3); wcsv(phed, "hed_phed_by_gpd.csv")

hdr("B3 HED decomposition (base fit): T target, A glm-sample obs, B glm on observed gpd, C engine expectation, S simulated")
allc <- ms_enpg[ms_enpg$current %in% 1 & is.finite(ms_enpg$gpd_survey) & ms_enpg$gpd_survey > 0 & !is.na(ms_enpg$hed), ]
allc$cell <- factor(paste(allc$sex, allc$age_group, sep = ":"), levels = cells); allc$time <- (allc$year - 2012) / 10
allc$pB <- predict(hb, newdata = allc, type = "response"); allc$pB_add <- predict(hb_add, newdata = allc, type = "response")
AB <- allc |> dplyr::group_by(year, sex, age_group) |>
  dplyr::summarise(A = weighted.mean(hed, weight), B = weighted.mean(pB, weight), B_add = weighted.mean(pB_add, weight), .groups = "drop")
eng <- drv_all[drv_all$year %in% seq(2012, 2024, 2), ]
eng$scale <- eng$mu_current / ((1 - eng$p_zero) * eng$shape)
add_int <- function(s, ag) { b <- coef(hb_add); b[["(Intercept)"]] + (if (s == "male") b[["sexmale"]] else 0) + (if (ag > 1) b[[paste0("factor(age_group)", ag)]] else 0) }
eng$C <- mapply(function(p0, k, th, a, b) hed_exp(p0, k, th, a, b), eng$p_zero, eng$shape, eng$scale, eng$hed_intercept, eng$hed_slope)
eng$C_add <- mapply(function(p0, k, th, s, ag) hed_exp(p0, k, th, add_int(s, ag), coef(hb_add)[["log1p(gpd_survey)"]]),
  eng$p_zero, eng$shape, eng$scale, eng$sex, eng$age_group)
eng$C_time <- mapply(function(p0, k, th, cl, t) hed_exp(p0, k, th, coef(hb_t)[[paste0("cell", cl)]] + coef(hb_t)[["time"]] * t, coef(hb_t)[["log1p(gpd_survey)"]]),
  eng$p_zero, eng$shape, eng$scale, as.character(eng$cell), eng$time)
dec <- Reduce(function(x, y) merge(x, y, by = c("year", "sex", "age_group")), list(
  tg[c("year", "sex", "age_group", "period", "hed_mean", "hed_se")], as.data.frame(AB), eng[c("year", "sex", "age_group", "C", "C_add", "C_time")],
  data.frame(sim_cells[c("year", "sex", "age_group")], S = sim_cells$hed_mean_sim, S_mc_sd = sim_cells$hed_mc_sd),
  a1[c("year", "sex", "age_group", "W_hed")]))
names(dec)[names(dec) == "hed_mean"] <- "T"
dec <- transform(dec, A_T = A - T, B_A = B - A, C_B = C - B, S_C = S - C, S_T = S - T)
dsum <- aggregate(cbind(A_T, B_A, C_B, S_C, S_T) ~ period, data = dec, FUN = mean); print(dsum, digits = 4)
dsex <- aggregate(cbind(A_T, B_A, C_B, S_C, S_T) ~ period + sex, data = dec, FUN = mean); print(dsex, digits = 4)
dyr <- aggregate(cbind(A_T, B_A, C_B, S_C, S_T) ~ year, data = dec, FUN = mean); print(dyr, digits = 4)
cat("C-B < 0 in", sum(dec$C_B < 0), "of 56 cells\n")
pooled <- do.call(rbind, lapply(split(dec, dec$year), function(x) data.frame(year = x$year[1], T = weighted.mean(x$T, x$W_hed), S = weighted.mean(x$S, x$W_hed))))
pooled$S_T <- pooled$S - pooled$T; print(pooled, digits = 4)
cat("population-weighted (survey current-drinker weights) S-T: train =", with(dec[dec$period == "train", ], weighted.mean(S_T, W_hed)),
    " held-out =", with(dec[dec$period == "held-out", ], weighted.mean(S_T, W_hed)), "\n")
wcsv(dec, "hed_decomposition_cells.csv"); wcsv(rbind(cbind(level = "period", dsum)), "hed_decomposition_period.csv")
wcsv(dsex, "hed_decomposition_period_sex.csv"); wcsv(dyr, "hed_decomposition_year.csv"); wcsv(pooled, "hed_pooled_by_wave.csv")
hed_alt <- do.call(rbind, lapply(c("train", "held-out"), function(p) { s <- dec$period == p
  rbind(cbind(model = "cell (code), simulated S", perf(dec$T[s], dec$S[s], dec$hed_se[s], dec$year[s], p)),
        cbind(model = "cell (code), engine C", perf(dec$T[s], dec$C[s], dec$hed_se[s], dec$year[s], p)),
        cbind(model = "additive (user), engine C", perf(dec$T[s], dec$C_add[s], dec$hed_se[s], dec$year[s], p)),
        cbind(model = "cell + linear time, engine C", perf(dec$T[s], dec$C_time[s], dec$hed_se[s], dec$year[s], p)),
        cbind(model = "cell (code) on OBSERVED gpd (B)", perf(dec$T[s], dec$B[s], dec$hed_se[s], dec$year[s], p)),
        cbind(model = "additive (user) on OBSERVED gpd", perf(dec$T[s], dec$B_add[s], dec$hed_se[s], dec$year[s], p))) }))
print(hed_alt, digits = 4); wcsv(hed_alt, "hed_performance_alternatives.csv")

hdr("B4 rho invariance of the HED margin (seed 1, rho 0 vs 0.8)")
r0 <- ms_simulate(m, 2012:2024, ms_cfg$n_sim, ms_cfg$seeds[1], rho = 0)
r8 <- ms_validation_runs[[1]]
f <- function(r) { x <- merge(r$summary, tg[c("year", "sex", "age_group", "hed_mean")], by = c("year", "sex", "age_group")); mean(x$hed_mean.x - x$hed_mean.y) }
cat("mean HED S-T over 56 cells: rho0 =", f(r0), " rho0.8 =", f(r8), "\n")

## C. CATEGORIES ==========================================================================================
hdr("C1 simulated categories by sex, 2016 and 2024 (survey scale, 5 seeds) + analytic + risk scale")
fac <- utils::read.csv("<repo>/__andres_control/oms_factor_by_year.csv")[c("year", "factor_CH")]
print(fac)
vs <- ms_validation_summary[ms_validation_summary$year %in% c(2016L, 2024L), ]
simcat <- vs |> dplyr::group_by(year, sex, seed) |>
  dplyr::summarise(cur = weighted.mean(current_mean, n), cat1 = weighted.mean(cat1, n), cat2 = weighted.mean(cat2, n), cat3 = weighted.mean(cat3, n), .groups = "drop") |>
  dplyr::group_by(year, sex) |> dplyr::summarise(dplyr::across(c(cur, cat1, cat2, cat3), mean), .groups = "drop")
nw <- vs |> dplyr::group_by(year, sex, age_group) |> dplyr::summarise(n = mean(n), .groups = "drop")
catp <- function(f) {
  d <- merge(drv_all[drv_all$year %in% c(2016L, 2024L), ], nw, by = c("year", "sex", "age_group"))
  d$scale <- d$mu_current / ((1 - d$p_zero) * d$shape); d$f <- if (f) fac$factor_CH[match(d$year, fac$year)] else 1
  lo <- ifelse(d$sex == "female", 20, 40) / d$f; hi <- ifelse(d$sex == "female", 40, 60) / d$f
  F <- function(x) d$p_zero + (1 - d$p_zero) * pgamma(x, d$shape, scale = d$scale)
  d$c1 <- F(lo); d$c2 <- F(hi) - F(lo); d$c3 <- 1 - F(hi)
  d |> dplyr::group_by(year, sex) |> dplyr::summarise(cur = weighted.mean(p_current, n),
    cat1 = weighted.mean(p_current * c1, n), cat2 = weighted.mean(p_current * c2, n), cat3 = weighted.mean(p_current * c3, n), .groups = "drop")
}
an_s <- catp(FALSE); an_r <- catp(TRUE)
obscat <- function(y, f) {
  x <- ms_enpg[ms_enpg$year == y & ms_enpg$current %in% 1 & is.finite(ms_enpg$gpd_survey), ]
  g <- x$gpd_survey * f; lo <- ifelse(x$sex == "female", 20, 40); hi <- ifelse(x$sex == "female", 40, 60)
  do.call(rbind, lapply(c("female", "male"), function(s) { k <- x$sex == s
    data.frame(year = y, sex = s, cat1 = weighted.mean(g[k] < lo[k], x$weight[k]), cat2 = weighted.mean(g[k] >= lo[k] & g[k] < hi[k], x$weight[k]),
      cat3 = weighted.mean(g[k] >= hi[k], x$weight[k])) }))
}
obs_s <- rbind(obscat(2016L, 1), obscat(2024L, 1)); obs_r <- rbind(obscat(2016L, fac$factor_CH[fac$year == 2016]), obscat(2024L, fac$factor_CH[fac$year == 2024]))
cat_tab <- rbind(
  cbind(source = "sim 5 seeds, survey scale", as.data.frame(simcat), within_cur = FALSE),
  cbind(source = "engine analytic, survey scale", as.data.frame(an_s), within_cur = FALSE),
  cbind(source = "engine analytic, x factor_CH", as.data.frame(an_r), within_cur = FALSE))
cat_tab$cat1_cur <- cat_tab$cat1 / cat_tab$cur; cat_tab$cat2_cur <- cat_tab$cat2 / cat_tab$cur; cat_tab$cat3_cur <- cat_tab$cat3 / cat_tab$cur
print(cat_tab, digits = 4)
cat("observed ENPG shares among current drinkers (survey scale):\n"); print(obs_s, digits = 4)
cat("observed ENPG shares among current drinkers (x factor_CH):\n"); print(obs_r, digits = 4)
wcsv(cat_tab, "categories_sim_analytic.csv"); wcsv(rbind(cbind(scale = "survey", obs_s), cbind(scale = "x factor_CH", obs_r)), "categories_observed.csv")

hdr("C2 boundary ties in observed data (weighted share of current drinkers with gpd exactly at a threshold), all waves")
ties <- do.call(rbind, lapply(c("female", "male"), function(s) {
  x <- ms_enpg[ms_enpg$sex == s & ms_enpg$current %in% 1 & is.finite(ms_enpg$gpd_survey), ]
  th <- if (s == "female") c(20, 40) else c(40, 60)
  data.frame(sex = s, threshold = th, n_exact = sapply(th, function(t) sum(abs(x$gpd_survey - t) < 1e-9)),
    w_share = sapply(th, function(t) weighted.mean(abs(x$gpd_survey - t) < 1e-9, x$weight)), n_cur = nrow(x))
}))
print(ties, digits = 4); wcsv(ties, "category_boundary_ties.csv")

## D. WORKED EXAMPLE =======================================================================================
hdr("D worked example: man aged 35 (cell male:2), 2016 -> 2017")
dx <- ms_drivers(m, 2016:2017); dx <- dx[dx$sex == "male" & dx$age_group == 2, ]
dx$scale <- dx$mu_current / ((1 - dx$p_zero) * dx$shape)
print(dx[c("year", "time", "p_current", "mu_current", "p_zero", "shape", "scale", "hed_intercept", "hed_slope")], digits = 8)
z <- c(current = -0.6, amount = 0.9, hed = -0.3); eps <- c(current = 0.3, amount = -0.5, hed = 1.2)
step <- function(z, d) {
  U <- pnorm(z[["current"]]); cur <- U < d$p_current; ua <- pnorm(z[["amount"]]); pos <- cur & ua > d$p_zero
  upos <- if (pos) (ua - d$p_zero) / (1 - d$p_zero) else NA
  g <- if (pos) qgamma(upos, d$shape, scale = d$scale) else 0
  eta <- d$hed_intercept + d$hed_slope * log1p(g); ph <- plogis(eta); uh <- pnorm(z[["hed"]])
  hed <- pos && uh < ph
  cat_ <- if (!cur) "noncurrent" else if (g < 40) "cat1" else if (g < 60) "cat2" else "cat3"
  data.frame(year = d$year, z_current = z[["current"]], U_status = U, pc = d$p_current, is_current = cur,
    z_amount = z[["amount"]], U_amount = ua, p0 = d$p_zero, U_pos = upos, gpd = g, log1p_gpd = log1p(g), eta_hed = eta, p_hed = ph,
    z_hed = z[["hed"]], U_hed = uh, hed = hed, category = cat_,
    user_U_amount_U_over_p0 = U / d$p_zero, user_alt_U_over_pc = U / d$p_current, user_alt_1_minus_U_over_pc = 1 - U / d$p_current,
    gpd_if_U_over_pc = qgamma((U / d$p_current - d$p_zero) / (1 - d$p_zero), d$shape, scale = d$scale),
    gpd_if_1_minus_U_over_pc = qgamma((1 - U / d$p_current - d$p_zero) / (1 - d$p_zero), d$shape, scale = d$scale))
}
e16 <- step(z, dx[dx$year == 2016, ])
z17 <- 0.8 * z + sqrt(1 - 0.8^2) * eps
e17 <- step(z17, dx[dx$year == 2017, ])
ex <- rbind(e16, e17); print(t(ex), digits = 8)
cat("gpd x factor_CH(2016) =", e16$gpd * fac$factor_CH[fac$year == 2016], "\n")
# Cross-check with the engine function itself on a one-person population.
p1 <- data.frame(id = 1L, sex = "male", age = 35L, z_current = z[["current"]], z_amount = z[["amount"]], z_hed = z[["hed"]], ever = NA)
set.seed(7); q16 <- ms_exposure(p1, 2016L, drv_d <- ms_drivers(m, 2016:2017))
p2 <- q16; p2$age <- 36L; p2$z_current <- z17[["current"]]; p2$z_amount <- z17[["amount"]]; p2$z_hed <- z17[["hed"]]
q17 <- ms_exposure(p2, 2017L, drv_d)
print(rbind(q16, q17)[c("age", "current", "gpd_survey", "hed", "alc_status", "alc_cat", "ever")], digits = 8)
stopifnot(abs(q16$gpd_survey - e16$gpd) < 1e-10, abs(q17$gpd_survey - e17$gpd) < 1e-10, q16$hed == e16$hed, q17$hed == e17$hed,
  q16$alc_cat == e16$category, q17$alc_cat == e17$category)
wcsv(ex, "worked_example.csv")
# Probabilities for the example cell (what a random man in this cell would face)
cat("P(cat2|current), P(cat3|current), P(gpd<1|current) for male:2 2016:",
  with(dx[dx$year == 2016, ], c(pgamma(60, shape, scale = scale) - pgamma(40, shape, scale = scale), 1 - pgamma(60, shape, scale = scale), pgamma(1, shape, scale = scale))), "\n")

cat(sprintf("\nTotal elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
