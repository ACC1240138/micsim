# Dossier: ENPG inputs, demography, mortality, annual flow (BASE spec: ms_fit(2020, trend = TRUE), seeds 20260917 + 0:4).
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
# Writes ONLY aggregates (cell/year tables, coefficients, simulated summaries) to spec/out_demo/. Row-level ENPG/DEIS stay in memory.
.t0 <- Sys.time(); .t_script <- .t0  # cells reset .t0
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "out_demo"); dir.create(OUT, showWarnings = FALSE)
wcsv <- function(x, f) utils::write.csv(x, file.path(OUT, f), row.names = FALSE)
options(width = 220, digits = 6)
hdr <- function(s) cat("\n==== ", s, " ====\n", sep = "")

## A. ENPG INPUTS =========================================================================================
hdr("A1 harmonised columns and oh2 levels / encoding")
print(names(ms_raw)); print(sapply(ms_raw[c("oh1", "oh2", "oh3", "db", "audit2", "sexo", "edad")], function(x) class(x)[1]))
lv <- unique(as.character(ms_raw$oh2)); print(lv); print(Encoding(lv)); print(lapply(lv[!is.na(lv)], charToRaw))
tab_oh <- as.data.frame(table(year = ms_raw$year, oh1 = addNA(as.character(ms_raw$oh1)), oh2 = addNA(as.character(ms_raw$oh2))))
tab_oh <- tab_oh[tab_oh$Freq > 0, ]; print(tab_oh); wcsv(tab_oh, "raw_oh1_oh2_by_year_allages.csv")
tab_a2 <- as.data.frame(table(year = ms_raw$year, audit2 = addNA(as.character(ms_raw$audit2))))
tab_a2 <- tab_a2[tab_a2$Freq > 0, ]; wcsv(tab_a2, "raw_audit2_by_year_allages.csv")
print(stats::xtabs(Freq ~ year + audit2, tab_a2, addNA = TRUE))

hdr("A2 locale caveat: the status rule (ms-survey-inputs L69-71) re-evaluated under LC_ALL=C")
status_expr <- 'base::ifelse(ms_ever == "No" & base::is.na(ms_recency), "never",
  base::ifelse(ms_ever == "Si" & ms_recency == "30 dias", "current",
    base::ifelse(ms_ever == "Si" & ms_recency %in% base::c(">30", ">1 a\\u00f1o"), "former", NA_character_)))'
st_utf8 <- eval(parse(text = status_expr))
invisible(Sys.setlocale("LC_ALL", "C")); st_c <- eval(parse(text = status_expr)); invisible(Sys.setlocale("LC_ALL", "C.UTF-8"))
loc_tab <- data.frame(status = c("never", "current", "former", "NA(unknown)"),
  C.UTF8 = c(sum(st_utf8 %in% "never"), sum(st_utf8 %in% "current"), sum(st_utf8 %in% "former"), sum(is.na(st_utf8))),
  C = c(sum(st_c %in% "never"), sum(st_c %in% "current"), sum(st_c %in% "former"), sum(is.na(st_c))))
print(loc_tab); wcsv(loc_tab, "locale_status_counts_allages.csv")
stopifnot(identical(st_utf8[!is.na(st_utf8)], ms_enpg_all$status[!is.na(st_utf8)]))

hdr("A3 status by wave, 15-65 (ms_data_audit)"); print(ms_data_audit); wcsv(ms_data_audit, "data_audit.csv")

hdr("A4 g/day formula diagnostics among current drinkers, 15-65")
cur <- ms_enpg[ms_enpg$status == "current", ]
d_days <- as.numeric(ms_raw$oh3); d_ep <- as.numeric(ms_raw$db)
k <- match(paste(cur$year, cur$id), paste(ms_raw$year, as.character(ms_raw$id)))
stopifnot(!anyNA(k))
cur$days <- d_days[k]; cur$ep <- d_ep[k]; cur$drinks <- unname(ms_midpoints[as.character(ms_raw$audit2[k])])
cur$days_ok <- is.finite(cur$days) & cur$days >= 0 & cur$days <= 30
cur$ep_ok <- is.finite(cur$ep) & cur$ep >= 0 & cur$ep < 88
# independent recomputation of the formula
g2 <- ifelse(cur$days_ok & cur$ep_ok & !is.na(cur$drinks),
  (pmax(cur$days - cur$ep, 0) * cur$drinks + cur$ep * ifelse(cur$sex == "male", 5, 4)) * 12 / 30, NA_real_)
stopifnot(identical(is.na(g2), is.na(cur$gpd_survey)), max(abs(g2 - cur$gpd_survey), na.rm = TRUE) < 1e-12)
bd <- ifelse(cur$sex == "male", 5, 4)
a4 <- do.call(rbind, lapply(c(ms_wave_years, 0L), function(y) {
  x <- if (y == 0L) cur else cur[cur$year == y, ]; ok <- is.finite(x$gpd_survey); wx <- x$weight
  bdx <- ifelse(x$sex == "male", 5, 4)
  data.frame(year = if (y == 0L) "all" else as.character(y), n_current = nrow(x),
    days_missing = sum(!x$days_ok), episodes_missing = sum(!x$ep_ok), drinks_missing = sum(is.na(x$drinks)),
    gpd_missing = sum(!ok), hed_missing = sum(is.na(x$hed)),
    w_share_gpd_missing = sum(wx[!ok]) / sum(wx), w_share_hed_missing = sum(wx[is.na(x$hed)]) / sum(wx),
    n_ep_gt_days = sum(ok & x$ep > x$days), w_share_ep_gt_days = sum(wx[ok & x$ep > x$days]) / sum(wx[ok]),
    n_ep_gt_30 = sum(ok & x$ep > 30), n_days0 = sum(ok & x$days == 0),
    # binge day valued at fewer drinks than the typical-day midpoint: more binge days lowers g/day
    n_binge_below_typical = sum(ok & x$ep > 0 & x$drinks > bdx),
    w_share_binge_below_typical_among_hed = sum(wx[ok & x$ep > 0 & x$drinks > bdx]) / sum(wx[ok & x$ep > 0]),
    min_pos_gpd = min(x$gpd_survey[ok & x$gpd_survey > 0]), max_gpd = max(x$gpd_survey[ok]),
    p99_gpd = unname(stats::quantile(x$gpd_survey[ok], 0.99)), max_ep_valid = max(x$ep[x$ep_ok]))
}))
print(a4); wcsv(a4, "gpd_formula_diagnostics_current_15_65.csv")
# illustrative arithmetic of the formula (not data)
ex <- expand.grid(sex = c("male", "female"), days = c(1, 4, 30), episodes = c(0, 2, 30), drinks = c(1, 5.5, 9), stringsAsFactors = FALSE)
ex <- ex[ex$episodes <= ex$days | ex$days == 30, ]
ex$gpd <- (pmax(ex$days - ex$episodes, 0) * ex$drinks + ex$episodes * ifelse(ex$sex == "male", 5, 4)) * 12 / 30
wcsv(ex, "gpd_formula_worked_examples.csv")

hdr("A4b former split: last drink 1-12 months ('>30') vs >1 year, 15-65, weighted share of former and of status-known")
fo <- ms_enpg[ms_enpg$status != "unknown", ]
fo$oh2 <- as.character(ms_raw$oh2)[match(paste(fo$year, fo$id), paste(ms_raw$year, as.character(ms_raw$id)))]
a4b <- do.call(rbind, lapply(ms_wave_years, function(y) { x <- fo[fo$year == y, ]; f <- x$status == "former"
  data.frame(year = y, n_former = sum(f), n_former_1_12m = sum(f & x$oh2 == ">30"),
    w_share_1_12m_of_former = sum(x$weight[f & x$oh2 == ">30"]) / sum(x$weight[f]),
    w_share_1_12m_of_known = sum(x$weight[f & x$oh2 == ">30"]) / sum(x$weight)) }))
print(a4b); wcsv(a4b, "former_split_15_65.csv")

hdr("A5 survey design per wave (full wave, all ages)")
a5 <- do.call(rbind, lapply(ms_wave_years, function(y) {
  w <- ms_enpg_all[ms_enpg_all$year == y, ]
  psu_per_stratum <- if (y == 2020L) NA else tapply(w$psu, w$stratum, function(z) length(unique(z)))
  dom <- w[w$in_domain, ]
  data.frame(year = y, rows = nrow(w), rows_15_65 = nrow(dom), n_strata = length(unique(w$stratum)),
    n_psu = if (y == 2020L) NA else length(unique(paste(w$stratum, w$psu))),
    strata_with_1_psu = if (y == 2020L) NA else sum(psu_per_stratum == 1),
    sum_weight_15_65 = sum(dom$weight), cv_weight = stats::sd(w$weight) / mean(w$weight),
    n_eff_15_65 = sum(dom$weight)^2 / sum(dom$weight^2), design_status = unique(w$design_status))
}))
d16 <- ms_design_cache$waves[["2016"]]
a5$psu_short_key_2016 <- ifelse(a5$year == 2016L, length(unique(paste(d16$commune, d16$psu))), NA)
print(a5); wcsv(a5, "design_by_wave.csv")
lonely <- stats::aggregate(lonely_psu_adjustment_warnings ~ year, ms_targets, sum); print(lonely)

hdr("A6 56-cell targets (ms_targets) + never/former from out_latente (same design)")
nf <- utils::read.csv(file.path(SPEC, "out_latente", "observed_never_former_year_sex_age.csv"))
tg <- merge(ms_targets, nf[c("year", "sex", "age_group", "never", "never_se", "former", "former_se", "current")],
  by = c("year", "sex", "age_group"), all.x = TRUE, sort = TRUE)
stopifnot(nrow(tg) == 56L, !anyNA(tg$never), max(abs(tg$current - tg$current_mean)) < 1e-12,
  max(abs(tg$never + tg$former + tg$current_mean - 1)) < 1e-12)
tg$current <- NULL; tg$period <- ifelse(tg$year <= ms_cfg$train_end, "train", "held-out")
tg <- tg[order(tg$year, tg$sex, tg$age_group), ]
wcsv(tg, "targets_56_full.csv")
cat("max|never+former+current-1| =", max(abs(tg$never + tg$former + tg$current_mean - 1)), "\n")
print(tg[c("year", "sex", "age_group", "n", "n_current", "n_gpd", "n_hed", "current_mean", "current_se", "gpd_mean", "gpd_se", "hed_mean", "hed_se", "never", "former")])
# Independent check of the design means: Hajek ratio = weighted mean
chk <- do.call(rbind, lapply(seq_len(nrow(tg)), function(i) {
  x <- ms_enpg[ms_enpg$year == tg$year[i] & ms_enpg$sex == tg$sex[i] & ms_enpg$age_group == tg$age_group[i], ]
  kc <- !is.na(x$current); c1 <- x$current %in% 1
  g <- c1 & is.finite(x$gpd_survey); h <- c1 & !is.na(x$hed)
  c(cur = weighted.mean(x$current[kc], x$weight[kc]) - tg$current_mean[i],
    gpd = weighted.mean(x$gpd_survey[g], x$weight[g]) - tg$gpd_mean[i],
    hed = weighted.mean(x$hed[h], x$weight[h]) - tg$hed_mean[i])
}))
cat("max |Hajek weighted mean - svymean|:", apply(abs(chk), 2, max), "\n")
stopifnot(max(abs(chk)) < 1e-10)

## B. DEMOGRAPHY ==========================================================================================
hdr("B1 INE stocks 15-65: 01-Jan vs 30-Jun, by year x sex")
b1 <- stats::aggregate(cbind(pop_jan, pop_mid) ~ year + sex, ms_population, sum)
b1$mid_over_jan <- b1$pop_mid / b1$pop_jan
print(b1); wcsv(b1, "ine_stocks_15_65_year_sex.csv")
hdr("B2 HMD columns used; DEIS deaths 15-65 by year x sex")
b2 <- stats::aggregate(cbind(deaths, pop_jan, pop_mid) ~ year + sex, ms_mortality, sum)
b2 <- merge(b2, stats::aggregate(cbind(E1 = pop_jan * qx, Emx_mid = pop_mid * mx) ~ year + sex, ms_mortality, sum))
print(b2[c("year", "sex", "deaths")]); cat("DEIS 2024 file:", ms_deis_enc, "\n")
cat("total deaths 15-65 2012-2024:", sum(ms_mortality$deaths), "\n")

## C. MORTALITY ===========================================================================================
hdr("C1 literal cells: ms-fit-and-check, ms-historical-validation (5 seeds), ms-mortality-concordance")
run_cell("ms-fit-and-check")
run_cell("ms-historical-validation")
run_cell("ms-mortality-concordance")
kap <- ms_calibrated$mortality_scale; print(kap)
stopifnot(max(ms_calibrated$training_years) == 2020L)
kap_tight <- vapply(c("female", "male"), function(s) {
  d <- ms_mortality[ms_mortality$year <= 2020L & ms_mortality$sex == s, ]
  f <- function(l) sum(d$pop_jan * (-expm1(log1p(-d$qx) * exp(l)))) - sum(d$deaths)
  stopifnot(f(-3) < 0, f(3) > 0)
  exp(stats::uniroot(f, c(-3, 3), tol = 1e-12)$root)
}, numeric(1))
kap_year <- do.call(rbind, lapply(split(ms_mortality, list(ms_mortality$year, ms_mortality$sex)), function(d) {
  f <- function(l) sum(d$pop_jan * (-expm1(log1p(-d$qx) * exp(l)))) - sum(d$deaths)
  data.frame(year = d$year[1], sex = d$sex[1], kappa_year = exp(stats::uniroot(f, c(-3, 3), tol = 1e-12)$root))
}))
run_cell("ms-full-refit-projection")
kap_tab <- data.frame(sex = c("female", "male"), kappa_train2020 = unname(kap), kappa_train2020_tol1e12 = unname(kap_tight),
  kappa_refit2024 = unname(ms_full_model$mortality_scale[c("female", "male")]), kappa_uncalibrated = unname(ms_uncalibrated$mortality_scale))
print(kap_tab); wcsv(kap_tab, "kappa.csv")

mm <- ms_mortality
mm$q_star <- -expm1(log1p(-mm$qx) * kap[mm$sex])
mm$q_refit <- -expm1(log1p(-mm$qx) * ms_full_model$mortality_scale[mm$sex])
c2 <- stats::aggregate(cbind(deaths, E1 = pop_jan * qx, E_kappa = pop_jan * q_star, E_refit = pop_jan * q_refit, Emx_mid = pop_mid * mx) ~ year + sex, mm, sum)
c2 <- merge(c2, kap_year)
# January-age shift with HMD itself: parallelogram q_jan(a) = 1 - exp(-(m_a + m_{a+1})/2), needs HMD age 66
hmd66 <- do.call(rbind, lapply(c("male", "female"), function(sx) {
  z <- utils::read.table(ms_path(ms_demography_files[[paste0("hmd_", sx)]]), header = TRUE, skip = 2L, stringsAsFactors = FALSE)
  z <- z[z$Year %in% 2012:2024 & z$Age %in% as.character(15:66), ]
  data.frame(year = as.integer(z$Year), sex = sx, age = as.integer(z$Age), mx = z$mx, qx = z$qx)
}))
h1 <- merge(mm[c("year", "sex", "age", "pop_jan", "mx", "qx")], transform(hmd66[c("year", "sex", "age", "mx")], age = age - 1L, mx1 = mx, mx = NULL))
h1$q_par <- 1 - exp(-(h1$mx + h1$mx1) / 2)
c2 <- merge(c2, stats::aggregate(cbind(E_par = pop_jan * q_par, E1b = pop_jan * qx) ~ year + sex, h1, sum))
c2$rel_err_kappa <- c2$E_kappa / c2$deaths - 1
c2$rel_err_kappa1 <- c2$E1 / c2$deaths - 1
c2$rel_err_refit <- c2$E_refit / c2$deaths - 1
c2$hmd_mx_inemid_over_deis <- c2$Emx_mid / c2$deaths
c2$par_over_naive <- c2$E_par / c2$E1b
c2$period <- ifelse(c2$year <= 2020L, "train", "held-out")
c2 <- merge(c2, as.data.frame(ms_mortality_comparison)[c("year", "sex", "simulated_deaths", "expected_deaths", "mc_sd", "expected_relative_error")])
c2 <- c2[order(c2$sex, c2$year), ]
print(c2); wcsv(c2, "mortality_expected_vs_deis.csv")
train_gap <- sapply(c("female", "male"), function(s) sum(c2$E_kappa[c2$year <= 2020 & c2$sex == s]) / sum(c2$deaths[c2$year <= 2020 & c2$sex == s]) - 1)
cat("training-period sum(E_kappa)/sum(DEIS) - 1 (uniroot default tol):", train_gap, "\n"); stopifnot(all(abs(train_gap) < 1e-3))
slopes <- do.call(rbind, lapply(c("female", "male"), function(s) {
  x <- c2[c2$sex == s, ]; b <- stats::coef(stats::lm(rel_err_kappa ~ year, x))
  bt <- stats::coef(stats::lm(rel_err_kappa ~ year, x[x$year <= 2020 & !(x$year %in% 2020), ]))
  data.frame(sex = s, slope_pp_per_year_2012_2024 = 100 * b[[2]], slope_pp_2012_2019 = 100 * bt[[2]],
    kappa_year_slope_per_year = stats::coef(stats::lm(kappa_year ~ year, x))[[2]],
    sum_heldout_rel_err = sum(x$E_kappa[x$year > 2020]) / sum(x$deaths[x$year > 2020]) - 1,
    rel_err_2022 = x$rel_err_kappa[x$year == 2022], rel_err_2024 = x$rel_err_kappa[x$year == 2024],
    rel_err_2012 = x$rel_err_kappa[x$year == 2012])
}))
print(slopes); wcsv(slopes, "mortality_drift_slopes.csv")
cat("MC diagnostic (ms_mortality_mc):\n"); print(ms_mortality_mc); wcsv(as.data.frame(ms_mortality_mc), "mortality_mc_diagnostic.csv")
# expected_deaths in the engine output equals sum(pop_jan-rounded * q*) * w; compare with INE-scale analytic
c3 <- stats::aggregate(cbind(expected_deaths, deaths, mc_variance) ~ year + sex + seed, ms_validation_deaths, sum)
c3 <- stats::aggregate(cbind(expected_deaths, deaths, mc_variance) ~ year + sex, c3, mean)
c3 <- merge(c3, c2[c("year", "sex", "E_kappa")]); c3$engine_vs_analytic <- c3$expected_deaths / c3$E_kappa - 1
print(summary(c3$engine_vs_analytic)); wcsv(c3, "engine_expected_vs_analytic.csv")
# power form vs linear scaling
pw <- data.frame(max_rel_diff_qstar_vs_kappa_q = max(abs(mm$q_star - kap[mm$sex] * mm$qx) / mm$q_star),
  max_qx = max(mm$qx), H_ratio_check = max(abs(-log1p(-mm$q_star) / (-log1p(-mm$qx)) - kap[mm$sex])))
print(pw); wcsv(pw, "power_form_check.csv")
# 2025-2034: frozen 2024 qx applied to projected INE January stocks (analytic, kappa_refit2024 as in the notebook projection)
proj <- merge(ms_population[ms_population$year >= 2025, c("year", "sex", "age", "pop_jan")],
  ms_mortality[ms_mortality$year == 2024L, c("sex", "age", "qx")])
proj$q <- -expm1(log1p(-proj$qx) * ms_full_model$mortality_scale[proj$sex])
proj_t <- stats::aggregate(cbind(pop_jan, E = pop_jan * q) ~ year + sex, proj, sum); proj_t$rate_per_1000 <- 1000 * proj_t$E / proj_t$pop_jan
print(proj_t); wcsv(proj_t, "projection_expected_deaths_frozen2024.csv")

## D. FLOWS ===============================================================================================
hdr("D1 flows: validation run (train2020, seed 20260917) and full run (refit2024, 2012-2034, seed 20260917)")
fv <- ms_validation_runs[[1]]$flows; ff <- ms_full_run$flows
stopifnot(fv$seed[1] == 20260917L, ff$seed[1] == 20260917L)
print(fv); print(ff); wcsv(fv, "flows_validation_train2020_seed20260917.csv"); wcsv(ff, "flows_full_refit2024_seed20260917.csv")
w <- ff$unit_weight[1]; cat("unit weight =", w, "; INE Jan 2012 15-65 =", sum(ms_population$pop_jan[ms_population$year == 2012]), "\n")
st <- ms_population[ms_population$year %in% 2012:2034, ]
st$n_target <- as.integer(round(st$pop_jan / w))
rt <- stats::aggregate(cbind(pop_jan, n_target) ~ year, st, sum); rt$rounding_rel <- rt$n_target * w / rt$pop_jan - 1
print(rt); wcsv(rt, "rounding_by_year.csv")
# Analytic expectations of the flows, model = refit2024 (as in ff)
qk <- function(y, sx, a) { yy <- pmin(y, 2024L); kk <- match(paste(yy, sx, a), paste(ms_mortality$year, ms_mortality$sex, ms_mortality$age))
  -expm1(log1p(-ms_mortality$qx[kk]) * ms_full_model$mortality_scale[sx]) }
st$q <- qk(st$year, st$sex, st$age)
an <- do.call(rbind, lapply(2012:2033, function(y) {
  a <- st[st$year == y, ]; b <- st[st$year == y + 1L, ]
  surv <- a$n_target * (1 - a$q)
  jb <- match(paste(a$sex, a$age + 1L), paste(b$sex, b$age))      # cohort a -> a+1
  ine_surv <- a$pop_jan * (1 - a$q)
  data.frame(year = y, E_deaths = sum(a$n_target * a$q), E_exits = sum(surv[a$age == 65]),
    entries_det = sum(b$n_target[b$age == 15]),
    E_net_residual = sum(b$n_target[jb[a$age < 65]] - surv[a$age < 65]),
    ine_net_residual_persons = sum(b$pop_jan[jb[a$age < 65]] - ine_surv[a$age < 65]))
}))
d1 <- merge(ff[ff$year <= 2033, c("year", "start", "deaths", "age_exits", "age_entries", "residual_inflow", "residual_outflow", "end")], an)
d1$net_residual <- d1$residual_inflow - d1$residual_outflow
print(d1); wcsv(d1, "flows_vs_analytic_refit2024.csv")
stopifnot(all(d1$age_entries == d1$entries_det),
  all(ff$end == ff$start - ff$deaths - ff$age_exits - ff$residual_outflow + ff$age_entries + ff$residual_inflow),
  all(utils::head(ff$end, -1) == ff$start[-1]),
  all(utils::head(ff$end, -1) == rt$n_target[rt$year %in% 2013:2034]))
cat("max |net_residual - E_net_residual| =", max(abs(d1$net_residual - d1$E_net_residual)),
    "; max |deaths - E_deaths| / sqrt(E) =", max(abs(d1$deaths - d1$E_deaths) / sqrt(d1$E_deaths)), "\n")
# gross vs net residual flows in persons
gross <- data.frame(period = c("2012-2023", "2024-2033"),
  inflow_persons = c(sum(ff$residual_inflow[ff$year <= 2023]), sum(ff$residual_inflow[ff$year %in% 2024:2033])) * w,
  outflow_persons = c(sum(ff$residual_outflow[ff$year <= 2023]), sum(ff$residual_outflow[ff$year %in% 2024:2033])) * w,
  ine_net_persons = c(sum(d1$ine_net_residual_persons[d1$year <= 2023]), sum(d1$ine_net_residual_persons[d1$year >= 2024])))
print(gross); wcsv(gross, "gross_vs_net_residual.csv")

## E. 66+ DEATHS ==========================================================================================
hdr("E1 share of deaths at ages 66+ among deaths 15+ (DEIS 2012-2023 bundle + 2024 acc_deis)")
old <- py_read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]), c("year", "gender", "age"))
old <- old[old$year %in% 2012:2023 & old$gender %in% c("Hombre", "Mujer") & old$age >= 15, ]
new <- as.data.frame(acc_deis()[c("AÑO", "SEXO_NOMBRE", "EDAD_TIPO", "EDAD_CANT")]); names(new) <- c("year", "gender", "age_type", "age")
new <- new[new$year == 2024L & new$age_type == 1L & new$age >= 15 & new$gender %in% c("Hombre", "Mujer"), c("year", "gender", "age")]
dd <- rbind(old, new); dd$sex <- ifelse(dd$gender == "Hombre", "male", "female")
dd$band <- cut(dd$age, c(14, 65, 66, 79, Inf), labels = c("15-65", "66", "67-79", "80+"))
e1 <- as.data.frame.matrix(table(dd$sex, dd$band)); e1$sex <- rownames(e1)
e1$share_66plus <- 1 - e1[["15-65"]] / rowSums(e1[c("15-65", "66", "67-79", "80+")])
e1y <- as.data.frame.matrix(table(paste(dd$year, dd$sex), dd$age >= 66)); names(e1y) <- c("d15_65", "d66plus")
e1y$share_66plus <- e1y$d66plus / (e1y$d15_65 + e1y$d66plus)
print(e1); print(e1y); wcsv(e1, "deaths_by_band_sex_2012_2024.csv"); wcsv(cbind(key = rownames(e1y), e1y), "deaths_66plus_share_year_sex.csv")
stopifnot(all(stats::aggregate(deaths ~ sex, ms_mortality, sum)$deaths == e1[c("female", "male"), "15-65"]))
rm(old, new, dd)
message(sprintf("dossier_insumos_demografia elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t_script, units = "mins"))))
