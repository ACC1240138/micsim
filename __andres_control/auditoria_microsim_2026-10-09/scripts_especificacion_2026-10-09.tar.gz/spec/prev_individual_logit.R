# Contrast: the code's cell-level WLS-on-logit vs an individual-level survey-weighted logistic (same linear predictor).
# Point estimates of glm(quasibinomial, weights) equal those of survey::svyglm on the pooled 2012-2020 file.
# Microdata stay in memory; writes only coefficients and cell-level held-out errors.
.t0_il <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "prev_out")
wls <- ms_fit(2020L, trend = TRUE)$prevalence
d <- ms_enpg[ms_enpg$year <= 2020L & !is.na(ms_enpg$current), ]
d$cell <- factor(paste(d$sex, d$age_group, sep = ":"), levels = wls$xlevels$cell); d$time <- (d$year - 2012) / 10
d$w <- d$weight / mean(d$weight)  # rescaling does not change point estimates
il <- stats::glm(current ~ 0 + cell + cell:time, family = stats::quasibinomial(), weights = w, data = d)
stopifnot(il$converged, identical(names(stats::coef(il)), names(stats::coef(wls))))
cf <- data.frame(parameter = names(stats::coef(wls)), wls = unname(stats::coef(wls)), indiv_logit = unname(stats::coef(il)))
cf$diff <- cf$indiv_logit - cf$wls
print(cf, digits = 4)
ho <- ms_targets[ms_targets$year > 2020L, ]
nd <- data.frame(cell = factor(paste(ho$sex, ho$age_group, sep = ":"), levels = wls$xlevels$cell), time = (ho$year - 2012) / 10)
e_w <- plogis(stats::predict(wls, newdata = nd)) - ho$current_mean
e_i <- plogis(stats::predict(il, newdata = nd)) - ho$current_mean
res <- data.frame(estimator = c("WLS logit of cell means (code)", "individual weighted logistic"),
  heldout_bias_pp = 100 * c(mean(e_w), mean(e_i)), heldout_rmse_pp = 100 * c(sqrt(mean(e_w^2)), sqrt(mean(e_i^2))),
  max_abs_coef_diff = c(0, max(abs(cf$diff))))
print(res, digits = 4)
utils::write.csv(cf, file.path(OUT, "prev_individual_logit_coef.csv"), row.names = FALSE)
utils::write.csv(res, file.path(OUT, "prev_individual_logit_heldout.csv"), row.names = FALSE)
message(sprintf("prev_individual_logit.R elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0_il, units = "mins"))))
