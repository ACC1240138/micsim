# Analytic (no engine) held-out error of simple prevalence rules fitted on 2012-2020 cell targets.
# Input: aggregate cell table prev_targets_56.csv written by prev_validation.R. Run: Rscript --vanilla <file>
.t0 <- Sys.time()
OUT <- "<scratch>/spec/prev_out"
tg <- utils::read.csv(file.path(OUT, "prev_targets_56.csv"))
tg$cell <- paste(tg$sex, tg$age_group, sep = ":"); tg$time <- (tg$year - 2012) / 10
tr <- tg[tg$set == "train", ]; ho <- tg[tg$set == "held-out", ]
lin <- stats::lm(logit_p ~ 0 + factor(cell) + factor(cell):time, data = tr, weights = w_current)
flat <- stats::lm(logit_p ~ 0 + factor(cell), data = tr, weights = w_current)
nd <- ho; nd$time <- (pmin(nd$year, 2024) - 2012) / 10
rules <- list(
  linear_wls = plogis(stats::predict(lin, newdata = nd)),
  flat_wls_mean_2012_2020 = plogis(stats::predict(flat, newdata = nd)),
  static_2012 = tr$current_mean[tr$year == 2012][match(ho$cell, tr$cell[tr$year == 2012])],
  hold_last_2020 = tr$current_mean[tr$year == 2020][match(ho$cell, tr$cell[tr$year == 2020])])
res <- do.call(rbind, lapply(names(rules), function(r) { e <- rules[[r]] - ho$current_mean
  data.frame(rule = r, bias_pp = 100 * mean(e), rmse_pp = 100 * sqrt(mean(e^2)),
    n_in_95 = sum(abs(e) <= stats::qnorm(0.975) * ho$current_se), n = length(e)) }))
stopifnot(nrow(res) == 4L, all(res$n == 16L))
print(res, digits = 4)
utils::write.csv(res, file.path(OUT, "prev_naive_rules_heldout.csv"), row.names = FALSE)
message(sprintf("prev_naive_rules.R elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
