# Projection 2025-2034 analytic expected deaths (qx frozen 2024, kappa refit 2012-2024). Aggregates only.
.t0x <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
k <- ms_fit(2024)$mortality_scale
q24 <- ms_mortality[ms_mortality$year == 2024, c("sex", "age", "qx")]
p <- merge(ms_population[ms_population$year >= 2025, c("year", "sex", "age", "pop_jan")], q24)
p$E <- p$pop_jan * (1 - (1 - p$qx)^k[p$sex])
a <- stats::aggregate(cbind(pop_jan, E) ~ year + sex, p, sum); a$per1000 <- 1000 * a$E / a$pop_jan
print(a[a$year %in% c(2025, 2034), ])
m <- ms_mortality; m$E <- m$pop_jan * (1 - (1 - m$qx)^k[m$sex])
b <- stats::aggregate(cbind(E, deaths) ~ sex, m[m$year == 2024, ], sum); b$err <- b$E / b$deaths - 1; print(b)
utils::write.csv(a, file.path(SPEC, "verify_demo", "projection_verify.csv"), row.names = FALSE)
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0x, units = "mins"))))
