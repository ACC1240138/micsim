# Format aggregate CSVs in prev_out/ as Markdown tables (decimal comma) for the dossier.
.t0 <- Sys.time()
setwd("<scratch>/spec/prev_out")
f <- function(x, d) gsub(".", ",", formatC(x, format = "f", digits = d), fixed = TRUE)
lab <- c("female:1" = "M 15–29", "female:2" = "M 30–44", "female:3" = "M 45–59", "female:4" = "M 60–65",
  "male:1" = "H 15–29", "male:2" = "H 30–44", "male:3" = "H 45–59", "male:4" = "H 60–65")
md <- function(df) { cat("| ", paste(names(df), collapse = " | "), " |\n|", paste(rep("---", ncol(df)), collapse = "|"), "|\n", sep = "")
  for (i in seq_len(nrow(df))) cat("| ", paste(df[i, ], collapse = " | "), " |\n", sep = ""); cat("\n") }
t <- read.csv("prev_targets_56.csv"); t$cell <- lab[paste(t$sex, t$age_group, sep = ":")]
w <- reshape(data.frame(cell = t$cell, year = t$year, v = paste0(f(100 * t$current_mean, 2), " (", f(100 * t$current_se, 2), ")")),
  idvar = "cell", timevar = "year", direction = "wide"); names(w) <- sub("v.", "", names(w)); md(w[match(lab, w$cell), ])
w <- reshape(data.frame(cell = t$cell, year = t$year, v = paste0(t$n, " / ", f(t$n_eff, 0))), idvar = "cell", timevar = "year", direction = "wide")
names(w) <- sub("v.", "", names(w)); md(w[match(lab, w$cell), ])
c <- read.csv("prev_coef.csv"); c$cell <- lab[c$cell]
for (fit in c("train2020", "refit2024")) { x <- c[c$fit == fit, ]
  md(data.frame(celda = x$cell, n = x$n_obs, alpha = f(x$alpha, 4), EE_lm = f(x$se_alpha_lm, 4), EE_conocida = f(x$se_alpha_known, 4),
    beta = f(x$beta, 4), EE_lm_b = f(x$se_beta_lm, 4), EE_conocida_b = f(x$se_beta_known, 4), t_beta = f(x$t_beta_lm, 2)))
  cat(fit, "sigma2", f(x$sigma2[1], 3), "df", x$df_resid[1], "wrss", f(x$wrss[1], 1), "p", format(x$p_chisq_known[1], digits = 3), "\n\n") }
p <- read.csv("prev_pc_by_year.csv"); p$cell <- lab[p$cell]
for (fit in c("train2020", "refit2024")) { x <- p[p$fit == fit & p$year %in% c(2012, 2016, 2020, 2022, 2024, 2025), ]
  x$v <- paste0(f(100 * x$pc, 1), " [", f(100 * x$lo, 1), "; ", f(100 * x$hi, 1), "]")
  w <- reshape(x[, c("cell", "year", "v")], idvar = "cell", timevar = "year", direction = "wide"); names(w) <- sub("v.", "", names(w))
  u <- p[p$fit == fit & p$year == 2034, ]; w$`2034 sin congelar` <- f(100 * u$pc_unfrozen_2034[match(w$cell, u$cell)], 1)
  names(w)[names(w) == "2025"] <- "2025–2034 (congelado)"; md(w[match(lab, w$cell), ]) }
v <- read.csv("prev_validation_cells_current.csv"); v <- v[v$year >= 2022, ]; v$cell <- lab[paste(v$sex, v$age_group, sep = ":")]
md(data.frame(año = v$year, celda = v$cell, observado = f(100 * v$observed, 2), EE = f(100 * v$se, 2), simulado = f(100 * v$simulated, 2),
  pc_analitico = f(100 * v$p_current, 2), DE_MC = f(100 * v$mc_sd, 2), error_pp = f(100 * v$error, 2), z = f(v$standardized_error, 2)))
message(sprintf("prev_md_tables.R elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
