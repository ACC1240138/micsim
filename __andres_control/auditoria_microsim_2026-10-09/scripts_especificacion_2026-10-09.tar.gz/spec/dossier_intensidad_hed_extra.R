# Follow-up to dossier_intensidad_hed.R: per-seed HED/gpd errors (MC spread of S - C), F-test cell vs additive,
# and small worked-example numbers. Writes aggregates only to spec/out_ihc/.
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
.t0 <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "out_ihc")
run_cell("ms-fit-and-check"); run_cell("ms-historical-validation")
options(width = 200)
# 1. Per-seed simulated cell summaries (aggregate) and per-seed mean errors.
utils::write.csv(ms_validation_summary, file.path(OUT, "validation_summary_5seeds_cells.csv"), row.names = FALSE)
dec <- utils::read.csv(file.path(OUT, "hed_decomposition_cells.csv"))
x <- merge(as.data.frame(ms_validation_summary)[c("year", "sex", "age_group", "seed", "hed_mean", "gpd_mean")],
  dec[c("year", "sex", "age_group", "period", "T", "C")], by = c("year", "sex", "age_group"))
amt <- utils::read.csv(file.path(OUT, "amount_cells_cell_vs_additive.csv"))
x <- merge(x, amt[c("year", "sex", "age_group", "gpd_mean", "mu_cell")], by = c("year", "sex", "age_group"), suffixes = c("_sim", "_obs"))
ps <- do.call(rbind, lapply(split(x, list(x$seed, x$period)), function(d) data.frame(seed = d$seed[1], period = d$period[1],
  hed_S_T = mean(d$hed_mean - d$T), hed_S_C = mean(d$hed_mean - d$C), gpd_S_mu = mean(d$gpd_mean_sim - d$mu_cell))))
print(ps, digits = 4)
print(aggregate(cbind(hed_S_T, hed_S_C, gpd_S_mu) ~ period, ps, function(v) c(mean = mean(v), sd = sd(v), se_mean = sd(v) / sqrt(length(v)))), digits = 4)
utils::write.csv(ps, file.path(OUT, "per_seed_errors.csv"), row.names = FALSE)
# 2. F-test additive (6 par.) vs cell-specific (16 par.) WLS on the 40 training targets.
tr <- ms_targets[ms_targets$year <= 2020, ]; tr$time <- (tr$year - 2012) / 10
tr$cell <- factor(paste(tr$sex, tr$age_group, sep = ":")); tr$y <- log(tr$gpd_mean); tr$w <- (tr$gpd_mean / tr$gpd_se)^2
a <- lm(y ~ sex + factor(age_group) + time, tr, weights = w); b <- lm(y ~ 0 + cell + cell:time, tr, weights = w)
print(anova(a, b))
cat("chi2 tests vs design variance only: cell p =", pchisq(sum(tr$w * resid(b)^2), 24, lower.tail = FALSE),
    "; additive p =", pchisq(sum(tr$w * resid(a)^2), 34, lower.tail = FALSE), "\n")
# 3. Worked-example extras.
d <- ms_drivers(ms_calibrated, 2016:2017); dm <- d[d$sex == "male" & d$age_group == 2, ]
cat("z_hed threshold for HED=0 in 2017:", qnorm(plogis(dm$hed_intercept[2] + dm$hed_slope[2] * log1p(7.4343715))), "\n")
f3 <- d[d$sex == "female" & d$age_group == 3 & d$year == 2016, ]
cat("female:3 p0 =", f3$p_zero, "; U_status = pnorm(-0.6) =", pnorm(-0.6), "; user U/p0 =", pnorm(-0.6) / f3$p_zero,
    "; P(U/p0 <= 1 | current) = p0/pc =", f3$p_zero / f3$p_current, "\n")
cat("max over cells of p0 * plogis(intercept) (HED the user's rule would give to zero-gpd drinkers):",
    max(ms_calibrated$shape$p_zero * plogis(stats::coef(ms_calibrated$hed)[paste0("cell", ms_calibrated$shape$sex, ":", ms_calibrated$shape$age_group)])), "\n")
cat(sprintf("elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
