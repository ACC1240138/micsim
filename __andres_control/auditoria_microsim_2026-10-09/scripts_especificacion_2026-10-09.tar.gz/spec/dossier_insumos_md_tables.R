# Formats spec/out_demo/*.csv (aggregates only) as Markdown tables with decimal comma -> spec/out_demo/tables.md
# Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
.t0 <- Sys.time()
D <- "<scratch>/spec/out_demo"
rd <- function(f) utils::read.csv(file.path(D, f), stringsAsFactors = FALSE)
nf <- function(x, d = 0) formatC(x, format = "f", digits = d, big.mark = ".", decimal.mark = ",")
pc <- function(x, d = 1) nf(100 * x, d)
sg <- function(x, d = 2) ifelse(x > 0, paste0("+", nf(x, d)), nf(x, d))
md <- function(df, title) {
  c(paste0("### ", title), "", paste0("| ", paste(names(df), collapse = " | "), " |"),
    paste0("|", paste(rep("---", ncol(df)), collapse = "|"), "|"),
    apply(df, 1, function(r) paste0("| ", paste(r, collapse = " | "), " |")), "")
}
sx <- function(s) ifelse(s == "female", "M", "H")
ag <- c("15–29", "30–44", "45–59", "60–65")
out <- character()

t <- rd("targets_56_full.csv")
out <- c(out, md(data.frame(Año = t$year, Sexo = sx(t$sex), Edad = ag[t$age_group], n = nf(t$n), `n act.` = nf(t$n_current),
  `Actual % (EE)` = paste0(pc(t$current_mean), " (", pc(t$current_se), ")"),
  `g/d entre act. (EE)` = paste0(nf(t$gpd_mean, 2), " (", nf(t$gpd_se, 2), ")"), `n g/d` = nf(t$n_gpd),
  `HED % entre act. (EE)` = paste0(pc(t$hed_mean), " (", pc(t$hed_se), ")"), `n HED` = nf(t$n_hed),
  `Nunca % (EE)` = paste0(pc(t$never), " (", pc(t$never_se), ")"), `Ex % (EE)` = paste0(pc(t$former), " (", pc(t$former_se), ")"),
  `n_eff` = nf(t$n_eff), check.names = FALSE), "T-A1. Las 56 celdas objetivo (ENPG, diseño por ola)"))

a <- rd("data_audit.csv")
out <- c(out, md(data.frame(Ola = a$year, `Filas ola` = nf(a$raw_n), `15–65` = nf(a$domain_n), Nunca = nf(a$never_n), Ex = nf(a$former_n),
  Actual = nf(a$current_n), Desconocido = nf(a$unknown_status), `Act. g/d NA` = nf(a$current_gpd_missing), `Act. g/d = 0` = nf(a$current_gpd_zero),
  `Act. HED NA` = nf(a$current_hed_missing), Diseño = a$design_status, check.names = FALSE), "T-A2. Conteos por ola (ms_data_audit, 15–65)"))

g <- rd("gpd_formula_diagnostics_current_15_65.csv")
out <- c(out, md(data.frame(Ola = g$year, `n act.` = nf(g$n_current), `días NA` = nf(g$days_missing), `episodios NA` = nf(g$episodes_missing),
  `tragos NA` = nf(g$drinks_missing), `% g/d NA (pond.)` = pc(g$w_share_gpd_missing), `% HED NA (pond.)` = pc(g$w_share_hed_missing),
  `episodios > días: n (% pond.)` = paste0(nf(g$n_ep_gt_days), " (", pc(g$w_share_ep_gt_days), ")"), `episodios > 30` = nf(g$n_ep_gt_30),
  `día binge < día típico: n (% de HED, pond.)` = paste0(nf(g$n_binge_below_typical), " (", pc(g$w_share_binge_below_typical_among_hed), ")"),
  `mín. g/d > 0` = nf(g$min_pos_gpd, 1), `p99 g/d` = nf(g$p99_gpd, 1), `máx. g/d` = nf(g$max_gpd, 1), check.names = FALSE),
  "T-A3. Diagnóstico de la fórmula g/día entre consumidores actuales 15–65"))

f <- rd("former_split_15_65.csv")
out <- c(out, md(data.frame(Ola = f$year, `n ex` = nf(f$n_former), `n ex con último trago hace 1–12 meses (">30")` = nf(f$n_former_1_12m),
  `% pond. de los ex` = pc(f$w_share_1_12m_of_former), `% pond. de la población 15–65 con estado conocido` = pc(f$w_share_1_12m_of_known), check.names = FALSE),
  "T-A4. Composición de los 'ex' (FD) 15–65"))

d <- rd("design_by_wave.csv")
out <- c(out, md(data.frame(Ola = d$year, Filas = nf(d$rows), `Estratos` = nf(d$n_strata), `UPM` = ifelse(is.na(d$n_psu), "—", nf(d$n_psu)),
  `Estratos con 1 UPM (ola)` = ifelse(is.na(d$strata_with_1_psu), "—", nf(d$strata_with_1_psu)), `CV pesos` = nf(d$cv_weight, 2),
  `n_eff Kish 15–65` = nf(d$n_eff_15_65), `Suma pesos 15–65` = nf(d$sum_weight_15_65), Estado = d$design_status, check.names = FALSE),
  "T-A5. Diseño muestral por ola"))

i <- rd("ine_stocks_15_65_year_sex.csv")
iw <- merge(i[i$sex == "female", ], i[i$sex == "male", ], by = "year", suffixes = c("_f", "_m"))
out <- c(out, md(data.frame(Año = iw$year, `M 01-ene` = nf(iw$pop_jan_f), `M 30-jun` = nf(iw$pop_mid_f), `H 01-ene` = nf(iw$pop_jan_m),
  `H 30-jun` = nf(iw$pop_mid_m), `30-jun/01-ene − 1 (M, H) %` = paste0(pc(iw$mid_over_jan_f - 1, 2), "; ", pc(iw$mid_over_jan_m - 1, 2)), check.names = FALSE),
  "T-B1. Stocks INE 15–65"))

k <- rd("kappa.csv")
out <- c(out, md(data.frame(Sexo = sx(k$sex), `κ train 2012–2020 (uniroot por defecto)` = nf(k$kappa_train2020, 6),
  `κ train, tol 1e-12` = nf(k$kappa_train2020_tol1e12, 6), `κ reajuste 2012–2024 (proyección)` = nf(k$kappa_refit2024, 6),
  `κ comparador estático` = nf(k$kappa_uncalibrated, 0), check.names = FALSE), "T-C1. Multiplicador κ_s"))

m <- rd("mortality_expected_vs_deis.csv"); m <- m[order(m$sex, m$year), ]
out <- c(out, md(data.frame(Año = m$year, Sexo = sx(m$sex), Período = ifelse(m$period == "train", "train", "post-train"),
  DEIS = nf(m$deaths), `κ=1: Σ N_ene·qx` = nf(m$E1), `Esperadas κ_train` = nf(m$E_kappa), `Error %` = sg(100 * m$rel_err_kappa),
  `Error % κ=1` = sg(100 * m$rel_err_kappa1), `Error % κ reajuste` = sg(100 * m$rel_err_refit), `κ_t del año` = nf(m$kappa_year, 4),
  `Σ N_jun·mx / DEIS` = nf(m$hmd_mx_inemid_over_deis, 3), `paralelogramo/ingenuo` = nf(m$par_over_naive, 3),
  `Simuladas (media 5 sem.)` = nf(m$simulated_deaths), `DE MC entre sem.` = nf(m$mc_sd), check.names = FALSE),
  "T-C2. Muertes 15–65 esperadas frente a DEIS"))

s <- rd("mortality_drift_slopes.csv")
out <- c(out, md(data.frame(Sexo = sx(s$sex), `Pendiente error (pp/año) 2012–2024` = nf(s$slope_pp_per_year_2012_2024, 3),
  `Pendiente 2012–2019` = nf(s$slope_pp_2012_2019, 3), `Pendiente κ_t por año` = nf(s$kappa_year_slope_per_year, 5),
  `Error 2012 %` = sg(100 * s$rel_err_2012), `Error 2022 %` = sg(100 * s$rel_err_2022), `Error 2024 %` = sg(100 * s$rel_err_2024),
  `Error acumulado 2021–2024 %` = sg(100 * s$sum_heldout_rel_err), check.names = FALSE), "T-C3. Deriva"))

mc <- rd("mortality_mc_diagnostic.csv")
out <- c(out, md(data.frame(Semilla = mc$seed, Realizadas = nf(mc$realized), Esperadas = nf(mc$expected), `DE condicional` = nf(mc$conditional_sd),
  z = nf(mc$z_mc, 3), check.names = FALSE), "T-C4. Diagnóstico Monte Carlo 2012–2024 (ms_mortality_mc)"))

p <- rd("projection_expected_deaths_frozen2024.csv")
pw <- merge(p[p$sex == "female", ], p[p$sex == "male", ], by = "year", suffixes = c("_f", "_m"))
out <- c(out, md(data.frame(Año = pw$year, `N_ene M` = nf(pw$pop_jan_f), `Esperadas M` = nf(pw$E_f), `por 1.000 M` = nf(pw$rate_per_1000_f, 3),
  `N_ene H` = nf(pw$pop_jan_m), `Esperadas H` = nf(pw$E_m), `por 1.000 H` = nf(pw$rate_per_1000_m, 3), check.names = FALSE),
  "T-C5. Proyección 2025–2034: qx congelado en 2024, κ reajuste"))

fl <- rd("flows_vs_analytic_refit2024.csv"); ff <- rd("flows_full_refit2024_seed20260917.csv")
fl <- merge(ff[c("year", "start", "deaths", "age_exits", "age_entries", "residual_inflow", "residual_outflow", "end", "end_definition")],
  fl[c("year", "E_deaths", "E_exits", "E_net_residual", "ine_net_residual_persons")], all.x = TRUE)
fl$id_ok <- fl$end == fl$start - fl$deaths - fl$age_exits - fl$residual_outflow + fl$age_entries + fl$residual_inflow
out <- c(out, md(data.frame(Año = fl$year, `Inicio (1-ene)` = nf(fl$start), Muertes = nf(fl$deaths), `E[muertes]` = nf(fl$E_deaths, 1),
  `Salidas a 66` = nf(fl$age_exits), `E[salidas]` = nf(fl$E_exits, 1), `Entradas a 15` = nf(fl$age_entries),
  `Inflow residual` = nf(fl$residual_inflow), `Outflow residual` = nf(fl$residual_outflow),
  `Neto residual (E)` = ifelse(is.na(fl$E_net_residual), "—", paste0(nf(fl$residual_inflow - fl$residual_outflow), " (", nf(fl$E_net_residual, 1), ")")),
  `Neto INE implícito (personas)` = ifelse(is.na(fl$ine_net_residual_persons), "—", nf(fl$ine_net_residual_persons)),
  Fin = nf(fl$end), Identidad = ifelse(fl$id_ok, "OK", "FALLA"), check.names = FALSE),
  "T-D1. Flujos de personas sintéticas, corrida completa 2012–2034 (modelo reajuste 2024, semilla 20260917, peso 481,249)"))
fv <- rd("flows_validation_train2020_seed20260917.csv")
out <- c(out, md(data.frame(Año = fv$year, Inicio = nf(fv$start), Muertes = nf(fv$deaths), `Salidas 66` = nf(fv$age_exits),
  `Entradas 15` = nf(fv$age_entries), Inflow = nf(fv$residual_inflow), Outflow = nf(fv$residual_outflow), Fin = nf(fv$end),
  `Cambios de estado actual` = nf(fv$status_changes), `n transición` = nf(fv$transition_n), check.names = FALSE),
  "T-D2. Flujos, corrida de validación 2012–2024 (modelo train 2020, semilla 20260917)"))
r <- rd("rounding_by_year.csv")
out <- c(out, md(data.frame(Año = r$year, `INE 01-ene 15–65` = nf(r$pop_jan), `n_target` = nf(r$n_target),
  `Error de redondeo (×10⁻⁴)` = sg(1e4 * r$rounding_rel, 2), check.names = FALSE), "T-D3. Redondeo de stocks a personas sintéticas"))
gr <- rd("gross_vs_net_residual.csv")
out <- c(out, md(data.frame(Período = gr$period, `Inflow (personas)` = nf(gr$inflow_persons), `Outflow (personas)` = nf(gr$outflow_persons),
  `Neto INE implícito (personas)` = nf(gr$ine_net_persons), check.names = FALSE), "T-D4. Flujos residuales brutos y neto"))

e <- rd("deaths_66plus_share_year_sex.csv")
e$year <- substr(e$key, 1, 4); e$sex <- substr(e$key, 6, 20)
ew <- merge(e[e$sex == "female", ], e[e$sex == "male", ], by = "year", suffixes = c("_f", "_m"))
eb <- rd("deaths_by_band_sex_2012_2024.csv")
out <- c(out, md(data.frame(Año = c(ew$year, "2012–2024"), `M 15–65` = nf(c(ew$d15_65_f, eb$X15.65[eb$sex == "female"])),
  `M 66+` = nf(c(ew$d66plus_f, sum(eb[eb$sex == "female", c("X66", "X67.79", "X80.")]))),
  `M % 66+` = pc(c(ew$share_66plus_f, eb$share_66plus[eb$sex == "female"])),
  `H 15–65` = nf(c(ew$d15_65_m, eb$X15.65[eb$sex == "male"])), `H 66+` = nf(c(ew$d66plus_m, sum(eb[eb$sex == "male", c("X66", "X67.79", "X80.")]))),
  `H % 66+` = pc(c(ew$share_66plus_m, eb$share_66plus[eb$sex == "male"])), check.names = FALSE), "T-E1. Muertes DEIS de 15+ años: 15–65 frente a 66+"))
out <- c(out, md(data.frame(Sexo = sx(eb$sex), `15–65` = nf(eb$X15.65), `66` = nf(eb$X66), `67–79` = nf(eb$X67.79), `80+` = nf(eb$X80.), check.names = FALSE),
  "T-E2. Muertes DEIS 2012–2024 por tramo"))
writeLines(out, file.path(D, "tables.md"))
message(sprintf("md tables elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
