# Load the BASE microsimulation engine (__andres_control/microsim_base_ACC_2012_2024.ipynb) for Rscript --vanilla.
# Cells are extracted verbatim to spec/base_cells/*.R; only these substitutions are applied:
#  - arrow/knitr/IRdisplay/ggplot2 are not installed here: parquet read via python3 into R tempdir() only;
#  - ms_table() is a no-op.
# Microdata-derived objects (ms_enpg, ...) live only in memory / R tempdir(); never write them to disk.
.t0_load <- Sys.time()
SPEC <- "<scratch>/spec"
setwd("<repo>/__andres_control")
Sys.setlocale("LC_ALL", "C.UTF-8")  # the '> 1 año' match fails under a C locale
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
py_read_parquet <- function(path, col_select) {
  out <- tempfile(tmpdir = tempdir(), fileext = ".csv")
  code <- sprintf("import pandas as pd; pd.read_parquet(r'%s', columns=%s).to_csv(r'%s', index=False)",
    path, paste0("[", paste0("'", col_select, "'", collapse = ","), "]"), out)
  stopifnot(system2("python3", c("-I", "-c", shQuote(code))) == 0)
  d <- utils::read.csv(out, stringsAsFactors = FALSE); unlink(out); d[col_select]
}
run_cell <- function(label, subs = list(), quiet = TRUE) {
  src <- paste(readLines(file.path(SPEC, "base_cells", paste0(label, ".R")), warn = FALSE), collapse = "\n")
  for (s in subs) { stopifnot(grepl(s[[1]], src, fixed = TRUE)); src <- gsub(s[[1]], s[[2]], src, fixed = TRUE) }
  exprs <- parse(text = src)
  if (quiet) utils::capture.output(for (e in exprs) eval(e, envir = globalenv())) else
    for (e in exprs) eval(e, envir = globalenv())
  invisible(TRUE)
}
run_cell("ms-setup", list(
  list('"arrow", "knitr", "IRdisplay", "ggplot2"', '"here"'),
  list('IRdisplay::display_html(base::as.character(knitr::kable(x, format = "html", digits = 4,\n    row.names = FALSE, caption = caption)))',
       'base::invisible(NULL)')))
run_cell("ms-survey-inputs")
run_cell("ms-demography-inputs", list(
  list('base::as.data.frame(arrow::read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]),\n  col_select = base::c("year", "gender", "age")))',
       'py_read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]), base::c("year", "gender", "age"))')))
run_cell("ms-calibration-functions")
run_cell("ms-annual-engine")
stopifnot(nrow(ms_targets) == 56L, exists("ms_enpg"), exists("ms_mortality"), exists("ms_simulate"), ms_cfg$train_end == 2020L)
message(sprintf("load_base_engine elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0_load, units = "mins"))))
