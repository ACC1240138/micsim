# Independent verification of dossier_prevalencia_validacion.md (BASE spec). Own code; reuses only the loader + ms_simulate/ms_fit.
# Writes ONLY aggregates to spec/verify_prev_out/. Run: cd <home> && LANG=C.UTF-8 Rscript --vanilla <this file>
.t0_v <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
OUT <- file.path(SPEC, "verify_prev_out"); dir.create(OUT, showWarnings = FALSE)
wcsv <- function(x, f) utils::write.csv(x, file.path(OUT, f), row.names = FALSE)
options(width = 200)
cellid <- function(s, a) paste(s, a, sep = ":")

# ---- V1. Targets: own Hajek mean + own linearized SE (no lonely-PSU adjustment) ----------------
own <- do.call(rbind, lapply(seq(2012L, 2024L, 2L), function(yy) {
  d <- ms_enpg_all[ms_enpg_all$year == yy, ]
  psu <- if (yy == 2020L) paste0("i", seq_len(nrow(d))) else paste(d$stratum, d$psu, sep = "#")
  str <- if (yy == 2020L) rep("all", nrow(d)) else d$stratum
  do.call(rbind, lapply(c("female", "male"), function(s) do.call(rbind, lapply(1:4, function(a) {
    D <- d$in_domain & d$sex == s & d$age_group == a & !is.na(d$current)
    W <- sum(d$weight[D]); p <- sum(d$weight[D] * d$current[D]) / W
    z <- ifelse(D, d$weight * (d$current - p) / W, 0)
    Z <- rowsum(z, psu); hs <- str[match(rownames(Z), psu)]
    nh <- tabulate(factor(hs)); names(nh) <- levels(factor(hs))
    Zbar <- ave(Z[, 1], hs); n_h <- nh[hs]
    v <- sum(ifelse(n_h > 1, n_h / (n_h - 1) * (Z[, 1] - Zbar)^2, 0))
    # domain-lonely strata: strata where exactly one PSU has domain members (current only)
    dom_psu <- unique(psu[D]); lonely <- sum(table(str[match(dom_psu, psu)]) == 1L)
    wD <- d$weight[D]
    data.frame(year = yy, sex = s, age_group = a, p_own = p, se_own = sqrt(v),
      n_eff_own = sum(wD)^2 / sum(wD^2), lonely_strata_current = lonely, singleton_strata_full = sum(nh == 1))
  }))))
}))
tg <- merge(ms_targets[, c("year", "sex", "age_group", "current_mean", "current_se", "n_eff", "lonely_psu_adjustment_warnings")], own)
tg$d_p <- tg$p_own - tg$current_mean; tg$se_ratio <- tg$se_own / tg$current_se
cat("V1 Hajek p max|diff|:", signif(max(abs(tg$d_p)), 3), " n_eff max|diff|:", signif(max(abs(tg$n_eff_own - tg$n_eff)), 3), "\n")
print(do.call(rbind, lapply(split(tg, tg$year), function(x) data.frame(year = x$year[1],
  se_ratio_min = min(x$se_ratio), se_ratio_max = max(x$se_ratio), mean_se_pp = 100 * mean(x$current_se),
  mean_neff = mean(x$n_eff), lonely_warn_all3 = sum(x$lonely_psu_adjustment_warnings),
  lonely_strata_current = sum(x$lonely_strata_current), singleton_full = x$singleton_strata_full[1]))), digits = 4)
wcsv(tg, "v_targets_check.csv")

# ---- V2. Own WLS (closed form per cell), sigma2, chi2, t, wave residuals ---------------------
tr <- ms_targets[ms_targets$year <= 2020L, ]; ho <- ms_targets[ms_targets$year > 2020L, ]
wls_cell <- function(d) {
  y <- qlogis(d$current_mean); w <- (d$current_mean * (1 - d$current_mean) / d$current_se)^2; t <- (d$year - 2012) / 10
  tb <- sum(w * t) / sum(w); yb <- sum(w * y) / sum(w)
  b <- sum(w * (t - tb) * (y - yb)) / sum(w * (t - tb)^2); a <- yb - b * tb
  Sxx <- sum(w * (t - tb)^2)
  list(a = a, b = b, rss = sum(w * (y - a - b * t)^2), res = (y - a - b * t) * sqrt(w), year = d$year,
    # (X'WX)^-1 for (a, b)
    V = solve(matrix(c(sum(w), sum(w * t), sum(w * t), sum(w * t^2)), 2)))
}
fits <- lapply(split(tr, cellid(tr$sex, tr$age_group)), wls_cell)
rss <- sum(sapply(fits, `[[`, "rss")); df <- nrow(tr) - 16; s2 <- rss / df
coefs <- data.frame(cell = names(fits), alpha = sapply(fits, `[[`, "a"), beta = sapply(fits, `[[`, "b"),
  se_beta_lm = sapply(fits, function(f) sqrt(s2 * f$V[2, 2])), se_beta_known = sapply(fits, function(f) sqrt(f$V[2, 2])))
coefs$t_lm <- coefs$beta / coefs$se_beta_lm; coefs$t_known <- coefs$beta / coefs$se_beta_known
lmcf <- stats::coef(ms_fit(2020L)$prevalence)
cat(sprintf("V2 own WLS vs ms_fit: max|diff| alpha %.1e beta %.1e\n", max(abs(coefs$alpha - lmcf[paste0("cell", coefs$cell)])),
  max(abs(coefs$beta - lmcf[paste0("cell", coefs$cell, ":time")]))))
cat(sprintf("V2 sigma2 %.4f df %d rss %.2f p_chi2 %.3g; max|t_lm| %.3f; max|t_known| %.3f\n", s2, df, rss,
  stats::pchisq(rss, df, lower.tail = FALSE), max(abs(coefs$t_lm)), max(abs(coefs$t_known))))
res <- data.frame(year = unlist(lapply(fits, `[[`, "year")), r = unlist(lapply(fits, `[[`, "res")))
print(aggregate(r ~ year, data = res, FUN = function(v) round(c(mean = mean(v), rms = sqrt(mean(v^2)), n_pos = sum(v > 0)), 3)))
wcsv(coefs, "v_coef_train2020.csv")

# ---- V3. Analytic held-out rules + prediction interval ---------------------------------------
hk <- cellid(ho$sex, ho$age_group); th <- (ho$year - 2012) / 10
pred_lin <- plogis(sapply(seq_len(nrow(ho)), function(i) fits[[hk[i]]]$a + fits[[hk[i]]]$b * th[i]))
flat <- sapply(split(tr, cellid(tr$sex, tr$age_group)), function(d) {
  w <- (d$current_mean * (1 - d$current_mean) / d$current_se)^2; plogis(sum(w * qlogis(d$current_mean)) / sum(w)) })
get_year <- function(yy) { x <- tr[tr$year == yy, ]; stats::setNames(x$current_mean, cellid(x$sex, x$age_group)) }
rules <- list(linear = pred_lin, flat = flat[hk], hold2020 = get_year(2020)[hk], hold2012 = get_year(2012)[hk])
rr <- do.call(rbind, lapply(names(rules), function(r) { e <- rules[[r]] - ho$current_mean
  data.frame(rule = r, bias_pp = 100 * mean(e), rmse_pp = 100 * sqrt(mean(e^2)), n_in = sum(abs(e) <= 1.959964 * ho$current_se),
    by2022 = 100 * mean(e[ho$year == 2022]), by2024 = 100 * mean(e[ho$year == 2024])) }))
print(rr, digits = 4); wcsv(rr, "v_rules_heldout.csv")
cat(sprintf("V3 flat/linear bias ratio %.3f\n", rr$bias_pp[2] / rr$bias_pp[1]))
yh <- qlogis(ho$current_mean); wh <- (ho$current_mean * (1 - ho$current_mean) / ho$current_se)^2
pz <- sapply(seq_len(nrow(ho)), function(i) { f <- fits[[hk[i]]]; x <- c(1, th[i])
  (yh[i] - f$a - f$b * th[i]) / sqrt(s2 * (drop(t(x) %*% f$V %*% x) + 1 / wh[i])) })
q24 <- stats::qt(0.975, df)
cat(sprintf("V3 PI: inside %d/16, all z<0: %s, min z %.2f (%s %d)\n", sum(abs(pz) <= q24), all(pz < 0), min(pz),
  hk[which.min(pz)], ho$year[which.min(pz)]))
# 2024 CI half-widths (train2020, t24, logit scale)
hw <- sapply(names(fits), function(k) { f <- fits[[k]]; x <- c(1, 1.2); m <- f$a + 1.2 * f$b; se <- sqrt(s2 * drop(t(x) %*% f$V %*% x))
  100 * (plogis(m + q24 * se) - plogis(m - q24 * se)) / 2 })
cat("V3 2024 pc 95% CI half-width (pp): ", paste(names(hw), round(hw, 1), collapse = "; "), "\n")

# ---- V4. National pc (own) -------------------------------------------------------------------
full <- lapply(split(ms_targets, cellid(ms_targets$sex, ms_targets$age_group)), wls_cell)
natpc <- function(fl, yy, freeze = TRUE) { p <- ms_population[ms_population$year == yy, ]
  k <- cellid(p$sex, findInterval(p$age, c(15, 30, 45, 60))); tt <- ((if (freeze) min(yy, 2024) else yy) - 2012) / 10
  pc <- sapply(k, function(z) plogis(fl[[z]]$a + fl[[z]]$b * tt)); 100 * sum(pc * p$pop_jan) / sum(p$pop_jan) }
obsnat <- function(yy) { p <- ms_population[ms_population$year == yy, ]; k <- cellid(p$sex, findInterval(p$age, c(15, 30, 45, 60)))
  o <- ms_targets[ms_targets$year == yy, ]; 100 * sum(o$current_mean[match(k, cellid(o$sex, o$age_group))] * p$pop_jan) / sum(p$pop_jan) }
nat <- data.frame(year = c(2012, 2022, 2024, 2034),
  train_frozen = sapply(c(2012, 2022, 2024, 2034), function(y) natpc(fits, y)),
  train_unfrozen = sapply(c(2012, 2022, 2024, 2034), function(y) natpc(fits, y, FALSE)),
  refit_frozen = sapply(c(2012, 2022, 2024, 2034), function(y) natpc(full, y)),
  refit_unfrozen = sapply(c(2012, 2022, 2024, 2034), function(y) natpc(full, y, FALSE)),
  observed = c(obsnat(2012), obsnat(2022), obsnat(2024), NA))
print(nat, digits = 4); wcsv(nat, "v_national.csv")
ref_cell <- sapply(names(full), function(k) 100 * (plogis(full[[k]]$a + 2.2 * full[[k]]$b) - plogis(full[[k]]$a + 1.2 * full[[k]]$b)))
cat("V4 refit2024 2034 unfrozen - frozen (pp):", paste(names(ref_cell), round(ref_cell, 2), collapse = "; "), "\n")
an_proj <- sapply(2025:2034, function(y) natpc(full, y))
cat("V4 refit2024 analytic national 2025-2034:", round(an_proj, 2), "\n")

# ---- V5. Engine: 5 seeds (today), 5 seeds with STORED mortality scale, static comparator ------
m20 <- ms_fit(2020L, trend = TRUE)
cat("V5 mortality_scale today:", signif(m20$mortality_scale, 6), "\n")
metrics <- function(runs) {
  s <- dplyr::bind_rows(lapply(runs, `[[`, "summary"))
  agg <- s |> dplyr::group_by(year, sex, age_group) |> dplyr::summarise(dplyr::across(c(current_mean, gpd_mean, hed_mean), mean), .groups = "drop")
  j <- merge(agg, ms_targets, by = c("year", "sex", "age_group"), suffixes = c("_s", "_o"))
  do.call(rbind, lapply(c("current", "gpd", "hed"), function(m) do.call(rbind, lapply(c("train", "held"), function(per) {
    x <- j[if (per == "train") j$year <= 2020 else j$year > 2020, ]
    e <- x[[paste0(m, "_mean_s")]] - x[[paste0(m, "_mean_o")]]; se <- x[[paste0(m, "_se")]]
    data.frame(metric = m, period = per, bias = mean(e), rmse = sqrt(mean(e^2)),
      n_in = sum((abs(e) <= qnorm(0.975) * se)[x$year != 2020]), n_eval = sum(x$year != 2020)) }))))
}
runs_today <- lapply(ms_cfg$seeds, function(sd) ms_simulate(m20, 2012:2024, 25000L, sd, 0.8))
mt <- metrics(runs_today); print(mt, digits = 5)
m_old <- m20; m_old$mortality_scale <- c(female = 0.976675998119906, male = 0.957068652665794)
runs_old <- lapply(ms_cfg$seeds, function(sd) ms_simulate(m_old, 2012:2024, 25000L, sd, 0.8))
mo <- metrics(runs_old)
sv <- utils::read.csv("<repo>/__andres_control/microsim_base_outputs/validation_metrics.csv")
sv$per <- ifelse(grepl("Held", sv$period), "held", "train")
cmp <- merge(mo, sv[, c("metric", "per", "bias", "rmse")], by.x = c("metric", "period"), by.y = c("metric", "per"), suffixes = c("_storedscale", "_stored"))
cmp$max_abs_diff <- pmax(abs(cmp$bias_storedscale - cmp$bias_stored), abs(cmp$rmse_storedscale - cmp$rmse_stored))
print(cmp, digits = 6); wcsv(rbind(cbind(run = "today", mt), cbind(run = "stored_mortality_scale", mo)), "v_engine_metrics.csv")
st <- ms_simulate(ms_fit(2020L, trend = FALSE), 2012:2024, 25000L, ms_cfg$seeds[1], 0.8)
stm <- metrics(list(st)); print(stm[stm$period == "held", ], digits = 5)
# per-seed held-out current bias; MC sd; n per cell; switching
pb <- sapply(runs_today, function(r) { j <- merge(r$summary, ms_targets, by = c("year", "sex", "age_group"), suffixes = c("_s", "_o"))
  j <- j[j$year > 2020, ]; 100 * mean(j$current_mean_s - j$current_mean_o) })
cat(sprintf("V5 per-seed held-out bias pp: %s; sd %.3f\n", paste(round(pb, 2), collapse = ", "), sd(pb)))
s5 <- dplyr::bind_rows(lapply(runs_today, `[[`, "summary"))
ncell <- aggregate(n ~ sex + age_group, data = s5[s5$year %in% c(2012, 2022, 2024), ], FUN = mean)
print(ncell)
fl <- dplyr::bind_rows(lapply(runs_today, `[[`, "flows"))
cat(sprintf("V5 switching 5 seeds: %.4f\n", sum(fl$status_changes) / sum(fl$transition_n)))
# engine vs analytic pc z (pooled seeds)
dr <- ms_drivers(m20, 2012:2024)
a5 <- s5 |> dplyr::group_by(year, sex, age_group) |> dplyr::summarise(nt = sum(n), x = sum(n * current_mean) / sum(n), .groups = "drop")
a5 <- merge(a5, dr[, c("year", "sex", "age_group", "p_current")]); a5$z <- (a5$x - a5$p_current) / sqrt(a5$p_current * (1 - a5$p_current) / a5$nt)
cat(sprintf("V5 engine z: mean %.3f sd %.3f max|z| %.2f n=%d\n", mean(a5$z), sd(a5$z), max(abs(a5$z)), nrow(a5)))

# ---- V6. Individual weighted logistic (binomial glm, raw weights) --------------------------
d <- ms_enpg[ms_enpg$year <= 2020L & !is.na(ms_enpg$current), ]
d$cell <- factor(cellid(d$sex, d$age_group)); d$time <- (d$year - 2012) / 10
il <- suppressWarnings(stats::glm(current ~ 0 + cell + cell:time, family = stats::binomial(), weights = weight, data = d))
cf_il <- stats::coef(il); cf_w <- lmcf[names(cf_il)]
nd <- data.frame(cell = factor(hk, levels = levels(d$cell)), time = th)
e_il <- plogis(stats::predict(il, newdata = nd)) - ho$current_mean
cat(sprintf("V6 indiv logit: max|coef diff| %.3f at %s (wls %.3f, il %.3f); held-out bias %.2f rmse %.2f\n",
  max(abs(cf_il - cf_w)), names(cf_il)[which.max(abs(cf_il - cf_w))], cf_w[which.max(abs(cf_il - cf_w))],
  cf_il[which.max(abs(cf_il - cf_w))], 100 * mean(e_il), 100 * sqrt(mean(e_il^2))))

# ---- V7. Theoretical switching 2[p - Phi2(c,c;rho)] ----------------------------------------
sw <- function(p, r) { c0 <- qnorm(p); if (r == 0) return(2 * p * (1 - p))
  2 * (p - mvtnorm::pmvnorm(upper = c(c0, c0), corr = matrix(c(1, r, r, 1), 2))[1]) }
swt <- expand.grid(p = c(0.40, 0.45, 0.48), rho = c(0, 0.8, 0.95)); swt$switch <- mapply(sw, swt$p, swt$rho)
print(swt, digits = 4); wcsv(swt, "v_switching_theory.csv")
cat(sprintf("V7 0.8^7.7 = %.4f; MC sd sqrt(.45*.55/3000) %.4f, /1000 %.4f; sqrt(25000/30091) %.4f; Bonferroni 80*2*(1-Phi(3.20)) %.3f\n",
  0.8^7.7, sqrt(.45 * .55 / 3000), sqrt(.45 * .55 / 1000), sqrt(25000 / 30091), 80 * 2 * pnorm(-3.20)))
message(sprintf("verify_prev.R elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0_v, units = "mins"))))
