.t0 <- Sys.time()
source("<scratch>/spec/load_base_engine.R")
m <- ms_fit(2020)
cat("kappa:", sprintf("%.6f", m$mortality_scale), "\n")
d <- ms_drivers(m, 2012:2034)
r <- d[d$sex == "male" & d$age_group == 2 & d$year %in% 2016:2017, ]
print(r[, c("year","time","p_current","mu_current","shape","p_zero","p_ever_noncurrent","hed_intercept","hed_slope")], digits = 8)
zs <- c(-0.6, 0.8*-0.6 + 0.6*0.3); za <- c(0.9, 0.8*0.9 + 0.6*-0.5); zh <- c(-0.3, 0.8*-0.3 + 0.6*1.2)
for (i in 1:2) {
  U <- pnorm(zs[i]); Ua <- pnorm(za[i]); Uh <- pnorm(zh[i]); x <- r[i, ]
  phi <- x$mu_current / (x$shape * (1 - x$p_zero))
  g <- qgamma((Ua - x$p_zero)/(1 - x$p_zero), x$shape, scale = phi)
  eta <- x$hed_intercept + x$hed_slope * log1p(g); ph <- plogis(eta)
  cat(sprintf("yr %d zs %.2f U %.6f cur %s za %.2f Ua %.6f phi %.5f g %.4f eta %.5f phed %.6f zh %.2f Uh %.6f hed %s thr_zhed %.4f\n",
    x$year, zs[i], U, U < x$p_current, za[i], Ua, phi, g, eta, ph, zh[i], Uh, Uh < ph, qnorm(ph)))
  cat(sprintf("   U/pc %.5f g %.4f ; 1-U/pc %.5f g %.4f\n", U/x$p_current, qgamma(U/x$p_current, x$shape, scale=phi),
     1-U/x$p_current, qgamma(1-U/x$p_current, x$shape, scale=phi)))
}
# literal engine on the person
pop <- data.frame(id = 1, sex = "male", age = 35L, z_current = -0.6, z_amount = 0.9, z_hed = -0.3, ever = NA)
set.seed(1); e16 <- ms_exposure(pop, 2016L, d); print(e16[, c("current","gpd_survey","hed","alc_cat","ever")])
fac <- read.csv("<repo>/__andres_control/oms_factor_by_year.csv"); print(fac)
# mortality
mm <- ms_mortality[ms_mortality$sex == "male" & ((ms_mortality$year == 2016 & ms_mortality$age == 35) | (ms_mortality$year == 2017 & ms_mortality$age == 36)), ]
mm$qstar <- -expm1(log1p(-mm$qx) * m$mortality_scale["male"]); print(mm[, c("year","age","qx","qstar")], digits = 7)
# omega and n_target 2012
st <- ms_population[ms_population$year == 2012, ]; w <- sum(st$pop_jan)/25000
cat("sum pop_jan 2012", sum(st$pop_jan), "omega", w, "sum n_target", sum(round(st$pop_jan/w)), "\n")
# chi-sq p values
cat("prev chisq p", pchisq(102.25, 24, lower.tail = FALSE), " amount p", pchisq(1.302*24, 24, lower.tail=FALSE), "\n")
# status change p=0.45 rho 0.8 via integration
c0 <- qnorm(0.45); f <- function(z) dnorm(z) * pnorm((c0 - 0.8*z)/0.6)
p11 <- integrate(f, -Inf, c0)$value; cat("switch", 2*(0.45 - p11), "\n")
# pF at 15 used vs observed: p_ever_noncurrent per cell
print(m$shape)
# HED table p at grid
cf <- coef(m$hed); print(round(cf, 4))
g <- c(0.4,1,5,10,20); for (nm in names(cf)[1:8]) cat(nm, round(plogis(cf[nm] + cf[9]*log1p(g)),3), "\n")
# p_hed at g=0 times p0 max
cat("p0*plogis(gamma):", max(m$shape$p_zero * plogis(cf[paste0("cell", m$shape$sex, ":", m$shape$age_group)])), "\n")
# coefficients prevalence
cp <- coef(m$prevalence); print(round(cp, 3))
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
