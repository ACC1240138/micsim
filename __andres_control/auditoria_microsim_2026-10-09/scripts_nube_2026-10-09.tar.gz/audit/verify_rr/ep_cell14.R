#| label: mortality-consolidate-and-update
#| results: "hold"
#| warnings: false

#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:
# DEIS records were cleaned and filtered to include only records for 
# individuals over or equal 15 years old. 
# The data was then transformed to include relevant variables such as year
# so it can be uploaded to GitHub
# mort21|> 
#   janitor::clean_names() |> 
#   transmute(year = a_o, 
#     gender = sexo_nombre, 
#     age = edad_cant, 
#     age_group = case_when(between(age, 15, 29) ~ 1,
#         between(age, 30, 44) ~ 2,
#         between(age, 45, 59) ~ 3,
#         age >= 60 ~ 4),
#         # 2026-06-16= added diag1
#             comuna = iconv(comuna, "latin1", "UTF-8"), region = iconv(nombre_region, "latin1", "UTF-8"), diag1, diag2) |> 
#   dplyr::filter(year >= 2012, age >= 15) |> #, diag2 != ""
#   rio::export(file.path(
#     gsub("__andres_control","",getwd()),
#     "ACC1240138-Potentially-Avoidable-Injury-Mortality-in-Chile--bc6359e",
#     "udpate jun 26",
#     "DEFUNCIONES_DEIS_12_23_15plus.parquet"
#   ))
#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:
#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:#:

path_deis_defunciones_90_23 <- 
acc_data("_deis/DEFUNCIONES_DEIS_2012_2023_15plus.tar.xz.enc")

# Code made by JRT, updated to expand for all causes
# 2026-06-30= Restricted to <65 years old
# 2026-07-10= Restricted to <=65 years old
if(file.exists(path_deis_defunciones_90_23)) {
    mort21 <- rio::import(path_deis_defunciones_90_23) |> 
      janitor::clean_names() |> 
      # 2026-07-02= Restricted to 15-65 years old, just like SENDA ENPG
      dplyr::filter(age <=65) |> 
      dplyr::filter(year >= 2012, age >= 15)#, diag2 != ""
  } else {
    stop("Not found: ", path_deis_defunciones_90_23)
  }

# JRT took it from DEFUNCIONES_FUENTE_DEIS_2024_2026_02062026; acc_deis() loads the newest release (see [acc_deis] in the output)
# 2026-06-30= Restricted to <65 years old
# 2026-07-10= Restricted to <=65 years old
mort24 <- acc_deis() |> 
  janitor::clean_names() |> 
  dplyr::filter(edad_tipo == 1, edad_cant <=65) |>   # 2026-07-15= edad_tipo==1 => age in years; exclude infants in days/hrs (bug)
  transmute(year = ano, 
    gender = sexo_nombre, 
    age = edad_cant, 
    age_group = case_when(between(age, 15, 29) ~ 1,
        between(age, 30, 44) ~ 2,
        between(age, 45, 59) ~ 3,
        age >= 60 ~ 4),
        # 2026-06-16= added diag1
            comuna = iconv(comuna, "latin1", "UTF-8"), region = iconv(nombre_region, "latin1", "UTF-8"), diag1, diag2) |> 
  dplyr::filter(year == 2024, age >= 15)#, diag2 != ""


mort <- rbind.data.frame(mort21, mort24)