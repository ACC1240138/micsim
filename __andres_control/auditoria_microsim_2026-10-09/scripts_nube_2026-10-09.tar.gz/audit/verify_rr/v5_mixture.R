.t0 <- Sys.time()
# Claim 11: no-HED causes evaluated on the NHED/HED mixture instead of the pooled gamma (2024), own integrator.
audit <- "<scratch>/audit"
source(file.path(audit, "rr_bridge_lib.R")); spec <- bridge_load()
r <- utils::read.csv(file.path(audit, "verify_rr", "v4_aaf_numerics_2024.csv"))
inp <- readRDS("<repo>/__andres_control/aaf_engine_inputs_bundle_20261007.rds")$exposure_inputs
xg <- seq(0.1, 150, length.out = 150001L); trap <- function(y) sum(diff(xg) * (y[-1] + y[-length(y)]) / 2)
E <- function(est, fx) { d <- stats::dgamma(xg, est$estimate[["shape"]], est$estimate[["rate"]]); trap(d * fx) / trap(d) }
k <- which(r$principal & r$hed_mode == "none"); out <- numeric(length(k))
for (j in seq_along(k)) { z <- r[k[j], ]; s <- if (z$sex == "female") "fem" else "male"; g <- z$age_group
  rec <- spec$record[[which(spec$cause == z$cause & spec$sex == z$sex & spec$principal)]]
  sp <- inp[[paste0("g_", s, "_hed_list")]][["2024"]][[g]]; ph <- inp[[paste0("p_hed_list_", s)]][[g]][[7]]
  pa <- inp[[paste0("p_abs_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]; pf <- inp[[paste0("p_form_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]
  rr <- rep_len(rec$RRCurrent(xg, rec$betaCurrent), length(xg))
  R <- pa + pf * exp(rec$lnRRFormer) + (1 - pa - pf) * ((1 - ph) * E(sp$nhed, rr) + ph * E(sp$hed, rr)); out[j] <- (R - 1) / R }
dif <- abs(out - r$stored[k]); w <- which.max(dif)
cat(sprintf("[11] mixture vs pooled (stored), %d principal no-HED cells: max |diff| = %.4f (%s %s g%d: %.3f -> %.3f), median %.4f\n",
  length(k), max(dif), r$cause[k][w], r$sex[k][w], r$age_group[k][w], r$stored[k][w], out[w], stats::median(dif)))
cat(sprintf("v5 elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
