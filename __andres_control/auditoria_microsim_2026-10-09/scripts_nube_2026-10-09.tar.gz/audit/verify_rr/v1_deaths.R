.t0 <- Sys.time()
# Independent verification of rr_bridge claim 7 (2024 deaths, attributable, averted).
# Counts deaths directly from the DEIS 2024-2026 bundle (both packed versions) with my own code,
# using only the ICD-10 code vectors from ypll_icd_defs.R. Writes aggregates only.
# Run: LANG=C.UTF-8 Rscript --vanilla v1_deaths.R
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>/__andres_control")
out_dir <- "<scratch>/audit/verify_rr"
source("<repo>/_tools/acc_data.R")
source("ypll_icd_defs.R")   # code vectors only (and ypll_pipeline_deaths for the comparison)

principal <- setdiff(names(ypll_disease_filters), c("Stomach Cancer", "Pancreatic Cancer"))
stopifnot(length(principal) == 21L)
cl <- function(x) toupper(gsub("[^A-Za-z0-9]", "", x))
codes <- list(
  "Breast Cancer" = brcan_codes, "Liver Cancer" = lican_codes, "Larynx Cancer" = lxcan_codes,
  "Oesophagus Cancer" = oescan_codes, "Oral Cavity and Pharynx Cancer" = locan_codes,
  "Other Pharyngeal Cancer" = opcan_codes, "Colon and rectum Cancer" = crcan_codes,
  "Acute Pancreatitis" = panc_codes, "Epilepsy" = epilepsy_codes, "DM2" = dm2_codes, "HIV" = hiv_codes,
  "Hypertensive Heart Disease" = hhd_codes, "Intracerebral Haemorrhage" = ich_codes,
  "Ischaemic Heart Disease" = ihd_codes, "Ischaemic Stroke" = is_codes, "Liver Cirrhosis" = lc_codes,
  "Lower Respiratory Infection" = lri_codes, "Tuberculosis" = tb_codes)
inj <- c("Road Injuries", "Unintentional Injuries", "Intentional Injuries")
stopifnot(setequal(c(names(codes), inj), principal))

count_version <- function(ver) {
  d <- acc_deis(ver)
  yr <- d[[1]]                                    # "AÑO"
  keep <- yr == 2024 & d$EDAD_TIPO == 1 & d$EDAD_CANT >= 15 & d$EDAD_CANT <= 65
  d <- d[keep, ]
  d1 <- cl(d$DIAG1); d2 <- cl(d$DIAG2)
  sex <- ifelse(d$SEXO_NOMBRE == "Mujer", "female", ifelse(d$SEXO_NOMBRE == "Hombre", "male", NA))
  g <- findInterval(d$EDAD_CANT, c(15, 30, 45, 60))
  flag <- lapply(codes, function(cc) d1 %in% cc)
  ri <- d1 %in% ri_codes | d2 %in% ri_codes
  flag[["Road Injuries"]] <- ri
  flag[["Intentional Injuries"]] <- d1 %in% int_inj_codes | d2 %in% int_inj_codes
  flag[["Unintentional Injuries"]] <- (d1 %in% unint_inj_codes | d2 %in% unint_inj_codes) & !ri
  flag[["Breast Cancer"]] <- flag[["Breast Cancer"]] & sex == "female"   # female-only cause
  res <- do.call(rbind, lapply(names(flag), function(cs) {
    f <- flag[[cs]] & !is.na(sex)
    if (!any(f)) return(NULL)
    a <- stats::aggregate(list(deaths = rep(1L, sum(f))), list(sex = sex[f], age_group = g[f]), sum)
    a$cause <- cs; a
  }))
  res$version <- ver
  list(cells = res, n_rows_2024_15_65 = nrow(d), unknown_sex = sum(is.na(sex)))
}
vers <- c("29092026", "06102026")
cnt <- lapply(vers, count_version); names(cnt) <- vers
for (v in vers) cat(sprintf("DEIS %s: 2024 deaths age 15-65 (edad_tipo 1) = %d; unknown sex = %d\n",
                            v, cnt[[v]]$n_rows_2024_15_65, cnt[[v]]$unknown_sex))

# ---- stored AAF (WHO nested, IS from Table 5) and pif2 volume_reduction_10 for 2024 ----
aafs <- readRDS("aaf_nested_by_disease_20261007.rds")$by_disease
t5 <- readRDS("aaf_table5_result_20261007.rds")$by_age_scope[["15_64"]]$standard_tables
pif2 <- readRDS("pif2_pif_results_full_20261008.rds"); pif2t <- readRDS("pif2_pif_results_table5_full_20261008.rds")
ref <- do.call(rbind, lapply(principal, function(cs) do.call(rbind, lapply(aafs[[cs]]$outputs, function(o) {
  o$sex <- if (any(grepl("^Fem", names(o$table)))) "female" else "male"   # $sex is NA for *_fem outputs
  do.call(rbind, lapply(1:4, function(g) {
    if (cs == "Ischaemic Stroke") {
      tb <- t5[[o$sex]]; aaf <- tb[tb$disease == cs & tb$Year == 2024, paste0("AAF_ag", g)]; pf <- pif2t
    } else {
      tb <- o$table; aaf <- tb[tb$Year == 2024, paste0(if (o$sex == "female") "Fem" else "Male", g, "_point")]; pf <- pif2
    }
    p <- pf$pif[pf$output_name == o$table_name & pf$year == 2024 & pf$age_group == g & pf$scenario_id == "volume_reduction_10"]
    stopifnot(length(aaf) == 1L, length(p) == 1L)
    data.frame(cause = cs, sex = o$sex, age_group = g, output = o$table_name, aaf = aaf, pif_vol10 = p)
  }))
}))))
cat(sprintf("principal reference cells: %d\n", nrow(ref)))

summ <- list()
for (v in vers) {
  m <- merge(ref, cnt[[v]]$cells[, c("cause", "sex", "age_group", "deaths")], all.x = TRUE)
  m$deaths[is.na(m$deaths)] <- 0
  summ[[v]] <- m
  cat(sprintf("[DEIS %s] principal cells with >=1 death: %d of %d | deaths %d | attributable %.1f | averted vol-10%% %.1f\n",
              v, sum(m$deaths > 0), nrow(m), sum(m$deaths), sum(m$deaths * m$aaf), sum(m$deaths * m$pif_vol10)))
}

# ---- the pipeline's own death base (n = mort/aaf), as used by the report ----
pd <- ypll_pipeline_deaths()
pd <- pd[pd$year == 2024 & pd$disease %in% principal, ]
pd$sex <- ifelse(pd$gender == "Mujer", "female", "male")
cmp <- merge(summ[["06102026"]], pd[, c("disease", "sex", "age_group", "n")], by.x = c("cause", "sex", "age_group"),
             by.y = c("disease", "sex", "age_group"), all.x = TRUE)
cmp <- merge(cmp, summ[["29092026"]][, c("cause", "sex", "age_group", "deaths")], by = c("cause", "sex", "age_group"),
             suffixes = c("_v0610", "_v2909"))
cat(sprintf("pipeline death base (mort/aaf), 2024 principal: matched %d cells, total %.3f\n", sum(is.finite(cmp$n)), sum(cmp$n, na.rm = TRUE)))
cat(sprintf("max |pipeline n - DEIS 06102026| = %.3g ; max |pipeline n - DEIS 29092026| = %.3g (cells with pipeline n)\n",
            max(abs(cmp$n - cmp$deaths_v0610), na.rm = TRUE), max(abs(cmp$n - cmp$deaths_v2909), na.rm = TRUE)))
cat(sprintf("cells with deaths>0 but no pipeline n (dropped by abs(aaf)>1e-12 or join): %d (deaths %d)\n",
            sum(!is.finite(cmp$n) & cmp$deaths_v0610 > 0), sum(cmp$deaths_v0610[!is.finite(cmp$n)])))
by_cause <- stats::aggregate(cbind(deaths = deaths_v0610, deaths_v2909, attrib = deaths_v0610 * aaf,
                                   averted_vol10 = deaths_v0610 * pif_vol10) ~ cause, cmp, sum)
by_cause <- by_cause[order(-by_cause$attrib), ]
print(by_cause, digits = 5, row.names = FALSE)
utils::write.csv(by_cause, file.path(out_dir, "v1_deaths_by_cause_2024.csv"), row.names = FALSE)
utils::write.csv(cmp, file.path(out_dir, "v1_deaths_cells_2024.csv"), row.names = FALSE)

# IS attributable and IHD sign: share of the total carried by negative-AAF cells
cat(sprintf("negative-AAF cells: %d, contributing %.1f attributable deaths\n", sum(cmp$aaf < 0), sum((cmp$deaths_v0610 * cmp$aaf)[cmp$aaf < 0])))
cat(sprintf("v1_deaths elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
