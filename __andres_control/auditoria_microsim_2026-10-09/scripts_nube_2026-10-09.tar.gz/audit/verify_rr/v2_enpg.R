.t0 <- Sys.time()
# Independent verification of rr_bridge claims 5 (scale identity, factor_CH), 8 (former composition),
# 10 (HED denominator) and 14 (locale). ENPG microdata only via acc_data(); writes aggregates only.
# Run: LANG=C.UTF-8 Rscript --vanilla v2_enpg.R   (and LANG=C LC_ALL=C for the locale probe line)
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>/__andres_control")
out_dir <- "<scratch>/audit/verify_rr"
source("<repo>/_tools/acc_data.R")
cat("locale LC_CTYPE:", Sys.getlocale("LC_CTYPE"), "\n")
raw <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))
des <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/enpg_design_waves_2012_2024_list.RDS"))
oh2 <- as.character(raw$oh2)
cat("oh2 levels:", paste(sprintf("'%s'[%s]", unique(oh2), Encoding(unique(oh2))), collapse = " "), "\n")
cat("max age by wave:", paste(tapply(as.numeric(raw$edad), raw$year, max), collapse = " "), "\n")

# ---- microsim ms-survey-inputs status / gpd / hed, verbatim logic (cell ms-survey-inputs lines 67-92) ----
ms_ever <- as.character(raw$oh1); ms_recency <- oh2
status <- ifelse(ms_ever == "No" & is.na(ms_recency), "never",
  ifelse(ms_ever == "Si" & ms_recency == "30 dias", "current",
    ifelse(ms_ever == "Si" & ms_recency %in% c(">30", ">1 año"), "former", NA_character_)))
status[is.na(status)] <- "unknown"
days <- as.numeric(raw$oh3); days[!is.finite(days) | days < 0 | days > 30] <- NA_real_
eps <- as.numeric(raw$db); eps[!is.finite(eps) | eps < 0 | eps >= 88] <- NA_real_
drinks <- unname(c("0-2" = 1, "3-4" = 3.5, "5-6" = 5.5, "7-8" = 7.5, "9 o mas" = 9)[as.character(raw$audit2)])
sex <- ifelse(raw$sexo == "Hombre", "male", "female")
gpd <- (pmax(days - eps, 0) * drinks + eps * ifelse(sex == "male", 5, 4)) * 12 / 30
hed <- as.numeric(eps > 0)
gpd[status %in% c("never", "former")] <- 0; hed[status %in% c("never", "former")] <- 0
gpd[status == "unknown"] <- NA; hed[status == "unknown"] <- NA
age <- as.integer(raw$edad); g <- findInterval(age, c(15, 30, 45, 60))
year <- as.integer(raw$year)
# microsim weight = design-cache weight (unrounded), expand_pif weight = exp
lk <- do.call(rbind, lapply(names(des$waves), function(y) data.frame(year = as.integer(y), id = as.character(des$waves[[y]]$id_join), w = des$waves[[y]]$weight)))
mw <- lk$w[match(paste(year, as.character(raw$id)), paste(lk$year, lk$id))]
ew <- as.numeric(raw$exp)
dom <- age >= 15 & age <= 65
cat(sprintf("design weight matched: %d of %d rows\n", sum(!is.na(mw)), length(mw)))
for (y in sort(unique(year))) {
  s <- year == y & dom
  cat(sprintf("weights %d: max |w_design/exp - 1| = %.3g; corr = %.6f\n", y, max(abs(mw[s] / ew[s] - 1), na.rm = TRUE), stats::cor(mw[s], ew[s])))
}

# ---- claim 8 / 14: former composition 2024, 15-65 ----
fm <- dom & status == "former"
for (y in sort(unique(year))) {
  s <- fm & year == y; r <- s & oh2 == ">30"
  cat(sprintf("former %d: n = %d, n(>30 i.e. 31d-12m) = %d, weighted share exp = %.4f, design w = %.4f, unknown status n = %d\n",
              y, sum(s), sum(r), sum(ew[r]) / sum(ew[s]), sum(mw[r]) / sum(mw[s]), sum(dom & year == y & status == "unknown")))
}
fc <- do.call(rbind, lapply(c("female", "male"), function(sx) do.call(rbind, lapply(1:4, function(gg) {
  s <- fm & year == 2024 & sex == sx & g == gg; r <- s & oh2 == ">30"
  data.frame(sex = sx, tramo = gg, n_former = sum(s), n_31d_12m = sum(r), share_exp = sum(ew[r]) / sum(ew[s]), share_design = sum(mw[r]) / sum(mw[s]))
}))))
utils::write.csv(fc, file.path(out_dir, "v2_former_share_2024.csv"), row.names = FALSE)
print(fc, digits = 4, row.names = FALSE)

# ---- claim 5: factor_CH recomputed from expand_pif enpg-consolidate logic ----
db_ep <- as.numeric(haven::zap_labels(raw$db)); db_ep[db_ep >= 88] <- NA
oh3_ep <- as.numeric(haven::zap_labels(raw$oh3)); oh3_ep[oh3_ep %in% c(88, 99)] <- NA
nd <- (ms_ever %in% "No") | (oh2 %in% c(">30", ">1 año"))
oh3_ep[nd] <- 0
prom <- c("0-2" = 1, "3-4" = 3.5, "5-6" = 5.5, "7-8" = 7.5, "9 o mas" = 9)[as.character(raw$audit2)]; prom[nd] <- 0
volCH <- ((pmax(oh3_ep - db_ep, 0)) * prom + db_ep * ifelse(raw$sexo == "Hombre", 5, 4)) * 12 / 30 * 365
keep_ep <- age >= 15 & (is.na(oh3_ep) | oh3_ep <= 30)
st_ep <- ifelse(nd, "nondrinker", ifelse(oh2 %in% "30 dias", "current", NA))
fac <- utils::read.csv("oms_factor_by_year.csv")
apc <- c(`2012` = 7.21, `2014` = 7.17, `2016` = 7.23, `2018` = 6.98, `2020` = 7.09, `2022` = 6.99, `2024` = 6.58)
fr <- do.call(rbind, lapply(names(apc), function(y) {
  s <- keep_ep & year == as.integer(y) & !is.na(st_ep)
  cu <- s & st_ep == "current"
  pc <- sum(ew[cu]) / sum(ew[s]); ok <- cu & !is.na(volCH)
  m <- sum(ew[ok] * volCH[ok]) / sum(ew[ok])
  data.frame(year = as.integer(y), p_current = pc, factor_mine = apc[[y]] * 0.8 * 0.789 * 1000 / (pc * m),
             factor_csv = fac$factor_CH[fac$year == as.integer(y)])
}))
print(fr, digits = 6, row.names = FALSE)

# ---- claim 5: gamma MoM on microsim gpd x factor, exp weights vs design weights, vs bundle (2024) ----
inp <- readRDS("aaf_engine_inputs_bundle_20261007.rds")$exposure_inputs
f24 <- fac$factor_CH[fac$year == 2024]
wm <- function(x, w) { m <- sum(w * x) / sum(w); v <- sum(w * (x - m)^2) / sum(w); c(shape = m^2 / v, rate = m / v) }
gm <- do.call(rbind, lapply(c("female", "male"), function(sx) do.call(rbind, lapply(1:4, function(gg) {
  s <- dom & year == 2024 & sex == sx & g == gg & status == "current" & is.finite(gpd) & gpd > 0
  # expand_pif also drops rows with oh3 outside 0..30 (non 88/99) before the fits; the microsim keeps them as NA days -> NA gpd
  b <- inp[[paste0("g_", if (sx == "female") "fem" else "male", "_list")]][["2024"]][[gg]]$estimate
  ph_b <- inp[[paste0("p_hed_list_", if (sx == "female") "fem" else "male")]][[gg]][[7]]
  e1 <- wm(gpd[s] * f24, ew[s]); e2 <- wm(gpd[s] * f24, mw[s])
  cs <- dom & year == 2024 & sex == sx & g == gg & status == "current"
  # p_hed per microsim target: svymean(hed) among ALL current drinkers with non-NA hed, design weight
  t1 <- cs & !is.na(hed)
  data.frame(sex = sx, tramo = gg, n = sum(s),
             mean_bundle = b[["shape"]] / b[["rate"]], mean_exp = e1[["shape"]] / e1[["rate"]], mean_design = e2[["shape"]] / e2[["rate"]],
             shape_bundle = b[["shape"]], shape_exp = e1[["shape"]], shape_design = e2[["shape"]],
             p_hed_bundle = ph_b,
             p_hed_gpdpos_exp = sum(ew[s & hed == 1]) / sum(ew[s]),
             p_hed_ms_target = sum(mw[t1 & hed == 1]) / sum(mw[t1]),
             n_current = sum(cs), n_current_gpd_na = sum(cs & is.na(gpd)), n_current_hed_known_gpd_na = sum(cs & is.na(gpd) & !is.na(hed)))
}))))
utils::write.csv(gm, file.path(out_dir, "v2_scale_identity_2024.csv"), row.names = FALSE)
print(gm, digits = 5, row.names = FALSE)
cat(sprintf("max rel diff mean: exp weights %.2e | design weights %.2e ; shape: exp %.2e | design %.2e\n",
            max(abs(gm$mean_exp / gm$mean_bundle - 1)), max(abs(gm$mean_design / gm$mean_bundle - 1)),
            max(abs(gm$shape_exp / gm$shape_bundle - 1)), max(abs(gm$shape_design / gm$shape_bundle - 1))))
cat(sprintf("p_hed: max |gpd>0 exp def - bundle| = %.2e ; max |microsim target def - bundle| = %.4f\n",
            max(abs(gm$p_hed_gpdpos_exp - gm$p_hed_bundle)), max(abs(gm$p_hed_ms_target - gm$p_hed_bundle))))
cat(sprintf("v2_enpg elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
