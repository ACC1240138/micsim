#| label: mort-trends-age-sex-chile11-mortalidad-etiqueta
#| results: "hold"

# X45 = 2.050 muertes por **intoxicacion accidental por alcohol 
# X65 = 7 muertes por "Envenenamiento autoinfligido intencionalmente por, y exposicion al alcohol"
# Y15 = 0 muertes por "Envenenamiento por, y exposicion al alcohol, de intencion no determinada"

#Helper: take ICD-10 in rangess
icd_codes <- function(letter, numbers, suffix = 0:9) {
  as.vector(outer(
    sprintf("%s%02d", letter, numbers),
    suffix,
    paste0
  ))
}
# 2026-06-16: Shield Table S6 helper; keeps old helper above intact, but adds "X" suffix support.
icd_codes_s6 <- function(letter, numbers, suffix = c(0:9, "X")) {
  as.vector(outer(
    sprintf("%s%02d", letter, numbers),
    suffix,
    paste0
  ))
}
# 2026-06-16: Helper for already formatted 3-character ICD stems, e.g. "X65", "Y87".
icd_stems_s6 <- function(stems, suffix = c(0:9, "X")) {
  as.vector(outer(stems, suffix, paste0))
}
# 2026-06-16: Normalize ICD-10 format before matching: remove dots/spaces, uppercase.
clean_icd10 <- function(x) {
  toupper(gsub("[^A-Za-z0-9]", "", x))
}
# 2026-06-16: Use cleaned no-dot ICD columns for all matches below.
def <- mort %>%
  dplyr::mutate(
    DIAG1_s6 = clean_icd10(diag1),
    DIAG2_s6 = clean_icd10(diag2)
  )
###########
# AFF = 1 #
###########
# polineu      # polineuropatia alcoholica
# cardiomio    # cardiomiopatia alcoholica
# pancreati_oh # pancreatitis inducida por alcohol
# gastrit      # gastritis alcoholica
# enven_acc    # intoxicacion accidental por alcohol
# enven_int    # intoxicacion intencional por alcohol
# enven_indet  # intoxicacion por alcohol de intenciÃ³n indeterminada

# 2026-06-16: F10 is alcohol use disorder; Shield Table S6 alcohol-use row includes F10.
des_men_codes <- icd_stems_s6("F10")
# 2026-06-16: Kept from previous fully attributable block.
deg_nerv_codes <- "G312"
# 2026-06-16: Kept from previous fully attributable block.
polineu_codes <- "G621"
# 2026-06-16: Shield Table S6 alcohol-use row also includes G72.1.
myopathy_oh_codes <- "G721"
# 2026-06-16: Shield Table S6 alcohol-use row also includes Q86.0.
fetal_oh_codes <- "Q860"
# 2026-06-16: Kept from previous fully attributable block.
cardiomio_codes <- "I426"
# 2026-06-16: Kept here as fully attributable; excluded from partial pancreatitis below.
pancreati_oh_codes <- "K860"
# 2026-06-16: Kept from previous fully attributable block.
gastrit_codes <- "K292"
# 2026-06-16: X45 remains fully attributable accidental alcohol poisoning.
x45_alcohol_accidental_poisoning_codes_aff1 <- icd_stems_s6("X45")
# 2026-06-16: X65 remains fully attributable intentional alcohol self-poisoning.
# 2026-06-16: The same X65 codes are removed from partial self-harm below.
x65_alcohol_self_poisoning_codes_aff1 <- icd_stems_s6("X65")
# 2026-06-16: Kept from previous fully attributable block.
y15_alcohol_undetermined_poisoning_codes_aff1 <- icd_stems_s6("Y15")
def <- def %>%
  dplyr::mutate(
    des_men = as.integer(DIAG1_s6 %in% des_men_codes), #Mental and behavioral disorders due to alcohol
    deg_nerv = dplyr::if_else(DIAG1_s6 %in% deg_nerv_codes, 1, 0),
    polineu = dplyr::if_else(DIAG1_s6 %in% polineu_codes, 1, 0),
    myopathy_oh = dplyr::if_else(DIAG1_s6 %in% myopathy_oh_codes, 1, 0), # 2026-06-16: Shield G72.1.
    fetal_oh = dplyr::if_else(DIAG1_s6 %in% fetal_oh_codes, 1, 0),       # 2026-06-16: Shield Q86.0.
    cardiomio = dplyr::if_else(DIAG1_s6 %in% cardiomio_codes, 1, 0),
    pancreati_oh = dplyr::if_else(DIAG1_s6 %in% pancreati_oh_codes, 1, 0),
    gastrit = dplyr::if_else(DIAG1_s6 %in% gastrit_codes, 1, 0),
    enven_acc = as.integer(DIAG2_s6 %in% x45_alcohol_accidental_poisoning_codes_aff1),
    enven_int = as.integer(DIAG2_s6 %in% x65_alcohol_self_poisoning_codes_aff1),
    enven_indet = as.integer(DIAG2_s6 %in% y15_alcohol_undetermined_poisoning_codes_aff1)
  )
# Avoid hard-coding by position in sum
# 2026-06-25: dont stop execution if  double-counting deaths by cause
def <- def %>%
  dplyr::mutate(
    aaf1 = as.integer(rowSums(
          dplyr::across(c(
            des_men, deg_nerv, polineu, myopathy_oh, fetal_oh,
            cardiomio, pancreati_oh, gastrit,
            enven_acc, enven_int, enven_indet
          )),
          na.rm = TRUE
        ) >= 1)
  )
################################
# PARTIALLY ATTRIBUTABLE TO OH #
################################
# NEUROPSYCHIATRIC
# Epilepsy
# 2026-05-27: Epilepsy codes are G40-41 instead of C40-41 (Malignant neoplasm of bone and articular cartilage of limbs)
# 2026-06-16: Shield Table S6 epilepsy row: G40-G41.
epilepsy_codes <- icd_codes_s6("G", 40:41)
# CARDIOVASCULAR
# Hypertensive disease
# 2026-06-16: Shield Table S6 hypertensive disease row: I10-I15.
hhd_codes <- icd_codes_s6("I", 10:15)
# Ischemic heart disease
# 2026-06-16: Shield Table S6 ischaemic heart disease row: I20-I25.
ihd_codes <- icd_codes_s6("I", 20:25)
# Hemorrhagic stroke
# 2026-06-16: Shield Table S6 haemorrhagic stroke row approximation:
# I60-I62, I67.0-I67.1, I69.0-I69.2.
ich_codes <- unique(c(
  icd_codes_s6("I", 60:62),
  c("I670", "I671"),
  c("I690", "I691", "I692")
))
# Ischemic stroke
# 2026-06-16: Shield Table S6 ischaemic stroke row approximation:
# G45-G46.8, I63, I65-I66, I67.2-I67.8, I69.3-I69.4.
is_codes <- unique(c(
  icd_codes_s6("G", 45),
  paste0("G46", 0:8),
  icd_codes_s6("I", 63),
  icd_codes_s6("I", 65:66),
  paste0("I67", 2:8),
  c("I693", "I694")
))
# CANCER
# Mouth, oropharynx and laryngeal cancer
# 2026-05-27: opcan_codes fixed. Split into locan (C000-C099) and opcan (C100-C149)
# locan = Lip and Oral Cavity (C00-C09); opcan = Other Pharyngeal (C10-C14)
# Both use same RR (oralcancer_male/female); kept separate to preserve mortality counts by anatomical site
# Reference label: "Oral Cavity and Pharynx Cancer" (matches AAF CALCULATION CANCER-ACC.R Table 2)
# 2026-06-16: Shield Table S6 split is stricter:
# lip/oral cavity = C00-C08; other pharyngeal = C09-C10 and C12-C14; C11 excluded.
locan_codes <- icd_codes_s6("C", 0:8)                         # C000-C089: lip and oral cavity.
opcan_codes <- unique(c(icd_codes_s6("C", 9:10), icd_codes_s6("C", 12:14))) # Other pharyngeal.
#opcan_codes <- paste0("C0", sprintf("%02d", 0:140))  # original bug: only captured C000-C099
# Esophageal cancer
# 2026-06-16: Shield Table S6 oesophagus cancer row: C15.
oescan_codes <- icd_codes_s6("C", 15)
# Colon and rectum cancer
# 2026-05-14= Had an error with the selection of causes:
# crcan_codes <- c(paste0("C18, 0:9"), "C19X", "C20X")
# 2026-06-16: Shield Table S6 colon and rectum cancer row: C18-C21.
crcan_codes <- icd_codes_s6("C", 18:21)
# Liver cancer
# 2026-06-16: Shield Table S6 liver cancer row: C22.
lican_codes <- icd_codes_s6("C", 22)
# Laryngeal cancer
# 2026-06-16: Shield Table S6 larynx cancer row: C32.
lxcan_codes <- icd_codes_s6("C", 32)
# Breast cancer
# 2026-06-16: Shield Table S6 breast cancer row: C50.
brcan_codes <- icd_codes_s6("C", 50)
# Cervix uteri cancer
# 2026-06-16: Shield Table S6 cervix uteri cancer row: C53.
# 2026-06-30: Not in Shield 2025, placeholder only in code
# cervcan_codes <- icd_codes_s6("C", 53)
# Other causes attributable to alcohol
# Diabetes
# 2026-06-16: Shield Table S6 diabetes mellitus row: E10-E14 minus renal .2 codes.
diabetes_codes <- setdiff(
  icd_codes_s6("E", 10:14),
  c("E102", "E112", "E122", "E132", "E142")
)
# 2026-06-16: Keep old object name for downstream code, but this is now all diabetes, not only DM2.
dm2_codes <- diabetes_codes
# Tuberculosis
# 2026-06-16: Shield Table S6 tuberculosis row: A15-A19, B90.
tb_codes <- unique(c(icd_codes_s6("A", 15:19), icd_codes_s6("B", 90)))
# HIV/Aids
# 2026-06-16: Shield Table S6 HIV/AIDS row: B20-B24.
hiv_codes <- icd_codes_s6("B", 20:24)
# Lower respiratory infection
# 2026-06-16: Shield Table S6 lower respiratory infections row: J09-J22, P23, U04.
lri_codes <- unique(c(icd_codes_s6("J", 9:22), icd_codes_s6("P", 23), icd_codes_s6("U", 4)))
# Liver cirrhosis
# 2026-06-16: Shield Table S6 cirrhosis row: K70 and K74.
lc_codes <- unique(c(icd_codes_s6("K", 70), icd_codes_s6("K", 74)))
#Acute pancreatitis
# 2026-06-16: Shield Table S6 pancreatitis row: K85-K86.
# 2026-06-16: Exclude K860 here because K860 remains fully attributable as pancreati_oh above.
panc_codes <- setdiff(icd_codes_s6("K", 85:86), pancreati_oh_codes)
# Stomach cancer
# 2026-06-16: Not in the pasted Shield Table S6 alcohol-causal rows; retained for downstream compatibility.
stom_codes <- icd_codes_s6("C", 16)         # C160-C169/C16X
# Pancreatic cancer (note: panc_codes above = K85 Acute Pancreatitis, different disease)
# 2026-06-16: Not in the pasted Shield Table S6 alcohol-causal rows; retained for downstream compatibility.
panccan_codes <- icd_codes_s6("C", 25)      # C250-C259/C25X
# MOTOR VEHICLE
# 2026-06-16: Old v_codes()/ri_codes used selected motor-vehicle 4th digits.
# 2026-06-16: Replaced by Shield Table S6 road injury row: V01-V04, V06, V09-V80, V87, V89, V99.
ri_codes <- unique(c(
  icd_stems_s6(sprintf("V0%d", 1:4)),       # Shield: V01-V04.
  icd_stems_s6("V06"),                      # Shield: V06.
  icd_stems_s6(sprintf("V%02d", 9:80)),     # Shield: V09-V80.
  icd_stems_s6("V87"),                      # Shield: V87.
  icd_stems_s6("V89"),                      # Shield: V89.
  icd_stems_s6("V99")                       # Shield: V99.
))
# 2026-06-16: Shield Table S6 poisonings row: X40, X43, X46-X48, X49.
# 2026-06-16: X45 is excluded because accidental alcohol poisoning remains AFF=1.
poisonings_codes <- unique(c(
  icd_stems_s6("X40"),
  icd_stems_s6("X43"),
  icd_stems_s6(sprintf("X%02d", 46:48)),
  icd_stems_s6("X49")
))
# 2026-06-16: Shield Table S6 falls row: W00-W19.
falls_codes <- icd_codes_s6("W", 0:19)
# 2026-06-16: Shield Table S6 fire, heat and hot substances row: X00-X19.
fire_heat_codes <- icd_codes_s6("X", 0:19)
# 2026-06-16: Shield Table S6 drowning row: W65-W74.
drowning_codes <- icd_codes_s6("W", 65:74)
# 2026-06-16: Shield Table S6 mechanical forces row:
# W20-W38, W40-W43, W45, W46, W49-W52, W75, W76.
mechanical_forces_codes <- unique(c(
  icd_codes_s6("W", 20:38),
  icd_codes_s6("W", 40:43),
  icd_stems_s6("W45"),
  icd_stems_s6("W46"),
  icd_codes_s6("W", 49:52),
  icd_stems_s6("W75"),
  icd_stems_s6("W76")
))
# 2026-06-16: All V codes are needed for Shield "Rest of V".
all_v_codes <- icd_codes_s6("V", 1:99)
# 2026-06-16: Shield Table S6 other unintentional injuries row:
# Rest of V, W39, W44, W53-W64, W77-W99, X20-X29, X50-X59, Y40-Y86, Y88, Y89.
# 2026-06-16: Added W47-W48 and X30-X39 to close the parent row:
# "Unintentional injuries: V01-X40, X43, X46-X59, Y40-Y86, Y88, Y89".
# 2026-06-16: Remove W47-W48 and X30-X39 only if you want strict subrow reproduction.
other_unintentional_codes <- unique(c(
  setdiff(all_v_codes, ri_codes),
  icd_stems_s6("W39"),
  icd_stems_s6("W44"),
  # icd_codes_s6("W", 47:48), # 2026-06-25: to replicate Shield's analysis
  icd_codes_s6("W", 53:64),
  icd_codes_s6("W", 77:99),
  icd_codes_s6("X", 20:29),
  # icd_codes_s6("X", 30:39),
  icd_codes_s6("X", 50:59),
  icd_codes_s6("Y", 40:86),
  icd_stems_s6("Y88"),
  icd_stems_s6("Y89")
))
# 2026-06-16: Shield Table S6 unintentional injuries parent category.
unint_inj_codes <- unique(c(
  ri_codes,
  poisonings_codes,
  falls_codes,
  fire_heat_codes,
  drowning_codes,
  mechanical_forces_codes,
  other_unintentional_codes
))
# 2026-06-16: Shield Table S6 self-harm row: X60-X84, Y870.
self_harm_codes_shield <- unique(c(
  icd_codes_s6("X", 60:84),
  "Y870"
))
# 2026-06-16: Exclude X65 from partial self-harm because X65 remains AFF=1 above.
self_harm_codes <- setdiff(
  self_harm_codes_shield,
  x65_alcohol_self_poisoning_codes_aff1
)
# 2026-06-16: Shield Table S6 interpersonal violence row: X85-Y09, Y871.
# 2026-06-16: Old Y35 and dotted "Y87.1" removed; Shield uses Y871 without dot.
interpersonal_violence_codes <- unique(c(
  icd_codes_s6("X", 85:99),
  icd_codes_s6("Y", 0:9),
  "Y871"
))
# 2026-06-16: Shield Table S6 intentional injuries parent category.
int_inj_codes <- unique(c(
  self_harm_codes,
  interpersonal_violence_codes
))
def <- def |>
  dplyr::mutate(
    epi = dplyr::if_else(DIAG1_s6 %in% epilepsy_codes, 1, 0),
    ich = dplyr::if_else(DIAG1_s6 %in% ich_codes, 1, 0),
    is = dplyr::if_else(DIAG1_s6 %in% is_codes, 1, 0),
    hhd = dplyr::if_else(DIAG1_s6 %in% hhd_codes, 1, 0),
    bcan = dplyr::if_else(DIAG1_s6 %in% brcan_codes, 1, 0),
    crcan = dplyr::if_else(DIAG1_s6 %in% crcan_codes, 1, 0),
    lxcan = dplyr::if_else(DIAG1_s6 %in% lxcan_codes, 1, 0),
    lican = dplyr::if_else(DIAG1_s6 %in% lican_codes, 1, 0),
    oescan = dplyr::if_else(DIAG1_s6 %in% oescan_codes, 1, 0),
    locan = dplyr::if_else(DIAG1_s6 %in% locan_codes, 1, 0),  # Lip and Oral Cavity C000-C089
    opcan = dplyr::if_else(DIAG1_s6 %in% opcan_codes, 1, 0),  # Other Pharyngeal C090-C109, C120-C149
    # Cervix cancer, dead code, is not in the `disease_filters` 
    # cervcan = dplyr::if_else(DIAG1_s6 %in% cervcan_codes, 1, 0),  # C53 no alcohol-causal, has a placeholder (Shield 2025); no RR; out of AAF
    stomcan = dplyr::if_else(DIAG1_s6 %in% stom_codes, 1, 0),
    panccan = dplyr::if_else(DIAG1_s6 %in% panccan_codes, 1, 0),  # C25; distinct from panc (K85-K86 = pancreatitis)
    dm2 = dplyr::if_else(DIAG1_s6 %in% dm2_codes, 1, 0),
    ihd = dplyr::if_else(DIAG1_s6 %in% ihd_codes, 1, 0),
    lri = dplyr::if_else(DIAG1_s6 %in% lri_codes, 1, 0),
    tb = dplyr::if_else(DIAG1_s6 %in% tb_codes, 1, 0),
    panc = dplyr::if_else(DIAG1_s6 %in% panc_codes, 1, 0),
    lc = dplyr::if_else(DIAG1_s6 %in% lc_codes, 1, 0),
    unint_inj = dplyr::if_else(DIAG2_s6 %in% unint_inj_codes | DIAG1_s6 %in% unint_inj_codes, 1, 0),
    ri_inj = dplyr::if_else(DIAG1_s6 %in% ri_codes | DIAG2_s6 %in% ri_codes, 1, 0),
    int_inj = dplyr::if_else(DIAG1_s6 %in% int_inj_codes | DIAG2_s6 %in% int_inj_codes, 1, 0),
    # 2026-06-30= Separate clearly what are road from no-road unintentional injuries, 
    # so road injury deaths dont enter as road (son) and the broader classification of unintentional
    # injuries
    unint_inj_noroad = dplyr::if_else(
      (DIAG1_s6 %in% unint_inj_codes | DIAG2_s6 %in% unint_inj_codes) &
      !(DIAG1_s6 %in% ri_codes | DIAG2_s6 %in% ri_codes), 1, 0),
    hiv = dplyr::if_else(DIAG1_s6 %in% hiv_codes, 1, 0)
  )
def <- def |>
  dplyr::mutate(
    age_group = dplyr::case_when(
      dplyr::between(age, 15, 29) ~ 1,
      dplyr::between(age, 30, 44) ~ 2,
      dplyr::between(age, 45, 59) ~ 3,
      age >= 60 ~ 4
    )
  ) %>%
  dplyr::filter(age >= 15)
dplyr::glimpse(def)

# 100% attributable causes (including I42.6, F10, X45...)
fully_attr <- def |>
  dplyr::filter(aaf1 >= 1)|> #, year %in% unique(aaf_long$year)) |>
  dplyr::group_by(year, age_group, gender) |>
  dplyr::summarise(n = dplyr::n(), .groups = "drop") |>
  dplyr::mutate(disease = "Fully attributable to alcohol",
                mort = n, ll_mort = n, up_mort = n) |>
  dplyr::select(year, age_group, gender, disease, mort, ll_mort, up_mort)