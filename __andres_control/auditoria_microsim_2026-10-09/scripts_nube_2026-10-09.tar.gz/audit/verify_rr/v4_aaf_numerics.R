.t0 <- Sys.time()
# Independent recomputation (own fine-grid integrator, not aaf_point / not synthetic quantiles) of rr_bridge
# claims 6 (vol -10% PIF), 8 (former bound), 9 (quitting raises RR), 10 (HED bias), 12 (clamp vs truncation; survey scale).
# RR records: the repo registry, selected with audit/rr_bridge_lib.R::bridge_load() (read line by line; mapping is
# validated below by reproducing every stored 2024 AAF). Aggregates only; no microdata.
# Run: LANG=C.UTF-8 Rscript --vanilla v4_aaf_numerics.R
audit <- "<scratch>/audit"
out_dir <- file.path(audit, "verify_rr")
ctrl <- "<repo>/__andres_control"
source(file.path(audit, "rr_bridge_lib.R")); spec <- bridge_load()
inp <- readRDS(file.path(ctrl, "aaf_engine_inputs_bundle_20261007.rds"))$exposure_inputs
aafs <- readRDS(file.path(ctrl, "aaf_nested_by_disease_20261007.rds"))$by_disease
t5 <- readRDS(file.path(ctrl, "aaf_table5_result_20261007.rds"))$by_age_scope[["15_64"]]$standard_tables
pif2 <- readRDS(file.path(ctrl, "pif2_pif_results_full_20261008.rds")); pif2t <- readRDS(file.path(ctrl, "pif2_pif_results_table5_full_20261008.rds"))
f24 <- utils::read.csv(file.path(ctrl, "oms_factor_by_year.csv"))$factor_CH[7]
rec_err <- utils::read.csv(file.path(ctrl, "microsim_recalib_outputs", "reconstruction_comparison.csv"))
rec_err <- rec_err[rec_err$metric == "hed" & rec_err$year == 2024, c("sex", "age_group", "error")]
stopifnot(nrow(rec_err) == 8L)
fshare <- utils::read.csv(file.path(out_dir, "v2_former_share_2024.csv"))
deaths <- utils::read.csv(file.path(out_dir, "v1_deaths_cells_2024.csv"))

xg <- seq(0.1, 150, length.out = 150001L)
trap <- function(y) sum(diff(xg) * (y[-1] + y[-length(y)]) / 2)
dens <- function(est) stats::dgamma(xg, est$estimate[["shape"]], est$estimate[["rate"]])
# E over the gamma truncated to [0.1,150] (expand_pif) and over the full gamma with x clamped to [0.1,150]
E_tr <- function(est, fx) { d <- dens(est); trap(d * fx) / trap(d) }
E_cl <- function(est, fx) { sh <- est$estimate[["shape"]]; ra <- est$estimate[["rate"]]
  fx[1] * stats::pgamma(0.1, sh, ra) + trap(dens(est) * fx) + fx[length(fx)] * stats::pgamma(150, sh, ra, lower.tail = FALSE) }

ent <- unique(spec[, c("cause", "output", "sex", "rr_source", "principal", "hed_mode")])
rows <- list()
for (i in seq_len(nrow(ent))) for (g in 1:4) {
  e0 <- ent[i, ]; band <- c("15-34", "35-64", "35-64", "35-64")[g]
  e <- spec[spec$cause == e0$cause & spec$sex == e0$sex & spec$rr_source == e0$rr_source & (is.na(spec$band) | spec$band == band), ]
  stopifnot(nrow(e) == 1L); rec <- e$record[[1]]
  s <- if (e0$sex == "female") "fem" else "male"
  p_abs <- inp[[paste0("p_abs_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]
  p_form <- inp[[paste0("p_form_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]
  p_hed <- inp[[paste0("p_hed_list_", s)]][[g]][[7]]
  pooled <- inp[[paste0("g_", s, "_list")]][["2024"]][[g]]; split <- inp[[paste0("g_", s, "_hed_list")]][["2024"]][[g]]
  cur <- 1 - p_abs - p_form; rrfd <- exp(rec$lnRRFormer)
  RR <- function(x) rep_len(rec$RRCurrent(x, rec$betaCurrent), length(x))
  RRh <- function(x) if (e0$hed_mode == "cap") pmax(RR(x), 1) else rep_len(rec$RRCurrent_binge(x, rec$betaCurrent_binge), length(x))
  Rpop <- function(Edr) p_abs + p_form * rrfd + cur * Edr
  drink <- function(E, f_n, f_h, ph = p_hed) if (e0$hed_mode == "none") E(pooled, f_n) else (1 - ph) * E(split$nhed, f_n) + ph * E(split$hed, f_h)
  rn <- RR(xg); rh <- if (e0$hed_mode == "none") NULL else RRh(xg)
  R0 <- Rpop(drink(E_tr, rn, rh))
  Rcl <- Rpop(drink(E_cl, rn, rh))
  xs <- pmax(xg / f24, 0.1)
  Rsv <- Rpop(drink(E_tr, RR(xs), if (is.null(rh)) NULL else RRh(xs)))
  Rv <- Rpop(drink(E_tr, RR(0.9 * xg), if (is.null(rh)) NULL else RRh(0.9 * xg)))
  a <- function(R) (R - 1) / R
  stored <- if (e0$rr_source == "table5_puc") { tb <- t5[[e0$sex]]; tb[tb$disease == e0$cause & tb$Year == 2024, paste0("AAF_ag", g)] } else {
    tb <- aafs[[e0$cause]]$outputs[[e0$output]]$table; tb[tb$Year == 2024, paste0(if (e0$sex == "female") "Fem" else "Male", g, "_point")] }
  pf <- if (e0$rr_source == "table5_puc") pif2t else pif2
  pv <- pf$pif[pf$output_name == e0$output & pf$year == 2024 & pf$age_group == g & pf$scenario_id == "volume_reduction_10"]
  # former bound: the 31d-12m share takes RR(0.1) instead of RR_FD
  sh <- fshare$share_exp[fshare$sex == e0$sex & fshare$tramo == g]
  Rfm <- R0 - p_form * sh * (rrfd - RR(0.1))
  # HED: uniform -4.5 pp vs 2024 cell-specific reconstruction error (simulated - observed)
  err <- rec_err$error[rec_err$sex == e0$sex & rec_err$age_group == g]
  Rh45 <- Rh24 <- NA_real_
  if (e0$hed_mode != "none") { Rh45 <- Rpop(drink(E_tr, rn, rh, max(p_hed - 0.045, 0))); Rh24 <- Rpop(drink(E_tr, rn, rh, p_hed + err)) }
  # share of current drinkers for whom quitting (RR(x) -> RR_FD) RAISES risk, under the drinker exposure density
  qs <- if (e0$hed_mode == "none") { d <- dens(pooled); trap(d * (rn < rrfd)) / trap(d) } else
    (1 - p_hed) * { d <- dens(split$nhed); trap(d * (rn < rrfd)) / trap(d) } + p_hed * { d <- dens(split$hed); trap(d * (rh < rrfd)) / trap(d) }
  rows[[length(rows) + 1L]] <- data.frame(cause = e0$cause, sex = e0$sex, age_group = g, rr_source = e0$rr_source,
    principal = e0$principal, hed_mode = e0$hed_mode, rr_fd = rrfd, stored = stored, aaf_mine = a(R0), aaf_clamp = a(Rcl),
    aaf_survey = a(Rsv), pif_vol10_mine = 1 - Rv / R0, pif_vol10_pif2 = pv, aaf_former12m = a(Rfm),
    aaf_hed_m45 = a(Rh45), aaf_hed_2024err = a(Rh24), hed_err_2024 = err, share_quit_raises_rr = qs)
}
r <- do.call(rbind, rows)
utils::write.csv(r, file.path(out_dir, "v4_aaf_numerics_2024.csv"), row.names = FALSE)
pr <- r$principal
cat(sprintf("baseline: my AAF vs stored, max |diff| = %.2e over %d cells (validates record mapping + integrator)\n", max(abs(r$aaf_mine - r$stored)), nrow(r)))
cat(sprintf("[12] clamp vs truncation, principal: max |diff| = %.4f (%s %s g%d); cells |diff|>0.01: %d of %d; all cells max %.4f\n",
  max(abs(r$aaf_clamp - r$stored)[pr]), r$cause[pr][which.max(abs(r$aaf_clamp - r$stored)[pr])], r$sex[pr][which.max(abs(r$aaf_clamp - r$stored)[pr])],
  r$age_group[pr][which.max(abs(r$aaf_clamp - r$stored)[pr])], sum(abs(r$aaf_clamp - r$stored)[pr] > 0.01), sum(pr), max(abs(r$aaf_clamp - r$stored))))
k <- pr & abs(r$stored) > 0.01
cat(sprintf("[12] survey scale: median AAF_survey/AAF = %.3f over %d principal cells with |AAF|>0.01; max |diff| = %.4f\n",
  stats::median(r$aaf_survey[k] / r$stored[k]), sum(k), max(abs(r$aaf_survey - r$stored))))
cat(sprintf("[6] PIF vol-10: mine vs pif2 max |diff| = %.2e over %d cells\n", max(abs(r$pif_vol10_mine - r$pif_vol10_pif2)), nrow(r)))
fm <- stats::aggregate(cbind(stored, aaf_former12m) ~ cause + sex, r[pr & r$cause %in% c("Liver Cancer", "Ischaemic Heart Disease", "Colon and rectum Cancer", "Liver Cirrhosis"), ], mean)
cat("[8] former bound (unweighted mean over 4 tramos):\n"); print(fm, digits = 3, row.names = FALSE)
hd <- r[pr & r$hed_mode != "none", ]
hd$rel45 <- hd$aaf_hed_m45 / hd$stored - 1; hd$rel24 <- hd$aaf_hed_2024err / hd$stored - 1
cat("[10] HED: relative AAF change, mean over tramos, uniform -4.5pp vs 2024 cell-specific error:\n")
print(stats::aggregate(cbind(rel45, rel24) ~ cause + sex, hd, mean), digits = 3, row.names = FALSE)
cat(sprintf("[10] 2024 HED reconstruction error by cell (sim - obs, pp): %s ; mean %.2f pp\n",
  paste(sprintf("%s%d:%+.1f", substr(rec_err$sex, 1, 1), rec_err$age_group, 100 * rec_err$error), collapse = " "), 100 * mean(rec_err$error)))
dd <- merge(hd, deaths[, c("cause", "sex", "age_group", "deaths_v0610")], by = c("cause", "sex", "age_group"), all.x = TRUE)
dd$deaths_v0610[is.na(dd$deaths_v0610)] <- 0
cat(sprintf("[10] attributable deaths 2024 in IHD+IS+injuries: base %.1f | uniform -4.5pp %.1f (%+.1f) | 2024 cell errors %.1f (%+.1f)\n",
  sum(dd$deaths_v0610 * dd$stored), sum(dd$deaths_v0610 * dd$aaf_hed_m45), sum(dd$deaths_v0610 * (dd$aaf_hed_m45 - dd$stored)),
  sum(dd$deaths_v0610 * dd$aaf_hed_2024err), sum(dd$deaths_v0610 * (dd$aaf_hed_2024err - dd$stored))))
q <- r[pr & r$rr_fd > 1.0001, ]
cat("[9] share of current drinkers (2024 exposure density) for whom RR(x) < RR_FD, i.e. quitting -> former RAISES RR:\n")
print(stats::aggregate(share_quit_raises_rr ~ cause + sex, q, function(z) round(range(z), 3)), row.names = FALSE)
cat(sprintf("v4 elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
