#| label: enpg-consolidate
#| results: "hold"

enpg_binge <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))

data <- enpg_binge %>%
  dplyr::filter(edad >= 15) %>%
  dplyr::mutate(
    # db, episodios en el ultimo mes (si una persona tuvo mÃ¡s de un episodio en el dÃ­a, >30). Puede tener mÃ¡s de un episodio en el Ãºltimo mes.
    db = ifelse(db >= 88, NA, db),
    oh3 = as.numeric(haven::zap_labels(oh3)),          # 1) quita post-it -> nÃºmero (dÃ­as)
    oh3 = if_else(oh3 %in% c(88, 99), NA_real_, oh3),  # 2) "No sabe"/"No contesta" -> NA
    # 2026-07-03: Former drinker (fd): last drink NOT in the past 30 days.
    # Force days-since-last-drink to 0 for abstainers AND both former-drinker
    # recency codes, so ">1 year" ex-drinkers survive filter(oh3 <= 30) below.
    # If ">1 year" is dropped here, those rows fall out, and p_form collapses
    # All the confusion was due to Mojibake error. Did not recognized 
    # ENCODING: the survey stores this level as ">1 año" with "ñ" (U+00F1). Write it
    # as ">1 a\u00f1o" (ASCII escape).
    oh3 = dplyr::case_when(
      oh1 == "No" | oh2 == ">30" | oh2 == ">1 a\u00f1o" ~ 0,
      TRUE ~ oh3
    ),
    prom_tragos = dplyr::case_when(
      oh1 == "No" | oh2 == ">30" | oh2 == ">1 a\u00f1o" ~ 0,
      audit2 == "0-2" ~ 1,
      audit2 == "3-4" ~ 3.5,
      audit2 == "5-6" ~ 5.5,
      audit2 == "7-8" ~ 7.5,
      audit2 == "9 o mas" ~ 9
    ),
    diasalchab = oh3 - db, # WARNING:
    # Discount days to episodes and at what point this is compatible
    diasalchab = ifelse(diasalchab < 0, 0, diasalchab),
    volalchab = diasalchab * prom_tragos,
    # binge  move PAFs from distribution (not through the mean)
    volbinge = ifelse(sexo == "Hombre", db * 5, db * 4),
    voltotal = (volbinge + volalchab) * 12, # grams per drink (1)
    voltotMS = (volbinge + volalchab) * 15.7,# grams per drink (2)
    voltotdia = voltotal / 30,
    voltotMINSAL = voltotMS / 30,
    volCH = (voltotdia * 365), # mean = media_tragos day/gr
    volCHMS = (voltotMINSAL * 365)
  ) %>%
  # 2026-10-06 cc-cloud: B1. Current drinkers with unknown drinking days (oh3 NA, 36-341 per wave)
  # used to be dropped here; they now stay in the current-drinker prevalence with an NA volume.
  dplyr::filter(is.na(oh3) | oh3 <= 30)

# db= # 88 -> 1673 times     99 -> 1044       <- documented
# 888 ->  379           999 -> 172       <- same convention (3 digits)
# 500, 550, 1000, 2000, 5000, 6000, 10000  -> 1 each   <- error codes

# APC WHO
# 2026-10-06 cc-cloud: V1 + B1 + C4 (supersedes the 2026-10-06 user patch and the positional,
# rounded conversion() below it). The WHO anchor is the per-capita volume of the WHOLE 15-65
# population, lifetime abstainers and former drinkers = 0 g (Rehm 2010; Shield 2025), NOT the
# mean among drinkers. Current drinkers with an item-missing volume (db/audit2/oh3 NA) stay in
# p_current (B1, WHO GHO 458/459 convention) and are assumed to drink like the observed current
# drinkers of their wave, so per capita = p_current x mean(volume | observed current drinkers)
# and the drinker mean is anchored at 0.8 x APC / p_current. Unknown status (oh1 == "Si" and
# oh2 NA) is left out of numerator and denominator. The factor is joined by year, unrounded, and
# exported for the microsimulation (oms_factor_by_year.csv, 7 aggregate rows).
who_apc <- tibble::tibble(   # WHO GHO SA_0000001688, total APC 15+, litres/year (vintage 2026-06-15); 2024 = 2023 carried forward
  year       = c(2012, 2014, 2016, 2018, 2020, 2022, 2024),
  apc_litres = c(7.21, 7.17, 7.23, 6.98, 7.09, 6.99, 6.58))
oms_factor_by_year <- data %>%
  dplyr::mutate(status = dplyr::case_when(
    oh1 == "No" | oh2 == ">30" | oh2 == ">1 a\u00f1o" ~ "nondrinker",   # ltabs + fd: 0 g
    oh2 == "30 dias" ~ "current",
    TRUE ~ NA_character_)) %>%
  dplyr::filter(!is.na(status)) %>%
  dplyr::group_by(year) %>%
  dplyr::summarise(
    n_status_known     = dplyr::n(),
    p_current          = sum(exp[status == "current"]) / sum(exp),
    mean_drinkers_CH   = stats::weighted.mean(volCH[status == "current"],   exp[status == "current"], na.rm = TRUE),
    mean_drinkers_CHMS = stats::weighted.mean(volCHMS[status == "current"], exp[status == "current"], na.rm = TRUE),
    .groups = "drop") %>%
  dplyr::mutate(pc_totalvolCH   = p_current * mean_drinkers_CH,        # g/year per capita, 12 g/drink
                pc_totalvolCHMS = p_current * mean_drinkers_CHMS) %>%  # g/year per capita, 15.7 g/drink
  dplyr::inner_join(who_apc, by = "year") %>%
  dplyr::mutate(apc_grams   = apc_litres * 0.8 * 0.789 * 1000,   # 0.8 = covered fraction (Rehm, per ACC); 0.789 = ethanol density
                factor_CH   = apc_grams / pc_totalvolCH,
                factor_CHMS = apc_grams / pc_totalvolCHMS)
stopifnot(nrow(oms_factor_by_year) == 7L, all(is.finite(oms_factor_by_year$factor_CH)))
readr::write_csv(oms_factor_by_year, file.path(acc_root(), "__andres_control", "oms_factor_by_year.csv"))
print(as.data.frame(oms_factor_by_year[, c("year", "apc_litres", "p_current", "pc_totalvolCH", "factor_CH", "factor_CHMS")]))

data <- data %>%
  dplyr::left_join(dplyr::select(oms_factor_by_year, year, factor_CH, factor_CHMS), by = "year") %>%
  mutate(volaj   = volCH   * factor_CH,     # g/year, WHO-anchored (12 g/drink)
         volajms = volCHMS * factor_CHMS,   # g/year, WHO-anchored (15.7 g/drink; B19: the grams-per-drink choice cancels)
          # 2026-07-03= 
          # Former drinker (fd): last drink NOT in the past 30 days.
          # Includes BOTH recency codes -- oh2 == ">30" (last drink >30 days ago) and
          # oh2 == ">1 year" (last drink >1 year ago) -- matching JRT / Sherk-InterMAHP,
          # which apply the single former-drinker RR to every ex-drinker regardless of
          # time since quitting.
          # CAVEAT: for flat-RR cancers (colorectal, liver, stomach, pancreas) this term
          # is ~90-100% of the AAF and is sensitive to sick-quitter / reverse causation
          # (worst for liver, RR_fd=2.68). Report a sensitivity bracket at RR_fd = 1.
         volajohdia = volaj/365,
         volajohdiams = volajms/365,
         cvolaj = case_when(oh1 == "No" ~ "ltabs",
                            oh2 == ">30" | oh2 == ">1 a\u00f1o" ~ "fd",
           sexo == "Mujer" & volajohdia > 0 & volajohdia <= 19.99 ~ "cat1",
           sexo == "Mujer" & volajohdia >= 20 & volajohdia <= 39.99 ~ "cat2",
           sexo == "Mujer" & volajohdia >= 40 & volajohdia <= 100 ~ "cat3",
           sexo == "Mujer" & volajohdia > 100 ~ "cat4",
           sexo == "Hombre" & volajohdia > 0 & volajohdia <= 39.99 ~ "cat1",
           sexo == "Hombre" & volajohdia >= 40 & volajohdia <= 59.99 ~ "cat2",
           sexo == "Hombre" & volajohdia >= 60 & volajohdia <= 100 ~ "cat3",
           sexo == "Hombre" & volajohdia > 100 ~ "cat4",
           # 2026-10-06 cc-cloud: B1. Current drinker (last 30 days) with item-missing or zero volume:
           # keeps the current status (counts in the p_abs/p_form denominators of step0) but enters
           # neither the gamma fits (volajohdia > 0) nor the HED share (hed is NA when db is NA; V3).
           oh2 == "30 dias" ~ "cur_na",
           TRUE ~ NA),
         cvolajms = case_when(oh1 == "No" ~ "ltabs",
                        oh2 == ">30" | oh2 == ">1 a\u00f1o" ~ "fd",
                        sexo == "Mujer" & volajohdiams > 0 & volajohdiams <= 19.99 ~ "cat1",
                        sexo == "Mujer" & volajohdiams >= 20 & volajohdiams <= 39.99 ~ "cat2",
                        sexo == "Mujer" & volajohdiams >= 40 & volajohdiams <= 100 ~ "cat3",
                        sexo == "Mujer" & volajohdiams > 100 ~ "cat4",
                        sexo == "Hombre" & volajohdiams > 0 & volajohdiams <= 39.99 ~ "cat1",
                        sexo == "Hombre" & volajohdiams >= 40 & volajohdiams <= 59.99 ~ "cat2",
                        sexo == "Hombre" & volajohdiams >= 60 & volajohdiams <= 100 ~ "cat3",
                        sexo == "Hombre" & volajohdiams > 100 ~ "cat4",
                        oh2 == "30 dias" ~ "cur_na",   # 2026-10-06 cc-cloud: B1, same rule as cvolaj
                        TRUE ~ NA),
         hed = ifelse(db > 0,1,0),
         edad_tramo = case_when(between(edad, 15, 29)~1,
                                between(edad, 30,44)~2,
                                between(edad,45,59)~3,
                                between(edad,60,65)~4),
         aux = ifelse(oh1 == "No" & !is.na(oh2) ,1,0)) %>% 
  filter(aux == 0) %>% 
  dplyr::select(year, sexo, exp, edad_tramo, oh1, oh2, oh3, volajohdia, volajohdiams,cvolaj,cvolajms, hed,db, -aux)

# Derived from microdata: write to tempdir() and pack it encrypted (never plain inside the repo).
.binge_tmp <- file.path(tempdir(), "data_binge_sensitivity.rds")
write_rds(data, .binge_tmp)
acc_pack(.binge_tmp, file.path(acc_root(), "_enpg", "data_binge_sensitivity.rds.tar.xz.enc"))