#| label: mort-trends-age-sex-chile12-join-aaf-w-mortality
#| results: "hold"

# Define all diseases with their filters and genders
disease_filters <- list(
  "Breast Cancer" = list(filter_col = "bcan", genders = c("Mujer")),
  "Liver Cancer" = list(filter_col = "lican", genders = c("Mujer", "Hombre")),
  "Larynx Cancer" = list(filter_col = "lxcan", genders = c("Mujer", "Hombre")),
  "Oesophagus Cancer" = list(filter_col = "oescan", genders = c("Mujer", "Hombre")),
  "Oral Cavity and Pharynx Cancer" = list(filter_col = "locan", genders = c("Mujer", "Hombre")),
  "Other Pharyngeal Cancer" = list(filter_col = "opcan", genders = c("Mujer", "Hombre")),
  "Colon and rectum Cancer" = list(filter_col = "crcan", genders = c("Mujer", "Hombre")),
  # 2026-07-02: recovered - registry audit confirms Stomachcancer_*/Pancreascancer_*
  # carry real WHO2024/Adam RR; Sherk/InterMAHP (JRT_20260702_cancer) independently
  # confirms both with sourced betas too. "not in Shield S6" only matters for a
  # strict Lancet PH 2025 replication, not the WHO2024 GSR one this notebook runs.
  "Stomach Cancer" = list(filter_col = "stomcan", genders = c("Mujer", "Hombre")),
  "Pancreatic Cancer" = list(filter_col = "panccan", genders = c("Mujer", "Hombre")),
  "Acute Pancreatitis" = list(filter_col = "panc", genders = c("Mujer", "Hombre")),
  "Epilepsy" = list(filter_col = "epi", genders = c("Mujer", "Hombre")),
  "DM2" = list(filter_col = "dm2", genders = c("Mujer", "Hombre")),
  "HIV" = list(filter_col = "hiv", genders = c("Mujer", "Hombre")),
  "Hypertensive Heart Disease" = list(filter_col = "hhd", genders = c("Mujer", "Hombre")),
  "Intracerebral Haemorrhage" = list(filter_col = "ich", genders = c("Mujer", "Hombre")),
  "Ischaemic Heart Disease" = list(filter_col = "ihd", genders = c("Mujer", "Hombre")),
  "Ischaemic Stroke" = list(filter_col = "is", genders = c("Mujer", "Hombre")),
  "Liver Cirrhosis" = list(filter_col = "lc", genders = c("Mujer", "Hombre")),
  "Lower Respiratory Infection" = list(filter_col = "lri", genders = c("Mujer", "Hombre")),
  "Road Injuries" = list(filter_col = "ri_inj", genders = c("Mujer", "Hombre")),
  "Tuberculosis" = list(filter_col = "tb", genders = c("Mujer", "Hombre")),
  # 2026-06-30: Changed to exclude road injuries in the classification  
  "Unintentional Injuries" = list(filter_col = "unint_inj_noroad", genders = c("Mujer", "Hombre")),
  "Intentional Injuries" = list(filter_col = "int_inj", genders = c("Mujer", "Hombre"))
)
# Generate mortality results by disease, sex, and age group
mortality_results <- purrr::imap_dfr(disease_filters, function(filter_info, disease_name) {
  filter_col <- filter_info$filter_col
  purrr::map_dfr(filter_info$genders, function(gender_i) {
    def |>
      dplyr::filter(
        gender == gender_i,
        year %in% unique(aaf_long$year)
      ) |>
      dplyr::group_by(year, gender, age_group) |>
      dplyr::summarise(
        n = sum(.data[[filter_col]] == 1, na.rm = TRUE),
        .groups = "drop"
      ) |>
      dplyr::filter(n > 0) |>
      dplyr::left_join(
        aaf_long |>
          dplyr::filter(disease == disease_name, gender == gender_i) |>
          dplyr::distinct(year, age_group, gender, disease, .keep_all = TRUE),
        by = c("year", "age_group", "gender")
      ) |>
      dplyr::mutate(
        mort = point * n,
        ll_mort = lower * n,
        up_mort = upper * n,
        disease = disease_name
      ) |>
      dplyr::select(year, age_group, gender, disease, mort, ll_mort, up_mort)
  })
})
# 2026-07-02: fold the AAF=1 block (`fully_attr`, built in chile11) into the same object that
# gets exported. Previously bind_rows(mortality_results, fully_attr) fed only the kable() preview
# and was never reassigned, so the Excel export kept the partial-cause table only.
# 2026-10-06 cc-cloud: B2. Keep the AAF = 1 block on the 7 ENPG wave years only, so that every
# total, standardized rate and figure mixes the same year set as the partial causes (the filter
# cannot live in chile11, where aaf_long does not exist yet).
mortality_results <- dplyr::bind_rows(mortality_results,
                                      fully_attr |> dplyr::filter(year %in% unique(aaf_long$year))) |>
  dplyr::filter(!is.na(mort)) |>
  dplyr::arrange(disease, year, age_group, gender)

mortality_results |>
  rio::export(
  file.path(acc_root(), "__andres_control",
            sprintf("Mortality Estimates WHO 2024_%s.xlsx", format(Sys.Date(), "%Y%m%d")))
)