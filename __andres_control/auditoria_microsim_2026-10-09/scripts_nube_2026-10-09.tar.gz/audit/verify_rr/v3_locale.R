.t0 <- Sys.time()
# Claim 14 probe: does the ">1 año" comparison fail in the C locale? Escape form (used by expand_pif and
# ms-survey-inputs) vs a literal UTF-8 byte form (used by audit/rr_bridge_data_checks.R). Counts only.
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>/__andres_control"); source("<repo>/_tools/acc_data.R")
raw <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))
s <- raw$year == 2024 & raw$edad >= 15 & raw$edad <= 65 & as.character(raw$oh1) == "Si"
oh2 <- as.character(raw$oh2)[s]
lit <- rawToChar(as.raw(c(0x3e, 0x31, 0x20, 0x61, 0xc3, 0xb1, 0x6f)))   # literal bytes, as a source file typed "ñ"
cat(sprintf("LC_CTYPE=%s | escape '\\u00f1' matches: %d | literal-bytes matches: %d | '>30' matches: %d\n",
  Sys.getlocale("LC_CTYPE"), sum(oh2 %in% ">1 año"), sum(oh2 %in% lit), sum(oh2 %in% ">30")))
cat(sprintf("v3_locale elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
