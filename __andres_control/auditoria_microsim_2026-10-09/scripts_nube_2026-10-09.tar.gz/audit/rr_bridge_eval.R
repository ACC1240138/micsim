.t0 <- Sys.time()
# Evaluate RR_i for every cause/sex/band/source at x = 0,10,20,40,60,100 g/day (APC scale),
# NHED vs HED, plus former-drinker RR. Run: Rscript --vanilla rr_bridge_eval.R
audit_dir <- "<scratch>/audit"
source(file.path(audit_dir, "rr_bridge_lib.R"))
spec <- bridge_load()
cat(sprintf("spec rows: %d (causes %d)\n", nrow(spec), length(unique(spec$cause))))

xs <- c(0, 10, 20, 40, 60, 100)
band_to_group <- c("15-34" = 1L, "35-64" = 2L, "65+" = NA_integer_)
out <- list()
for (k in seq_len(nrow(spec))) {
  e <- spec[k, ]
  rec <- e$record[[1]]
  g <- if (is.na(e$band)) 2L else band_to_group[[e$band]]
  if (is.na(g)) {                      # 65+ band: no pipeline group maps to it under 15_65; evaluate raw
    nh <- rep_len(rec$RRCurrent(pmax(xs, 0.1), rec$betaCurrent), length(xs))
    hd <- pmax(nh, 1)
    via <- "raw record (65+ band, not reachable with age_scope 15_65)"
  } else {
    pop <- data.frame(sex = e$sex, age_group = g, status = "current", gpd_apc = rep(xs, 2),
                      hed = rep(c(FALSE, TRUE), each = length(xs)))
    # call through the contract, restricted to this entry's source
    rr <- rr_individual(pop, e$cause, spec[spec$cause == e$cause & spec$rr_source == e$rr_source &
                                             spec$sex == e$sex & (is.na(spec$band) | spec$band == e$band), ],
                        source = e$rr_source)
    nh <- rr[seq_along(xs)]; hd <- rr[length(xs) + seq_along(xs)]
    via <- "rr_individual()"
  }
  raw0 <- suppressWarnings(rec$RRCurrent(0, rec$betaCurrent)[1])
  out[[k]] <- data.frame(cause = e$cause, sex = e$sex, band = e$band, rr_source = e$rr_source,
                         principal = e$principal, hed_mode = e$hed_mode, source_object = rec$source_object,
                         rr_former = exp(rec$lnRRFormer), var_ln_rr_former = rec$varLnRRFormer,
                         raw_RR_at_0 = raw0,
                         setNames(as.list(nh), paste0("nhed_", xs)),
                         setNames(as.list(if (e$hed_mode == "none") rep(NA_real_, length(xs)) else hd), paste0("hed_", xs)),
                         via = via, stringsAsFactors = FALSE, check.names = FALSE)
}
tab <- do.call(rbind, out)
utils::write.csv(tab, file.path(audit_dir, "rr_bridge_table.csv"), row.names = FALSE)

# Self-checks of the contract (synthetic, no microdata)
chk <- function(ok, msg) cat(sprintf("[%s] %s\n", if (isTRUE(ok)) "PASS" else "FAIL", msg))
p <- data.frame(sex = c("female", "male", "male", "male"), age_group = c(1, 2, 2, 4),
                status = c("never", "former", "current", "current"), gpd_apc = c(50, 50, 0, 200), hed = c(TRUE, TRUE, FALSE, TRUE))
lc <- rr_individual(p, "Liver Cirrhosis", spec)
chk(lc[1] == 1, "never drinker -> RR 1 regardless of gpd/hed")
chk(abs(lc[2] - 3.26) < 1e-12, "former drinker -> exp(lnRRFormer) (cirrhosis 3.26)")
chk(is.na(rr_individual(p, "Breast Cancer", spec)[2]), "male breast cancer -> NA (no record)")
is5 <- rr_individual(p, "Ischaemic Stroke", spec)
chk(all(is.finite(is5)), "Table 5 IS at gpd 0 is finite after clamping to 0.1 (raw form is NaN at 0)")
chk(identical(rr_individual(p[4, ], "Road Injuries", spec), rr_individual(transform(p[4, ], gpd_apc = 150), "Road Injuries", spec)),
    "gpd above 150 is clamped to 150 (expand_pif grid max)")
ihd_m <- rr_individual(data.frame(sex = "male", age_group = 2, status = "current", gpd_apc = 30, hed = c(FALSE, TRUE)),
                       "Ischaemic Heart Disease", spec)
chk(ihd_m[1] < 1 && ihd_m[2] == 1, sprintf("IHD male 30 g/day: NHED protective (%.4f), HED capped to 1", ihd_m[1]))
cat(sprintf("rows in RR table: %d; any NaN among clamped values: %s\n", nrow(tab),
            any(is.nan(as.matrix(tab[grep("^(nhed|hed)_", names(tab))])))))
cat(sprintf("raw RR at x = 0 is NaN for: %s\n",
            paste(unique(paste(tab$cause, tab$sex, tab$rr_source)[is.nan(tab$raw_RR_at_0)]), collapse = "; ")))
cat(sprintf("rr_bridge_eval elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
