# rr_bridge_lib.R -- person-level bridge to the expand_pif RR registry (scratch prototype).
# Loads the registry exactly like test_rr_registry_*.R / test_aaf_compute.R:
#   source("rr_registry_adam.R"); source("aaf_unified.R")   (wd = __andres_control)
# plus the Table 5 PUC records (aaf_table5_ihd_is_experiment.R, autorun OFF) for IS (principal) / IHD (sensitivity).
# Nothing in the repo is modified.

bridge_load <- function(control_dir = "<repo>/__andres_control") {
  old <- setwd(control_dir); on.exit(setwd(old), add = TRUE)
  source("rr_registry_adam.R", local = globalenv())
  source("aaf_unified.R", local = globalenv())
  Sys.setenv(AAF_TABLE5_AUTORUN = "false")
  t5 <- new.env()
  sys.source("aaf_table5_ihd_is_experiment.R", envir = t5)   # own env: the file redefines .t0
  reg <- lapply(c(cancer = "cancer", hhd = "hhd", general = "general", ihd = "ihd", is = "is",
                  injuries = "injuries"), function(s) load_adam_rr_registry(scope = s, verbose = FALSE))
  invisible(lapply(reg, validate_adam_rr_registry))
  reg$ihd_t5 <- t5$table5_make_registry("ihd")
  reg$is_t5  <- t5$table5_make_registry("is")

  # One row per (cause, sex, Adam band, RR source). `output` = expand_pif output table name.
  rows <- list(); recs <- list()
  add <- function(cause, output, sex, scope, hed_mode, rr_source, principal, band = NA_character_, find = list()) {
    rows[[length(rows) + 1L]] <<- data.frame(cause = cause, output = output, sex = sex, scope = scope,
      band = band, hed_mode = hed_mode, rr_source = rr_source, principal = principal, stringsAsFactors = FALSE)
    recs[[length(recs) + 1L]] <<- do.call(.aaf_find_one, c(list(reg[[scope]]), find))
  }
  cancer <- data.frame(
    cause = c("Oral Cavity and Pharynx Cancer", "Other Pharyngeal Cancer", "Oesophagus Cancer",
              "Colon and rectum Cancer", "Liver Cancer", "Larynx Cancer", "Breast Cancer",
              "Stomach Cancer", "Pancreatic Cancer"),
    stem = c("locan", "opcan", "oescan", "crcan", "lican", "lxcan", "bcan", "stomcan", "panccan"),
    disease = c("Oral_Cavity_and_Pharynx_Cancer", "Oral_Cavity_and_Pharynx_Cancer", "Oesophagus_Cancer",
                "Colorectal_Cancer", "Liver_Cancer", "Larynx_Cancer", "Breast_Cancer",
                "Stomach_Cancer", "Pancreas_Cancer"),
    principal = c(rep(TRUE, 7), FALSE, FALSE), stringsAsFactors = FALSE)   # C16/C25 out (handoff Q10)
  for (i in seq_len(nrow(cancer))) for (sx in c("female", "male")) {
    if (cancer$stem[i] == "bcan" && sx == "male") next
    add(cancer$cause[i], paste0(cancer$stem[i], "_", sx), sx, "cancer", "none", "who_adam",
        cancer$principal[i], find = list(disease = cancer$disease[i], sex = sx))
  }
  for (sx in c("female", "male"))
    add("Hypertensive Heart Disease", paste0("hhd_", sx), sx, "hhd", "none", "who_adam", TRUE,
        find = list(disease = "Hypertension", sex = sx))
  gen <- data.frame(out = c("epi_female", "epi_male", "dm_fem", "dm_male", "tb_female", "tb_male",
                            "hiv_female", "hiv_male", "lri_female", "lri_male", "lc_fem", "lc_male",
                            "panc_fem", "panc_male", "ich_female", "ich_male"),
                    obj = c("epilepsyfemale", "epilepsymale", "diabetesfemale", "diabetesmale",
                            "tuberculosisfemale", "tuberculosismale", "HIVfemale", "HIVmale",
                            "lowerrespfemale", "lowerrespmale", "livercirrhosisfemale", "livercirrhosismale",
                            "pancreatitisfemale", "pancreatitismale", "hemorrhagicstrokefemale",
                            "hemorrhagicstrokemale"),
                    cause = rep(c("Epilepsy", "DM2", "Tuberculosis", "HIV", "Lower Respiratory Infection",
                                  "Liver Cirrhosis", "Acute Pancreatitis", "Intracerebral Haemorrhage"),
                                each = 2),
                    sex = rep(c("female", "male"), 8), stringsAsFactors = FALSE)
  for (i in seq_len(nrow(gen)))
    add(gen$cause[i], gen$out[i], gen$sex[i], "general", "none", "who_adam", TRUE,
        find = list(source_object = gen$obj[i], sex = gen$sex[i]))
  for (sx in c("female", "male")) for (b in c("15-34", "35-64", "65+")) {
    add("Ischaemic Heart Disease", paste0("ihd_", sx), sx, "ihd", "cap", "who_adam", TRUE, b,
        list(sex = sx, adam_age_band = b))                         # IHD: WHO principal (handoff 2026-10-07)
    add("Ischaemic Heart Disease", paste0("ihd_", sx), sx, "ihd_t5", "cap", "table5_puc", FALSE, b,
        list(sex = sx, adam_age_band = b))
    add("Ischaemic Stroke", paste0("is_", sx), sx, "is", "cap", "who_adam", FALSE, b,
        list(sex = sx, adam_age_band = b))
    add("Ischaemic Stroke", paste0("is_", sx), sx, "is_t5", "cap", "table5_puc", TRUE, b,
        list(sex = sx, adam_age_band = b))                         # IS: Table 5 PUC principal
  }
  inj <- data.frame(out = c("ri_fem", "ri_male", "injuries_fem", "injuries_male", "violence_fem", "violence_male"),
                    obj = rep(c("injuries_MVA", "injuries_other_unit", "injuries_other_int"), each = 2),
                    cause = rep(c("Road Injuries", "Unintentional Injuries", "Intentional Injuries"), each = 2),
                    sex = rep(c("female", "male"), 3), stringsAsFactors = FALSE)
  for (i in seq_len(nrow(inj)))
    add(inj$cause[i], inj$out[i], inj$sex[i], "injuries", "explicit", "who_adam", TRUE,
        find = list(source_object = inj$obj[i], sex = inj$sex[i]))
  spec <- do.call(rbind, rows)
  spec$record <- recs
  spec
}

# THE CONTRACT. pop: data.frame with
#   sex       "female"/"male"
#   age_group 1:4 (15-29, 30-44, 45-59, 60-65), the expand_pif tramo
#   status    "never" | "former" | "current"   (30-day definition, same as expand_pif cvolaj)
#   gpd_apc   g/day on the WHO/APC-anchored scale (= gpd_survey * factor_CH[year]); ignored unless current
#   hed       logical, HED in past 30 days (5+/4+ drinks); ignored unless current
# Returns RR_i (NA where the cause has no record for that sex, e.g. male breast cancer).
rr_individual <- function(pop, cause, spec, source = c("principal", "who_adam", "table5_puc"),
                          age_scope = "15_65", x_min = 0.1, x_max = 150) {
  source <- match.arg(source)
  ent <- spec[spec$cause == cause, , drop = FALSE]
  ent <- if (source == "principal") ent[ent$principal, , drop = FALSE] else ent[ent$rr_source == source, , drop = FALSE]
  if (!nrow(ent)) stop("rr_individual: no RR record for cause '", cause, "' / source '", source, "'")
  stopifnot(all(pop$status %in% c("never", "former", "current")), all(pop$age_group %in% 1:4))
  band <- aaf_age_band_mapping(age_scope)$adam_age_band[pop$age_group]
  rr <- rep(NA_real_, nrow(pop))
  for (k in seq_len(nrow(ent))) {
    rec <- ent$record[[k]]
    sel <- pop$sex == ent$sex[k] & (is.na(ent$band[k]) | band == ent$band[k])
    rr[sel & pop$status == "never"] <- 1
    rr[sel & pop$status == "former"] <- exp(rec$lnRRFormer)
    cu <- which(sel & pop$status == "current")
    if (!length(cu)) next
    # expand_pif integrates on [0.1, 150]; clamping also avoids NaN of Table 5 forms at x = 0 (0 * log 0).
    x <- pmin(pmax(pop$gpd_apc[cu], x_min), x_max)
    h <- as.logical(pop$hed[cu]); h[is.na(h)] <- FALSE
    r <- rep_len(rec$RRCurrent(x, rec$betaCurrent), length(x))
    if (ent$hed_mode[k] == "cap") r[h] <- pmax(r[h], 1)
    if (ent$hed_mode[k] == "explicit" && any(h))
      r[h] <- rep_len(rec$RRCurrent_binge(x[h], rec$betaCurrent_binge), sum(h))
    rr[cu] <- r
  }
  rr
}

# The identity a person-level AAF must satisfy (weights w; abstainers and former drinkers included).
aaf_from_people <- function(rr, w = rep(1, length(rr))) { ok <- !is.na(rr); sum(w[ok] * (rr[ok] - 1)) / sum(w[ok] * rr[ok]) }
