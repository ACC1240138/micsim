# v04_causes.R -- independent recomputation of the cause-level claims: small cells, 66+ shares, DEIS 2024 R99/road,
# reconciliation with the expand_pif pipeline (n = mort/aaf), and the 66+ attributable extrapolation.
.t0 <- Sys.time()
library(data.table)
ROOT <- "<repo>"; AC <- file.path(ROOT, "__andres_control")
V <- "<scratch>/audit/verify_mort"
source(file.path(ROOT, "_tools", "acc_data.R")); setwd(ROOT)
suppressMessages(source(file.path(AC, "ypll_icd_defs.R")))
d <- fread(file.path(V, "agg_v", "cause_year_sex_age.csv"))
d[, band := cut(age, c(14, 29, 44, 59, 65, 79, Inf), labels = c("15-29", "30-44", "45-59", "60-65", "66-79", "80+"))]
lab <- c(aaf1 = "AAF1", bcan = "Breast Cancer", lican = "Liver Cancer", lxcan = "Larynx Cancer", oescan = "Oesophagus Cancer",
  locan = "Oral Cavity and Pharynx Cancer", opcan = "Other Pharyngeal Cancer", crcan = "Colon and rectum Cancer", stom = "Stomach Cancer",
  panccan = "Pancreatic Cancer", panc = "Acute Pancreatitis", epi = "Epilepsy", dm2 = "DM2", hiv = "HIV", hhd = "Hypertensive Heart Disease",
  ich = "Intracerebral Haemorrhage", ihd = "Ischaemic Heart Disease", is = "Ischaemic Stroke", lc = "Liver Cirrhosis",
  lri = "Lower Respiratory Infection", tb = "Tuberculosis", ri = "Road Injuries", int = "Intentional Injuries", unint = "Unintentional Injuries",
  covid = "COVID", other = "Other")
d[, disease := lab[cause]]
stopifnot(!anyNA(d$disease), uniqueN(d$disease) == 26)

# ---- small cells at 15-65 (year x sex x 4 bands x 26 groups; no male breast) ----
g <- CJ(year = 2012:2024, sex = c("female", "male"), band = c("15-29", "30-44", "45-59", "60-65"), disease = unique(d$disease))[!(sex == "male" & disease == "Breast Cancer")]
cc <- merge(g, d[band %in% g$band, .(n = sum(deaths)), by = .(year, sex, band = as.character(band), disease)], all.x = TRUE)
cc[is.na(n), n := 0]
cat(sprintf("15-65 cells: %d | <10: %d | zero: %d\n", nrow(cc), cc[n < 10, .N], cc[n == 0, .N]))

# ---- 66+ shares (pooled 2012-2024, all deaths 15+) ----
d[, grp := fifelse(disease == "AAF1", "AAF1", fifelse(disease %in% c("COVID", "Other"), "nonalc", "partial"))]
sh <- function(x) x[, .(d15_65 = sum(deaths[age <= 65]), d66p = sum(deaths[age >= 66]), d66_79 = sum(deaths[age %between% c(66, 79)])), by = sex][,
  `:=`(share66p = d66p / (d15_65 + d66p), share66_79 = d66_79 / (d15_65 + d66p))][]
cat("all causes:\n"); print(sh(d)); cat("AAF1:\n"); print(sh(d[grp == "AAF1"])); cat("partial (23):\n"); print(sh(d[grp == "partial"]))

# ---- 2024 provisional: R99 and road injuries at 15-65 ----
r <- d[age <= 65, .(r99 = sum(r99), rchap = sum(rchap), road = sum(deaths[disease == "Road Injuries"]), all = sum(deaths)), by = year][order(year)]
r[, rchap_share := rchap / all]; print(r)
cat("R99 mean 2018-2023:", r[year %in% 2018:2023, mean(r99)], " road range 2019-2023:", paste(range(r[year %in% 2019:2023, road]), collapse = "-"),
    " road range 2012-2023:", paste(range(r[year <= 2023, road]), collapse = "-"), "\n")

# ---- reconciliation with the pipeline (15-65, wave years) ----
pp <- as.data.table(ypll_pipeline_deaths())
pp[, sex := ifelse(gender == "Hombre", "male", "female")][, band := c("15-29", "30-44", "45-59", "60-65")[age_group]]
mine <- d[age <= 65 & !disease %in% c("AAF1", "COVID", "Other"), .(mine = sum(deaths)), by = .(year, sex, band = as.character(band), disease)]
rc <- merge(pp[, .(year, sex, band, disease, n, aaf)], mine, by = c("year", "sex", "band", "disease"), all.x = TRUE)
rc[is.na(mine), mine := 0]
cat(sprintf("pipeline cells: %d | max |n - mine|: %.3g | cells off by >0.5: %d\n", nrow(rc), max(abs(rc$n - rc$mine)), rc[abs(n - mine) > 0.5, .N]))
xl <- as.data.table(readxl::read_xlsx(YPLL_MORTALITY_XLSX)); cat("mortality export:", basename(YPLL_MORTALITY_XLSX), " AAF bundle:", basename(YPLL_AAF_BUNDLE), "\n")
xl[, sex := ifelse(gender == "Hombre", "male", "female")]
cat("export diseases:", paste(sort(unique(xl$disease)), collapse = " | "), "\n")
cat("export age groups:", paste(sort(unique(xl$age_group)), collapse = ","), " years:", paste(sort(unique(xl$year)), collapse = ","), "\n")
a1 <- merge(xl[disease == "Fully attributable to alcohol", .(pipe = sum(mort)), by = .(year, sex)],
            d[disease == "AAF1" & age <= 65, .(mine = sum(deaths)), by = .(year, sex)], by = c("year", "sex"))
cat("AAF=1 max |pipe - mine|:", a1[, max(abs(pipe - mine))], "\n")

# ---- 66+ attributable extrapolation with the 60-65 AAF ----
waves <- sort(unique(xl$year))
a4 <- pp[age_group == 4, .(year, sex, disease, aaf)]
old <- d[age >= 66 & year %in% waves & grp == "partial", .(n = sum(deaths)), by = .(year, sex, disease, older = ifelse(age <= 79, "66-79", "80+"))]
ex <- merge(old, a4, by = c("year", "sex", "disease"))
cat("66+ partial deaths in wave years:", old[, sum(n)], " matched to an AAF:", ex[, sum(n)], "\n")
att66 <- ex[, .(attr_partial = sum(aaf * n), attr_partial_6679 = sum(aaf * n * (older == "66-79"))), by = sex]
aaf1_66 <- d[age >= 66 & year %in% waves & grp == "AAF1", .(aaf1_66p = sum(deaths), aaf1_6679 = sum(deaths[age <= 79])), by = sex]
young <- xl[, .(attr_15_65 = sum(mort)), by = sex]
E <- Reduce(merge, list(att66, aaf1_66, young))
E[, `:=`(attr66p = attr_partial + aaf1_66p)][, `:=`(share66p = attr66p / (attr66p + attr_15_65),
  share66_79 = (attr_partial_6679 + aaf1_6679) / (attr66p + attr_15_65))]
print(E)
cvd <- c("Ischaemic Heart Disease", "Ischaemic Stroke", "Intracerebral Haemorrhage", "Hypertensive Heart Disease", "DM2")
E2 <- merge(ex[!disease %in% cvd, .(attr_partial = sum(aaf * n)), by = sex], xl[!disease %in% cvd, .(attr_15_65 = sum(mort)), by = sex])
E2 <- merge(E2, aaf1_66[, .(sex, aaf1_66p)]); E2[, share66p := (attr_partial + aaf1_66p) / (attr_partial + aaf1_66p + attr_15_65)]
print(E2)
# How much of the 66+ partial attribution comes from cells where the 60-65 AAF is negative (protective)?
print(ex[, .(attr_pos = sum(aaf * n * (aaf > 0)), attr_neg = sum(aaf * n * (aaf < 0))), by = sex])
print(ex[disease == "Ischaemic Heart Disease", .(attr = sum(aaf * n), aaf_mean = mean(aaf)), by = sex])
fwrite(cc, file.path(V, "v04_cells_15_65.csv")); fwrite(r, file.path(V, "v04_r99_road.csv")); fwrite(E, file.path(V, "v04_attr66.csv"))
message(sprintf("v04 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
