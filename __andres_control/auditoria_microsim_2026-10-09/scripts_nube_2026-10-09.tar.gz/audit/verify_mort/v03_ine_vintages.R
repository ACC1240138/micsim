# v03_ine_vintages.R -- are there other INE population vintages in the repo? Compare ine_proyecciones.xlsx (2008-2022 even years)
# and ine_proyecciones_2012_2024.xlsx with the engine's ine_basedatos.xlsx June stocks and with HMD implied exposure (v02).
.t0 <- Sys.time()
library(data.table)
HD <- "<repo>/__andres_control/ine_proyecciones_rebuild"
V <- "<scratch>/audit/verify_mort"
rd <- function(f) rbindlist(lapply(c(male = "Hombres", female = "Mujeres"), function(s) {
  z <- as.data.table(readxl::read_xlsx(file.path(HD, f), sheet = s))
  z[, age := suppressWarnings(as.integer(as.numeric(edad)))]
  melt(z[, !"edad"], id.vars = "age", variable.name = "y", value.name = "pop")[, year := as.integer(sub("ano_", "", y))][, y := NULL]
}), idcol = "sex")
w1 <- rd("ine_proyecciones.xlsx"); w2 <- rd("ine_proyecciones_2012_2024.xlsx")
p <- as.data.table(readxl::read_xlsx(file.path(HD, "ine_basedatos.xlsx"), sheet = "BBDD_EEPP-2024_0101"))
p[, dt := as.Date(FECHA, "%d/%m/%Y")]
p <- p[format(dt, "%m-%d") == "06-30", .(year = as.integer(format(dt, "%Y")), sex = ifelse(SEXO == "H", "male", "female"), age = as.integer(EDAD), mid = POBLACION)]
dr <- fread(file.path(V, "v02_drift.csv"))[, .(year, sex, E_hmd)]
f <- function(w) w[age %in% 15:65, .(pop = sum(pop)), by = .(year, sex)]
R <- merge(merge(f(w1)[, .(year, sex, ine_proyecciones = pop)], f(w2)[, .(year, sex, ine_2012_2024 = pop)], all = TRUE),
           p[age %in% 15:65, .(basedatos_mid = sum(mid)), by = .(year, sex)], by = c("year", "sex"))
R <- merge(R, dr, by = c("year", "sex"), all.x = TRUE)
R[, `:=`(proy_vs_basedatos = ine_proyecciones / basedatos_mid - 1, w2_vs_basedatos = ine_2012_2024 / basedatos_mid - 1,
         hmd_vs_proy = E_hmd / ine_proyecciones - 1, hmd_vs_basedatos = E_hmd / basedatos_mid - 1)]
print(R[year %in% 2012:2024 & !is.na(ine_proyecciones), .(year, sex, ine_proyecciones, basedatos_mid, E_hmd = round(E_hmd),
  proy_vs_basedatos = round(100 * proy_vs_basedatos, 2), hmd_vs_proy = round(100 * hmd_vs_proy, 2), hmd_vs_basedatos = round(100 * hmd_vs_basedatos, 2))])
cat("all-ages totals ine_proyecciones.xlsx 2022:", w1[year == 2022, sum(pop)], " ine_basedatos mid-2022:", p[year == 2022, sum(mid)], "\n")
cat("max |w2 - basedatos| relative, 15-65:", R[year %in% 2012:2024, max(abs(w2_vs_basedatos))], "\n")
fwrite(R, file.path(V, "v03_ine_vintages.csv"))
message(sprintf("v03 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
