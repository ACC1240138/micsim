# v06_loyo_band.R -- independent band-level LOYO: S2 (mean of other years) vs S4 (log-linear trend without 2020-21),
# year x sex x 4 bands x cause (COVID excluded; held-out 2013-2023 minus 2020-22), with the Poisson noise floor.
.t0 <- Sys.time()
library(data.table)
V <- "<scratch>/audit/verify_mort"
HD <- "<repo>/__andres_control/ine_proyecciones_rebuild"
d <- fread(file.path(V, "agg_v", "cause_year_sex_age.csv"))[age <= 65 & cause != "covid"]
d[sex == "male" & cause == "bcan", cause := "other"]
p <- as.data.table(readxl::read_xlsx(file.path(HD, "ine_basedatos.xlsx"), sheet = "BBDD_EEPP-2024_0101"))
p[, dt := as.Date(FECHA, "%d/%m/%Y")]
p <- p[format(dt, "%m-%d") == "06-30" & EDAD %between% c(15, 65), .(year = as.integer(format(dt, "%Y")), sex = ifelse(SEXO == "H", "male", "female"), age = EDAD, mid = POBLACION)]
bd <- function(a) cut(a, c(14, 29, 44, 59, 65))
cs <- unique(d[, .(cause, sex)])
g <- merge(CJ(year = 2012:2024, band = levels(bd(15)), k = seq_len(nrow(cs))), data.table(k = seq_len(nrow(cs)), cs), by = "k")
g <- merge(g, d[, .(y = sum(deaths)), by = .(year, sex, cause, band = as.character(bd(age)))], all.x = TRUE, by = c("year", "sex", "cause", "band"))
g[is.na(y), y := 0]
g <- merge(g, p[, .(mid = sum(mid)), by = .(year, sex, band = as.character(bd(age)))], by = c("year", "sex", "band"))
pd <- function(y, mu) 2 * (ifelse(y > 0, y * log(y / mu), 0) - (y - mu))
edev <- function(mu) vapply(mu, function(u) { y <- 0:max(20, ceiling(u + 12 * sqrt(u) + 20)); sum(dpois(y, u) * pd(y, u)) }, 0)
r <- rbindlist(lapply(setdiff(2013:2023, 2020:2022), function(t) g[, {
  tr <- .SD[year != t]; te <- .SD[year == t]; tr4 <- tr[!year %in% 2020:2021]
  b <- suppressWarnings(coef(glm(y ~ I(year - 2018), poisson, data = tr4, offset = log(mid))))
  .(y = te$y, S2 = te$mid * sum(tr$y) / sum(tr$mid), S4 = te$mid * exp(b[1] + b[2] * (t - 2018)))
}, by = .(cause, sex, band)][, year := t]))
r[, `:=`(S2 = pmax(S2, 0.1), S4 = pmax(S4, 0.1))]   # same 0.1 floor as the report
print(r[, .(cells = .N, S2 = sum(pd(y, S2)) / .N, S4 = sum(pd(y, S4)) / .N, floor_S4 = sum(edev(S4)) / .N)])
message(sprintf("v06 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
