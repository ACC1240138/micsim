# v01_extract.R -- independent re-extraction of DEIS deaths for verifying mortality_deis.md.
# Writes ONLY aggregated counts to verify_mort/agg_v/. Microdata stay in R's tempdir().
# Run: Rscript --vanilla v01_extract.R
.t0 <- Sys.time()
library(data.table)
ROOT <- "<repo>"
V <- "<scratch>/audit/verify_mort"
dir.create(file.path(V, "agg_v"), showWarnings = FALSE)
source(file.path(ROOT, "_tools", "acc_data.R")); setwd(ROOT)
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
suppressMessages(source(file.path(ROOT, "__andres_control", "ypll_icd_defs.R")))  # project ICD lists

# --- 2012-2023 bundle: pandas -> csv inside tempdir only ---
pq <- acc_data("_deis/DEFUNCIONES_DEIS_2012_2023_15plus.tar.xz.enc")
tcsv <- tempfile(fileext = ".csv")
stopifnot(system2("python3", c("-I", "-c", shQuote("import sys,pandas as pd; pd.read_parquet(sys.argv[1]).to_csv(sys.argv[2], index=False)"),
                               shQuote(pq), shQuote(tcsv))) == 0)
a <- fread(tcsv, colClasses = "character", na.strings = c("", "NA")); unlink(tcsv)
cat("2012-2023 rows:", nrow(a), " years:", paste(range(a$year), collapse = "-"), " genders:", paste(unique(a$gender), collapse = ","), "\n")
a <- a[, .(year = as.integer(year), gender, age = as.integer(age), diag1, diag2)]

# --- 2024 from the newest weekly file ---
b <- as.data.table(acc_deis()); setnames(b, 1, "ANO")
cat("weekly file:", basename(acc_latest(file.path(ROOT, "_deis"))), "\n")
b24 <- b[ANO == 2024]
chk24 <- data.table(rows_2024 = nrow(b24), exact_dup_rows = sum(duplicated(b24)),
  edad_tipo1_age15p = b24[EDAD_TIPO == 1 & EDAD_CANT >= 15, .N],
  indeterminate_sex_age15p = b24[EDAD_TIPO == 1 & EDAD_CANT >= 15 & !SEXO_NOMBRE %in% c("Hombre", "Mujer"), .N],
  na_edad_cant_tipo1 = b24[EDAD_TIPO == 1, sum(is.na(EDAD_CANT))])
print(chk24); fwrite(chk24, file.path(V, "agg_v", "chk_2024.csv"))
b24 <- b24[EDAD_TIPO == 1 & EDAD_CANT >= 15 & SEXO_NOMBRE %in% c("Hombre", "Mujer"),
           .(year = 2024L, gender = SEXO_NOMBRE, age = as.integer(EDAD_CANT), diag1 = DIAG1, diag2 = DIAG2)]
rm(b)
m <- rbind(a, b24); rm(a, b24)
stopifnot(all(m$gender %in% c("Hombre", "Mujer")), !anyNA(m$age), all(m$age >= 15))
m[, sex := ifelse(gender == "Hombre", "male", "female")]
m[, `:=`(c1 = clean_icd10(diag1), c2 = clean_icd10(ifelse(is.na(diag2), "", diag2)))]

# --- all-cause by single age (all 15+) ---
fwrite(m[, .N, by = .(year, sex, age)], file.path(V, "agg_v", "allcause_year_sex_age.csv"))

# --- cause flags (expand_pif definitions) ---
aaf1_d1 <- c(icd_stems_s6("F10"), "G312", "G621", "G721", "Q860", "I426", "K860", "K292")
aaf1_d2 <- icd_stems_s6(c("X45", "X65", "Y15"))
either <- function(codes) m$c1 %in% codes | m$c2 %in% codes
F <- list(aaf1 = m$c1 %in% aaf1_d1 | m$c2 %in% aaf1_d2,
  bcan = m$c1 %in% brcan_codes, lican = m$c1 %in% lican_codes, lxcan = m$c1 %in% lxcan_codes,
  oescan = m$c1 %in% oescan_codes, locan = m$c1 %in% locan_codes, opcan = m$c1 %in% opcan_codes,
  crcan = m$c1 %in% crcan_codes, stom = m$c1 %in% stom_codes, panccan = m$c1 %in% panccan_codes,
  panc = m$c1 %in% panc_codes, epi = m$c1 %in% epilepsy_codes, dm2 = m$c1 %in% dm2_codes,
  hiv = m$c1 %in% hiv_codes, hhd = m$c1 %in% hhd_codes, ich = m$c1 %in% ich_codes,
  ihd = m$c1 %in% ihd_codes, is = m$c1 %in% is_codes, lc = m$c1 %in% lc_codes,
  lri = m$c1 %in% lri_codes, tb = m$c1 %in% tb_codes,
  ri = either(ri_codes), int = either(int_inj_codes), unint = either(unint_inj_codes) & !either(ri_codes))
FM <- do.call(cbind, F)
nflag <- rowSums(FM)
cat("deaths with >1 flag (all ages):", sum(nflag > 1), "\n")
m[, cause := ifelse(nflag == 0, "other", colnames(FM)[max.col(FM * 1, ties.method = "first")])]
m[cause == "other" & substr(c1, 1, 3) %in% c("U07", "U09", "U10"), cause := "covid"]
m[sex == "male" & cause == "bcan", cause := "other"]
m[, r99 := substr(c1, 1, 3) == "R99"][, rchap := substr(c1, 1, 1) == "R"]
fwrite(m[, .(deaths = .N, r99 = sum(r99), rchap = sum(rchap)), by = .(year, sex, age, cause)],
       file.path(V, "agg_v", "cause_year_sex_age.csv"))
fwrite(data.table(multi_flag = sum(nflag > 1), multi_flag_15_65 = sum(nflag > 1 & m$age <= 65)), file.path(V, "agg_v", "overlap.csv"))
message(sprintf("v01_extract elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
