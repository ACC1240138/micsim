# v05_hazard_loyo.R -- (1) does band-level normalisation by the PLAIN mean RR reproduce DEIS when hazards vary by single age?
# (2) single-age LOYO deviance with the correct Poisson noise floor (expected deviance under the predicted mean, not 1 per cell).
# (3) Monte Carlo granularity numbers.
.t0 <- Sys.time()
library(data.table)
set.seed(1240138)
V <- "<scratch>/audit/verify_mort"
HD <- "<repo>/__andres_control/ine_proyecciones_rebuild"
d <- fread(file.path(V, "agg_v", "cause_year_sex_age.csv"))
p <- as.data.table(readxl::read_xlsx(file.path(HD, "ine_basedatos.xlsx"), sheet = "BBDD_EEPP-2024_0101"))
p[, dt := as.Date(FECHA, "%d/%m/%Y")]
p <- p[, .(year = as.integer(format(dt, "%Y")), md = format(dt, "%m-%d"), sex = ifelse(SEXO == "H", "male", "female"), age = as.integer(EDAD), pop = POBLACION)]
P <- dcast(p[year %in% 2012:2025], year + sex + age ~ md, value.var = "pop"); setnames(P, c("01-01", "06-30"), c("jan", "mid"))

# ---- (1) band normalisation: male IHD, band 45-59, 2019 real single-age rates; synthetic agents with an engine-like RR ----
ihd <- merge(d[cause == "ihd" & sex == "male" & year == 2019 & age %between% c(45, 60), .(n = sum(deaths)), by = age],
             P[year == 2019 & sex == "male", .(age, mid, jan)], by = "age")
setorder(ihd, age); ihd[, m := n / mid][, h := (m + shift(m, -1)) / 2]   # January-age hazard as proposed in the report
ihd <- ihd[age <= 59]
N <- 4000L                                                             # ~ agents in a sex x band cell with n_sim = 25k
ag <- data.table(age = sample(ihd$age, N, TRUE, prob = ihd$jan))
ag[, h := ihd$h[match(age, ihd$age)]]
# Engine-like exposure: drinking drivers constant within band (as ms_drivers), former share rising with age (ever is sticky).
pf <- 0.10 + 0.10 * (ag$age - 45) / 14
u <- runif(N)
ag[, status := ifelse(u < 0.55, "current", ifelse(u < 0.55 + pf, "former", "never"))]
ag[, gpd := ifelse(status == "current", rgamma(N, 0.8, scale = 25), 0)]
ag[, rr := ifelse(status == "former", 1.25, exp(0.004 * gpd))]        # stand-in RR curve, not the registry
Rbar <- mean(ag$rr); Rw <- sum(ag$h * ag$rr) / sum(ag$h)
plain <- sum(ag$h * ag$rr / Rbar) / sum(ag$h) - 1                       # report's V1 with the plain mean
weighted <- sum(ag$h * ag$rr / Rw) / sum(ag$h) - 1
aaf_sim <- sum(ag$h * (ag$rr - 1) / Rbar) / sum(ag$h * ag$rr / Rbar)
cat(sprintf("V1 relative error, plain mean: %.3e | hazard-weighted mean: %.3e\n", plain, weighted))
cat(sprintf("simulated AAF %.5f vs 1-1/Rbar %.5f vs 1-1/Rw %.5f\n", aaf_sim, 1 - 1 / Rbar, 1 - 1 / Rw))
# Pure sampling version: identical exposure distribution at every age (no age gradient at all).
ag[, rr0 := ifelse(runif(N) < 0.55, exp(0.004 * rgamma(N, 0.8, scale = 25)), 1)]
cat(sprintf("V1 relative error, plain mean, no age gradient (sampling only): %.3e\n", sum(ag$h * ag$rr0 / mean(ag$rr0)) / sum(ag$h) - 1))
stopifnot(abs(weighted) < 1e-12)

# ---- (2) single-age LOYO with the right noise floor ----
pd <- function(y, mu) 2 * (ifelse(y > 0, y * log(y / mu), 0) - (y - mu))
edev <- function(mu) vapply(mu, function(u) { y <- 0:max(20, ceiling(u + 12 * sqrt(u) + 20)); sum(dpois(y, u) * pd(y, u)) }, 0)
d[sex == "male" & cause == "bcan", cause := "other"]
cs <- unique(d[, .(cause, sex)])[!(sex == "male" & cause == "bcan")]
sa <- merge(CJ(year = 2012:2024, age = 15:65, k = seq_len(nrow(cs))), data.table(k = seq_len(nrow(cs)), cs), by = "k")
sa <- merge(sa, d[age <= 65, .(y = sum(deaths)), by = .(year, sex, age, cause)], by = c("year", "sex", "age", "cause"), all.x = TRUE)
sa[is.na(y), y := 0]; sa <- merge(sa, P[, .(year, sex, age, mid)], by = c("year", "sex", "age"))
sa[, band := cut(age, c(14, 29, 44, 59, 65))]
res <- rbindlist(lapply(setdiff(2013:2023, 2020:2022), function(t) {
  sa[, {
    tr <- .SD[year != t & !year %in% 2020:2021]; te <- .SD[year == t]
    f1 <- suppressWarnings(glm(y ~ band + I(year - 2018), poisson, data = tr, offset = log(mid)))
    f2 <- suppressWarnings(glm(y ~ splines::ns(age, knots = c(29.5, 44.5, 59.5), Boundary.knots = c(15, 65)) + I(year - 2018), poisson, data = tr, offset = log(mid)))
    .(y = te$y, mu_flat = predict(f1, te, type = "response"), mu_spl = predict(f2, te, type = "response"))
  }, by = .(cause, sex)][, year := t]
}))
out <- res[, .(cells = .N, flat_per_cell = sum(pd(y, mu_flat)) / .N, spline_per_cell = sum(pd(y, mu_spl)) / .N,
               noise_floor_per_cell = sum(edev(mu_spl)) / .N, mean_mu = mean(mu_spl))]
print(out)
byc <- res[, .(cells = .N, spline = sum(pd(y, mu_spl)) / .N, floor = sum(edev(mu_spl)) / .N), by = cause][, ratio := spline / floor]
print(byc[order(-ratio)])
fwrite(rbind(out[, .(cause = "TOTAL", cells, spline = spline_per_cell, floor = noise_floor_per_cell)], byc[, .(cause, cells, spline, floor)]),
       file.path(V, "v05_loyo_single_age.csv"))

# ---- (3) MC granularity ----
P24 <- P[year == 2024 & age %in% 15:65, sum(jan)]
ihd_yr <- d[cause == "ihd" & age <= 65 & year %in% 2022:2024, sum(deaths) / 3]
cat(sprintf("INE Jan 2024 15-65: %s | IHD deaths/yr 2022-24 at 15-65: %.0f | expected at 100k agents: %.1f | rel SE: %.1f%%\n",
            format(P24, big.mark = ","), ihd_yr, ihd_yr * 1e5 / P24, 100 / sqrt(ihd_yr * 1e5 / P24)))
message(sprintf("v05 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
