# v02_drift_lexis.R -- independent recomputation of claims A (stale outputs / multipliers), B (drift decomposition)
# and C (age-at-1-January conversion) of mortality_deis.md. Inputs: agg_v/ (v01), INE xlsx, HMD text files.
.t0 <- Sys.time()
library(data.table)
ROOT <- "<repo>"; AC <- file.path(ROOT, "__andres_control"); HD <- file.path(AC, "ine_proyecciones_rebuild")
V <- "<scratch>/audit/verify_mort"
D <- fread(file.path(V, "agg_v", "allcause_year_sex_age.csv"))   # year, sex, age, N (all ages 15+)

# INE: same sheet as ms-demography-inputs
p <- as.data.table(readxl::read_xlsx(file.path(HD, "ine_basedatos.xlsx"), sheet = "BBDD_EEPP-2024_0101"))
p[, d := as.Date(FECHA, "%d/%m/%Y")]
p <- p[, .(year = as.integer(format(d, "%Y")), md = format(d, "%m-%d"), sex = ifelse(SEXO == "H", "male", "female"), age = as.integer(EDAD), pop = POBLACION)]
cat("INE total population all ages, 30 June 2017 / 2024:", p[md == "06-30" & year == 2017, sum(pop)], "/", p[md == "06-30" & year == 2024, sum(pop)], "\n")
P <- dcast(p, year + sex + age ~ md, value.var = "pop"); setnames(P, c("01-01", "06-30"), c("jan", "mid"))

hmd <- rbindlist(lapply(c(female = "fltper_1x1.txt", male = "mltper_1x1.txt"), function(f)
  read.table(file.path(HD, f), header = TRUE, skip = 2, stringsAsFactors = FALSE)), idcol = "sex")
setDT(hmd); hmd <- hmd[Age %in% as.character(0:109), .(sex, year = Year, age = as.integer(Age), qx, mx)]
lx <- fread(file.path(HD, "Deaths_lexis.txt"), skip = 2, header = TRUE)[Age != "110+"]
lx <- melt(lx[, .(Female = sum(Female), Male = sum(Male)), by = .(year = Year, age = as.integer(Age))], id.vars = c("year", "age"),
           variable.name = "sex", value.name = "hmd_d")[, sex := tolower(sex)]

X <- Reduce(function(a, b) merge(a, b, by = c("year", "sex", "age")),
            list(P[year %in% 2012:2024 & age %in% 15:65], D[age %in% 15:65], hmd, lx))
stopifnot(nrow(X) == 13 * 2 * 51)
cat("min deaths per single-age cell 15-65:", min(X$N), " cells:", nrow(X), "\n")

# ---- A. stale outputs and multiplier ----
old <- fread(file.path(AC, "microsim_recalib_outputs", "mortality_concordance.csv"))
oldb <- fread(file.path(AC, "microsim_base_outputs", "mortality_concordance.csv"))
cur <- X[, .(deis_now = sum(N)), by = .(year, sex)]
A <- merge(merge(cur, old[, .(year, sex, saved_recalib = observed_deaths)]), oldb[, .(year, sex, saved_base = observed_deaths)])
A[, diff_recalib := saved_recalib - deis_now]
print(A[, .(diff_recalib = sum(diff_recalib), base_eq_recalib = all(saved_base == saved_recalib)), by = sex])
print(A[, .(diff = sum(diff_recalib)), by = year])
mult <- function(d, total, tol = .Machine$double.eps^0.25) exp(uniroot(function(ls) sum(d$jan * (1 - (1 - d$qx)^exp(ls))) - total, c(-3, 3), tol = tol)$root)
MU <- rbindlist(lapply(c("female", "male"), function(s) data.table(sex = s,
  saved_totals = mult(X[sex == s], sum(A[sex == s]$saved_recalib)),
  current_bundle = mult(X[sex == s], sum(X[sex == s]$N)),
  current_bundle_tight_tol = mult(X[sex == s], sum(X[sex == s]$N), 1e-12))))
print(MU)

# ---- B. drift decomposition ----
X[, q_eng := 1 - (1 - qx)^MU$current_bundle_tight_tol[match(sex, MU$sex)]]
X[, `:=`(E_hmd = hmd_d / mx, E_lo = hmd_d / (mx + 5e-6), E_hi = hmd_d / pmax(mx - 5e-6, 1e-9))]  # HMD mx printed to 5 decimals
B <- X[, .(deis = sum(N), eng = sum(jan * q_eng), hmd_d = sum(hmd_d), ine_mid = sum(mid), E_hmd = sum(E_hmd), E_lo = sum(E_lo), E_hi = sum(E_hi)), by = .(year, sex)]
B[, `:=`(eng_rel = eng / deis - 1, hmd_vs_deis = hmd_d / deis - 1, Ehmd_vs_ine = E_hmd / ine_mid - 1,
         Ehmd_vs_ine_lo = E_lo / ine_mid - 1, Ehmd_vs_ine_hi = E_hi / ine_mid - 1)]
print(B[, .(year, sex, eng_rel = round(100 * eng_rel, 2), hmd_vs_deis = round(100 * hmd_vs_deis, 3),
            Ehmd_vs_ine = round(100 * Ehmd_vs_ine, 2), lo = round(100 * Ehmd_vs_ine_lo, 2), hi = round(100 * Ehmd_vs_ine_hi, 2))])
print(B[, .(slope_pp_per_yr = 100 * coef(lm(eng_rel ~ year))[2]), by = sex])
fwrite(B, file.path(V, "v02_drift.csv"))

# ---- C. age at 1 January ----
Y <- merge(P[year %in% 2012:2024 & age %in% 14:67], D, by = c("year", "sex", "age"), all.x = TRUE)
Y[is.na(N), N := 0]; setorder(Y, year, sex, age); Y[, m := N / mid][, m1 := shift(m, -1), by = .(year, sex)]
C <- Y[age %in% 15:65, .(deis15_65 = sum(N), d15 = N[age == 15], par = sum(jan * (1 - exp(-(m + m1) / 2))),
                          naive = sum(jan * m / (1 + m / 2))), by = .(year, sex)]
C <- merge(C, Y[age == 66, .(year, sex, d66 = N)])
C[, `:=`(target = deis15_65 - d15 / 2 + d66 / 2)][, `:=`(target_vs_deis = target / deis15_65 - 1, par_vs_target = par / target - 1,
                                                       par_vs_deis = par / deis15_65 - 1, naive_vs_deis = naive / deis15_65 - 1)]
print(C[, .(year, sex, target_vs_deis = round(100 * target_vs_deis, 2), par_vs_target = round(100 * par_vs_target, 2),
            naive_vs_deis = round(100 * naive_vs_deis, 2))])
# Independent check of the target with a direct cohort count: INE Jan stock(a, t) - Jan stock(a+1, t+1) mixes migration, so only
# report it as context: implied cohort decrement vs target.
fwrite(C, file.path(V, "v02_lexis.csv"))
message(sprintf("v02 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
