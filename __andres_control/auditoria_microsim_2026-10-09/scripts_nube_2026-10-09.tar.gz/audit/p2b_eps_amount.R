# Step 5 support (EPS microdata): persistence of AMOUNT (grams/day copula) and of a high-typical-quantity proxy.
# Setup identical to p2_eps_microdata.R: reproduce the published same-people tetrachoric correlations, extend them to
# baseline ages < 50, and get a PSU bootstrap (joint covariance of the three correlations) for lambda, phi.
# Reuses notebook eps_alcohol_prevalencia_persistencia.ipynb cells verbatim (extracted to nbsrc/):
# eps-inputs, eps-harmonize (whole cells); eps_design (eps-prevalence); eps_time/eps_make_pair/eps_pairs (eps-panel);
# eps_bvn/eps_tetra/eps_rho (eps-persistence); td/triple_design/eps_triple_rho (eps-panel-diagnostics).
# Writes aggregated CSVs only, to scratchpad/audit/out/ (eps_save is redirected there too).
.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
audit <- "<scratch>/audit"
setwd("<repo>/__andres_control")
source(file.path("<repo>", "_tools", "acc_data.R"))
source(file.path(audit, "fit_lib.R"))
# --- setup equivalent to cell eps-setup, with outputs redirected away from the repo ---
eps_root <- acc_data("_eps/eps.tar.xz.enc")
eps_abs <- function(x) file.path(eps_root, sub("^_eps/", "", x))
eps_out <- file.path(audit, "out", "eps_rerun"); dir.create(eps_out, recursive = TRUE, showWarnings = FALSE)
options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE, scipen = 8)
set.seed(1240138L)
eps_age_levels <- c("18-29", "30-44", "45-59", "60-65", "66-70", "71-76", "77+")
eps_edu_levels <- c("Primary completed or less", "Secondary completed or less", "Tertiary completed or higher")
eps_states <- c("Current abstainer (history unknown)", "Occasional (frequency proxy)", "Moderate", "Heavy")
eps_table <- function(x, caption, digits = 3) invisible(NULL)
eps_read <- function(path) {
  x <- as.data.frame(haven::read_dta(eps_abs(path)))
  stopifnot("folio_n20" %in% names(x), !anyNA(x$folio_n20), !anyDuplicated(x$folio_n20))
  x
}
eps_save <- function(x, name) utils::write.csv(x, file.path(eps_out, paste0(name, ".csv")), row.names = FALSE, na = "")
run_exprs <- function(file, names = NULL, first_n = NULL) {
  ex <- parse(file.path(audit, "nbsrc", file), keep.source = FALSE)
  for (i in seq_along(ex)) {
    e <- ex[[i]]
    lhs <- if (is.call(e) && identical(e[[1]], as.name("<-"))) paste(deparse(e[[2]]), collapse = "") else ""
    if ((!is.null(names) && lhs %in% names) || (!is.null(first_n) && i <= first_n)) eval(e, envir = globalenv())
  }
}
run_exprs("eps_07_eps-inputs.R", first_n = 1e3)
run_exprs("eps_09_eps-harmonize.R", first_n = 1e3)
run_exprs("eps_11_eps-prevalence.R", names = c("eps_design", "eps_prop", "eps_domains"))
run_exprs("eps_19_eps-panel.R", names = c("eps_time", "eps_make_pair", "eps_pairs"))
run_exprs("eps_24_eps-persistence.R", names = c("eps_bvn", "eps_tetra", "eps_rho"))
run_exprs("eps_28_eps-panel-diagnostics.R", names = c("td", "mid_match", "mid_data", "td$current_mid", "mid_good",
  "td$triple_valid", "triple_design", "eps_triple_rho"))
# --- reproduction check against the published CSV ---
pub <- utils::read.csv("eps_alcohol_outputs/rho_same_people_three_interviews.csv")
chk <- merge(pub[c("sex", "pair", "n", "rho_interval")], eps_triple_rho[c("sex", "pair", "n", "rho_interval")],
             by = c("sex", "pair"), suffixes = c("_pub", "_rerun"))
print(chk); stopifnot(all(chk$n_pub == chk$n_rerun), max(abs(chk$rho_interval_pub - chk$rho_interval_rerun)) < 1e-6)
utils::write.csv(chk, file.path(audit, "out", "p2_reproduction_check.csv"), row.names = FALSE)


# --- amount persistence among people drinking (with known grams/day) at both interviews ---
lags <- c(VI_VII = 3.671, VII_VIII = 4.022, VI_VIII = 7.693)
td$grams_mid <- mid_data$grams_day
qclean <- function(q) { q[q %in% c(88, 99, 888, 999, 8888, 9999) | !is.finite(q) | q <= 0] <- NA_real_; q }
hiq <- function(w, ids, sex) {   # any beverage with typical quantity per occasion >= 5 (men) / >= 4 (women)
  x <- eps_data[[w]][match(ids, eps_data[[w]]$id), ]
  q <- sapply(1:3, function(j) qclean(x[[paste0("f15_", j)]])); y <- x$current == 1 & rowSums(sapply(1:3, function(j) x[[paste0("f13_", j)]] == 1), na.rm = TRUE) > 0
  thr <- ifelse(sex == "Men", 5, 4); hi <- rowSums(q >= thr, na.rm = TRUE) > 0
  ifelse(y & rowSums(!is.na(q)) > 0, as.numeric(hi), NA_real_)
}
td$hiq0 <- hiq("VI", td$id, td$sex); td$hiqm <- hiq("VII_presencial", td$id, td$sex); td$hiq1 <- hiq("VIII", td$id, td$sex)
nscore_cor <- function(a, b, w) {  # weighted normal-scores (Gaussian copula) correlation
  ns <- function(v) { o <- order(v); cw <- cumsum(w[o]) / sum(w); r <- numeric(length(v)); r[o] <- cw - w[o] / (2 * sum(w)); stats::qnorm(r) }
  stats::cov.wt(cbind(ns(a), ns(b)), wt = w / sum(w), cor = TRUE)$cor[1, 2]
}
pairs <- list(VI_VII = c("grams0", "grams_mid"), VII_VIII = c("grams_mid", "grams1"), VI_VIII = c("grams0", "grams1"))
hpairs <- list(VI_VII = c("hiq0", "hiqm"), VII_VIII = c("hiqm", "hiq1"), VI_VIII = c("hiq0", "hiq1"))
set.seed(1240138)
res <- do.call(rbind, lapply(c("All 18+", "50+"), function(a) do.call(rbind, lapply(c("All", "Men", "Women"), function(s) {
  base <- td$triple_valid & td$age >= ifelse(a == "50+", 50, 18) & (s == "All" | td$sex == s)
  do.call(rbind, lapply(names(pairs), function(p) {
    v <- pairs[[p]]; k <- which(base & is.finite(td[[v[1]]]) & is.finite(td[[v[2]]]) & td[[v[1]]] > 0 & td[[v[2]]] > 0)
    r <- nscore_cor(td[[v[1]]][k], td[[v[2]]][k], td$weight[k])
    # PSU bootstrap (resample clusters, ignore strata) for a 95% interval.
    cl <- unique(td$psu[k]); bt <- replicate(300, { b <- sample(cl, replace = TRUE)
      kk <- unlist(lapply(b, function(c) k[td$psu[k] == c])); nscore_cor(td[[v[1]]][kk], td[[v[2]]][kk], td$weight[kk]) })
    h <- hpairs[[p]]; kh <- which(base & !is.na(td[[h[1]]]) & !is.na(td[[h[2]]]))
    cell <- 1L + td[[h[2]]][kh] + 2L * td[[h[1]]][kh]
    rh <- eps_tetra(vapply(1:4, function(j) sum(td$weight[kh][cell == j]), 0))
    data.frame(age = a, sex = s, pair = p, lag = lags[[p]], n_amount = length(k), r_amount_nscore = r,
      lo = stats::quantile(bt, .025), hi = stats::quantile(bt, .975),
      n_hiq = length(kh), prev_hiq_from = stats::weighted.mean(td[[h[1]]][kh], td$weight[kh]),
      r_hiq_tetra = rh, row.names = NULL)
  }))
}))))
utils::write.csv(res, file.path(audit, "out", "p2b_amount_hiq_persistence.csv"), row.names = FALSE)
print(format(res, digits = 3))
fits <- do.call(rbind, lapply(split(res, list(res$age, res$sex), drop = TRUE), function(x) {
  x <- x[match(names(lags), x$pair), ]; se <- (atanh(x$hi) - atanh(x$lo)) / (2 * 1.96)
  f <- fit_trait_ar1(x$r_amount_nscore, x$lag, se); a1 <- fit_ar1(x$r_amount_nscore, x$lag, se)
  data.frame(age = x$age[1], sex = x$sex[1], lambda_amount = f[["lambda"]], phi_amount = f[["phi"]], obj = f[["obj"]],
             phi_ar1_amount = a1[["phi"]], obj_ar1 = a1[["obj"]], r1y_amount = r_model(f[["lambda"]], f[["phi"]], 1),
             r10y_amount = r_model(f[["lambda"]], f[["phi"]], 10))
}))
utils::write.csv(fits, file.path(audit, "out", "p2b_amount_trait_ar1_fit.csv"), row.names = FALSE)
print(format(fits, digits = 3))
message(sprintf("p2b elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
