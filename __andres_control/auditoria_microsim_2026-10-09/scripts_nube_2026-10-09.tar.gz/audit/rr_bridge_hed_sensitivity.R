.t0 <- Sys.time()
# How much a -4.5 pp HED bias (share of current drinkers) moves 2024 AAFs of HED-dependent causes (saved bundle).
audit_dir <- "<scratch>/audit"
source(file.path(audit_dir, "rr_bridge_lib.R")); spec <- bridge_load()
inp <- readRDS("<repo>/__andres_control/aaf_engine_inputs_bundle_20261007.rds")$exposure_inputs
out <- list()
for (cause in c("Road Injuries", "Unintentional Injuries", "Intentional Injuries", "Ischaemic Heart Disease")) for (sx in c("female", "male")) for (g in 1:4) {
  band <- aaf_age_band_mapping("15_65")$adam_age_band[g]
  e <- spec[spec$cause == cause & spec$sex == sx & spec$principal & (is.na(spec$band) | spec$band == band), ]
  rec <- e$record[[1]]; s <- if (sx == "female") "fem" else "male"
  spl <- inp[[paste0("g_", s, "_hed_list")]][["2024"]][[g]]; ph <- inp[[paste0("p_hed_list_", s)]][[g]][[7]]
  f <- function(p) aaf_point(inp$x_vals, rec$RRCurrent, rec$betaCurrent,
         p_abs = inp[[paste0("p_abs_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]],
         p_form = inp[[paste0("p_form_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]],
         rr_fd = exp(rec$lnRRFormer), gamma = spl$nhed, p_hed = p, gamma_hed = spl$hed,
         rr_hed = if (e$hed_mode == "cap") "cap" else rec$RRCurrent_binge,
         beta_hed = if (e$hed_mode == "cap") NULL else rec$betaCurrent_binge)
  out[[length(out) + 1L]] <- data.frame(cause = cause, sex = sx, tramo = g, p_hed = ph, aaf = f(ph), aaf_hed_minus_4.5pp = f(max(ph - 0.045, 0)))
}
o <- do.call(rbind, out); o$rel_change <- o$aaf_hed_minus_4.5pp / o$aaf - 1
utils::write.csv(o, file.path(audit_dir, "rr_bridge_hed_bias_2024.csv"), row.names = FALSE)
print(stats::aggregate(cbind(aaf, aaf_hed_minus_4.5pp, rel_change) ~ cause + sex, o, mean), digits = 3)
cat(sprintf("rr_bridge_hed_sensitivity elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
