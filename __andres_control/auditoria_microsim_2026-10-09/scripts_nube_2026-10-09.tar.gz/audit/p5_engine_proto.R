# Step 5 support: run the REAL annual engine (cell ms-annual-engine, verbatim) and a scratch prototype with
# trait + AR(1) participation (+ optional lifetime-abstainer "stayers"), then compare never/former with ENPG
# and recompute EPS-type tetrachoric correlations inside the simulated panel. Nothing in the repo is modified.
# Deviation from the notebook: DEIS 2012-2023 parquet is read by python (R here has no arrow) and only
# year x sex x age death COUNTS cross back into R; rows are re-expanded so cell ms-demography-inputs runs unchanged.
.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
audit <- "<scratch>/audit"
out <- file.path(audit, "out")
setwd("<repo>/__andres_control")
source(file.path("<repo>", "_tools", "acc_data.R"))
source(file.path(audit, "fit_lib.R"))
ms_cfg <- base::list(start_year = 2012L, train_end = 2020L, observed_end = 2024L, end_year = 2034L,
  min_age = 15L, max_age = 65L, n_sim = 25000L, seeds = 2125L + 0:4, rho = 0.8,
  cutoffs = base::c(2016L, 2018L, 2020L, 2022L), specs = base::c("static2012", "interp_hold", "linear_all", "spline_shared"))
ms_table <- function(x, caption = NULL) invisible(NULL)
here_root <- "<repo>"
src <- function(f, patch = NULL) {
  s <- paste(readLines(file.path(audit, "nbsrc", f), warn = FALSE), collapse = "\n")
  for (p in patch) { stopifnot(grepl(p[1], s, fixed = TRUE)); s <- sub(p[1], p[2], s, fixed = TRUE) }
  eval(parse(text = s), envir = globalenv())
}
src("07_ms-survey-inputs.R")
# DEIS parquet -> aggregated counts via python (decrypted file stays in R's tempdir()).
deis_counts <- file.path(audit, "out", "deis_2012_2023_counts_15_65.csv")
py <- "import sys,pandas as pd; d=pd.read_parquet(sys.argv[1],columns=['year','gender','age']); d=d[d.age.between(15,65)&d.year.between(2012,2023)&d.gender.isin(['Hombre','Mujer'])]; d.groupby(['year','gender','age']).size().rename('n').reset_index().to_csv(sys.argv[2],index=False)"
stopifnot(system2("python3", c("-I", "-c", shQuote(py), shQuote(acc_data("_deis/DEFUNCIONES_DEIS_2012_2023_15plus.tar.xz.enc")), shQuote(deis_counts))) == 0)
ms_read_deis_old <- function() { x <- utils::read.csv(deis_counts); x <- x[rep(seq_len(nrow(x)), x$n), c("year", "gender", "age")]; rownames(x) <- NULL; x }
src("09_ms-demography-inputs.R", list(
  c('base::as.data.frame(arrow::read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]),\n  col_select = base::c("year", "gender", "age")))', "ms_read_deis_old()")))
src("13_ms-calibration-functions.R")
src("15_ms-annual-engine.R")
ms_reconstruction_model <- ms_fit(ms_cfg$observed_end, "interp_hold")

# ---------- scratch prototype: trait + AR(1) participation, optional stayers ----------
# trait_share / ar_phi follow the handoff naming (line ~8100); stayer = lifetime abstainer, never drinks.
s_target <- local({   # stayer share for FRESH people by sex x age_group: ENPG pooled never at 25-29 for group 1,
  p <- utils::read.csv(file.path(out, "enpg_pooled_sex_agegroup.csv"))   # ENPG pooled never share for groups 2-4
  f <- utils::read.csv(file.path(out, "enpg_pooled_sex_agefine.csv"))
  x <- p[p$variable == "never", ]; x$age_group <- match(x$age_grp, c("15-29", "30-44", "45-59", "60-65"))
  y <- f[f$variable == "never" & f$age_fine == "25-29", ]
  x$s <- ifelse(x$age_group == 1, y$estimate[match(x$sex, y$sex)], x$estimate)
  stats::setNames(x$s, paste(x$sex, x$age_group))
})
tp_new_people <- function(sex, age, n, first_id) {
  x <- ms_new_people(sex, age, n, first_id)
  x$u <- stats::rnorm(n); x$a <- stats::rnorm(n); x$stayer <- NA
  x
}
tp_exposure <- function(pop, year, drivers, trait_share, use_stayers) {
  pop$age_group <- ms_age_group(pop$age)
  k <- base::match(base::paste(year, pop$sex, pop$age_group, sep = ":"), drivers$key)
  base::stopifnot(!base::anyNA(k)); d <- drivers[k, ]
  fresh <- base::is.na(pop$ever)
  never_cell <- (1 - d$p_current) * (1 - d$p_ever_noncurrent)
  s_fresh <- if (use_stayers) base::pmin(never_cell, s_target[paste(pop$sex, pop$age_group)]) else base::rep(0, base::nrow(pop))
  pop$stayer[fresh] <- stats::runif(base::sum(fresh)) < s_fresh[fresh]
  pop$z_current <- sqrt(trait_share) * pop$u + sqrt(1 - trait_share) * pop$a
  # Movers' threshold keeps each cell's margin: p / (1 - stayer share of that cell in this population).
  cell <- base::paste(pop$sex, pop$age_group)
  # Fresh batches (entrants) use the expected share: tiny cells would otherwise give s_hat = 1.
  s_hat <- base::ifelse(fresh, s_fresh, stats::ave(base::as.numeric(pop$stayer), cell))
  p_mover <- d$p_current / (1 - s_hat)
  base::stopifnot(base::all(p_mover < 1))
  pop$current <- !pop$stayer & stats::pnorm(pop$z_current) < p_mover
  u <- stats::pnorm(pop$z_amount); positive <- pop$current & u > d$p_zero
  pop$gpd_survey <- 0
  pop$gpd_survey[positive] <- stats::qgamma(base::pmin(1 - 1e-12, base::pmax(1e-12,
      (u[positive] - d$p_zero[positive]) / (1 - d$p_zero[positive]))),
    shape = d$shape[positive], scale = d$mu_current[positive] / ((1 - d$p_zero[positive]) * d$shape[positive]))
  p_hed <- stats::plogis(d$hed_intercept + d$hed_slope * base::log1p(pop$gpd_survey))
  pop$hed <- positive & stats::pnorm(pop$z_hed) < p_hed
  # Fresh movers: 'ever' drawn so that the cell's never share (stayers + never movers) matches ENPG.
  pm <- p_mover; q <- base::pmin(1, base::pmax(0, 1 - (never_cell - s_hat) / ((1 - s_hat) * (1 - pm))))
  pop$ever[fresh] <- !pop$stayer[fresh] & (pop$current[fresh] | stats::runif(base::sum(fresh)) < q[fresh])
  pop$ever <- pop$ever | pop$current
  pop$alc_status <- base::ifelse(pop$current, "current", base::ifelse(pop$ever, "former", "never"))
  low <- base::ifelse(pop$sex == "female", 20, 40); high <- base::ifelse(pop$sex == "female", 40, 60)
  pop$alc_cat <- base::ifelse(!pop$current, "noncurrent", base::ifelse(pop$gpd_survey < low, "cat1",
    base::ifelse(pop$gpd_survey < high, "cat2", "cat3")))
  base::stopifnot(!base::any(pop$current & pop$stayer), !base::any(pop$ever & pop$stayer), !base::any(pop$current & !pop$ever))
  pop
}
# Prototype loop = ms_simulate with (i) tp_* functions, (ii) z_current from u/a, (iii) a full status panel.
tp_simulate <- function(model, years, n_sim, seed, trait_share, ar_phi, use_stayers, rho_other = 0.8) {
  base::set.seed(seed)
  drivers <- ms_drivers(model, years)
  stocks <- ms_population[ms_population$year %in% years, ]
  unit_weight <- base::sum(stocks$pop_jan[stocks$year == years[1]]) / n_sim
  stocks$n_target <- base::as.integer(base::round(stocks$pop_jan / unit_weight))
  initial <- stocks[stocks$year == years[1], ]
  ids <- base::c(0L, base::cumsum(initial$n_target))
  pop <- dplyr::bind_rows(base::lapply(base::seq_len(base::nrow(initial)), function(i)
    tp_new_people(initial$sex[i], initial$age[i], initial$n_target[i], ids[i])))
  last_id <- base::max(pop$id)
  pop <- tp_exposure(pop, years[1], drivers, trait_share, use_stayers)
  mortality <- ms_mortality; mortality$key <- base::paste(mortality$year, mortality$sex, mortality$age, sep = ":")
  summ <- panel <- base::vector("list", base::length(years)); changes <- trans <- 0
  for (i in base::seq_along(years)) {
    year <- years[i]
    panel[[i]] <- base::data.frame(year = year, id = pop$id, sex = pop$sex, age = pop$age, current = pop$current)
    summ[[i]] <- base::data.frame(year = year, sex = pop$sex, age_group = pop$age_group, current = pop$current,
                                  never = !pop$ever, former = pop$ever & !pop$current)
    k <- base::match(base::paste(base::min(year, ms_cfg$observed_end), pop$sex, pop$age, sep = ":"), mortality$key)
    q <- -base::expm1(base::log1p(-mortality$qx[k]) * model$mortality_scale[pop$sex])
    pop <- pop[!(stats::runif(base::nrow(pop)) < q), ]
    if (i < base::length(years)) {
      pop$age <- pop$age + 1L; pop <- pop[pop$age <= ms_cfg$max_age, ]
      next_stock <- stocks[stocks$year == year + 1L, ]
      keep <- base::rep(TRUE, base::nrow(pop)); additions <- base::vector("list", base::nrow(next_stock))
      for (j in base::seq_len(base::nrow(next_stock))) {
        ix <- base::which(pop$sex == next_stock$sex[j] & pop$age == next_stock$age[j])
        delta <- next_stock$n_target[j] - base::length(ix)
        if (delta < 0) keep[ix[base::sample.int(base::length(ix), -delta)]] <- FALSE
        else if (delta > 0) { additions[[j]] <- tp_new_people(next_stock$sex[j], next_stock$age[j], delta, last_id); last_id <- last_id + delta }
      }
      pop <- pop[keep, ]
      previous <- pop$current; n <- base::nrow(pop)
      pop$a <- ar_phi * pop$a + base::sqrt(1 - ar_phi^2) * stats::rnorm(n)
      for (z in base::c("z_amount", "z_hed")) pop[[z]] <- rho_other * pop[[z]] + base::sqrt(1 - rho_other^2) * stats::rnorm(n)
      pop <- tp_exposure(pop, year + 1L, drivers, trait_share, use_stayers)
      changes <- changes + base::sum(pop$current != previous); trans <- trans + n
      new <- dplyr::bind_rows(additions)
      if (base::nrow(new)) pop <- dplyr::bind_rows(pop, tp_exposure(new, year + 1L, drivers, trait_share, use_stayers))
    }
  }
  base::list(summary = dplyr::bind_rows(summ), panel = dplyr::bind_rows(panel), switching = changes / trans, unit_weight = unit_weight)
}

# In-engine EPS check: tetrachoric of status between t0 and t0 + lag for people aged lo-hi at t0 who stay in the domain.
tetra_panel <- function(panel, t0, lag, lo, hi) {
  a <- panel[panel$year == t0 & panel$age >= lo & panel$age <= hi, ]; b <- panel[panel$year == t0 + lag, ]
  m <- merge(a[c("id", "current")], b[c("id", "current")], by = "id")
  tab <- table(factor(m$current.x, c(FALSE, TRUE)), factor(m$current.y, c(FALSE, TRUE)))
  p <- c(tab[1, 1], tab[1, 2], tab[2, 1], tab[2, 2]) / sum(tab)
  t0q <- stats::qnorm(p[3] + p[4]); t1q <- stats::qnorm(p[2] + p[4])
  r <- stats::uniroot(function(r) mvtnorm::pmvnorm(upper = c(t0q, t1q), corr = matrix(c(1, r, r, 1), 2))[1] - p[4], c(-.999, .999))$root
  c(n = nrow(m), r = r)
}
runs <- list(
  engine_ar1_rho0.8 = list(trait_share = 0, ar_phi = 0.8, use_stayers = FALSE),
  trait0.45_phi0.68 = list(trait_share = 0.45, ar_phi = 0.68, use_stayers = FALSE),
  ar1_rho0.8_stayers = list(trait_share = 0, ar_phi = 0.8, use_stayers = TRUE),
  trait0.32_phi0.66_stayers = list(trait_share = 0.32, ar_phi = 0.66, use_stayers = TRUE))
# Regression check: prototype with trait 0 and no stayers vs the verbatim engine (same seed) -> same margins.
eng <- ms_simulate(ms_reconstruction_model, 2012:2024, ms_cfg$n_sim, ms_cfg$seeds[1], 0.8)
last <- eng$summary[eng$summary$year == 2024L, ]
engine_ref <- data.frame(source = "verbatim ms_simulate rho=0.8 (seed 2125)",
  annual_switching = sum(eng$flows$status_changes) / sum(eng$flows$transition_n),
  current_2024 = stats::weighted.mean(last$current_mean, last$n), never_2024 = stats::weighted.mean(last$never, last$n),
  former_2024 = stats::weighted.mean(last$former, last$n))
print(engine_ref)
res <- list(); cells <- list(); eps <- list()
for (nm in names(runs)) {
  r <- runs[[nm]]
  x <- tp_simulate(ms_reconstruction_model, 2012:2024, ms_cfg$n_sim, ms_cfg$seeds[1], r$trait_share, r$ar_phi, r$use_stayers)
  s24 <- x$summary[x$summary$year == 2024L, ]
  res[[nm]] <- data.frame(run = nm, annual_switching = x$switching, current_2024 = mean(s24$current),
    never_2024 = mean(s24$never), former_2024 = mean(s24$former))
  cells[[nm]] <- cbind(run = nm, stats::aggregate(cbind(current, never, former) ~ year + sex + age_group, x$summary, mean))
  eps[[nm]] <- do.call(rbind, lapply(list(c(50, 57, "50-57"), c(18, 49, "18-49")), function(a) {
    lo <- as.numeric(a[1]); hi <- as.numeric(a[2])
    data.frame(run = nm, ages_t0 = a[3], lag = c(4, 4, 8),
      from = c(2012, 2016, 2012), r = c(tetra_panel(x$panel, 2012, 4, lo, hi)[["r"]], tetra_panel(x$panel, 2016, 4, lo + 4, hi + 4)[["r"]],
                                       tetra_panel(x$panel, 2012, 8, lo, hi)[["r"]]),
      n = c(tetra_panel(x$panel, 2012, 4, lo, hi)[["n"]], tetra_panel(x$panel, 2016, 4, lo + 4, hi + 4)[["n"]], tetra_panel(x$panel, 2012, 8, lo, hi)[["n"]]))
  }))
  message(nm, " done ", round(as.numeric(difftime(Sys.time(), .t0, units = "mins")), 2), " min")
}
res <- do.call(rbind, res); cells <- do.call(rbind, cells); eps <- do.call(rbind, eps)
utils::write.csv(rbind(cbind(run = engine_ref$source, engine_ref[-1]), res), file.path(out, "p5_engine_proto_2024.csv"), row.names = FALSE)
utils::write.csv(cells, file.path(out, "p5_engine_proto_cells.csv"), row.names = FALSE)
utils::write.csv(eps, file.path(out, "p5_engine_proto_eps_check.csv"), row.names = FALSE)
print(res); print(eps)
message(sprintf("p5_engine_proto elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
