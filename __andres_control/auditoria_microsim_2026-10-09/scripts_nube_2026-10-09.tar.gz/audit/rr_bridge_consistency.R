.t0 <- Sys.time()
# Consistency check, one year (2024): person-level AAF/PIF from a synthetic weighted population built
# from the SAVED expand_pif inputs vs the SAVED expand_pif / pif2 outputs. Aggregate artefacts only
# (no microdata). Run: Rscript --vanilla rr_bridge_consistency.R
audit_dir <- "<scratch>/audit"
ctrl <- "<repo>/__andres_control"
source(file.path(audit_dir, "rr_bridge_lib.R"))
spec <- bridge_load()

YEAR <- 2024L
inp  <- readRDS(file.path(ctrl, "aaf_engine_inputs_bundle_20261007.rds"))$exposure_inputs
aafs <- readRDS(file.path(ctrl, "aaf_nested_by_disease_20261007.rds"))$by_disease
t5   <- readRDS(file.path(ctrl, "aaf_table5_result_20261007.rds"))$by_age_scope[["15_64"]]$standard_tables
pif2 <- readRDS(file.path(ctrl, "pif2_pif_results_full_20261008.rds"))
pif2_t5 <- readRDS(file.path(ctrl, "pif2_pif_results_table5_full_20261008.rds"))
fac  <- utils::read.csv(file.path(ctrl, "oms_factor_by_year.csv"))
factor_ch <- fac$factor_CH[fac$year == YEAR]
x_grid <- inp$x_vals
stopifnot(identical(range(x_grid), c(0.1, 150)), length(x_grid) == 1500L)
yi <- match(YEAR, as.integer(names(inp$g_male_list)))

cell_inputs <- function(sex, g) {
  s <- if (sex == "female") "fem" else "male"
  list(p_abs = inp[[paste0("p_abs_list_", s)]][[as.character(YEAR)]][[paste0("edad_tramo_", g)]],
       p_form = inp[[paste0("p_form_list_", s)]][[as.character(YEAR)]][[paste0("edad_tramo_", g)]],
       p_hed = inp[[paste0("p_hed_list_", s)]][[g]][[yi]],
       pooled = inp[[paste0("g_", s, "_list")]][[as.character(YEAR)]][[g]],
       split = inp[[paste0("g_", s, "_hed_list")]][[as.character(YEAR)]][[g]])
}
# n stratified quantiles of a gamma truncated to [lo, hi] (= expand_pif renormalisation on the grid)
q_trunc <- function(n, est, lo = 0.1, hi = 150) {
  sh <- est$estimate[["shape"]]; ra <- est$estimate[["rate"]]
  a <- stats::pgamma(lo, sh, ra); b <- stats::pgamma(hi, sh, ra)
  stats::qgamma(a + (seq_len(n) - 0.5) / n * (b - a), sh, ra)
}
q_clamp <- function(n, est) {   # untruncated draw, then clamped by rr_individual
  stats::qgamma((seq_len(n) - 0.5) / n, est$estimate[["shape"]], est$estimate[["rate"]])
}
# Weighted synthetic population of one (sex, tramo) cell: exact composition, n quantile points per drinker group.
make_pop <- function(sex, g, ci, mode = c("pooled", "split"), draw = q_trunc, n = 20000L) {
  mode <- match.arg(mode)
  cur <- 1 - ci$p_abs - ci$p_form
  base <- data.frame(sex = sex, age_group = g, status = c("never", "former"), gpd_apc = 0, hed = FALSE,
                     w = c(ci$p_abs, ci$p_form))
  if (mode == "pooled") {
    drk <- data.frame(sex = sex, age_group = g, status = "current", gpd_apc = draw(n, ci$pooled),
                      hed = FALSE, w = cur / n)
  } else {
    drk <- rbind(
      data.frame(sex = sex, age_group = g, status = "current", gpd_apc = draw(n, ci$split$nhed), hed = FALSE,
                 w = cur * (1 - ci$p_hed) / n),
      data.frame(sex = sex, age_group = g, status = "current", gpd_apc = draw(n, ci$split$hed), hed = TRUE,
                 w = cur * ci$p_hed / n))
  }
  rbind(base, drk)
}
stored_point <- function(cause, output, sex, g, rr_source) {
  if (rr_source == "table5_puc") {
    tb <- t5[[sex]]; tb <- tb[tb$disease == cause & tb$Year == YEAR, ]
    return(tb[[paste0("AAF_ag", g)]])
  }
  tb <- aafs[[cause]]$outputs[[output]]$table
  tb[tb$Year == YEAR, paste0(if (sex == "female") "Fem" else "Male", g, "_point")]
}
engine_point <- function(e, ci) {   # deterministic aaf_point with the record's central betas
  rec <- e$record[[1]]
  if (e$hed_mode == "none")
    return(aaf_point(x_grid, rec$RRCurrent, rec$betaCurrent, p_abs = ci$p_abs, p_form = ci$p_form,
                     rr_fd = exp(rec$lnRRFormer), gamma = ci$pooled))
  aaf_point(x_grid, rec$RRCurrent, rec$betaCurrent, p_abs = ci$p_abs, p_form = ci$p_form,
            rr_fd = exp(rec$lnRRFormer), gamma = ci$split$nhed, p_hed = ci$p_hed,
            rr_hed = if (e$hed_mode == "cap") "cap" else rec$RRCurrent_binge,
            beta_hed = if (e$hed_mode == "cap") NULL else rec$betaCurrent_binge, gamma_hed = ci$split$hed)
}

# entries to check: every principal cause + the non-principal IHD Table 5 / IS WHO alternatives
ent_all <- unique(spec[, c("cause", "output", "sex", "rr_source", "principal", "hed_mode")])
rows <- list()
for (i in seq_len(nrow(ent_all))) {
  e0 <- ent_all[i, ]
  for (g in 1:4) {
    band <- aaf_age_band_mapping("15_65")$adam_age_band[g]
    e <- spec[spec$cause == e0$cause & spec$sex == e0$sex & spec$rr_source == e0$rr_source &
                (is.na(spec$band) | spec$band == band), ]
    stopifnot(nrow(e) == 1L)
    ci <- cell_inputs(e0$sex, g)
    mode <- if (e0$hed_mode == "none") "pooled" else "split"
    rr_of <- function(pop) rr_individual(pop, e0$cause, e, source = e0$rr_source)
    p_par <- make_pop(e0$sex, g, ci, mode)                       # parity population
    p_mix <- make_pop(e0$sex, g, ci, "split")                    # one population for all causes
    p_clp <- make_pop(e0$sex, g, ci, mode, draw = q_clamp)       # clamp instead of truncate
    p_srv <- transform(p_par, gpd_apc = gpd_apc / factor_ch)     # APC factor forgotten (survey scale)
    rr_par <- rr_of(p_par)
    # PIF volume -10%: every current drinker x -> 0.9 x (same HED flags)
    pif_vol <- 1 - sum(p_par$w * rr_of(transform(p_par, gpd_apc = 0.9 * gpd_apc))) / sum(p_par$w * rr_par)
    # PIF HED -10% (lambda = 0, rho = 1): 10% of HED weight drops HED, keeps its own grams
    pif_hed <- NA_real_
    if (e0$hed_mode != "none") {
      ex <- p_par[p_par$hed, ]; ex$hed <- FALSE; ex$w <- 0.1 * ex$w
      stay <- p_par; stay$w[stay$hed] <- 0.9 * stay$w[stay$hed]
      p_cf <- rbind(stay, ex)
      pif_hed <- 1 - sum(p_cf$w * rr_of(p_cf)) / sum(p_par$w * rr_par)
    }
    pf <- if (e0$rr_source == "table5_puc") pif2_t5 else pif2
    pf <- pf[pf$output_name == e0$output & pf$year == YEAR & pf$age_group == g, ]
    pif2_of <- function(id) { v <- pf$pif[pf$scenario_id == id]; if (length(v) == 1L) v else NA_real_ }
    rows[[length(rows) + 1L]] <- data.frame(
      cause = e0$cause, sex = e0$sex, age_group = g, rr_source = e0$rr_source, principal = e0$principal,
      hed_mode = e0$hed_mode, p_abs = ci$p_abs, p_form = ci$p_form, p_hed = ci$p_hed,
      stored_aaf = stored_point(e0$cause, e0$output, e0$sex, g, e0$rr_source),
      engine_aaf = engine_point(e, ci),
      micro_aaf = aaf_from_people(rr_par, p_par$w),
      micro_aaf_mixture = aaf_from_people(rr_of(p_mix), p_mix$w),
      micro_aaf_clamp = aaf_from_people(rr_of(p_clp), p_clp$w),
      micro_aaf_survey_scale = aaf_from_people(rr_of(p_srv), p_srv$w),
      micro_pif_vol10 = pif_vol, pif2_vol10 = pif2_of("volume_reduction_10"),
      micro_pif_hed10 = pif_hed, pif2_hed10 = pif2_of("hed_reduction_10"),
      mass_above_150 = if (mode == "pooled") 1 - stats::pgamma(150, ci$pooled$estimate[["shape"]], ci$pooled$estimate[["rate"]]) else
        (1 - ci$p_hed) * (1 - stats::pgamma(150, ci$split$nhed$estimate[["shape"]], ci$split$nhed$estimate[["rate"]])) +
        ci$p_hed * (1 - stats::pgamma(150, ci$split$hed$estimate[["shape"]], ci$split$hed$estimate[["rate"]])),
      stringsAsFactors = FALSE)
  }
}
res <- do.call(rbind, rows)
utils::write.csv(res, file.path(audit_dir, "rr_bridge_consistency_2024.csv"), row.names = FALSE)

mx <- function(a, b) max(abs(a - b), na.rm = TRUE)
pr <- res$principal
cat(sprintf("factor_CH %d = %.4f (oms_factor_by_year.csv)\n", YEAR, factor_ch))
cat(sprintf("cells checked: %d (%d principal) = cause x sex x 4 tramos\n", nrow(res), sum(pr)))
cat(sprintf("[1] engine aaf_point vs stored expand_pif point: max|diff| = %.2e over %d cells\n",
            mx(res$engine_aaf, res$stored_aaf), sum(is.finite(res$stored_aaf))))
cat(sprintf("[2] person-level AAF (parity population) vs stored: max|diff| = %.2e; max rel = %.2e\n",
            mx(res$micro_aaf, res$stored_aaf), max(abs(res$micro_aaf / res$stored_aaf - 1), na.rm = TRUE)))
cat(sprintf("[3] PIF vol -10%%: person-level vs pif2 point: max|diff| = %.2e over %d cells\n",
            mx(res$micro_pif_vol10, res$pif2_vol10), sum(is.finite(res$pif2_vol10))))
cat(sprintf("[4] PIF HED -10%% (lambda 0): person-level vs pif2: max|diff| = %.2e over %d cells\n",
            mx(res$micro_pif_hed10, res$pif2_hed10), sum(is.finite(res$pif2_hed10))))
nh <- res$hed_mode == "none" & pr
cat(sprintf("[5] no-HED causes, single NHED/HED mixture population vs stored (pooled gamma): max|diff| = %.4f, median |diff| = %.4f over %d cells\n",
            mx(res$micro_aaf_mixture[nh], res$stored_aaf[nh]), stats::median(abs(res$micro_aaf_mixture[nh] - res$stored_aaf[nh])), sum(nh)))
cat(sprintf("[6] clamp-at-150 instead of truncation: max|diff| = %.4f; max gamma mass above 150 = %.4f\n",
            mx(res$micro_aaf_clamp, res$stored_aaf), max(res$mass_above_150)))
cat(sprintf("[7] APC factor forgotten (survey g/day): max|diff| = %.4f, median ratio AAF_survey/AAF = %.3f (principal, |AAF|>0.01)\n",
            mx(res$micro_aaf_survey_scale, res$stored_aaf),
            stats::median((res$micro_aaf_survey_scale / res$stored_aaf)[pr & abs(res$stored_aaf) > 0.01])))

# ---- DEIS death base (expand_pif export): total deaths n = mort / aaf, as ypll_pipeline_deaths() does ----
old_wd <- setwd(ctrl); source("ypll_icd_defs.R"); deaths <- ypll_pipeline_deaths(); setwd(old_wd)
deaths <- deaths[deaths$year == YEAR, ]
deaths$sex <- ifelse(deaths$gender == "Mujer", "female", "male")
pp <- res[res$principal, ]
pp <- merge(pp, deaths[, c("disease", "sex", "age_group", "n")], by.x = c("cause", "sex", "age_group"),
            by.y = c("disease", "sex", "age_group"), all.x = TRUE)
cat(sprintf("[8] DEIS %d deaths matched to %d of %d principal cells (unmatched = no deaths in cell)\n",
            YEAR, sum(is.finite(pp$n)), nrow(pp)))
pp$n[!is.finite(pp$n)] <- 0
by_cause <- stats::aggregate(cbind(deaths = n, attrib_expand = n * stored_aaf, attrib_person = n * micro_aaf,
                                   averted_vol10_pif2 = n * pif2_vol10, averted_vol10_person = n * micro_pif_vol10) ~ cause,
                             transform(pp, pif2_vol10 = ifelse(is.finite(pif2_vol10), pif2_vol10, 0)), sum)
by_cause <- by_cause[order(-by_cause$attrib_expand), ]
utils::write.csv(by_cause, file.path(audit_dir, "rr_bridge_deaths_2024.csv"), row.names = FALSE)
print(by_cause, digits = 4, row.names = FALSE)
cat(sprintf("[8] totals %d (15-65, 21 principal causes): deaths %.0f | attributable expand_pif %.1f vs person-level %.1f | averted vol-10%% pif2 %.1f vs person-level %.1f\n",
            YEAR, sum(by_cause$deaths), sum(by_cause$attrib_expand), sum(by_cause$attrib_person),
            sum(by_cause$averted_vol10_pif2), sum(by_cause$averted_vol10_person)))
cat(sprintf("rr_bridge_consistency elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
