"""Step 5: EPS (50+ same people) WLS objective of candidate sensitivity sets under the mover-stayer mixture."""
import sys, numpy as np, pandas as pd
sys.argv = ["x"]
src = open("<scratch>/audit/p4b_mover_stayer.py").read().split("rows = []")[0]
exec(src)  # reuse implied()/obj() definitions only (no grid search)
sets = [(0.32, 0.66), (0.20, 0.60), (0.45, 0.75), (0.45, 0.68), (0.30, 0.75), (0.0, 0.80)]
rows = [dict(s=s, lambda_m=l, phi_m=f, wls_obj=obj(l, f, s)) for s in [0.15, 0.20, 0.25] for l, f in sets]
r = pd.DataFrame(rows); best = r.groupby("s").wls_obj.transform("min")
r.to_csv(f"{OUT}/p4f_sensitivity_sets_eps.csv", index=False); print(r.round(2).to_string())

# Joint 95% region (delta <= 5.99) for movers at s = 0.20 on a coarse grid.
g = pd.DataFrame([dict(lambda_m=l, phi_m=f, wls_obj=obj(l, f, 0.20)) for l in np.arange(0, 0.61, 0.04) for f in np.arange(0.40, 0.91, 0.04)])
g["delta"] = g.wls_obj - g.wls_obj.min(); g.to_csv(f"{OUT}/p4f_region_s020.csv", index=False)
reg = g[g.delta <= 5.99]
print("s=0.20 region lambda_m", reg.lambda_m.min(), reg.lambda_m.max(), "phi_m", reg.phi_m.min(), reg.phi_m.max())
reg = reg.assign(r1y=reg.lambda_m + (1 - reg.lambda_m) * reg.phi_m, r10y=reg.lambda_m + (1 - reg.lambda_m) * reg.phi_m ** 10)
print(reg.sort_values("delta").head(40).round(3).to_string())
