"""Step 4e: women, stayer share matched to the band's own (older-cohort) never share: does former>12m then match?"""
import sys
import pandas as pd
sys.path.insert(0, "<scratch>/audit")
from p4_grid import simulate, summarise, targets, OUT
rows = []
for sex, s, lam, phi in [("female", 0.21, 0.32, 0.66), ("female", 0.30, 0.20, 0.66), ("male", 0.14, 0.36, 0.67), ("male", 0.15, 0.36, 0.67)]:
    rows.append(summarise(simulate(lam, phi, sex, init="latent", stayer=s), lam, phi, sex, "latent", s))
r = pd.DataFrame(rows)
for sex in ["male", "female"]:
    for k, v in targets(sex).items(): r.loc[r.sex == sex, "target_" + k] = v
r.to_csv(f"{OUT}/p4e_cohort_specific_stayer.csv", index=False)
cols = ["sex", "stayer", "lam", "phi"] + [f"{v}_{b}" for v in ["never", "former12", "not30_given12"] for b in ["30-34", "45-49", "60-65"]]
x = r[cols].copy(); x[cols[4:]] = (x[cols[4:]] * 100).round(1); print(x.to_string())
