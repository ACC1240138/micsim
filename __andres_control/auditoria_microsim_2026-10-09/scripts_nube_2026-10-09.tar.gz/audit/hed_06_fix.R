# Step 6: smallest fixes for the HED margin; re-run the 7-wave reconstruction (5 seeds, rho = 0.8, common random numbers).
#   base        : notebook engine (glm on log1p(observed g/day), cell intercepts, no time term)
#   A_cell      : same link; cell intercepts re-solved (uniroot) so the ENGINE g/day law reproduces the 7-wave mean target
#   B_wave      : same link; cell x wave intercepts re-solved so E_engine[HED | current] = target each wave
#                 (linear interpolation between waves, the interp_hold rule)
#   C_rank      : logit-rank link (volume rank within cell x wave), cell intercepts from the glm, no time term
#   D_rank_wave : C_rank + cell x wave intercepts re-solved
#   E_bins_wave : observed HED rate by volume-rank decile (pooled waves) + cell x wave logit offsets re-solved
# Variant definitions: hed_00b_hooks.R. Writes only aggregated CSVs.
.t0 <- Sys.time()
AUDIT <- "<scratch>/audit"
source(file.path(AUDIT, "hed_00_load_engine.R"))
source(file.path(AUDIT, "hed_00b_hooks.R"))
V <- build_hed_variants(ms_cfg$observed_end)
cat("glm slopes: log1p link", round(V$b_log, 3), "| rank link", round(V$b_rank, 3), "\n")
cat("HED by volume-rank decile (pooled waves), rows = cells:\n"); print(round(HED_BINS, 3))

runs <- list(); timing <- list()
for (v in names(V$variants)) {
  HED_MODE <- V$variants[[v]]$mode
  t1 <- Sys.time()
  for (s in ms_cfg$seeds) {
    r <- ms_simulate(V$variants[[v]]$model, 2012:2024, ms_cfg$n_sim, s, ms_cfg$rho)
    runs[[length(runs) + 1]] <- cbind(variant = v, r$summary[c("year", "sex", "age_group", "current_mean", "gpd_mean", "hed_mean", "seed")])
  }
  timing[[v]] <- as.numeric(difftime(Sys.time(), t1, units = "mins"))
}
HED_MODE <- "log"
sim <- dplyr::bind_rows(runs)
cells <- sim |> dplyr::group_by(variant, year, sex, age_group) |>
  dplyr::summarise(hed_sim = mean(hed_mean), hed_mc_sd = stats::sd(hed_mean), gpd_sim = mean(gpd_mean),
    cur_sim = mean(current_mean), .groups = "drop") |>
  dplyr::inner_join(ms_targets[c("year", "sex", "age_group", "hed_mean", "hed_se", "gpd_mean", "current_mean")],
    by = c("year", "sex", "age_group")) |>
  dplyr::mutate(err = hed_sim - hed_mean, inside = ifelse(year == 2020L, NA, abs(err) <= stats::qnorm(0.975) * hed_se))
metrics <- cells |> dplyr::group_by(variant) |>
  dplyr::summarise(cells = dplyr::n(), bias_pp = 100 * mean(err), rmse_pp = 100 * sqrt(mean(err^2)),
    mae_pp = 100 * mean(abs(err)), coverage = mean(inside, na.rm = TRUE), cells_in = sum(inside, na.rm = TRUE),
    cells_judged = sum(!is.na(inside)), bias_2018_pp = 100 * mean(err[year == 2018]),
    max_abs_gpd_err = max(abs(gpd_sim - gpd_mean)), max_abs_current_err = max(abs(cur_sim - current_mean)),
    mean_mc_sd_pp = 100 * mean(hed_mc_sd), .groups = "drop")
metrics$minutes_5_seeds <- unlist(timing[metrics$variant])
metrics <- metrics[match(names(V$variants), metrics$variant), ]
print(as.data.frame(metrics), digits = 4)
utils::write.csv(metrics, file.path(AUDIT, "hed_fix_metrics.csv"), row.names = FALSE)
utils::write.csv(cells, file.path(AUDIT, "hed_fix_cells.csv"), row.names = FALSE)
byyear <- stats::aggregate(cbind(err_pp = 100 * err) ~ variant + year, cells, function(v) round(mean(v), 2))
print(stats::xtabs(err_pp ~ variant + year, byyear))

# HED rate by within-cell volume-rank quintile: observed (randomized-PIT rank) vs each engine law (analytic).
tg <- V$tg; hd <- V$hd; qb <- seq(0, 1, 0.2)
obs_q <- do.call(rbind, lapply(split(hd, list(hd$year, hd$cell), drop = TRUE), function(z)
  data.frame(sex = z$sex[1], q = 1:5, rate = vapply(1:5, function(j) {
    k <- z$u_r >= qb[j] & z$u_r < qb[j + 1]; stats::weighted.mean(z$hed[k], z$weight[k]) }, numeric(1)))))
a_of <- function(tab, i) if (is.null(tab$year)) tab$a[tab$cell == tg$cell[i]] else tab$a[tab$cell == tg$cell[i] & tab$year == tg$year[i]]
rate_log <- function(tab) function(i, lo, hi) {
  sc <- tg$mu_current[i] / ((1 - tg$p_zero[i]) * tg$shape[i])
  stats::integrate(function(v) stats::plogis(a_of(tab, i) + V$b_log * log1p(stats::qgamma(v, tg$shape[i], scale = sc))), lo, hi)$value / (hi - lo)
}
rate_rank <- function(tab) function(i, lo, hi)
  stats::integrate(function(t) stats::plogis(a_of(tab, i) + V$b_rank * t) * stats::dlogis(t), stats::qlogis(lo), stats::qlogis(hi))$value / (hi - lo)
rate_bins <- function(tab) function(i, lo, hi) mean(stats::plogis(stats::qlogis(HED_BINS[tg$cell[i], (round(10 * lo) + 1):round(10 * hi)]) + a_of(tab, i)))
eng_q <- function(f, nm) {
  d <- do.call(rbind, lapply(seq_len(nrow(tg)), function(i) data.frame(sex = tg$sex[i], q = 1:5,
    rate = vapply(1:5, function(j) f(i, qb[j], qb[j + 1]), numeric(1)))))
  a <- stats::aggregate(rate ~ sex + q, d, mean); names(a)[3] <- nm; a
}
oq <- stats::aggregate(rate ~ sex + q, obs_q, mean); names(oq)[3] <- "observed"
qcomp <- Reduce(function(a, b) merge(a, b, by = c("sex", "q")), list(oq,
  eng_q(rate_log(V$tabs$base), "base"), eng_q(rate_log(V$tabs$A_cell), "A_cell"), eng_q(rate_log(V$tabs$B_wave), "B_wave"),
  eng_q(rate_rank(V$tabs$C_rank), "C_rank"), eng_q(rate_rank(V$tabs$D_rank_wave), "D_rank_wave"),
  eng_q(rate_bins(V$tabs$E_bins_wave), "E_bins_wave")))
cat("\n== HED among current drinkers by within-cell volume-rank quintile (mean over 4 ages x 7 waves) ==\n")
print(qcomp, digits = 3)
qerr <- sapply(names(qcomp)[-(1:3)], function(v) 100 * sqrt(mean((qcomp[[v]] - qcomp$observed)^2)))
cat("RMSE vs observed quintile curve (pp):\n"); print(round(qerr, 2))
utils::write.csv(qcomp, file.path(AUDIT, "hed_fix_volume_quintiles.csv"), row.names = FALSE)
message(sprintf("hed_06_fix elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
