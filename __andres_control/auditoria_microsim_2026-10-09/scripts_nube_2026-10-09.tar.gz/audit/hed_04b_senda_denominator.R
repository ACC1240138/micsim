# Does SENDA's published "embriaguez" series count unknown HED (88/99) as "no" in the denominator of past-month users?
.t0 <- Sys.time()
source("<scratch>/audit/hed_00_load_engine.R")
senda <- c(`2012` = 52.1, `2014` = 43.7, `2016` = 51.1, `2018` = 56.3, `2020` = 50.2, `2022` = 50.7, `2024` = 47.2)
r <- do.call(rbind, lapply(ms_wave_years, function(y) {
  a <- ms_enpg_all[ms_enpg_all$year == y & ms_enpg_all$status == "current", ]
  data.frame(year = y, complete_case_pct = 100 * stats::weighted.mean(a$hed, a$weight, na.rm = TRUE),
    unknown_as_no_pct = 100 * sum(a$weight * (a$hed %in% 1)) / sum(a$weight),
    hed_unknown_w_pct = 100 * sum(a$weight * is.na(a$hed)) / sum(a$weight), senda = senda[[as.character(y)]])
}))
r$cc_minus_senda <- r$complete_case_pct - r$senda; r$uan_minus_senda <- r$unknown_as_no_pct - r$senda
print(r, digits = 3)
utils::write.csv(r, file.path(AUDIT, "hed_def_senda_denominator.csv"), row.names = FALSE)
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
