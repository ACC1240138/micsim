.t0 <- Sys.time()
setwd("<repo>/__andres_control")
source(file.path("<repo>", "_tools", "acc_data.R"))
root <- dirname(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))
root <- dirname(root); print(list.files(root))
f <- c("2012"="Base de datos ENPG 2012 (PG).DTA.dta","2014"="Base de datos ENPG 2014 (PG).DTA.dta",
 "2016"="base ENPG 2016 publico general.dta","2018"="Base de datos ENPG 2018 (PG).DTA","2020"="enpg2020.RDS",
 "2022"="BD - ENPG 2022 (Stata 16).dta","2024"="Base Publica ENPG 2024 (Stata 16).dta")
for (y in names(f)) {
  p <- file.path(root, f[[y]])
  nm <- if (grepl("RDS$", p)) names(readRDS(p)) else names(haven::read_dta(p, n_max = 1))
  cat(y, ":", grep("^(p1[0-9]|oh_?[0-9]+[a-zA-Z]*|OH_[0-9]+[A-Z]*|idencuesta|SbjNum|FOLIO|folio)$", nm, value = TRUE, ignore.case = TRUE), "\n")
}
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
