# 07_tables.py -- format the aggregated outputs of 02-06 as markdown tables and fill mortality_deis.template.md.
# Run: python3 -I 07_tables.py   (reads only aggregated CSVs in this folder)
import time, re, sys
import pandas as pd
t0 = time.time()
A = "<scratch>/audit/"
def md(df, fmt=None):
    fmt = fmt or {}
    cols = list(df.columns)
    out = ["| " + " | ".join(map(str, cols)) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for i in range(len(df)):
        cells = []
        for c in cols:
            v = df[c].iloc[i]
            f = fmt.get(c)
            cells.append(f(v) if f else (f"{v:,.0f}" if isinstance(v, float) and abs(v) >= 100 else (f"{v:.3f}" if isinstance(v, float) else str(v))))
        out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out)
pct = lambda v: f"{100*v:+.1f}%"
pct0 = lambda v: f"{100*v:.1f}%"
n0 = lambda v: f"{v:,.0f}"
T = {}

# A1 drift
d = pd.read_csv(A + "out_A1_drift_year_sex.csv")
w = d.pivot(index="year", columns="sex")
t = pd.DataFrame({"year": w.index,
  "DEIS F": w["deis"]["female"].values, "engine exp. F": w["engine_expected"]["female"].values, "rel. err F": w["engine_rel_err"]["female"].values,
  "DEIS M": w["deis"]["male"].values, "engine exp. M": w["engine_expected"]["male"].values, "rel. err M": w["engine_rel_err"]["male"].values,
  "HMD mx x INE June / DEIS F": w["hmd_mx_rel_err"]["female"].values, "same M": w["hmd_mx_rel_err"]["male"].values,
  "HMD exposure vs INE June F": w["hmd_exposure_vs_ine_mid"]["female"].values, "same M ": w["hmd_exposure_vs_ine_mid"]["male"].values,
  "HMD deaths vs DEIS F": (w["hmd_lexis_deaths"]["female"] / w["deis"]["female"] - 1).values, "same  M": (w["hmd_lexis_deaths"]["male"] / w["deis"]["male"] - 1).values})
f = {c: pct for c in t.columns if "rel" in c or "vs" in c or "same" in c or "/" in c}
f.update({c: n0 for c in ["DEIS F", "engine exp. F", "DEIS M", "engine exp. M"]}); f["year"] = str
T["drift"] = md(t, f)
s = pd.read_csv(A + "out_A1_multiplier.csv")
s = s.rename(columns={"scale_old_outputs_deis": "reproduced from saved outputs' DEIS totals", "scale_corrected_deis": "with corrected DEIS bundle", "notebook_saved": "saved in model_parameters.csv"})
T["multiplier"] = md(s, {c: (lambda v: f"{v:.6f}") for c in s.columns if c != "sex"})
old = d.groupby("sex")[["deis", "deis_in_saved_outputs"]].sum().reset_index()
old["difference"] = old.deis_in_saved_outputs - old.deis
old = old.rename(columns={"deis": "DEIS 15-65 2012-2024, current bundle", "deis_in_saved_outputs": "observed_deaths in microsim_recalib_outputs/mortality_concordance.csv"})
T["stale"] = md(old, {c: n0 for c in old.columns if c != "sex"})

# A2 single-age q
x = pd.read_csv(A + "out_A2_m_q_year_sex_age.csv")
sel = x[x.age.isin([15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65]) & x.year.isin([2012, 2016, 2019, 2021, 2024])]
p = sel.pivot_table(index=["sex", "age"], columns="year", values="q").reset_index()
p.columns = [str(c) for c in p.columns]
st = pd.read_csv(A + "out_A2_stability_sex_age.csv")
p = p.merge(st[["sex", "age", "mean_deaths", "cv_q_2012_2019", "cv_poisson", "trend_pct_per_year_2012_2019"]], on=["sex", "age"])
f = {c: (lambda v: f"{1000*v:.2f}") for c in ["2012", "2016", "2019", "2021", "2024"]}
f.update({"mean_deaths": n0 if False else (lambda v: f"{v:.0f}"), "cv_q_2012_2019": pct0, "cv_poisson": pct0, "trend_pct_per_year_2012_2019": lambda v: f"{v:+.1f}%", "age": str})
T["q_single"] = md(p.rename(columns={}), f)
sb = pd.read_csv(A + "out_A2_stability_band.csv")
T["stab_band"] = md(sb, {"ages": str, "mean_deaths_per_age": lambda v: f"{v:.0f}", "min_deaths": lambda v: f"{v:.0f}", "median_cv_q": pct0, "median_cv_poisson": pct0,
                         "median_trend_pct": lambda v: f"{v:+.1f}%", "median_covid_ratio": lambda v: f"{v:.2f}"})
lx = pd.read_csv(A + "out_A3_lexis_year_sex.csv")
lxs = lx.groupby("sex").agg(naive_min=("naive_rel", "min"), naive_max=("naive_rel", "max"), par_min=("parallelogram_rel", "min"), par_max=("parallelogram_rel", "max"),
                            edge_min=("parallelogram_vs_edge_target", "min"), edge_max=("parallelogram_vs_edge_target", "max"), d15=("d15", "mean"), d66=("d66", "mean")).reset_index()
T["lexis"] = md(lxs, {c: pct for c in lxs.columns if c.endswith(("min", "max"))} | {"d15": n0, "d66": n0})
pv = pd.read_csv(A + "out_A4_population_vintages.csv")
T["vintage"] = md(pv[pv.year.isin([2012, 2017, 2020, 2024])][["year", "sex", "pop_old_workbook", "pop_mid_cpv2024", "hmd_implied_exposure", "old_vs_mid", "hmd_vs_mid"]],
                  {"year": str, "pop_old_workbook": n0, "pop_mid_cpv2024": n0, "hmd_implied_exposure": n0, "old_vs_mid": pct, "hmd_vs_mid": pct})

# B cause tables
sm = pd.read_csv(A + "out_B2_summary_cause_sex_band.csv")
bands = ["15-29", "30-44", "45-59", "60-65", "66-79", "80+"]
order = sm[sm.band.isin(bands[:4])].groupby("cause").mean_deaths.sum().sort_values(ascending=False).index
for sex in ["female", "male"]:
    s_ = sm[sm.sex == sex]
    rows = []
    for c in order:
        r = {"cause": c}
        for b in bands:
            q = s_[(s_.cause == c) & (s_.band == b)]
            r[b] = "" if q.empty else f"{q.mean_deaths.iloc[0]:.0f} ({q.rate100k.iloc[0]:.1f}) [{int(q.years_lt10.iloc[0])}]"
        if not all(v == "" for k, v in r.items() if k != "cause"): rows.append(r)
    T[f"cause_{sex}"] = md(pd.DataFrame(rows), {b: str for b in bands})
cv = sm[sm.band.isin(bands[:4]) & ~sm.cause.str.startswith("COVID")]
cvt = cv.groupby("band").agg(cells=("cause", "size"), mean_deaths_median=("mean_deaths", "median"), cv_rate_median=("cv_rate_pre_covid", "median"),
                             cv_poisson_median=("cv_poisson", "median"), causes_with_any_year_lt10=("years_lt10", lambda v: int((v > 0).sum())),
                             causes_all_years_lt10=("years_lt10", lambda v: int((v == 13).sum()))).reset_index()
T["cv_band"] = md(cvt, {"cells": str, "mean_deaths_median": lambda v: f"{v:.0f}", "cv_rate_median": pct0, "cv_poisson_median": pct0,
                        "causes_with_any_year_lt10": str, "causes_all_years_lt10": str})
small = pd.read_csv(A + "out_B2_small_cells.csv")
T["small"] = md(small, {"cells": n0, "cells_lt10": n0, "cells_zero": n0})
lo = pd.read_csv(A + "out_B3_loyo_overall.csv")
T["loyo"] = md(lo[["method", "cells_excl_covid", "deviance_excl_2020_22_and_covid_cause", "deviance_per_cell_excl_covid", "poisson_deviance", "mae_deaths", "floored"]].sort_values("deviance_per_cell_excl_covid"),
               {"cells_excl_covid": n0, "deviance_excl_2020_22_and_covid_cause": n0, "deviance_per_cell_excl_covid": lambda v: f"{v:.2f}", "poisson_deviance": n0, "mae_deaths": lambda v: f"{v:.1f}", "floored": n0})
la = pd.read_csv(A + "out_B4_loyo_single_age.csv")
la["flat/cell"] = la.flat_band_trend / la.cells; la["spline/cell"] = la.spline_age_trend / la.cells
T["loyo_sa"] = md(la[la.cause.isin(["TOTAL", "All other causes", "Ischaemic Heart Disease", "Liver Cirrhosis", "Intentional Injuries", "Road Injuries", "Fully attributable (AAF=1)", "Colon and rectum Cancer", "Breast Cancer"])][["cause", "cells", "flat/cell", "spline/cell"]],
                  {"cells": n0, "flat/cell": lambda v: f"{v:.2f}", "spline/cell": lambda v: f"{v:.2f}"})
g = pd.read_csv(A + "out_B5_sim_granularity.csv")
T["gran"] = md(g, {"deaths_per_year": n0, "sim_deaths_per_year_n25k": lambda v: f"{v:.2f}", "sim_deaths_per_year_n100k": lambda v: f"{v:.1f}", "mc_rel_se_n100k_realized": pct0})

# C 66+
c1 = pd.read_csv(A + "out_C1_share66_pooled.csv")
T["share66"] = md(c1[["group", "sex", "d15_65", "d66_79", "d80p", "share_66_79", "share_66plus"]], {"d15_65": n0, "d66_79": n0, "d80p": n0, "share_66_79": pct0, "share_66plus": pct0})
c1y = pd.read_csv(A + "out_C1_share66_year_sex.csv")
c1y = c1y.groupby("sex").agg(all_min=("share_66plus_all", "min"), all_max=("share_66plus_all", "max"), aaf1_min=("share_66plus_aaf1", "min"),
                             aaf1_max=("share_66plus_aaf1", "max"), partial_min=("share_66plus_partial", "min"), partial_max=("share_66plus_partial", "max")).reset_index()
T["share66_range"] = md(c1y, {c: pct0 for c in c1y.columns if c != "sex"})
bc = pd.read_csv(A + "out_C1_share66_cause_sex.csv")
bcw = bc.pivot(index="cause", columns="sex", values="share_66plus").reset_index().sort_values("male", ascending=False)
T["share66_cause"] = md(bcw, {"female": lambda v: "" if pd.isna(v) else pct0(v), "male": lambda v: "" if pd.isna(v) else pct0(v)})
c3 = pd.read_csv(A + "out_C3_attr66plus_pooled.csv")
T["attr66"] = md(c3, {c: n0 for c in ["attr_15_65", "attr66p_net", "aaf1_66_79", "aaf1_80p", "attr_15_65_harm_only", "attr66p_harm"]} | {"share_net": pct0, "share_harm": pct0})
c3y = pd.read_csv(A + "out_C3_attr66plus_extrapolated.csv")
T["attr66_year"] = md(c3y[["year", "sex", "attr_15_65", "attr66p_net", "share_attr_66p_net", "share_attr_66_79_net"]],
                      {"year": str, "attr_15_65": n0, "attr66p_net": n0, "share_attr_66p_net": pct0, "share_attr_66_79_net": pct0})
bcz = pd.read_csv(A + "out_C3_attr66plus_by_cause.csv")
bcz["attr_66p"] = bcz.attr_66_79 + bcz.attr_80p
T["attr66_cause"] = md(bcz.sort_values(["sex", "attr_66p"], ascending=[True, False]).groupby("sex").head(6)[["sex", "disease", "deaths_66p", "aaf_60_65_mean", "attr_66_79", "attr_80p"]],
                       {"deaths_66p": n0, "aaf_60_65_mean": lambda v: f"{v:.3f}", "attr_66_79": n0, "attr_80p": n0})
# sensitivity: drop cardiovascular + diabetes (age-attenuated / J-shaped RR) from both sides
sx = pd.read_csv(A + "out_C3_attr66plus_excl_cvd_dm.csv")
T["attr66_sens"] = md(sx, {"attr66p_partial": n0, "attr_15_65": n0, "aaf1_66p": n0, "share_66p": pct0})
# D quality
q = pd.read_csv(A + "agg/quality_illdef_year_age6.csv"); q["share"] = q.illdef / q.deaths
qp = q.pivot(index="year", columns="age6", values="share").reset_index()
T["illdef"] = md(qp, {"year": str} | {b: pct0 for b in bands})
r = pd.read_csv(A + "agg/illdef_codes_year.csv"); r = r[r.scope == "15-65"]
r["code"] = r.code3.where(r.code3.isin(["R99", "R96", "R98"]), "other R")
rp = r.pivot_table(index="year", columns="code", values="deaths", aggfunc="sum").fillna(0).astype(int).reset_index()
T["rcodes"] = md(rp, {c: str for c in rp.columns})
qr = pd.read_csv(A + "agg/quality_records.csv")
T["qrec"] = md(qr, {"check": str, "value": str})
dd = pd.read_csv(A + "agg/deaths_year_sex_age_cause.csv")
cov = dd[dd.cause.str.startswith("COVID")].assign(scope=lambda z: z.age.le(65).map({True: "15-65", False: "66+"})).pivot_table(index="year", columns="scope", values="deaths", aggfunc="sum").reset_index()
T["covid"] = md(cov, {c: (lambda v: f"{v:,.0f}") for c in cov.columns if c != "year"} | {"year": str})
inj = pd.read_csv(A + "out_B1_cells_year_sex_band_cause.csv")
inj = inj[inj.band.isin(bands[:4]) & inj.cause.isin(["Intentional Injuries", "Unintentional Injuries", "Road Injuries", "All other causes"]) & (inj.year >= 2019)]
inj = inj.pivot_table(index="year", columns="cause", values="deaths", aggfunc="sum").reset_index()
T["inj"] = md(inj, {c: n0 for c in inj.columns if c != "year"} | {"year": str})

tpl = open(A + "mortality_deis.template.md").read()
missing = sorted(set(re.findall(r"\{\{(\w+)\}\}", tpl)) - set(T))
assert not missing, f"template placeholders without a table: {missing}"
open(A + "mortality_deis.md", "w").write(re.sub(r"\{\{(\w+)\}\}", lambda m_: T[m_.group(1)], tpl))
print("unused tables:", sorted(set(T) - set(re.findall(r"\{\{(\w+)\}\}", tpl))))
print(f"07_tables elapsed minutes: {(time.time() - t0) / 60:.2f}")
