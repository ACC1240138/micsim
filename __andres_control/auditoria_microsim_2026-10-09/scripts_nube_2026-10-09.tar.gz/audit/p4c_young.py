"""Step 4c: never share at ages 15-29 (initiation window) under the recommended mover-stayer model vs ENPG pooled bands."""
import sys, time
import pandas as pd
sys.path.insert(0, "<scratch>/audit")
from p4_grid import simulate, pool, OUT
t0 = time.time()
bands = {"15-17": (15, 17), "18-20": (18, 20), "21-24": (21, 24), "25-29": (25, 29)}
rows = []
for sex, s, lam, phi in [("male", 0.12, 0.32, 0.66), ("female", 0.18, 0.32, 0.66), ("male", 0.0, 0.45, 0.68), ("female", 0.0, 0.45, 0.68),
                         ("male", 0.0, 0.0, 0.8), ("female", 0.0, 0.0, 0.8)]:
    for init in ["latent", "engine_random"]:
        df = simulate(lam, phi, sex, init=init, stayer=s)
        for b, (lo, hi) in bands.items():
            t = pool[(pool.variable == "never") & (pool.sex == sex) & (pool.age_fine == b)].estimate.iloc[0]
            m = df[(df.age >= lo) & (df.age <= hi)]
            rows.append(dict(sex=sex, stayer=s, lam=lam, phi=phi, init=init, band=b, model_never=m.never.mean(),
                             model_never_annual=m.never_annual.mean(), enpg_never=t))
r = pd.DataFrame(rows); r.to_csv(f"{OUT}/p4c_young_never.csv", index=False)
print((r.pivot_table(index=["sex", "stayer", "lam", "phi", "init"], columns="band", values="model_never") * 100).round(1))
print((r.groupby(["sex", "band"]).enpg_never.first().unstack() * 100).round(1))
print(f"p4c elapsed minutes: {(time.time() - t0) / 60:.2f}")

# Sensitivity: entry never share = ENPG cross-sectional 15-17 band (retrospective OH_3 onset is prone to telescoping).
import p4_grid
p4_grid.never15 = lambda sex: 0.60 if sex == "male" else 0.62   # shortcut: ~band 15-17 extrapolated to exact 15; replace with single-age ENPG
rows = []
for sex, s, lam, phi in [("male", 0.12, 0.32, 0.66), ("female", 0.18, 0.32, 0.66)]:
    df = p4_grid.simulate(lam, phi, sex, init="latent", stayer=s)
    for b, (lo, hi) in bands.items():
        t = pool[(pool.variable == "never") & (pool.sex == sex) & (pool.age_fine == b)].estimate.iloc[0]
        m = df[(df.age >= lo) & (df.age <= hi)]
        rows.append(dict(sex=sex, stayer=s, band=b, model_never=m.never.mean(), enpg_never=t))
r2 = pd.DataFrame(rows); r2.to_csv(f"{OUT}/p4c_young_never_entry_sensitivity.csv", index=False)
print((r2.pivot_table(index=["sex", "stayer"], columns="band", values=["model_never", "enpg_never"]) * 100).round(1))
