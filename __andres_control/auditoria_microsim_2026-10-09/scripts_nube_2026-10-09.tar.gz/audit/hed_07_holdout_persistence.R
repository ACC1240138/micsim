# Step 6b: held-out check of the HED variants (fit waves 2012-2020, predict 2022/2024 with the interp_hold rule:
#          drivers and offsets held at 2020). Analytic engine expectation (simulation = analytic + MC, see hed_05).
# Step 5/7: what z_hed persistence does: fixed 2024 cohort (no ageing, no demography), copula updates only,
#          rho_current = rho_amount = 0.8, rho_hed in {0, 0.5, 0.8, 0.95, 1}; HED margin vs individual persistence.
# Writes only aggregated CSVs.
.t0 <- Sys.time()
AUDIT <- "<scratch>/audit"
source(file.path(AUDIT, "hed_00_load_engine.R"))
source(file.path(AUDIT, "hed_00b_hooks.R"))

## Holdout -------------------------------------------------------------------------------------------
V <- build_hed_variants(2020L)
test <- ms_targets[ms_targets$year %in% c(2022L, 2024L), ]
test$cell <- paste(test$sex, test$age_group, sep = ":")
d <- ms_drivers_nb(V$base_model, c(2022L, 2024L))
test <- merge(test, d[c("year", "cell", "mu_current", "shape", "p_zero")], by = c("year", "cell"))
a_hold <- function(tab, cl, yr) { t <- tab[tab$cell == cl, ]; if (nrow(t) == 1L) t$a else stats::approx(t$year, t$a, xout = yr, rule = 2)$y }
pred <- function(v, i) {
  a <- a_hold(V$tabs[[v]], test$cell[i], test$year[i])
  switch(V$variants[[v]]$mode,
    log = E_log(a, test$mu_current[i], test$shape[i], test$p_zero[i], V$b_log),
    rank = E_rank(a, V$b_rank, test$p_zero[i]),
    bins = V$E_bins(a, test$cell[i], test$p_zero[i]))
}
t20 <- ms_targets[ms_targets$year == 2020L, c("sex", "age_group", "hed_mean")]
names(t20)[3] <- "hed_2020"
test <- merge(test, t20, by = c("sex", "age_group"))
ho <- do.call(rbind, lapply(c(names(V$variants), "naive_hold_2020_target"), function(v) {
  p <- if (v == "naive_hold_2020_target") test$hed_2020 else vapply(seq_len(nrow(test)), function(i) pred(v, i), numeric(1))
  e <- p - test$hed_mean
  data.frame(variant = v, cells = length(e), bias_pp = 100 * mean(e), rmse_pp = 100 * sqrt(mean(e^2)),
    coverage = mean(abs(e) <= stats::qnorm(0.975) * test$hed_se), bias_2022_pp = 100 * mean(e[test$year == 2022]),
    bias_2024_pp = 100 * mean(e[test$year == 2024]))
}))
cat("== Holdout 2022/2024 (fit <= 2020), analytic engine expectation, 16 cells ==\n"); print(ho, digits = 3)
utils::write.csv(ho, file.path(AUDIT, "hed_holdout_2022_2024.csv"), row.names = FALSE)

## Persistence ---------------------------------------------------------------------------------------
V24 <- build_hed_variants(2024L)
set.seed(424242)
st <- ms_population[ms_population$year == 2024L, ]
n_tot <- 200000L
st$n <- pmax(1L, as.integer(round(n_tot * st$pop_jan / sum(st$pop_jan))))
pop0 <- dplyr::bind_rows(lapply(seq_len(nrow(st)), function(i) ms_new_people(st$sex[i], st$age[i], st$n[i], sum(st$n[seq_len(i - 1)]))))
pers <- list()
for (v in c("base", "E_bins_wave")) {
  HED_MODE <- V24$variants[[v]]$mode
  drv <- ms_drivers(V24$variants[[v]]$model, 2024L)
  for (rho_hed in c(0, 0.5, 0.8, 0.95, 1)) {
    set.seed(99)
    pop <- ms_exposure(pop0, 2024L, drv)
    H <- C <- matrix(NA, nrow(pop), 6)
    H[, 1] <- pop$hed; C[, 1] <- pop$current
    for (t in 2:6) {
      n <- nrow(pop)
      pop$z_current <- 0.8 * pop$z_current + sqrt(1 - 0.8^2) * stats::rnorm(n)
      pop$z_amount <- 0.8 * pop$z_amount + sqrt(1 - 0.8^2) * stats::rnorm(n)
      pop$z_hed <- rho_hed * pop$z_hed + sqrt(1 - rho_hed^2) * stats::rnorm(n)
      pop <- ms_exposure(pop, 2024L, drv)
      H[, t] <- pop$hed; C[, t] <- pop$current
    }
    both <- C[, 1:5] & C[, 2:6]
    allc <- rowSums(C) == 6
    pers[[length(pers) + 1]] <- data.frame(variant = v, rho_hed = rho_hed,
      hed_among_current_mean_t1_t6 = mean(colSums(H) / colSums(C)),
      hed_among_current_sd_over_t = stats::sd(colSums(H) / colSums(C)),
      p_hed_next_given_hed = sum(H[, 2:6] & H[, 1:5] & both) / sum(H[, 1:5] & both),
      p_hed_next_given_nohed = sum(H[, 2:6] & !H[, 1:5] & both) / sum(!H[, 1:5] & both),
      ever_hed_6y_among_always_current = mean(rowSums(H[allc, ]) > 0),
      always_hed_6y_among_always_current = mean(rowSums(H[allc, ]) == 6),
      n_always_current = sum(allc))
  }
}
HED_MODE <- "log"
pers <- do.call(rbind, pers)
cat("\n== z_hed persistence: fixed 2024 cohort, 6 annual updates, rho_current = rho_amount = 0.8 ==\n"); print(pers, digits = 3)
utils::write.csv(pers, file.path(AUDIT, "hed_persistence_grid.csv"), row.names = FALSE)
message(sprintf("hed_07 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
