#| label: ms-fit-and-check
.t0 <- Sys.time()
ms_train_models <- base::lapply(ms_cfg$specs, function(spec) ms_fit(ms_cfg$train_end, spec))
base::names(ms_train_models) <- ms_cfg$specs
base::stopifnot(base::all(base::vapply(ms_train_models, function(m) base::max(m$training_years) == 2020L, base::logical(1))))
ms_smoke <- ms_simulate(ms_train_models$interp_hold, 2012:2014, 1500L, ms_cfg$seeds[1], rho = 0.8)
ms_smoke_again <- ms_simulate(ms_train_models$interp_hold, 2012:2014, 1500L, ms_cfg$seeds[1], rho = 0.8)
ms_smoke_rho0 <- ms_simulate(ms_train_models$interp_hold, 2012:2014, 1500L, ms_cfg$seeds[1], rho = 0)
base::stopifnot(base::identical(ms_smoke, ms_smoke_again),
  base::identical(ms_smoke$deaths, ms_smoke_rho0$deaths),
  base::setequal(ms_smoke$summary$year, 2012:2014),
  base::all(ms_smoke$flows$end == ms_smoke$flows$start - ms_smoke$flows$deaths -
    ms_smoke$flows$age_exits - ms_smoke$flows$residual_outflow +
    ms_smoke$flows$age_entries + ms_smoke$flows$residual_inflow))
ms_history_check <- ms_smoke$histories |>
  dplyr::group_by(id) |>
  dplyr::arrange(year, .by_group = TRUE) |>
  dplyr::summarise(age_step_ok = base::all(base::diff(age) == base::diff(year)),
    ever_monotone = base::all(base::diff(base::as.integer(ever)) >= 0), .groups = "drop")
base::stopifnot(base::all(ms_history_check$age_step_ok & ms_history_check$ever_monotone),
  base::all(base::abs(ms_smoke$summary$never + ms_smoke$summary$former + ms_smoke$summary$current_mean - 1) < 1e-12),
  base::all(base::abs(ms_smoke$summary$cat1 + ms_smoke$summary$cat2 + ms_smoke$summary$cat3 - ms_smoke$summary$current_mean) < 1e-12))
# interp_hold must reproduce the training targets exactly at the driver level, and hold 2020 afterwards.
ms_d_check <- ms_drivers(ms_train_models$interp_hold, 2012:2024)
ms_t_check <- ms_targets[ms_targets$year <= 2020L, ]
ms_k_check <- base::match(base::paste(ms_t_check$year, ms_t_check$sex, ms_t_check$age_group, sep = ":"), ms_d_check$key)
base::stopifnot(base::max(base::abs(ms_d_check$p_current[ms_k_check] - ms_t_check$current_mean)) < 1e-12,
  base::max(base::abs(ms_d_check$mu_current[ms_k_check] - ms_t_check$gpd_mean)) < 1e-9,
  base::identical(ms_d_check$p_current[ms_d_check$year == 2024L], ms_d_check$p_current[ms_d_check$year == 2020L]))
# No-leakage test for EVERY spec: perturb held-out outcomes in memory, refit, compare all fitted components.
ms_signature <- function(model) base::list(
  drivers = ms_drivers(model, ms_cfg$start_year:ms_cfg$end_year)[base::c("key", "p_current", "mu_current")],
  hed = stats::coef(model$hed), shape = model$shape, mortality_scale = model$mortality_scale)
ms_check_no_leakage <- function(cutoff) {
  original_enpg <- ms_enpg
  original_targets <- ms_targets
  original_deaths <- ms_mortality
  base::on.exit({ms_enpg <<- original_enpg; ms_targets <<- original_targets;
                 ms_mortality <<- original_deaths}, add = TRUE)
  before <- base::lapply(ms_cfg$specs, function(spec) ms_signature(ms_fit(cutoff, spec)))
  hold <- ms_enpg$year > cutoff
  ms_enpg$current[hold] <<- 0
  ms_enpg$gpd_survey[hold] <<- 999
  ms_enpg$hed[hold] <<- 1
  ms_targets$current_mean[ms_targets$year > cutoff] <<- 0.999
  ms_targets$gpd_mean[ms_targets$year > cutoff] <<- 999
  ms_mortality$deaths[ms_mortality$year > cutoff] <<- 999999
  after <- base::lapply(ms_cfg$specs, function(spec) ms_signature(ms_fit(cutoff, spec)))
  base::stopifnot(base::identical(before, after))
  TRUE
}
base::stopifnot(base::all(base::vapply(ms_cfg$cutoffs, ms_check_no_leakage, base::logical(1))))
ms_table(base::data.frame(check = base::c("Repeatability", "Annual stock identity", "Valid exposure/probabilities",
  "interp_hold reproduces training targets and holds the last wave",
  "Held-out outcome perturbation, 4 specs x 4 cutoffs"), result = "PASS"), "Runnable engineering checks")
ms_table(base::data.frame(sex = base::names(ms_train_models$interp_hold$mortality_scale),
  hazard_multiplier = base::unname(ms_train_models$interp_hold$mortality_scale)),
  "Mortality calibration using DEIS 2012-2020 only (identical across specs)")
base::message(base::sprintf("ms-fit-and-check elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
