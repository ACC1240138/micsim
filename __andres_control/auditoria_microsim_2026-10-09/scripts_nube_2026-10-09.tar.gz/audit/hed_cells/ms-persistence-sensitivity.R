#| label: ms-persistence-sensitivity
.t0 <- Sys.time()
ms_sensitivity <- dplyr::bind_rows(base::lapply(base::c(0, ms_cfg$rho, 0.95), function(rho) {
  run <- ms_simulate(ms_reconstruction_model, 2012:2024, ms_cfg$n_sim, ms_cfg$seeds[1], rho)
  last <- run$summary[run$summary$year == 2024L, ]
  base::data.frame(rho = rho,
    annual_current_status_change = base::sum(run$flows$status_changes) / base::sum(run$flows$transition_n),
    current_2024 = stats::weighted.mean(last$current_mean, last$n),
    never_2024 = stats::weighted.mean(last$never, last$n),
    former_2024 = stats::weighted.mean(last$former, last$n),
    deaths_total = base::sum(run$deaths$deaths))
}))
base::stopifnot(base::length(base::unique(ms_sensitivity$deaths_total)) == 1L)
ms_table(ms_sensitivity, "Persistence changes synthetic histories; the 2024 margin is fixed by calibration")
base::message(base::sprintf("ms-persistence-sensitivity elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
