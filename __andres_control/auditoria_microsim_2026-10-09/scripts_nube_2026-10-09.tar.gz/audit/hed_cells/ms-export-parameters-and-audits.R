#| label: ms-export-parameters-and-audits
.t0 <- Sys.time()
ms_coefficients <- function(model, fit_name) {
  curve_rows <- dplyr::bind_rows(base::lapply(base::c("prevalence", "amount"), function(component) {
    f <- model[[component]]$fit
    if (base::inherits(f, "lm")) base::data.frame(fit = fit_name, component = component,
      parameter = base::names(stats::coef(f)), value = base::unname(stats::coef(f))) else
      dplyr::bind_rows(base::lapply(base::names(f), function(cl) base::data.frame(fit = fit_name,
        component = component, parameter = base::paste0("knot:", cl, ":", ms_cfg$start_year + 10 * f[[cl]]$time),
        value = f[[cl]][[2L]])))
  }))
  dplyr::bind_rows(curve_rows,
    base::data.frame(fit = fit_name, component = "hed", parameter = base::names(stats::coef(model$hed)),
      value = base::unname(stats::coef(model$hed))),
    base::data.frame(fit = fit_name, component = "all_cause_mortality",
      parameter = base::names(model$mortality_scale), value = base::unname(model$mortality_scale))) |>
    dplyr::mutate(spec = model$spec, last_fit_year = model$last_year, drop_2020 = model$drop_2020)
}
ms_parameters <- dplyr::bind_rows(
  base::lapply(ms_cfg$specs, function(s) ms_coefficients(ms_train_models[[s]], base::paste0("train2020_", s))),
  ms_coefficients(ms_reconstruction_model, "reconstruction2024_interp_hold"),
  base::lapply(base::setdiff(ms_projection_specs, "interp_hold"), function(s)
    ms_coefficients(ms_fit(ms_cfg$observed_end, s), base::paste0("refit2024_", s))))
ms_structural_parameters <- base::data.frame(parameter = base::c("rho", "minimum_age", "maximum_age", "n_sim",
  "replicates", "first_seed", "grams_per_drink", "spline_df", "cutoffs", "reconstruction_spec"),
  value = base::c(ms_cfg$rho, 15, 65, ms_cfg$n_sim, base::length(ms_cfg$seeds), ms_cfg$seeds[1], 12, 2,
    base::paste(ms_cfg$cutoffs, collapse = "/"), "interp_hold"),
  interpretation = base::c("Unidentified persistence; sensitivity 0 and 0.95", "Entry at age 15",
    "Exit at age 66; older-age benefits excluded", "Synthetic population scale",
    "Monte Carlo repeats, not parameter uncertainty", "Seeds 2125-2129", "Inherited survey measurement convention",
    "Shared natural spline degrees of freedom", "Rolling-origin fit-through years",
    "Interpolates the seven waves and holds 2024 afterwards"))
ms_table(ms_structural_parameters, "Structural assumptions to discuss with coauthors")
ms_all_sources <- base::unique(base::c(ms_exposure_files, ms_demography_files,
  "__andres_control/microsim_base_ACC_2012_2024.ipynb"))
ms_provenance <- base::data.frame(file = ms_all_sources,
  md5 = base::unname(tools::md5sum(ms_path(ms_all_sources))))
# SIMAH is cited by DOI (not vendored): its own row, without a file hash.
ms_provenance <- base::rbind(ms_provenance, base::data.frame(
  file = "SIMAH release 0.1.1, doi:10.5281/zenodo.15641639", md5 = NA_character_))
if (ms_cfg$export) {
  base::dir.create(here::here(ms_cfg$output_dir), recursive = TRUE, showWarnings = FALSE)
  ms_exports <- base::list(observed_targets = ms_targets, data_audit = ms_data_audit, wave_comparability_audit = ms_wave_audit,
    rolling_origin_comparison = ms_rolling, rolling_origin_metrics = ms_rolling_metrics,
    rolling_origin_by_cutoff = ms_rolling_by_cutoff, sensitivity_2020 = ms_sens_2020,
    holdout2020_by_spec_metrics = ms_holdout_metrics, holdout2020_by_spec_comparison = ms_holdout_long,
    driver_identity_check = ms_driver_identity,
    reconstruction_metrics = ms_reconstruction_metrics, reconstruction_comparison = ms_reconstruction_long,
    mortality_concordance = ms_mortality_comparison, persistence_sensitivity = ms_sensitivity,
    projection_rules = ms_projection,
    projection_mortality_interp_hold = ms_projection_runs$interp_hold$deaths,
    demographic_accounting = ms_projection_runs$interp_hold$flows,
    model_parameters = ms_parameters, structural_parameters = ms_structural_parameters,
    input_provenance = ms_provenance)
  for (name in base::names(ms_exports))
    utils::write.csv(ms_exports[[name]], here::here(ms_cfg$output_dir, base::paste0(name, ".csv")),
      row.names = FALSE, fileEncoding = "UTF-8")
  ggplot2::ggsave(here::here(ms_cfg$output_dir, "rolling_origin_prevalence.png"), ms_fig_rolling, width = 8, height = 5, dpi = 160)
  ggplot2::ggsave(here::here(ms_cfg$output_dir, "reconstruction_prevalence.png"), ms_fig_recon_prevalence, width = 9, height = 8, dpi = 160)
  ggplot2::ggsave(here::here(ms_cfg$output_dir, "reconstruction_intensity.png"), ms_fig_recon_intensity, width = 9, height = 8, dpi = 160)
  ggplot2::ggsave(here::here(ms_cfg$output_dir, "projection_rules.png"), ms_fig_projection, width = 8, height = 5, dpi = 160)
  base::cat("Aggregate outputs saved to ", ms_cfg$output_dir, ". No survey microdata exported.\n", sep = "")
}
base::print(utils::sessionInfo())
base::message(base::sprintf("ms-export-parameters-and-audits elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
