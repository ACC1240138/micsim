#| label: ms-annual-engine
.t0 <- Sys.time()

ms_age_group <- function(age) base::findInterval(age, base::c(15, 30, 45, 60))

ms_new_people <- function(sex, age, n, first_id) {
  # IDs never repeat; latent variables encode explicit annual persistence, not observed histories.
  base::data.frame(id = first_id + base::seq_len(n), sex = sex, age = age,
    z_current = stats::rnorm(n), z_amount = stats::rnorm(n), z_hed = stats::rnorm(n),
    ever = base::rep(NA, n), stringsAsFactors = FALSE)
}

ms_exposure <- function(pop, year, drivers) {
  pop$age_group <- ms_age_group(pop$age)
  k <- base::match(base::paste(year, pop$sex, pop$age_group, sep = ":"), drivers$key)
  base::stopifnot(!base::anyNA(k))
  d <- drivers[k, ]
  pop$current <- stats::pnorm(pop$z_current) < d$p_current
  # The mixture retains observed current drinkers reporting zero g/day.
  u <- stats::pnorm(pop$z_amount)
  positive <- pop$current & u > d$p_zero
  pop$gpd_survey <- 0
  pop$gpd_survey[positive] <- stats::qgamma(
    base::pmin(1 - 1e-12, base::pmax(1e-12,
      (u[positive] - d$p_zero[positive]) / (1 - d$p_zero[positive]))),
    shape = d$shape[positive],
    scale = d$mu_current[positive] / ((1 - d$p_zero[positive]) * d$shape[positive]))
  p_hed <- stats::plogis(d$hed_intercept + d$hed_slope * base::log1p(pop$gpd_survey))
  pop$hed <- positive & stats::pnorm(pop$z_hed) < p_hed
  fresh <- base::is.na(pop$ever)
  pop$ever[fresh] <- pop$current[fresh] |
    stats::runif(base::sum(fresh)) < d$p_ever_noncurrent[fresh]
  pop$ever <- pop$ever | pop$current
  pop$alc_status <- base::ifelse(pop$current, "current", base::ifelse(pop$ever, "former", "never"))
  low <- base::ifelse(pop$sex == "female", 20, 40)
  high <- base::ifelse(pop$sex == "female", 40, 60)
  # Derive categories AFTER continuous exposure. No gaps at 19.99/20 or 39.99/40.
  pop$alc_cat <- base::ifelse(!pop$current, "noncurrent", base::ifelse(pop$gpd_survey < low,
    "cat1", base::ifelse(pop$gpd_survey < high, "cat2", "cat3")))
  base::stopifnot(base::all(base::is.finite(pop$gpd_survey) & pop$gpd_survey >= 0),
                  !base::any(pop$hed & !pop$current), !base::any(pop$current & !pop$ever))
  pop
}

ms_simulate <- function(model, years, n_sim, seed, rho = 0.8) {
  base::stopifnot(base::length(years) > 0, base::all(base::diff(years) == 1),
                  n_sim >= 1000, rho >= 0, rho <= 1)
  base::set.seed(seed)
  drivers <- ms_drivers(model, years)
  stocks <- ms_population[ms_population$year %in% years, ]
  unit_weight <- base::sum(stocks$pop_jan[stocks$year == years[1]]) / n_sim
  stocks$n_target <- base::as.integer(base::round(stocks$pop_jan / unit_weight))
  base::stopifnot(base::all(stocks$n_target > 0))
  initial <- stocks[stocks$year == years[1], ]
  ids <- base::c(0L, base::cumsum(initial$n_target))
  pop <- dplyr::bind_rows(base::lapply(base::seq_len(base::nrow(initial)), function(i)
    ms_new_people(initial$sex[i], initial$age[i], initial$n_target[i], ids[i])))
  last_id <- base::max(pop$id)
  pop <- ms_exposure(pop, years[1], drivers)
  summaries <- deaths_out <- flows <- histories <- base::vector("list", base::length(years))
  trace_ids <- utils::head(pop$id, 12)
  mortality <- ms_mortality
  mortality$key <- base::paste(mortality$year, mortality$sex, mortality$age, sep = ":")

  for (i in base::seq_along(years)) {
    year <- years[i]
    start_n <- base::nrow(pop)
    # A population record describes the beginning of the calendar year, before that year's deaths.
    summaries[[i]] <- pop |>
      dplyr::group_by(sex, age_group) |>
      dplyr::summarise(n = dplyr::n(), current_mean = base::mean(current),
        gpd_mean = base::mean(gpd_survey[current]), gpd_population = base::mean(gpd_survey),
        hed_mean = base::mean(hed[current]), never = base::mean(!ever),
        former = base::mean(ever & !current),
        cat1 = base::mean(alc_cat == "cat1"), cat2 = base::mean(alc_cat == "cat2"),
        cat3 = base::mean(alc_cat == "cat3"), .groups = "drop") |>
      dplyr::mutate(year = year, seed = seed, rho = rho, population = n * unit_weight)
    histories[[i]] <- pop[pop$id %in% trace_ids, base::c("id", "sex", "age", "ever", "current", "alc_status", "gpd_survey", "hed")]
    histories[[i]]$year <- base::rep(year, base::nrow(histories[[i]]))

    # All-cause mortality already includes alcohol-related deaths. Do not apply AAF a second time.
    mortality_year <- base::min(year, ms_cfg$observed_end)
    k <- base::match(base::paste(mortality_year, pop$sex, pop$age, sep = ":"), mortality$key)
    base::stopifnot(!base::anyNA(k))
    q <- -base::expm1(base::log1p(-mortality$qx[k]) * model$mortality_scale[pop$sex])
    base::stopifnot(base::all(q >= 0 & q <= 1))
    dead <- stats::runif(start_n) < q
    deaths_out[[i]] <- base::data.frame(sex = pop$sex, age = pop$age, expected = q, dead = dead) |>
      dplyr::group_by(sex, age) |>
      dplyr::summarise(expected_deaths = base::sum(expected) * unit_weight,
        deaths = base::sum(dead) * unit_weight, mc_variance = base::sum(expected * (1 - expected)) * unit_weight^2,
        .groups = "drop") |>
      dplyr::mutate(year = year, seed = seed)
    deaths_n <- base::sum(dead)
    pop <- pop[!dead, ]
    age_exits <- inflow <- outflow <- age_entries <- 0L
    status_changes <- transition_n <- 0L
    if (i < base::length(years)) {
      # Update real age, retire people crossing the domain limit, then reconcile next January stocks.
      pop$age <- pop$age + 1L
      age_exits <- base::sum(pop$age > ms_cfg$max_age)
      pop <- pop[pop$age <= ms_cfg$max_age, ]
      next_stock <- stocks[stocks$year == year + 1L, ]
      keep <- base::rep(TRUE, base::nrow(pop))
      additions <- base::vector("list", base::nrow(next_stock))
      for (j in base::seq_len(base::nrow(next_stock))) {
        ix <- base::which(pop$sex == next_stock$sex[j] & pop$age == next_stock$age[j])
        delta <- next_stock$n_target[j] - base::length(ix)
        if (delta < 0) {
          # Residual stock reductions are accounting exits, not observed emigration or deaths.
          remove <- ix[base::sample.int(base::length(ix), -delta)]
          keep[remove] <- FALSE
          outflow <- outflow - delta
        } else if (delta > 0) {
          additions[[j]] <- ms_new_people(next_stock$sex[j], next_stock$age[j], delta, last_id)
          last_id <- last_id + delta
          if (next_stock$age[j] == ms_cfg$min_age) age_entries <- age_entries + delta else inflow <- inflow + delta
        }
      }
      pop <- pop[keep, ]
      # ponytail: rho is an unidentified persistence assumption; replace with longitudinal evidence when available.
      # A Gaussian copula supplies annual persistence; marginal targets do not identify rho.
      previous <- pop$current
      transition_n <- base::nrow(pop)
      for (z in base::c("z_current", "z_amount", "z_hed"))
        pop[[z]] <- rho * pop[[z]] + base::sqrt(1 - rho^2) * stats::rnorm(transition_n)
      pop <- ms_exposure(pop, year + 1L, drivers)
      status_changes <- base::sum(pop$current != previous)
      new <- dplyr::bind_rows(additions)
      if (base::nrow(new)) pop <- dplyr::bind_rows(pop, ms_exposure(new, year + 1L, drivers))
      base::stopifnot(!base::anyDuplicated(pop$id),
        base::nrow(pop) == start_n - deaths_n - age_exits - outflow + age_entries + inflow)
      actual <- base::table(base::factor(base::paste(pop$sex, pop$age),
        levels = base::paste(next_stock$sex, next_stock$age)))
      base::stopifnot(base::all(base::as.integer(actual) == next_stock$n_target))
    }
    flows[[i]] <- base::data.frame(year = year, seed = seed, start = start_n, deaths = deaths_n,
      age_exits = age_exits, age_entries = age_entries, residual_inflow = inflow,
      residual_outflow = outflow, end = base::nrow(pop), status_changes = status_changes,
      transition_n = transition_n, unit_weight = unit_weight,
      end_definition = if (i < base::length(years)) "Next January stock" else "Terminal-year survivors")
  }
  base::list(summary = dplyr::bind_rows(summaries), deaths = dplyr::bind_rows(deaths_out),
    flows = dplyr::bind_rows(flows), histories = dplyr::bind_rows(histories),
    parameters = base::list(seed = seed, rho = rho, n_sim = n_sim, model_last_year = model$last_year))
}
base::message(base::sprintf("ms-annual-engine elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
