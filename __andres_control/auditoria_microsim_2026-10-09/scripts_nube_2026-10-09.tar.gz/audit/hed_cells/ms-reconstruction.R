#| label: ms-reconstruction
.t0 <- Sys.time()
ms_reconstruction_model <- ms_fit(ms_cfg$observed_end, "interp_hold")
base::stopifnot(base::setequal(ms_reconstruction_model$training_years, ms_wave_years))
ms_reconstruction_runs <- base::lapply(ms_cfg$seeds, function(seed)
  ms_simulate(ms_reconstruction_model, 2012:2024, ms_cfg$n_sim, seed, ms_cfg$rho))
ms_reconstruction_summary <- dplyr::bind_rows(base::lapply(ms_reconstruction_runs, `[[`, "summary"))
ms_reconstruction_deaths <- dplyr::bind_rows(base::lapply(ms_reconstruction_runs, `[[`, "deaths"))
ms_reconstruction_cells <- ms_reconstruction_summary |>
  dplyr::group_by(year, sex, age_group) |>
  dplyr::summarise(current_mc_sd = stats::sd(current_mean), gpd_mc_sd = stats::sd(gpd_mean),
    hed_mc_sd = stats::sd(hed_mean), current_mean = base::mean(current_mean),
    gpd_mean = base::mean(gpd_mean), hed_mean = base::mean(hed_mean), .groups = "drop") |>
  dplyr::inner_join(ms_targets, by = base::c("year", "sex", "age_group"), suffix = base::c("_simulated", "_observed"))
base::stopifnot(base::nrow(ms_reconstruction_cells) == 56L)
ms_reconstruction_long <- dplyr::bind_rows(base::lapply(base::c("current", "gpd", "hed"), function(m)
  base::data.frame(year = ms_reconstruction_cells$year, sex = ms_reconstruction_cells$sex,
    age_group = ms_reconstruction_cells$age_group, metric = m,
    observed = ms_reconstruction_cells[[base::paste0(m, "_mean_observed")]],
    simulated = ms_reconstruction_cells[[base::paste0(m, "_mean_simulated")]],
    se = ms_reconstruction_cells[[base::paste0(m, "_se")]],
    mc_sd = ms_reconstruction_cells[[base::paste0(m, "_mc_sd")]],
    design_status = ms_reconstruction_cells$design_status))) |>
  dplyr::mutate(error = simulated - observed, standardized_error = error / se,
    in_working_interval = base::ifelse(year == 2020L, NA, base::abs(error) <= stats::qnorm(0.975) * se))
ms_reconstruction_metrics <- ms_reconstruction_long |>
  dplyr::group_by(metric) |>
  dplyr::summarise(cells = dplyr::n(), bias = base::mean(error), rmse = base::sqrt(base::mean(error^2)),
    mae = base::mean(base::abs(error)), working_interval_coverage = base::mean(in_working_interval, na.rm = TRUE),
    mean_monte_carlo_sd = base::mean(mc_sd), .groups = "drop") |>
  dplyr::mutate(interpretation = "Seven-wave calibration reproduced by the engine; not held-out validation")
ms_table(ms_reconstruction_metrics, "Reconstruction fit 2012-2024: proportions for prevalence/HED, g/day for intensity")
ms_plot <- function(d, title, y_label, caption) {
  d$age_band <- base::factor(d$age_group, levels = 1:4, labels = base::c("15-29", "30-44", "45-59", "60-65"))
  ggplot2::ggplot(d, ggplot2::aes(year)) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = observed - 1.96 * se, ymax = observed + 1.96 * se),
      data = d[d$year != 2020L, ], width = 0.15, colour = "grey50") +
    ggplot2::geom_point(ggplot2::aes(y = observed, colour = "ENPG"), size = 1.6) +
    ggplot2::geom_line(ggplot2::aes(y = simulated, colour = "Simulation"), linewidth = 0.6) +
    ggplot2::facet_grid(age_band ~ sex, scales = "free_y") +
    ggplot2::scale_colour_manual(values = base::c(ENPG = "#222222", Simulation = "#0072B2")) +
    ggplot2::labs(title = title, x = "Year", y = y_label, colour = NULL, caption = caption) +
    ggplot2::theme_minimal(base_size = 11) + ggplot2::theme(legend.position = "bottom")
}
ms_caption_recon <- "Seven-wave interp_hold calibration; five-seed mean. Bars: working-design 95% intervals, omitted for 2020."
ms_fig_recon_prevalence <- ms_plot(ms_reconstruction_long[ms_reconstruction_long$metric == "current", ],
  "Reconstruction: past-30-day drinking prevalence", "Proportion", ms_caption_recon)
ms_fig_recon_intensity <- ms_plot(ms_reconstruction_long[ms_reconstruction_long$metric == "gpd", ],
  "Reconstruction: survey-scale intensity among current drinkers", "Grams/day", ms_caption_recon)
ms_fig_recon_hed <- ms_plot(ms_reconstruction_long[ms_reconstruction_long$metric == "hed", ],
  "Reconstruction: HED among current drinkers (secondary diagnostic)", "Proportion", ms_caption_recon)
base::print(ms_fig_recon_prevalence)
base::print(ms_fig_recon_intensity)
base::print(ms_fig_recon_hed)
base::message(base::sprintf("ms-reconstruction elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
