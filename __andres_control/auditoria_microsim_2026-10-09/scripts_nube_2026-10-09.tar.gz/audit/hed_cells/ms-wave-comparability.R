#| label: ms-wave-comparability
#| results: "hold"
.t0 <- Sys.time()
# Comparability signals computable from the files in hand. Wording, mode, fieldwork and response rates are not.
ms_wave_audit <- base::do.call(base::rbind, base::lapply(ms_wave_years, function(y) {
  x <- ms_enpg[ms_enpg$year == y, ]
  ine <- ms_population[ms_population$year == y, ]
  ine$age_group <- base::findInterval(ine$age, base::c(15, 30, 45, 60))
  ine_share <- stats::aggregate(pop_mid ~ sex + age_group, ine, base::sum)
  ine_share$share <- ine_share$pop_mid / base::sum(ine_share$pop_mid)
  svy_share <- stats::aggregate(weight ~ sex + age_group, x, base::sum)
  svy_share$share <- svy_share$weight / base::sum(svy_share$weight)
  m <- base::merge(ine_share, svy_share, by = base::c("sex", "age_group"))
  base::stopifnot(base::nrow(m) == 8L)
  cur <- x$status == "current"
  base::data.frame(year = y, n = base::nrow(x),
    unknown_status_pct = 100 * base::mean(x$status == "unknown"),
    gpd_missing_pct_current = 100 * base::mean(base::is.na(x$gpd_survey[cur])),
    hed_missing_pct_current = 100 * base::mean(base::is.na(x$hed[cur])),
    weight_cv = stats::sd(x$weight) / base::mean(x$weight),
    n_eff_ratio = base::sum(x$weight)^2 / base::sum(x$weight^2) / base::nrow(x),
    weighted_pop_15_65 = base::sum(x$weight), ine_pop_15_65_mid = base::sum(ine$pop_mid),
    coverage_ratio = base::sum(x$weight) / base::sum(ine$pop_mid),
    max_sex_age_share_gap_pp = 100 * base::max(base::abs(m$share.x - m$share.y)),
    weighted_male_pct = 100 * stats::weighted.mean(x$sex == "male", x$weight),
    design_status = base::unique(x$design_status))
}))
base::stopifnot(base::nrow(ms_wave_audit) == 7L, !base::anyNA(ms_wave_audit))
ms_wave_pending <- base::data.frame(
  item = base::c("Drinking/HED questionnaire wording by wave", "Survey mode (face-to-face, telephone, mixed)",
    "Fieldwork dates and pandemic timing", "Response rates and non-response adjustment"),
  status = "Not in project files; request SENDA methodological reports before attributing the 2022/2024 drop")
ms_table(ms_wave_audit, "Per-wave comparability signals; composition gaps use INE June stocks")
ms_table(ms_wave_pending, "Comparability items that cannot be audited from the data in hand")
base::message(base::sprintf("ms-wave-comparability elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
