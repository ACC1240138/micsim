#| label: ms-mortality-concordance
.t0 <- Sys.time()
ms_mortality_comparison <- ms_reconstruction_deaths |>
  dplyr::group_by(year, sex, seed) |>
  dplyr::summarise(simulated_deaths = base::sum(deaths), expected_deaths = base::sum(expected_deaths),
    .groups = "drop") |>
  dplyr::group_by(year, sex) |>
  dplyr::summarise(mc_sd = stats::sd(simulated_deaths),
    simulated_deaths = base::mean(simulated_deaths),
    expected_deaths = base::mean(expected_deaths), .groups = "drop") |>
  dplyr::left_join(ms_mortality |>
    dplyr::group_by(year, sex) |>
    dplyr::summarise(observed_deaths = base::sum(deaths),
      hmd_mx_expected = base::sum(mx * pop_mid), .groups = "drop"), by = base::c("year", "sex")) |>
  dplyr::mutate(expected_relative_error = expected_deaths / observed_deaths - 1)
ms_table(ms_mortality_comparison, "DEIS concordance for the seven-wave reconstruction; multiplier calibrated on 2012-2024")
base::stopifnot(base::all(base::is.finite(ms_mortality_comparison$mc_sd)))
ms_mortality_mc <- ms_reconstruction_deaths |>
  dplyr::group_by(seed) |>
  dplyr::summarise(realized = base::sum(deaths), expected = base::sum(expected_deaths),
    conditional_sd = base::sqrt(base::sum(mc_variance)), .groups = "drop") |>
  dplyr::mutate(z_mc = (realized - expected) / conditional_sd)
ms_table(ms_mortality_mc, "Monte Carlo death diagnostic; not a test of epidemiological validity")
ms_table(base::data.frame(sex = base::names(ms_reconstruction_model$mortality_scale),
  hazard_multiplier = base::unname(ms_reconstruction_model$mortality_scale)), "Mortality multipliers, DEIS 2012-2024")
base::message(base::sprintf("ms-mortality-concordance elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
