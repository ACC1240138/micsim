#| label: ms-holdout-2020-by-spec
.t0 <- Sys.time()
ms_holdout_runs <- base::lapply(ms_cfg$specs, function(spec) base::lapply(ms_cfg$seeds, function(seed)
  ms_simulate(ms_train_models[[spec]], 2012:2024, ms_cfg$n_sim, seed, ms_cfg$rho)))
base::names(ms_holdout_runs) <- ms_cfg$specs
ms_holdout_summary <- dplyr::bind_rows(base::lapply(ms_cfg$specs, function(spec)
  dplyr::bind_rows(base::lapply(ms_holdout_runs[[spec]], `[[`, "summary")) |> dplyr::mutate(spec = spec)))
ms_holdout_cells <- ms_holdout_summary |>
  dplyr::group_by(spec, year, sex, age_group) |>
  dplyr::summarise(current_mc_sd = stats::sd(current_mean), gpd_mc_sd = stats::sd(gpd_mean),
    hed_mc_sd = stats::sd(hed_mean), current_mean = base::mean(current_mean),
    gpd_mean = base::mean(gpd_mean), hed_mean = base::mean(hed_mean), n_pooled = base::sum(n), .groups = "drop") |>
  dplyr::inner_join(ms_targets, by = base::c("year", "sex", "age_group"), suffix = base::c("_simulated", "_observed"))
base::stopifnot(base::nrow(ms_holdout_cells) == 56L * base::length(ms_cfg$specs))
# Driver identity: pooled-seed cell prevalence must match the driver value within binomial Monte Carlo noise.
# Cells differ in size (60-65 is six ages), so the tolerance is a z-score, not a fixed gap.
ms_driver_identity <- dplyr::bind_rows(base::lapply(ms_cfg$specs, function(spec) {
  d <- ms_drivers(ms_train_models[[spec]], 2012:2024)
  s <- ms_holdout_cells[ms_holdout_cells$spec == spec, ]
  k <- base::match(base::paste(s$year, s$sex, s$age_group, sep = ":"), d$key)
  gap <- s$current_mean_simulated - d$p_current[k]
  z <- gap / base::sqrt(d$p_current[k] * (1 - d$p_current[k]) / s$n_pooled)
  base::data.frame(spec = spec, cells = base::length(gap), max_abs_gap_current = base::max(base::abs(gap)),
    mean_abs_gap_current = base::mean(base::abs(gap)), max_abs_z = base::max(base::abs(z)),
    mean_squared_z = base::mean(z^2), max_abs_gap_gpd = base::max(base::abs(s$gpd_mean_simulated - d$mu_current[k])))
}))
ms_table(ms_driver_identity, "Driver identity check: engine margins reproduce driver curves (binomial z over pooled seeds)")
base::stopifnot(base::all(ms_driver_identity$max_abs_z < 5), base::all(ms_driver_identity$mean_squared_z < 2))
ms_holdout_long <- dplyr::bind_rows(base::lapply(base::c("current", "gpd", "hed"), function(m)
  base::data.frame(spec = ms_holdout_cells$spec, year = ms_holdout_cells$year, sex = ms_holdout_cells$sex,
    age_group = ms_holdout_cells$age_group, metric = m,
    observed = ms_holdout_cells[[base::paste0(m, "_mean_observed")]],
    simulated = ms_holdout_cells[[base::paste0(m, "_mean_simulated")]],
    se = ms_holdout_cells[[base::paste0(m, "_se")]], mc_sd = ms_holdout_cells[[base::paste0(m, "_mc_sd")]]))) |>
  dplyr::mutate(error = simulated - observed,
    period = base::ifelse(year <= ms_cfg$train_end, "Training 2012-2020", "Post-cutoff 2022/2024"),
    in_working_interval = base::ifelse(year == 2020L, NA, base::abs(error) <= stats::qnorm(0.975) * se))
ms_holdout_metrics <- ms_holdout_long |>
  dplyr::group_by(spec, period, metric) |>
  dplyr::summarise(cells = dplyr::n(), bias = base::mean(error), rmse = base::sqrt(base::mean(error^2)),
    working_interval_coverage = base::mean(in_working_interval, na.rm = TRUE),
    mean_monte_carlo_sd = base::mean(mc_sd), .groups = "drop") |>
  dplyr::arrange(period, metric, rmse)
ms_table(ms_holdout_metrics[ms_holdout_metrics$period == "Post-cutoff 2022/2024", ],
  "Engine-based 2022/2024 comparison by specification, fitted through 2020, five seeds")
ms_table(ms_holdout_metrics[ms_holdout_metrics$period == "Training 2012-2020", ],
  "Training-period fit by specification (in-sample for all but static2012)")
# 2020 sensitivity: same rolling-origin evaluation with the 2020 wave dropped from consumption fits.
ms_sens_2020 <- ms_rolling |>
  dplyr::filter(cutoff >= 2020L, horizon_waves == 1L) |>
  dplyr::group_by(spec, cutoff, target_year = year, drop_2020) |>
  dplyr::summarise(current_rmse_pp = 100 * base::sqrt(base::mean(current_error^2)),
    current_bias_pp = 100 * base::mean(current_error), .groups = "drop") |>
  dplyr::mutate(wave2020 = base::ifelse(drop_2020, "without2020", "with2020"), drop_2020 = NULL) |>
  tidyr::pivot_wider(names_from = wave2020, values_from = c(current_rmse_pp, current_bias_pp),  # tidyselect helper, not base::c
    names_glue = "{.value}_{wave2020}") |>
  dplyr::arrange(target_year, current_rmse_pp_with2020)
ms_table(ms_sens_2020, "2020 sensitivity: one-wave-ahead prevalence error with and without the 2020 wave")
base::message(base::sprintf("ms-holdout-2020-by-spec elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))
