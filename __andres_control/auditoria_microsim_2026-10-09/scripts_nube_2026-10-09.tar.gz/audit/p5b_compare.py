"""Step 5 support: engine prototype never/former by wave x sex x age group vs ENPG (aggregates only)."""
import pandas as pd, numpy as np
OUT = "<scratch>/audit/out"
c = pd.read_csv(f"{OUT}/p5_engine_proto_cells.csv")
t = pd.read_csv(f"{OUT}/enpg_targets_wave_sex_agegroup.csv")
c["age_grp"] = c.age_group.map({1: "15-29", 2: "30-44", 3: "45-59", 4: "60-65"})
rows = []
for v, tv in [("never", "never"), ("former", "former_any")]:
    y = t[t.variable == tv][["year", "sex", "age_grp", "estimate", "se"]]
    m = c.merge(y, on=["year", "sex", "age_grp"])
    m["dev_pp"] = 100 * (m[v] - m.estimate)
    for (run, wset), d in m.assign(wset=np.where(m.year.isin([2012, 2024]), "2012+2024", "2014-2022")).groupby(["run", "wset"]):
        rows.append(dict(metric=v, run=run, waves=wset, cells=len(d), mean_dev_pp=d.dev_pp.mean(),
                         mean_abs_dev_pp=d.dev_pp.abs().mean(), max_abs_dev_pp=d.dev_pp.abs().max(),
                         share_within_5pp=(d.dev_pp.abs() <= 5).mean()))
r = pd.DataFrame(rows); r.to_csv(f"{OUT}/p5b_engine_vs_enpg_summary.csv", index=False)
pd.set_option("display.width", 250); print(r.round(2).to_string())
