# 06_population_vintages.R -- denominator sensitivity: INE CPV-2024 base (ine_basedatos.xlsx, used by the engine)
# vs the older INE workbook ine_proyecciones_2012_2024.xlsx vs HMD implied exposure, ages 15-65.
.t0 <- Sys.time()
library(data.table)
INE <- "<repo>/__andres_control/ine_proyecciones_rebuild"
AUD <- "<scratch>/audit"
old <- rbindlist(lapply(c(male = "Hombres", female = "Mujeres"), function(s) {
  z <- as.data.table(readxl::read_xlsx(file.path(INE, "ine_proyecciones_2012_2024.xlsx"), sheet = s))
  z[, age := suppressWarnings(as.integer(as.numeric(edad)))]
  melt(z[age %in% 15:65], id.vars = c("edad", "age"), variable.name = "y", value.name = "pop")[, .(year = as.integer(sub("ano_", "", y)), age, pop)]
}), idcol = "sex")
new <- fread(file.path(AUD, "agg", "ine_pop_2012_2025.csv"))[age %in% 15:65 & year <= 2024]
dr  <- fread(file.path(AUD, "out_A1_drift_year_sex.csv"))
v <- merge(merge(old[, .(pop_old_workbook = sum(pop)), by = .(year, sex)],
                 new[, .(pop_jan_cpv2024 = sum(pop_jan), pop_mid_cpv2024 = sum(pop_mid)), by = .(year, sex)], by = c("year", "sex")),
           dr[, .(year, sex, hmd_implied_exposure, deis)], by = c("year", "sex"))
v[, `:=`(old_vs_mid = pop_old_workbook / pop_mid_cpv2024 - 1, hmd_vs_mid = hmd_implied_exposure / pop_mid_cpv2024 - 1,
         hmd_vs_old = hmd_implied_exposure / pop_old_workbook - 1)]
print(v[, .(year, sex, old_vs_mid = round(old_vs_mid, 4), hmd_vs_mid = round(hmd_vs_mid, 4), hmd_vs_old = round(hmd_vs_old, 4))])
fwrite(v, file.path(AUD, "out_A4_population_vintages.csv"))
message(sprintf("06_population_vintages elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
