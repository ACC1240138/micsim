"""Step 4: simulate the trait + AR(1) latent participation model on a lambda x phi grid (no microdata).

z = sqrt(lam) u + sqrt(1 - lam) a,  a: AR(1) with annual phi, simulated MONTHLY (phi_m = phi**(1/12)),
drinking in a month  <=>  Phi(z) < p30(age, sex)  (same rule as the engine's ms_exposure, 30-day prevalence).
A synthetic cohort enters at 15 and is followed to 65. Quantities comparable with ENPG:
  never (lifetime), former > 12 months, 12-month vs 30-day intermittency, annual switching.
'never_annual' reproduces the engine rule (ever updated only at the yearly snapshot) and is an upper bound.
Inputs: aggregated ENPG CSVs written by p3_enpg_targets.R. Output: out/p4_grid.csv.
"""
import time, sys
import numpy as np, pandas as pd
from scipy.stats import norm

t0 = time.time()
OUT = "<scratch>/audit/out"
pool = pd.read_csv(f"{OUT}/enpg_pooled_sex_agefine.csv")
retro = pd.read_csv(f"{OUT}/enpg_retrospective_ever_by_age_cohort.csv")
mid = {"15-17": 16, "18-20": 19, "21-24": 22.5, "25-29": 27.5, "30-34": 32.5, "35-39": 37.5, "40-44": 42.5,
       "45-49": 47.5, "50-54": 52.5, "55-59": 57.5, "60-65": 63}
BANDS = {"30-34": (30, 34), "45-49": (45, 49), "60-65": (60, 65)}
AGES = np.arange(15, 66)

def p30_profile(sex):
    x = pool[(pool.variable == "cur30") & (pool.sex == sex)].copy()
    x["m"] = x.age_fine.map(mid); x = x.sort_values("m")
    return 1 / (1 + np.exp(-np.interp(AGES, x.m, np.log(x.estimate / (1 - x.estimate)))))

def never15(sex):
    # Entry never share at exact age 15 = 1 - ever by 15, recent cohorts (retrospective OH_3, born 1990-2004).
    r = retro[(retro.sex == sex) & (retro.age == 15) & retro.cohort.isin(["1990-1994", "1995-1999", "2000-2004"])]
    return 1 - r.ever_by_age.mean()

def targets(sex):
    out = {}
    for v in ["never", "former12", "not30_given12"]:
        x = pool[(pool.variable == v) & (pool.sex == sex)].set_index("age_fine").estimate
        for b in BANDS: out[f"{v}_{b}"] = x[b]
    return out

def simulate(lam, phi, sex, n=100_000, seed=1, init="latent", stayer=0.0):
    rng = np.random.default_rng(seed)
    p = p30_profile(sex); thr_all = norm.ppf(np.clip(p / (1 - stayer), 1e-9, 1 - 1e-9))
    phm = phi ** (1 / 12); sd_e = np.sqrt(1 - phm ** 2)
    u = rng.standard_normal(n); a = rng.standard_normal(n)
    mover = rng.random(n) >= stayer          # stayers never drink (mover-stayer variant only)
    z = np.sqrt(lam) * u + np.sqrt(1 - lam) * a
    d0 = (z < thr_all[0]) & mover
    nev0 = never15(sex)
    noncur = ~d0
    k = int(round(nev0 * n))                 # number of never drinkers at entry
    if init == "latent":                     # the never are the non-current furthest from the threshold
        score = np.where(noncur, z + np.where(mover, 0, 1e6), -np.inf)
        never = np.zeros(n, bool); never[np.argsort(-score)[:k]] = True
    else:                                    # engine rule: random among the non-current
        idx = np.flatnonzero(noncur); never = np.zeros(n, bool); never[rng.choice(idx, k, replace=False)] = True
    never_ann = never.copy(); last12 = np.zeros((12, n), bool); last12[0] = d0
    rows, prev_snap = [], d0
    for ai, age in enumerate(AGES):
        thr = thr_all[ai]
        for m in range(12):
            if ai == 0 and m == 0:
                d = d0
            else:
                a = phm * a + sd_e * rng.standard_normal(n)
                z = np.sqrt(lam) * u + np.sqrt(1 - lam) * a
                d = (z < thr) & mover
                last12 = np.roll(last12, 1, axis=0); last12[0] = d
            never &= ~d
            if m == 0:                       # yearly snapshot = survey/engine time point
                never_ann &= ~d
                m12 = last12.any(axis=0)
                rows.append(dict(age=age, cur30=d.mean(), m12=m12.mean(), never=never.mean(),
                    never_annual=never_ann.mean(), former12=((~never) & ~m12).mean(),
                    not30_given12=(m12 & ~d).sum() / max(m12.sum(), 1),
                    switch_annual=(d != prev_snap).mean() if ai > 0 else np.nan))
                prev_snap = d
    return pd.DataFrame(rows)

def summarise(df, lam, phi, sex, init, stayer):
    out = dict(sex=sex, lam=lam, phi=phi, init=init, stayer=stayer, r1y=lam + (1 - lam) * phi,
               switch_annual_mean=df.switch_annual.mean())
    for b, (lo, hi) in BANDS.items():
        s = df[(df.age >= lo) & (df.age <= hi)]
        for v in ["never", "never_annual", "former12", "not30_given12", "cur30"]:
            out[f"{v}_{b}"] = s[v].mean()
    return out

if __name__ == "__main__":
    lams = [0.0, 0.3, 0.45, 0.6]; phis = [0.6, 0.7, 0.8, 0.9]
    extra = [(0.45, 0.68), (0.5, 0.68)]
    res = []
    for sex in ["male", "female"]:
        for lam, phi in [(l, f) for l in lams for f in phis] + extra:
            for init in ["latent", "engine_random"]:
                res.append(summarise(simulate(lam, phi, sex, init=init), lam, phi, sex, init, 0.0))
        print(sex, "done", round(time.time() - t0, 1), "s", flush=True)
    res = pd.DataFrame(res)
    for sex in ["male", "female"]:
        for k, v in targets(sex).items(): res.loc[res.sex == sex, "target_" + k] = v
    res.to_csv(f"{OUT}/p4_grid.csv", index=False)
    # self-check: the 30-day margin is reproduced by construction (threshold rule), within MC error
    p = {s: p30_profile(s) for s in ["male", "female"]}
    print("max |cur30 - target| (30-34 band):",
          max(abs(r["cur30_30-34"] - p[r["sex"]][15:20].mean()) for _, r in res.iterrows()))
    print(f"p4_grid elapsed minutes: {(time.time() - t0) / 60:.2f}")
