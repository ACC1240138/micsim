# HED hooks on top of 00_load_engine.R. The notebook engine cell is re-parsed with ONE substituted line (p_hed);
# ms_drivers gets an override hook. Nothing else in the engine changes.
#   HED_MODE "log"  = notebook link plogis(a_cell + b * log1p(gpd))  (a can be overridden per cell or cell x wave)
#            "rank" = plogis(a + b * qlogis(volume rank v)), v = rank of the engine's own g/day draw
#            "bins" = observed HED rate by within-cell volume-rank decile (pooled waves), logit-shifted by a
run_cell("ms-annual-engine", list(list(
  "p_hed <- stats::plogis(d$hed_intercept + d$hed_slope * base::log1p(pop$gpd_survey))",
  "p_hed <- hed_prob(d, u, pop$gpd_survey)")))
HED_MODE <- "log"
hed_prob <- function(d, u, gpd) {
  v <- base::pmin(1 - 1e-12, base::pmax(1e-12, (u - d$p_zero) / (1 - d$p_zero)))
  if (HED_MODE == "log") return(stats::plogis(d$hed_intercept + d$hed_slope * base::log1p(gpd)))
  if (HED_MODE == "rank") return(stats::plogis(d$hed_intercept + d$hed_slope * stats::qlogis(v)))
  r <- HED_BINS[base::cbind(base::match(base::as.character(d$cell), base::rownames(HED_BINS)), base::pmin(10L, 1L + base::floor(10 * v)))]
  stats::plogis(stats::qlogis(r) + d$hed_intercept)
}
ms_drivers_nb <- ms_drivers
# model$hed_tab (cell[, year], a) replaces the intercept (linear interpolation between waves, held outside);
# model$hed_slope_override replaces the slope.
ms_drivers <- function(model, years) {
  g <- ms_drivers_nb(model, years)
  if (!is.null(model$hed_slope_override)) g$hed_slope <- model$hed_slope_override
  if (!is.null(model$hed_tab)) {
    g$hed_intercept <- vapply(seq_len(nrow(g)), function(i) {
      t <- model$hed_tab[model$hed_tab$cell == as.character(g$cell[i]), ]
      if (nrow(t) == 1L) t$a else stats::approx(t$year, t$a, xout = g$year[i], rule = 2)$y
    }, numeric(1))
  }
  g
}

E_log <- function(a, mu, shape, p0, b) {
  sc <- mu / ((1 - p0) * shape)
  f <- function(g) stats::plogis(a + b * log1p(g)) * stats::dgamma(g, shape = shape, scale = sc)
  # Split at the mean: a Gamma with shape < 1 has an integrable spike at 0.
  (1 - p0) * (stats::integrate(f, 0, mu, rel.tol = 1e-8)$value + stats::integrate(f, mu, Inf, rel.tol = 1e-8)$value)
}
# Logit space (t = qlogis(v), dv = dlogis(t) dt) keeps the integrand finite.
E_rank <- function(a, b, p0) (1 - p0) * stats::integrate(function(t) stats::plogis(a + b * t) * stats::dlogis(t), -Inf, Inf, rel.tol = 1e-8)$value
solve_a <- function(fun, target) stats::uniroot(function(a) fun(a) - target, c(-30, 30), tol = 1e-10)$root

# All HED variants estimated from waves <= last_year only. Sets HED_BINS globally (used by hed_prob).
build_hed_variants <- function(last_year) {
  base_model <- ms_fit(last_year, "interp_hold")
  b_log <- unname(stats::coef(base_model$hed)["base::log1p(gpd_survey)"])
  tg <- ms_targets[ms_targets$year <= last_year, ]
  tg$cell <- paste(tg$sex, tg$age_group, sep = ":")
  tg <- merge(tg, ms_drivers_nb(base_model, sort(unique(tg$year)))[c("year", "cell", "mu_current", "shape", "p_zero")], by = c("year", "cell"))
  tabA <- do.call(rbind, lapply(split(tg, tg$cell), function(z) data.frame(cell = z$cell[1],
    a = solve_a(function(a) mean(mapply(E_log, a, z$mu_current, z$shape, z$p_zero, b_log)), mean(z$hed_mean)))))
  tabB <- do.call(rbind, lapply(seq_len(nrow(tg)), function(i) data.frame(cell = tg$cell[i], year = tg$year[i],
    a = solve_a(function(a) E_log(a, tg$mu_current[i], tg$shape[i], tg$p_zero[i], b_log), tg$hed_mean[i]))))
  stopifnot(max(abs(mapply(function(a, i) E_log(a, tg$mu_current[i], tg$shape[i], tg$p_zero[i], b_log),
    tabB$a, seq_len(nrow(tg))) - tg$hed_mean)) < 1e-6)
  # Weighted rank of observed g/day among current drinkers within cell x wave: mid-rank (glm) and randomized PIT (deciles).
  x <- ms_enpg[ms_enpg$year <= last_year & ms_enpg$status == "current" & is.finite(ms_enpg$gpd_survey), ]
  x$cell <- factor(paste(x$sex, x$age_group, sep = ":"), levels = base_model$cells)
  x$u <- x$u_r <- NA_real_
  set.seed(20261009)
  for (k in split(seq_len(nrow(x)), list(x$year, x$cell), drop = TRUE)) {
    g <- x$gpd_survey[k]; w <- x$weight[k]
    below <- vapply(g, function(v) sum(w[g < v]), numeric(1)); tied <- vapply(g, function(v) sum(w[g == v]), numeric(1))
    x$u[k] <- (below + 0.5 * tied) / sum(w)
    x$u_r[k] <- (below + stats::runif(length(k)) * tied) / sum(w)
  }
  stopifnot(all(x$u > 0 & x$u < 1))
  hd <- x[!is.na(x$hed) & x$gpd_survey > 0, ]
  hd$w_fit <- hd$weight / mean(hd$weight)
  hd$qu <- stats::qlogis(hd$u)
  rank_glm <- stats::glm(hed ~ 0 + cell + qu, data = hd, weights = w_fit, family = stats::quasibinomial())
  stopifnot(rank_glm$converged)
  cf <- stats::coef(rank_glm)
  b_rank <- unname(cf["qu"])
  tabC <- data.frame(cell = sub("^cell", "", names(cf)[-length(cf)]), a = unname(cf[-length(cf)]))
  tabD <- do.call(rbind, lapply(seq_len(nrow(tg)), function(i) data.frame(cell = tg$cell[i], year = tg$year[i],
    a = solve_a(function(a) E_rank(a, b_rank, tg$p_zero[i]), tg$hed_mean[i]))))
  hd$dec <- pmin(10L, 1L + floor(10 * hd$u_r))
  HED_BINS <<- with(hd, tapply(seq_along(hed), list(as.character(cell), dec), function(k) stats::weighted.mean(hed[k], weight[k])))
  stopifnot(!anyNA(HED_BINS), all(HED_BINS < 1))
  E_bins <- function(delta, cl, p0) (1 - p0) * mean(stats::plogis(stats::qlogis(HED_BINS[cl, ]) + delta))
  tabE <- do.call(rbind, lapply(seq_len(nrow(tg)), function(i) data.frame(cell = tg$cell[i], year = tg$year[i],
    a = solve_a(function(a) E_bins(a, tg$cell[i], tg$p_zero[i]), tg$hed_mean[i]))))
  tab0 <- data.frame(cell = sub("^cell", "", names(stats::coef(base_model$hed))[1:8]), a = unname(stats::coef(base_model$hed)[1:8]))
  list(base_model = base_model, b_log = b_log, b_rank = b_rank, tg = tg, hd = hd, E_bins = E_bins,
    tabs = list(base = tab0, A_cell = tabA, B_wave = tabB, C_rank = tabC, D_rank_wave = tabD, E_bins_wave = tabE),
    variants = list(
      base = list(model = base_model, mode = "log"),
      A_cell = list(model = within(base_model, hed_tab <- tabA), mode = "log"),
      B_wave = list(model = within(base_model, hed_tab <- tabB), mode = "log"),
      C_rank = list(model = within(base_model, {hed_tab <- tabC; hed_slope_override <- b_rank}), mode = "rank"),
      D_rank_wave = list(model = within(base_model, {hed_tab <- tabD; hed_slope_override <- b_rank}), mode = "rank"),
      E_bins_wave = list(model = within(base_model, hed_tab <- tabE), mode = "bins")))
}
