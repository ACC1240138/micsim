.t0 <- Sys.time()
# Real-data checks for the RR bridge (ENPG microdata via acc_data(); only AGGREGATES are written).
#  A. Scale identity: microsim gpd_survey x factor_CH[year] reproduces the expand_pif gamma inputs (2024).
#  B. HED identity: microsim hed (episodes > 0 | gpd > 0) reproduces expand_pif p_hed (2024).
#  C. Former-drinker composition: ">30 days" (last drink 31 d - 12 m) vs ">1 year", all waves, 15-65.
#  D. AAF impact (2024, from the saved bundle) if ">30 days" were treated as WHO current drinkers at ~0 g/day.
# Run: Rscript --vanilla rr_bridge_data_checks.R
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>/__andres_control")   # acc_root() resolves the project from getwd()
audit_dir <- "<scratch>/audit"
ctrl <- "<repo>/__andres_control"
source(file.path("<repo>", "_tools", "acc_data.R"))
raw <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS"))   # decrypted into tempdir()
fac <- utils::read.csv(file.path(ctrl, "oms_factor_by_year.csv"))
inp <- readRDS(file.path(ctrl, "aaf_engine_inputs_bundle_20261007.rds"))$exposure_inputs

d <- data.frame(year = as.integer(raw$year), sexo = as.character(raw$sexo), edad = as.numeric(raw$edad),
                w = as.numeric(raw$exp), oh1 = as.character(raw$oh1), oh2 = as.character(raw$oh2),
                oh3 = as.numeric(haven::zap_labels(raw$oh3)), db = as.numeric(haven::zap_labels(raw$db)),
                audit2 = as.character(raw$audit2), stringsAsFactors = FALSE)
rm(raw)
d <- d[d$edad >= 15 & d$edad <= 65, ]
d$tramo <- findInterval(d$edad, c(15, 30, 45, 60))
d$status <- ifelse(d$oh1 == "No" & is.na(d$oh2), "never",
             ifelse(d$oh1 == "Si" & d$oh2 %in% "30 dias", "current",
             ifelse(d$oh1 == "Si" & d$oh2 %in% c(">30", ">1 año"), "former", "unknown")))
# microsim ms-survey-inputs formula (12 g/drink, no WHO multiplier)
days <- ifelse(is.finite(d$oh3) & d$oh3 >= 0 & d$oh3 <= 30, d$oh3, NA)
eps  <- ifelse(is.finite(d$db) & d$db >= 0 & d$db < 88, d$db, NA)
drinks <- c("0-2" = 1, "3-4" = 3.5, "5-6" = 5.5, "7-8" = 7.5, "9 o mas" = 9)[d$audit2]
d$gpd_survey <- (pmax(days - eps, 0) * drinks + eps * ifelse(d$sexo == "Hombre", 5, 4)) * 12 / 30
d$hed <- as.numeric(eps > 0)
d$gpd_apc <- d$gpd_survey * fac$factor_CH[match(d$year, fac$year)]

# ---- A + B (2024) ----
wmom <- function(x, w) { m <- sum(w * x) / sum(w); v <- sum(w * (x - m)^2) / sum(w); c(shape = m^2 / v, rate = m / v) }
ab <- list()
for (sx in c("Mujer", "Hombre")) for (g in 1:4) {
  s <- if (sx == "Mujer") "fem" else "male"
  c0 <- d[d$year == 2024 & d$sexo == sx & d$tramo == g & d$status == "current" &
            is.finite(d$gpd_apc) & d$gpd_apc > 0, ]
  pooled <- wmom(c0$gpd_apc, c0$w)
  nh <- wmom(c0$gpd_apc[c0$hed %in% 0], c0$w[c0$hed %in% 0]); hd <- wmom(c0$gpd_apc[c0$hed %in% 1], c0$w[c0$hed %in% 1])
  b_p <- inp[[paste0("g_", s, "_list")]][["2024"]][[g]]$estimate
  b_s <- inp[[paste0("g_", s, "_hed_list")]][["2024"]][[g]]
  p_hed_raw <- sum(c0$w[c0$hed %in% 1]) / sum(c0$w[c0$hed %in% c(0, 1)])
  ab[[length(ab) + 1L]] <- data.frame(sex = sx, tramo = g, n_current_positive = nrow(c0),
    shape_pooled_raw = pooled[["shape"]], shape_pooled_bundle = b_p[["shape"]],
    rate_pooled_raw = pooled[["rate"]], rate_pooled_bundle = b_p[["rate"]],
    mean_hed_raw = hd[["shape"]] / hd[["rate"]], mean_hed_bundle = b_s$hed$estimate[["shape"]] / b_s$hed$estimate[["rate"]],
    mean_nhed_raw = nh[["shape"]] / nh[["rate"]], mean_nhed_bundle = b_s$nhed$estimate[["shape"]] / b_s$nhed$estimate[["rate"]],
    p_hed_raw = p_hed_raw, p_hed_bundle = inp[[paste0("p_hed_list_", s)]][[g]][[7]])
}
ab <- do.call(rbind, ab)
utils::write.csv(ab, file.path(audit_dir, "rr_bridge_scale_hed_identity_2024.csv"), row.names = FALSE)
rel <- function(a, b) max(abs(a / b - 1))
cat(sprintf("[A] 2024 gamma on gpd_survey*factor_CH vs bundle: max rel diff shape %.2e, rate %.2e, HED mean %.2e, NHED mean %.2e (8 cells, n current>0 = %d)\n",
            rel(ab$shape_pooled_raw, ab$shape_pooled_bundle), rel(ab$rate_pooled_raw, ab$rate_pooled_bundle),
            rel(ab$mean_hed_raw, ab$mean_hed_bundle), rel(ab$mean_nhed_raw, ab$mean_nhed_bundle), sum(ab$n_current_positive)))
cat(sprintf("[B] 2024 p_hed (db > 0 among current with gpd > 0) vs bundle: max abs diff %.2e\n", max(abs(ab$p_hed_raw - ab$p_hed_bundle))))

# ---- C: former composition, all waves ----
fm <- d[d$status == "former", ]
fm$recent <- fm$oh2 == ">30"
C <- do.call(rbind, lapply(split(fm, list(fm$year, fm$sexo, fm$tramo), drop = TRUE), function(z)
  data.frame(year = z$year[1], sex = z$sexo[1], tramo = z$tramo[1], n_former = nrow(z),
             n_former_31d_12m = sum(z$recent), share_31d_12m_weighted = sum(z$w[z$recent]) / sum(z$w))))
C <- C[order(C$year, C$sex, C$tramo), ]
utils::write.csv(C, file.path(audit_dir, "rr_bridge_former_composition.csv"), row.names = FALSE)
Cy <- do.call(rbind, lapply(split(fm, fm$year), function(z) data.frame(year = z$year[1], n_former = nrow(z),
  n_31d_12m = sum(z$recent), share_31d_12m_w = sum(z$w[z$recent]) / sum(z$w))))
print(Cy, row.names = FALSE, digits = 3)

# ---- D: AAF impact of the former definition, 2024, saved bundle + registry ----
source(file.path(audit_dir, "rr_bridge_lib.R"))
spec <- bridge_load()
x <- inp$x_vals
D <- list()
for (cause in c("Liver Cirrhosis", "Liver Cancer", "Colon and rectum Cancer", "Acute Pancreatitis",
                "Ischaemic Heart Disease", "DM2", "Intracerebral Haemorrhage")) for (sx in c("female", "male")) for (g in 1:4) {
  band <- aaf_age_band_mapping("15_65")$adam_age_band[g]
  e <- spec[spec$cause == cause & spec$sex == sx & spec$principal & (is.na(spec$band) | spec$band == band), ]
  rec <- e$record[[1]]; s <- if (sx == "female") "fem" else "male"
  p_abs <- inp[[paste0("p_abs_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]
  p_form <- inp[[paste0("p_form_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]
  sh <- C$share_31d_12m_weighted[C$year == 2024 & C$sex == (if (sx == "female") "Mujer" else "Hombre") & C$tramo == g]
  rr0 <- rec$RRCurrent(0.1, rec$betaCurrent)
  spl <- inp[[paste0("g_", s, "_hed_list")]][["2024"]][[g]]
  base <- if (e$hed_mode == "none") aaf_point(x, rec$RRCurrent, rec$betaCurrent, p_abs = p_abs, p_form = p_form,
                                              rr_fd = exp(rec$lnRRFormer), gamma = inp[[paste0("g_", s, "_list")]][["2024"]][[g]]) else
    aaf_point(x, rec$RRCurrent, rec$betaCurrent, p_abs = p_abs, p_form = p_form, rr_fd = exp(rec$lnRRFormer),
              gamma = spl$nhed, p_hed = inp[[paste0("p_hed_list_", s)]][[g]][[7]], rr_hed = "cap", gamma_hed = spl$hed)
  # sensitivity: the ">30 days" share of formers carries RR(0.1 g/day) instead of RR_FD (i.e. WHO past-year current, ~0 g)
  # identity: R_obs' = R_obs - p_form*sh*(RR_FD - RR(0.1));  AAF' = 1 - 1/R_obs'
  R_obs <- 1 / (1 - base)
  R_alt <- R_obs - p_form * sh * (exp(rec$lnRRFormer) - rr0)
  D[[length(D) + 1L]] <- data.frame(cause = cause, sex = sx, tramo = g, p_form = p_form, share_31d_12m = sh,
                                    rr_former = exp(rec$lnRRFormer), aaf_expand_pif = base, aaf_former_12m = 1 - 1 / R_alt)
}
D <- do.call(rbind, D); D <- D[is.finite(D$aaf_expand_pif), ]
utils::write.csv(D, file.path(audit_dir, "rr_bridge_former_definition_aaf_2024.csv"), row.names = FALSE)
print(stats::aggregate(cbind(aaf_expand_pif, aaf_former_12m) ~ cause + sex, D, mean), digits = 3)
cat(sprintf("rr_bridge_data_checks elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
