# 05_hazard_formula_selfcheck.R -- reference implementation (synthetic agents, no project data) of the proposed
# person-level cause-specific hazard, with assert-based checks of the identities the engine must satisfy.
.t0 <- Sys.time()
set.seed(20261009)
n <- 20000
pop <- data.frame(cell = sample(c("male:45-59", "female:45-59"), n, TRUE),
                  status = sample(c("never", "former", "current"), n, TRUE, prob = c(.25, .15, .60)))
pop$gpd <- ifelse(pop$status == "current", rgamma(n, shape = 0.8, scale = 25), 0)
m_cell <- c("male:45-59" = 6e-4, "female:45-59" = 2e-4)       # DEIS/INE cause-specific rate of the cell (per person-year)
m_aaf1 <- c("male:45-59" = 1e-4, "female:45-59" = 1e-5)       # AAF=1 deaths / population of the cell
rr  <- function(gpd, status, rr_former = 1.3) ifelse(status == "former", rr_former, exp(0.012 * gpd))  # stand-in RR curve
w1  <- function(gpd, status, phi = 0.5, ref) ifelse(status == "current", gpd, ifelse(status == "former", phi * ref, 0))

hazard <- function(pop, gpd, denom = NULL, denom1 = NULL) {
  r <- rr(gpd, pop$status)
  ref <- mean(pop$gpd[pop$status == "current"])          # former-drinker weight anchored to BASELINE drinkers (frozen)
  w <- w1(gpd, pop$status, ref = ref)
  if (is.null(denom))  denom  <- tapply(r, pop$cell, mean)  # baseline arm: cell mean RR; scenario arm: pass baseline values
  if (is.null(denom1)) denom1 <- tapply(w, pop$cell, mean)
  list(m_c = as.vector(m_cell[pop$cell] * r / denom[pop$cell]), m_1 = as.vector(m_aaf1[pop$cell] * w / denom1[pop$cell]),
       denom = denom, denom1 = denom1, r = r, w = w)
}
b <- hazard(pop, pop$gpd)
# V1: baseline expected deaths reproduce the cell rate exactly (calibration by construction).
stopifnot(all(abs(tapply(b$m_c, pop$cell, sum) / (table(pop$cell) * m_cell[names(table(pop$cell))]) - 1) < 1e-12))
stopifnot(all(abs(tapply(b$m_1, pop$cell, sum) / (table(pop$cell) * m_aaf1[names(table(pop$cell))]) - 1) < 1e-12))
# V2: implied AAF = 1 - 1/mean(RR) equals the deterministic categorical formula sum p(RR-1) / (1 + sum p(RR-1)).
aaf_sim <- 1 - 1 / b$denom
aaf_det <- tapply(b$r - 1, pop$cell, mean) / (1 + tapply(b$r - 1, pop$cell, mean))
stopifnot(all(abs(aaf_sim - aaf_det) < 1e-12))
# V3: null intervention -> zero avoided deaths.
s0 <- hazard(pop, pop$gpd, b$denom, b$denom1)
stopifnot(identical(s0$m_c, b$m_c), identical(s0$m_1, b$m_1))
# V4: -10% volume with FROZEN baseline denominators -> avoided = PIF x deaths, PIF = 1 - mean RR' / mean RR.
s <- hazard(pop, 0.9 * pop$gpd, b$denom, b$denom1)
avoided <- tapply(b$m_c - s$m_c, pop$cell, sum)
pif <- 1 - tapply(s$r, pop$cell, mean) / b$denom
stopifnot(all(abs(avoided - pif * table(pop$cell)[names(pif)] * m_cell[names(pif)]) < 1e-12), all(avoided > 0))
# V5: the pitfall -- renormalising inside the scenario arm cancels the policy effect exactly.
wrong <- hazard(pop, 0.9 * pop$gpd)
stopifnot(all(abs(tapply(b$m_c - wrong$m_c, pop$cell, sum)) < 1e-12))
# V6: AAF=1 -- never drinkers have zero hazard; linear weights give -10% AAF=1 deaths among current drinkers.
stopifnot(all(b$m_1[pop$status == "never"] == 0))
cur <- pop$status == "current"
stopifnot(abs(sum(s$m_1[cur]) / sum(b$m_1[cur]) - 0.9) < 1e-12)
# V7: competing risks -- one annual draw with q = 1 - exp(-sum_c m); cause shares m_c / sum m; probabilities sum to q.
m_other <- 3e-3
M <- b$m_c + b$m_1 + m_other
q <- -expm1(-M)
by_cause <- cbind(alc = b$m_c, aaf1 = b$m_1, other = m_other) / M * q
stopifnot(all(abs(rowSums(by_cause) - q) < 1e-15), all(q >= 0 & q < 1))
# Lexis: probability for a person aged a on 1 January when DEIS rates are by age at death (cell hazards M_a, M_a+1).
q_jan <- function(M_a, M_a1) -expm1(-0.5 * (M_a + M_a1))
stopifnot(abs(q_jan(0.01, 0.01) - (-expm1(-0.01))) < 1e-15)
cat(sprintf("AAF (sim) %s | PIF -10%% %s | avoided per cell %s\n", paste(round(aaf_sim, 4), collapse = "/"),
            paste(round(pif, 4), collapse = "/"), paste(round(avoided, 4), collapse = "/")))
message(sprintf("05_hazard_formula_selfcheck: all checks passed | elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
