# Step 1 add-ons: (a) measurement-reliability sensitivity, (b) 1-year transitions implied by candidate parameters.
.t0 <- Sys.time()
audit <- "<scratch>/audit"
source(file.path(audit, "fit_lib.R"))
sp <- utils::read.csv("<repo>/__andres_control/eps_alcohol_outputs/rho_same_people_three_interviews.csv")
x <- sp[sp$sex == "All", ]; x <- x[match(c("VI_VII_same_people", "VII_VIII_same_people", "VI_VIII_same_people"), x$pair), ]
d <- c(3.671, 4.022, 7.693); se_z <- (atanh(x$upper) - atanh(x$lower)) / (2 * stats::qnorm(.975))
# Classical misclassification attenuates every latent correlation by a common reliability factor Rel (not identified
# by three correlations at two distinct lags); refit on r / Rel.
rel <- do.call(rbind, lapply(c(1, .95, .9, .85, .8), function(R) {
  f <- fit_trait_ar1(pmin(x$rho_interval / R, .99), d, se_z)
  data.frame(reliability = R, lambda = f[["lambda"]], phi = f[["phi"]], r1y = r_model(f[["lambda"]], f[["phi"]], 1),
             r10y = r_model(f[["lambda"]], f[["phi"]], 10), wls_obj = f[["obj"]])
}))
print(format(rel, digits = 3)); utils::write.csv(rel, file.path(audit, "out", "p1c_reliability_sensitivity.csv"), row.names = FALSE)
# 1-year transitions at prevalence p for candidate (lambda, phi): P(stay drinker), P(stay non-drinker), switching.
cand <- data.frame(set = c("engine_now", "proposal_note", "eps50_same_people", "eps18plus_same_people", "low_eps_band", "high_eps_band"),
                   lambda = c(0, .45, .453, .506, .30, .55), phi = c(.8, .65, .679, .683, .75, .60))
tr <- do.call(rbind, lapply(seq_len(nrow(cand)), function(i) do.call(rbind, lapply(c(.25, .45, .60), function(p) {
  r1 <- r_model(cand$lambda[i], cand$phi[i], 1); t <- stats::qnorm(p)
  p11 <- mvtnorm::pmvnorm(upper = c(t, t), corr = matrix(c(1, r1, r1, 1), 2))[1]
  data.frame(cand[i, ], prevalence = p, r1y = r1, r5y = r_model(cand$lambda[i], cand$phi[i], 5), r10y = r_model(cand$lambda[i], cand$phi[i], 10),
             stay_drinker = p11 / p, stay_nondrinker = (1 - 2 * p + p11) / (1 - p), switching = 2 * (p - p11))
}))))
print(format(tr, digits = 3)); utils::write.csv(tr, file.path(audit, "out", "p1c_transitions_candidates.csv"), row.names = FALSE)
message(sprintf("p1c elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
