"""HED-margin invariance to rho, from another agent's 5-seed x 3-rho engine run (aggregated cells).
Population HED among current drinkers, weighted by n*current_mean (current drinkers), by year and rho."""
import time, pandas as pd, numpy as np
t0 = time.time()
d = pd.read_csv("<scratch>/audit/hed_sim_baseline_rho0-0.8-0.95_5seeds.csv")
d["cur_n"] = d.n * d.current_mean; d["hed_n"] = d.cur_n * d.hed_mean
g = d.groupby(["rho", "seed", "year"])[["cur_n", "hed_n", "n"]].sum().reset_index()
g["hed_among_current"] = 100 * g.hed_n / g.cur_n; g["hed_pop"] = 100 * g.hed_n / g.n
s = g.groupby(["rho", "year"]).agg(hed_cur_mean=("hed_among_current", "mean"), hed_cur_sd=("hed_among_current", "std"),
                                   hed_pop_mean=("hed_pop", "mean")).reset_index()
w = s.pivot(index="year", columns="rho", values="hed_cur_mean"); w["max_diff_pp"] = w.max(axis=1) - w.min(axis=1)
w["seed_sd_rho0.8"] = s[s.rho == 0.8].set_index("year").hed_cur_sd
print(w.round(2).to_string()); w.round(4).to_csv("<scratch>/audit/verify_pers/out/v3_hed_by_rho.csv")
print(f"v3 elapsed minutes: {(time.time()-t0)/60:.2f}")
