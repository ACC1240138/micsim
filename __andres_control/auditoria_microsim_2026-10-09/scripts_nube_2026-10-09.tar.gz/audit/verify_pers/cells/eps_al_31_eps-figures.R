#| label: eps-figures
.t0 <- Sys.time()
eps_plot_data <- subset(eps_prevalence_main, outcome == "Declared current use")
eps_plot_data$age_group <- factor(eps_plot_data$age_group, levels = eps_age_levels)
eps_plot_data$wave <- factor(eps_plot_data$wave, levels = names(eps_data),
  labels = c("VI (2016)", "VII in person (2019-2020)", "VIII (2023-2024)"))
eps_plot <- ggplot2::ggplot(eps_plot_data, ggplot2::aes(age_group, estimate * 100, colour = wave, group = wave)) +
  ggplot2::geom_point(position = ggplot2::position_dodge(.45)) +
  ggplot2::geom_errorbar(ggplot2::aes(ymin = lower * 100, ymax = upper * 100), width = .15, position = ggplot2::position_dodge(.45)) +
  ggplot2::facet_wrap(~sex) + ggplot2::theme_minimal(base_size = 12) +
  ggplot2::labs(x = "Age at interview", y = "Reported use (%)", colour = "Wave",
    caption = "F13; approximate 95% CIs. VI: weights only. VII/VIII: PSUs/strata, with singleton-PSU adjustment.\nVII in-person sample has no young-cohort refreshment; waves are not annual observations.")
print(eps_plot)
ggplot2::ggsave(file.path(eps_out, "prevalence_age_sex.png"), eps_plot, width = 10, height = 5.3, dpi = 180, bg = "white")
eps_rp <- subset(eps_rho_table, age_group == "50+" & sex != "All")
eps_rho_plot <- ggplot2::ggplot(eps_rp, ggplot2::aes(pair, rho_interval, colour = sex)) +
  ggplot2::geom_point(position = ggplot2::position_dodge(.3), size = 2) +
  ggplot2::geom_errorbar(ggplot2::aes(ymin = lower, ymax = upper), width = .1, position = ggplot2::position_dodge(.3)) +
  ggplot2::geom_hline(yintercept = 0, linetype = 2) + ggplot2::coord_cartesian(ylim = c(0, 1)) +
  ggplot2::theme_minimal(base_size = 12) + ggplot2::labs(x = "Interview pair", y = "Latent rho between interviews", colour = "Sex",
    caption = "Age 50+ at baseline. Pair-specific longitudinal weights.\nTetrachoric association; neither a stay probability nor an identified annual rho.")
print(eps_rho_plot)
ggplot2::ggsave(file.path(eps_out, "rho_between_interviews.png"), eps_rho_plot, width = 8, height = 4.7, dpi = 180, bg = "white")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))