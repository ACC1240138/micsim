#| label: eps-checks
.t0 <- Sys.time()
# One compact runnable check covers the nontrivial derivation and latent-correlation inversion.
ss <- rbind(c(2,2,2), c(1,2,2), c(1,2,2), c(1,2,2), c(1,2,2), c(1,2,2), c(2,8,2))
ff <- rbind(c(NA,NA,NA), c(0,NA,NA), c(7,NA,NA), c(7,NA,NA), c(1,NA,NA), c(1,NA,NA), c(NA,NA,NA))
qq <- rbind(c(NA,NA,NA), c(1,NA,NA), c(40/12,NA,NA), c(60/12,NA,NA), c(888,NA,NA), c(0,NA,NA), c(NA,NA,NA))
zz <- eps_alcohol(ss, ff, qq, c("Women", "Women", "Women", "Men", "Women", "Men", "Women"))
stopifnot(zz$current[1] == 0, zz$grams_day[1] == 0, zz$current[2] == 1, zz$grams_day[2] > 0,
  zz$state[2] == eps_states[2], all(zz$state[3:4] == "Heavy"), all(is.na(zz$grams_day[5:7])), is.na(zz$current[7]))
stopifnot(eps_education(11, NA, 2, "VI") == eps_edu_levels[3],
          eps_education(11, NA, 3, "VI") == eps_edu_levels[2],
          eps_education(11, NA, 3, "VIII") == eps_edu_levels[3],
          eps_education(6, 2, NA, "VIII") == eps_edu_levels[1])
for (known in c(0, .3, .8)) {
  joint <- eps_bvn(.4, .55, known)
  probs <- c(1-.4-.55+joint, .55-joint, .4-joint, joint)
  stopifnot(abs(eps_tetra(probs) - known) < 1e-5)
}
stopifnot(abs((.8^4)^(1/4) - .8) < 1e-12, is.na(eps_tetra(c(.5,0,0,.5))))
cats <- subset(eps_prevalence_main, outcome != "Declared current use")
sums <- stats::aggregate(estimate ~ wave + age_group + sex, cats, sum)
stopifnot(all(abs(sums$estimate - 1) < 1e-8), all(eps_prevalence_main$estimate >= 0 & eps_prevalence_main$estimate <= 1, na.rm = TRUE),
  all(eps_prevalence_main$bound_lower <= eps_prevalence_main$bound_upper),
  all(eps_prevalence_main$estimate >= eps_prevalence_main$bound_lower - 1e-10 & eps_prevalence_main$estimate <= eps_prevalence_main$bound_upper + 1e-10, na.rm = TRUE),
  all(is.na(eps_requested$estimate[grepl("Lifetime", eps_requested$outcome)])),
  !anyDuplicated(eps_data$VIII$id), !any(grepl("2012", names(eps_data))))
trsum <- stats::aggregate(estimate ~ pair + age_group + sex + education + origin, eps_transitions, sum)
stopifnot(all(abs(trsum$estimate - 1) < 1e-8), all(abs(eps_rho_table$rho_interval) < 1, na.rm = TRUE))
csum <- stats::aggregate(estimate ~ pair + sex + origin, eps_state_transitions, sum)
stopifnot(all(abs(csum$estimate - 1) < 1e-8), all(eps_lifetime_bounds$lifetime_upper >= 0 & eps_lifetime_bounds$lifetime_upper <= 1),
          all(vapply(split(eps_triple_rho$n, eps_triple_rho$sex), function(x) length(unique(x)) == 1L, logical(1))))
for (p in names(eps_pairs)) {
  d <- eps_pairs[[p]]; tm <- eps_time[eps_time$pair == p, ]
  stopifnot(all(d$age_end[d$good_link] - d$age[d$good_link] >= floor(tm$delta_min)),
            all(d$age_end[d$good_link] - d$age[d$good_link] <= ceiling(tm$delta_max)))
}
eps_checks <- data.frame(check = c("skip_missing_frequency_boundaries", "education_code_change", "known_tetrachoric_rho", "category_and_transition_sums", "lifetime_not_fabricated", "unique_real_data_links"), result = "PASS")
eps_save(eps_checks, "validation_checks")

# The Calvo branch must honor strict thresholds, observed history, missingness and the distinct denominator.
history_test <- eps_lifetime_proxy(c(0,0,1,0,0), c(NA,1,0,0,0), rep(0,5), rep(TRUE,5), c(7,7,7,3.99,4))
stopifnot(identical(history_test, c(TRUE,FALSE,FALSE,FALSE,TRUE)),
  !eps_lifetime_proxy(0, NA, 0, TRUE, 7, strict = TRUE),
  eps_lifetime_proxy(0, 0, 0, TRUE, 7, strict = TRUE),
  all(!eps_cp$lifetime_strict | eps_cp$lifetime_proxy),
  !any(eps_cp$lifetime_proxy & eps_cp$current_mid == 1, na.rm = TRUE))
test_d <- data.frame(sex = c("Men", "Men", "Women", "Women", "Men", "Men", "Men"),
  f13_1 = 1, f13_2 = 2, f13_3 = 2,
  f14_1 = c(7,7,7,7,0,1,1), f14_2 = NA_real_, f14_3 = NA_real_,
  f15_1 = c(3,3.01,2,2.01,1,6,888), f15_2 = NA_real_, f15_3 = NA_real_)
z <- eps_calvo_classify(test_d); zq <- eps_calvo_classify(test_d, quantity_proxy = TRUE)
stopifnot(identical(z$code, c(4L,0L,4L,0L,3L,4L,NA_integer_)),
  zq$code[6] == 0L, is.na(zq$code[7]), is.na(z$typical_high_quantity[7]))
cps <- stats::aggregate(estimate ~ scenario + age_group + sex + education, eps_calvo_prevalence, sum)
stopifnot(all(abs(cps$estimate - 1) < 1e-8), all(abs(eps_beverage_rho$rho_interval) < 1, na.rm = TRUE))
for (w in names(eps_data)) {
  use <- do.call(cbind, eps_beverage_use(eps_data[[w]]))
  stopifnot(all(eps_data[[w]]$current[rowSums(use == 1, na.rm = TRUE) > 0] == 1),
    all(eps_data[[w]]$current[rowSums(use == 0, na.rm = TRUE) == 3] == 0))
}
eps_checks <- rbind(eps_checks, data.frame(check = c("calvo_strict_thresholds_and_HED_proxy", "four_year_history_no_positive", "five_proxy_categories_sum", "beverage_use_and_rho"), result = "PASS"))
eps_save(eps_checks, "validation_checks")


enpg_shares <- subset(enpg_preferred_beverage, outcome == "Most frequent beverage share")
enpg_share_sums <- stats::aggregate(estimate ~ age_group + sex, enpg_shares, sum)
stopifnot(all(abs(enpg_share_sums$estimate - 1) < 1e-8),
  all(is.na(enpg_prevalence$estimate[enpg_prevalence$flag == "outside_ENPG_age_support"])))
eps_checks <- rbind(eps_checks, data.frame(check = c("ENPG_skip_missing_HED_age_support", "ENPG_preferred_beverage_shares_sum"), result = "PASS"))
eps_save(eps_checks, "validation_checks")
eps_table(eps_checks, "Validation executed on synthetic cases and real data")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))