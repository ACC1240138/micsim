#| label: eps-beverage-persistence
.t0 <- Sys.time()
eps_beverage_rho <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  d <- eps_pairs[[p]]; tm <- eps_time[eps_time$pair == p, ]
  before <- eps_beverage_use(eps_data$VI[match(d$id, eps_data$VI$id), ])
  after_data <- eps_data[[tm$to]][match(d$id, eps_data[[tm$to]]$id), ]
  after_use <- eps_beverage_use(after_data)
  do.call(rbind, lapply(eps_beverage_names, function(beverage) {
    ds <- eps_pair_designs[[p]]
    ds$variables$current0 <- ifelse(d$good_link, before[[beverage]], NA_real_)
    ds$variables$current1 <- ifelse(d$good_link, after_use[[beverage]], NA_real_)
    do.call(rbind, lapply(eps_panel_groups(d), function(g)
      cbind(pair = p, beverage, g$key, eps_rho(ds[which(g$keep), ], tm$delta, tm$delta_min, tm$delta_max))))
  }))
}))
eps_save(eps_beverage_rho, "rho_beverage_age_sex")
eps_table(subset(eps_beverage_rho, age_group == "50+" & sex == "All")[,
  c("pair", "beverage", "n", "rho_interval", "lower", "upper", "rho_annual", "flag")],
  "Beverage-specific persistence: age 50+ at baseline; annual values are conditional transformations")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))