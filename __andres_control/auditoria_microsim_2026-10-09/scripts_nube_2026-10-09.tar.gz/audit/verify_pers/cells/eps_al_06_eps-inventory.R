#| label: eps-inventory
.t0 <- Sys.time()
eps_files <- list.files(eps_root, pattern = "\\.dta$", recursive = TRUE, full.names = TRUE)
eps_relative <- function(x) paste0("_eps/", substring(gsub("\\\\", "/", x), nchar(gsub("\\\\", "/", eps_root)) + 2L))
eps_inventory <- do.call(rbind, lapply(eps_files, function(p) {
  h <- haven::read_dta(p, n_max = 0)
  data.frame(file = eps_relative(p), variables = ncol(h), bytes = file.info(p)$size,
    has_f13 = all(paste0("f13_", 1:3) %in% names(h)),
    has_f14 = all(paste0("f14_", 1:3) %in% names(h)),
    has_f15 = all(paste0("f15_", 1:3) %in% names(h)), has_relative_change = "fc101_1" %in% names(h),
    has_psu = "cluster_ID" %in% names(h), has_strata = "strata_ID" %in% names(h))
}))
stopifnot(!any(eps_inventory$has_f13[grepl("_eps/2012/", eps_inventory$file)]))
eps_save(eps_inventory, "file_inventory")
eps_table(eps_inventory[eps_inventory$has_f13 | eps_inventory$has_relative_change, c("file", "variables", "has_f14", "has_f15", "has_relative_change")],
          "Files with absolute use or relative change; full inventory in CSV")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))