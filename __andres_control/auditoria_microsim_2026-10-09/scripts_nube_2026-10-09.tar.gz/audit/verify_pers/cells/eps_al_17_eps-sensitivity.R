#| label: eps-sensitivity
.t0 <- Sys.time()
eps_scenarios <- data.frame(scenario = c("base_sum_12g", "sum_10g", "sum_15.7g", "frequency_0.25", "frequency_0.75", "Calvo_max_complete", "quantity_cap15"),
  grams = c(12, 10, 15.7, 12, 12, 12, 12), less_week = c(.5, .5, .5, .25, .75, .5, .5),
  aggregation = c(rep("sum", 5), "max", "sum"))
eps_sensitivity <- do.call(rbind, lapply(names(eps_data), function(w) do.call(rbind, lapply(seq_len(nrow(eps_scenarios)), function(i) {
  d <- eps_data[[w]]; s <- eps_scenarios[i, ]; q <- as.matrix(d[paste0("f15_", 1:3)])
  # Clean missing codes before capping: 888 must never become a real 15-cup response.
  q[q %in% c(88, 99, 888, 999, 8888, 9999)] <- NA_real_
  if (s$scenario == "quantity_cap15") q <- pmin(q, 15)
  z <- eps_alcohol(as.matrix(d[paste0("f13_", 1:3)]), as.matrix(d[paste0("f14_", 1:3)]), q, d$sex, s$grams, s$less_week, s$aggregation)
  ds <- eps_designs[[w]]; ds$variables$state <- z$state; ds$variables$current <- z$current
  out <- eps_prevalence(ds)
  cbind(wave = w, scenario = s$scenario, out[out$outcome %in% c("Heavy", eps_states[2]), ])
}))))
eps_design_audit <- do.call(rbind, lapply(names(eps_data), function(w) {
  d <- eps_data[[w]]; ps <- unique(d[c("strata", "psu")]); cnt <- table(ps$strata)
  data.frame(wave = w, n = nrow(d), sum_weights = sum(d$weight), n_eff_weights = sum(d$weight)^2 / sum(d$weight^2),
    strata = if (w == "VI") NA else length(cnt), psu = if (w == "VI") NA else nrow(ps),
    singleton_strata = if (w == "VI") NA else sum(cnt == 1), minimum_age = min(d$age))
}))
eps_precision_sensitivity <- do.call(rbind, lapply(c("adjust", "certainty"), function(method) {
  options(survey.lonely.psu = method)
  do.call(rbind, lapply(c("VII_presencial", "VIII"), function(w) {
    ds <- eps_designs[[w]]; ds <- ds[ds$variables$age >= 50, ]
    cbind(wave = w, singleton_method = method, eps_prop(ds, ds$variables$current))
  }))
}))
options(survey.lonely.psu = "adjust")
eps_education_sensitivity <- do.call(rbind, lapply(names(eps_designs), function(w) {
  ds <- eps_designs[[w]]; ds$variables$education <- ds$variables$education_attended
  cbind(wave = w, eps_prevalence(ds, education = TRUE))
}))
eps_overlap <- do.call(rbind, lapply(eps_data, function(d) data.frame(wave = d$wave[1],
  occasional_multi_beverage = sum(d$state == eps_states[2] & rowSums(d[paste0("f13_", 1:3)] == 1, na.rm = TRUE) > 1, na.rm = TRUE),
  quantity_above15 = sum(as.matrix(d[paste0("f15_", 1:3)]) > 15 & as.matrix(d[paste0("f15_", 1:3)]) < 888, na.rm = TRUE))))
eps_save(eps_sensitivity, "measurement_sensitivity"); eps_save(eps_design_audit, "design_audit")
eps_save(eps_precision_sensitivity, "singleton_precision_sensitivity"); eps_save(eps_education_sensitivity, "education_attended_sensitivity")
eps_save(eps_overlap, "frequency_and_quantity_flags")
eps_table(eps_design_audit, "Available design information: no public VI PSU identifiers; VII/VIII include singleton strata")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))