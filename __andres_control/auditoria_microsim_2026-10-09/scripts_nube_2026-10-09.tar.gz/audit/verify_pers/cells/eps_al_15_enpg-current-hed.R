#| label: enpg-current-hed
.t0 <- Sys.time()
# The source questionnaire, not a processed mortality subset, defines the outcomes.
enpg_file <- "_enpg/enpg.tar.xz.enc::Base Publica ENPG 2024 (Stata 16).dta"
# Label "bundle::member" -> decrypted file (same md5 as the original).
enpg_abs <- function(x) vapply(x, function(z) acc_data(sub("::.*$", "", z), sub("^.*::", "", z)), character(1), USE.NAMES = FALSE)
enpg_raw <- haven::read_dta(enpg_abs(enpg_file))
enpg_d <- data.frame(age = as.numeric(enpg_raw$EDAD),
  sex = ifelse(enpg_raw$SEXO == 1, "Men", ifelse(enpg_raw$SEXO == 2, "Women", NA_character_)),
  weight = as.numeric(enpg_raw$FACTOR_EXPANSION), strata = as.character(enpg_raw$ESTRATO),
  psu = as.character(enpg_raw$UPM), ever = as.numeric(enpg_raw$OH_1),
  recency = as.numeric(enpg_raw$OH_4), beverage = as.numeric(enpg_raw$OH_6),
  hed_count = as.numeric(enpg_raw$OH_7))
stopifnot(nrow(enpg_d) == 18668L, all(enpg_d$age >= 12 & enpg_d$age <= 65),
  !anyNA(enpg_d[c("weight", "strata", "psu", "sex", "age")]), all(enpg_d$weight > 0),
  all(enpg_d$ever %in% c(1, 2, 88, 99)),
  all(enpg_d$recency %in% c(1, 2, 3, 88, 99, NA)),
  all(enpg_d$beverage %in% c(1:4, 88, 99, NA)))
enpg_age_levels <- c("15-17", "18-29", "30-44", "45-59", "60-65", "66-70", "71-76", "77+")
enpg_d$age_group <- as.character(cut(enpg_d$age, c(15, 18, 30, 45, 60, 66, 71, 77, Inf),
  right = FALSE, labels = enpg_age_levels))
# Never users and known non-current users have zero current use; unknowns remain NA.
enpg_d$current <- ifelse(enpg_d$ever == 2, 0,
  ifelse(enpg_d$ever == 1 & enpg_d$recency == 1, 1,
    ifelse(enpg_d$ever == 1 & enpg_d$recency %in% c(2, 3), 0, NA_real_)))
enpg_hed_valid <- !is.na(enpg_d$hed_count) & !enpg_d$hed_count %in% c(88, 99) &
  enpg_d$hed_count >= 0 & enpg_d$hed_count <= 99 & enpg_d$hed_count == floor(enpg_d$hed_count)
# OH_7 counts occasions (not days): retain values >30; 88/99 are unknown, zero is never.
# Direct threshold is >=5 drinks for men and >=4 for women, all beverages combined.
enpg_d$hed <- ifelse(enpg_d$current == 0, 0,
  ifelse(enpg_d$current == 1 & enpg_hed_valid, as.numeric(enpg_d$hed_count > 0), NA_real_))
enpg_beverages <- c("Beer", "Wine/sparkling wine", "Spirits/mixed drinks", "Other")
enpg_d$preferred <- ifelse(enpg_d$beverage %in% 1:4, enpg_beverages[enpg_d$beverage], NA_character_)
# Preserve the full 12-65 survey design before taking age/sex domains.
enpg_des <- eps_design(enpg_d)
enpg_upm_strata <- tapply(enpg_d$strata, enpg_d$psu, function(z) length(unique(z)))
enpg_upm_per_stratum <- tapply(enpg_d$psu, enpg_d$strata, function(z) length(unique(z)))
stopifnot(all(enpg_upm_strata == 1), all(enpg_upm_per_stratum > 1),
  sum(enpg_d$current == 1, na.rm = TRUE) == 5533L,
  all(enpg_d$hed[which(enpg_d$current == 0)] == 0),
  sum(enpg_d$hed_count == 0, na.rm = TRUE) == 2327L,
  sum(enpg_d$hed_count %in% c(88, 99)) == 349L,
  all(is.na(enpg_d$hed[which(enpg_d$current == 1 & !enpg_hed_valid)])),
  !any(enpg_d$hed == 1 & enpg_d$current == 0, na.rm = TRUE))
enpg_design_audit <- data.frame(wave = 2024, n = nrow(enpg_d), n_adults = sum(enpg_d$age >= 18),
  age_min = min(enpg_d$age), age_max = max(enpg_d$age), n_over65 = sum(enpg_d$age > 65),
  strata = length(enpg_upm_per_stratum), psu = length(enpg_upm_strata),
  singleton_strata = sum(enpg_upm_per_stratum == 1), weighted_n = sum(enpg_d$weight),
  current_n = sum(enpg_d$current == 1, na.rm = TRUE), current_unknown_n = sum(is.na(enpg_d$current)),
  hed_unknown_among_current_n = sum(enpg_d$current == 1 & is.na(enpg_d$hed), na.rm = TRUE),
  preferred_unknown_among_current_n = sum(enpg_d$current == 1 & is.na(enpg_d$preferred), na.rm = TRUE))
enpg_rows <- list()
for (ag in enpg_age_levels) for (sx in c("Men", "Women")) {
  keep <- which(enpg_d$age_group == ag & enpg_d$sex == sx)
  ds <- enpg_des[keep, ]; z <- ds$variables
  # Both population prevalence and prevalence conditional on current use are explicit.
  specifications <- list(
    list(outcome = "Current use, 30 days", denominator = "Age-sex population", preferred = "All", keep = seq_len(nrow(z)), y = z$current),
    list(outcome = "HED 5+/4+, 30 days", denominator = "Age-sex population", preferred = "All", keep = seq_len(nrow(z)), y = z$hed),
    list(outcome = "HED 5+/4+, 30 days", denominator = "Current 30-day drinkers", preferred = "All", keep = which(z$current == 1), y = z$hed))
  for (bev in enpg_beverages) {
    specifications[[length(specifications) + 1L]] <- list(outcome = "Most frequent beverage share",
      denominator = "Current 30-day drinkers", preferred = bev, keep = which(z$current == 1),
      y = ifelse(is.na(z$preferred), NA_real_, as.numeric(z$preferred == bev)))
    specifications[[length(specifications) + 1L]] <- list(outcome = "HED 5+/4+, 30 days",
      denominator = "Current drinkers with this most frequent beverage", preferred = bev,
      keep = which(z$current == 1 & z$preferred == bev), y = z$hed)
  }
  for (sp in specifications) {
    ss <- ds[sp$keep, ]; y <- sp$y[sp$keep]; w <- ss$variables$weight; W <- sum(w)
    est <- eps_prop(ss, y)
    domain_psu <- tapply(ss$variables$psu[!is.na(y)], ss$variables$strata[!is.na(y)], function(p) length(unique(p)))
    if (!length(keep)) { est$flag <- "outside_ENPG_age_support"; est$coverage <- NA_real_ }
    enpg_rows[[length(enpg_rows) + 1L]] <- cbind(data.frame(source = "ENPG", wave = 2024,
      age_group = ag, sex = sx, outcome = sp$outcome, denominator = sp$denominator,
      preferred_beverage = sp$preferred, n_domain = length(y), n_events = sum(y == 1, na.rm = TRUE),
      domain_singleton_strata = sum(domain_psu == 1), precision = "PSU_strata_domain_lonely_adjust_working_CI"), est,
      bound_lower = if (W > 0) sum(w[which(y == 1)]) / W else NA_real_,
      bound_upper = if (W > 0) sum(w[which(y == 1 | is.na(y))]) / W else NA_real_)
  }
}
enpg_estimates <- do.call(rbind, enpg_rows)
enpg_prevalence <- subset(enpg_estimates, preferred_beverage == "All")
enpg_preferred_beverage <- subset(enpg_estimates, preferred_beverage != "All")
stopifnot(nrow(enpg_prevalence) == 48L,
  all(is.na(enpg_estimates$estimate[enpg_estimates$age_group %in% c("66-70", "71-76", "77+")])),
  all(enpg_estimates$estimate >= 0 & enpg_estimates$estimate <= 1, na.rm = TRUE))
eps_save(enpg_design_audit, "enpg2024_design_audit")
eps_save(enpg_prevalence, "enpg2024_current_HED_age_sex")
eps_save(enpg_preferred_beverage, "enpg2024_preferred_beverage_age_sex")

# Historical coverage audit is embedded with hashes, so no temporary audit files are required.
enpg_inventory <- utils::read.csv(text = "\"year\",\"file\",\"n\",\"variables\",\"age_variable\",\"age_min\",\"age_max\",\"n_over65\",\"md5\"\n\"2008\",\"_enpg/enpg.tar.xz.enc::enpg2008.RDS\",17113,367,\"edad\",12,65,0,\"d468b3650ea3491d311d83adaf8de50b\"\n\"2010\",\"_enpg/enpg.tar.xz.enc::enpg2010.RDS\",15576,521,\"pedadent\",12,64,0,\"1dff2d05042804a48846c3128e84631a\"\n\"2012\",\"_enpg/enpg.tar.xz.enc::Base de datos ENPG 2012 (PG).DTA.dta\",17154,451,\"edad\",12,65,0,\"178c9e8ed9264c1aba89c99ccb137eda\"\n\"2014\",\"_enpg/enpg.tar.xz.enc::Base de datos ENPG 2014 (PG).DTA.dta\",20113,454,\"edad\",12,65,0,\"314c780019a90c44464ac991091d9913\"\n\"2016\",\"_enpg/enpg.tar.xz.enc::base ENPG 2016 publico general.dta\",19147,473,\"edad\",12,65,0,\"00a6db4c5be75432cd2a49c94eb65a2a\"\n\"2018\",\"_enpg/enpg.tar.xz.enc::Base de datos ENPG 2018 (PG).DTA\",19427,499,\"S02\",12,65,0,\"d69d7cd46f8473d24dd06327d639e88f\"\n\"2020\",\"_enpg/enpg.tar.xz.enc::enpg2020.RDS\",16662,395,\"S02\",12,65,0,\"03b10d40b3c37e7f4417f3f18142d69c\"\n\"2022\",\"_enpg/enpg.tar.xz.enc::BD - ENPG 2022 (Stata 16).dta\",17454,382,\"EDAD\",12,65,0,\"3300e94e433b385206a128c4f6a8ef3f\"\n\"2024\",\"_enpg/enpg.tar.xz.enc::Base Publica ENPG 2024 (Stata 16).dta\",18668,402,\"EDAD\",12,65,0,\"d2f6fd4e57b51c994cb6ede0396f6fb5\"\n", stringsAsFactors = FALSE)

stopifnot(all(enpg_inventory$md5 == unname(tools::md5sum(enpg_abs(enpg_inventory$file)))))
eps_save(enpg_inventory, "enpg_wave_inventory")
eps_manifest <- rbind(eps_manifest, enpg_inventory[, c("file", "md5")])
eps_save(eps_manifest, "input_manifest")
eps_table(enpg_inventory[, c("year", "n", "age_min", "age_max", "n_over65")], "Observed ENPG age coverage: all nine local waves")
eps_table(subset(enpg_prevalence, age_group %in% c("60-65", "66-70", "71-76"))[
  , c("age_group", "sex", "outcome", "denominator", "n_valid", "estimate", "lower", "upper", "flag")],
  "ENPG 2024: current use and HED, with unsupported older groups retained explicitly")

# Verified historical crosswalk, embedded rather than read from a temporary helper.
enpg_wave_crosswalk <- utils::read.csv(text = "year,ever_use,last_use,most_frequent_beverage,HED_30d_count,HED_missing_codes,AUDIT_6plus,AUDIT_never_code,AUDIT_positive_codes,sex,age,weight,design_fields\n2008,q12,q15,q17,not_found,not_applicable,q20,0,1:4,sexo,edad,exp,seccion_candidate_not_validated\n2010,p013,p016,p018,not_found,not_applicable,p021,0,1:4,psexoent,pedadent,factor_ajustado_com,manzana_candidate_not_validated\n2012,p10,p13,p15,p16,88;99,p21,0,1:4,sexo,edad,PONDERADOR,manzana;commune_proxy_stratum\n2014,oh1,oh4,oh6,oh7,88;99,oh12,0,1:4,sexo,edad,F2_MAY_AJUS_com,Segmento_n;commune_proxy_stratum\n2016,oh_1,oh_4,oh_6,oh_7a (men); oh_7b (women),88;99,oh_16,0,1:4,sexo,edad,Fexp_external_by_idencuesta,manzana;commune_proxy_stratum\n2018,OH_1,OH_4,OH_6,OH_7H (men); OH_7M (women),888;999_labels_plus_88;99_questionnaire_ambiguity,OH_14,1,2:5,S01,S02,Fexp,idmanzana;commune_x_size_stratum_reconstruction_unvalidated\n2020,OH_1,OH_4,OH_6,OH_7,88;99,OH_10,0,1:4,S01,S02,FACT_PERS_COMUNA,seccion_candidate_not_validated\n2022,OH_1,OH_4,OH_6,OH_7,88;99,OH_10,0,1:4,SEXO,EDAD,FACTOR_EXPANSION,UPM;COD_COMUNA_proxy_stratum\n2024,OH_1,OH_4,OH_6,OH_7,88;99,OH_10,0,1:4,SEXO,EDAD,FACTOR_EXPANSION,UPM;ESTRATO\n", stringsAsFactors = FALSE)
eps_save(enpg_wave_crosswalk, "enpg_wave_crosswalk")
enpg_availability_audit <- utils::read.csv(text = "year,ever_use,last_use,most_frequent_beverage,HED_30d_count,HED_missing_codes,AUDIT_6plus,AUDIT_never_code,AUDIT_positive_codes,sex,age,weight,design_fields,file,n,variables,age_variable,age_min,age_max,n_over65,md5,beverage_measure,beverage_codes,current_rule,current_window,HED_30d_definition,AUDIT_window,sex_codes,beer_wine_spirits_true_prevalence,individual_persistence,instrument_flags,questionnaire_evidence,weight_source,design_validation,ever_missing_codes,current_recency_codes\n2008,q12,q15,q17,not_found,not_applicable,q20,0,1:4,sexo,edad,exp,seccion_candidate_not_validated,_enpg/enpg.tar.xz.enc::enpg2008.RDS,17113,367,edad,12,65,0,d468b3650ea3491d311d83adaf8de50b,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine;3spirits;9unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",Not found; AUDIT6+ is a different instrument,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,No direct 5+/4+ count found; original questionnaire unavailable; recency raw0 is structural/unknown depending ever-use,Raw labels only; no original questionnaire located,_enpg/enpg.tar.xz.enc::enpg2008.RDS,Fields inspected; full design reconstruction not validated in this extension,9;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2010,p013,p016,p018,not_found,not_applicable,p021,0,1:4,psexoent,pedadent,factor_ajustado_com,manzana_candidate_not_validated,_enpg/enpg.tar.xz.enc::enpg2010.RDS,15576,521,pedadent,12,64,0,1dff2d05042804a48846c3128e84631a,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine;3spirits;0unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",Not found; AUDIT6+ is a different instrument,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,No direct 5+/4+ count found; p021 threshold unverified; observed max age64,Raw labels only; no original questionnaire located,_enpg/enpg.tar.xz.enc::enpg2010.RDS,Fields inspected; full design reconstruction not validated in this extension,0;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2012,p10,p13,p15,p16,88;99,p21,0,1:4,sexo,edad,PONDERADOR,manzana;commune_proxy_stratum,_enpg/enpg.tar.xz.enc::Base de datos ENPG 2012 (PG).DTA.dta,17154,451,edad,12,65,0,178c9e8ed9264c1aba89c99ccb137eda,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine/sparkling;3spirits/mixed;4other;88/99unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",At least5 drinks men or4 women on one occasion in last30days; all beverages pooled; valid count>0,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,Seven direct HED count values500-10000 require flagging before use,_enpg/enpg.tar.xz.enc::Cuestionario ENPG 2012.pdf.pdf pp2-3,_enpg/enpg.tar.xz.enc::Base de datos ENPG 2012 (PG).DTA.dta,Fields inspected; full design reconstruction not validated in this extension,88;99;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2014,oh1,oh4,oh6,oh7,88;99,oh12,0,1:4,sexo,edad,F2_MAY_AJUS_com,Segmento_n;commune_proxy_stratum,_enpg/enpg.tar.xz.enc::Base de datos ENPG 2014 (PG).DTA.dta,20113,454,edad,12,65,0,314c780019a90c44464ac991091d9913,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine/sparkling;3spirits/mixed;4other;88/99unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",At least5 drinks men or4 women on one occasion in last30days; all beverages pooled; valid count>0,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,No extra instrument flag identified in reviewed alcohol pages,_enpg/enpg.tar.xz.enc::Cuestionario ENPG 2014.pdf.pdf pp4-6,_enpg/enpg.tar.xz.enc::Base de datos ENPG 2014 (PG).DTA.dta,Fields inspected; full design reconstruction not validated in this extension,88;99;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2016,oh_1,oh_4,oh_6,oh_7a (men); oh_7b (women),88;99,oh_16,0,1:4,sexo,edad,Fexp_external_by_idencuesta,manzana;commune_proxy_stratum,_enpg/enpg.tar.xz.enc::base ENPG 2016 publico general.dta,19147,473,edad,12,65,0,00a6db4c5be75432cd2a49c94eb65a2a,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine/sparkling;3spirits/mixed;4other;88/99unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",At least5 drinks men or4 women on one occasion in last30days; all beverages pooled; valid count>0,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,Exclude Fiestas Patrias; expansion factor requires separate file join; split HED by sex,_enpg/enpg.tar.xz.enc::Cuestionario_Senda2016.pdf pp5-7,_enpg/enpg.tar.xz.enc::factoresdeexpansion.dta (idencuesta -> Fexp),Fields inspected; full design reconstruction not validated in this extension,88;99;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2018,OH_1,OH_4,OH_6,OH_7H (men); OH_7M (women),888;999_labels_plus_88;99_questionnaire_ambiguity,OH_14,1,2:5,S01,S02,Fexp,idmanzana;commune_x_size_stratum_reconstruction_unvalidated,_enpg/enpg.tar.xz.enc::Base de datos ENPG 2018 (PG).DTA,19427,499,S02,12,65,0,d69d7cd46f8473d24dd06327d639e88f,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine/sparkling;3spirits/mixed;4other;88/99unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",At least5 drinks men or4 women on one occasion in last30days; all beverages pooled; valid count>0,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,Exclude Fiestas Patrias; raw HED missing888/999 versus questionnaire88/99; four ambiguous88/99 responses; AUDIT coding shifted by1,_enpg/enpg.tar.xz.enc::ENPEG-2018.pdf PDF pp312-314,_enpg/enpg.tar.xz.enc::Base de datos ENPG 2018 (PG).DTA,Fields inspected; full design reconstruction not validated in this extension,88;99;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2020,OH_1,OH_4,OH_6,OH_7,88;99,OH_10,0,1:4,S01,S02,FACT_PERS_COMUNA,seccion_candidate_not_validated,_enpg/enpg.tar.xz.enc::enpg2020.RDS,16662,395,S02,12,65,0,03b10d40b3c37e7f4417f3f18142d69c,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine/sparkling;3spirits/mixed;4other;88/99unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",At least5 drinks men or4 women on one occasion in last30days; all beverages pooled; valid count>0,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,New Year exclusion January2021; female4-drink examples repeat male volumes; raw item labels absent but appendix verifies mapping; pandemic-era fieldwork,_enpg/enpg.tar.xz.enc::ENPG-2020-WEB.pdf PDF pp337-339,_enpg/enpg.tar.xz.enc::enpg2020.RDS,Fields inspected; full design reconstruction not validated in this extension,88;99;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2022,OH_1,OH_4,OH_6,OH_7,88;99,OH_10,0,1:4,SEXO,EDAD,FACTOR_EXPANSION,UPM;COD_COMUNA_proxy_stratum,_enpg/enpg.tar.xz.enc::BD - ENPG 2022 (Stata 16).dta,17454,382,EDAD,12,65,0,3300e94e433b385206a128c4f6a8ef3f,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine/sparkling;3spirits/mixed;4other;88/99unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",At least5 drinks men or4 women on one occasion in last30days; all beverages pooled; valid count>0,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,New Year exclusion January2023; female4-drink examples repeat male volumes,_enpg/enpg.tar.xz.enc::Cuestionario ENPG_2022.pdf pp4-6,_enpg/enpg.tar.xz.enc::BD - ENPG 2022 (Stata 16).dta,Fields inspected; full design reconstruction not validated in this extension,88;99;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n2024,OH_1,OH_4,OH_6,OH_7,88;99,OH_10,0,1:4,SEXO,EDAD,FACTOR_EXPANSION,UPM;ESTRATO,_enpg/enpg.tar.xz.enc::Base Publica ENPG 2024 (Stata 16).dta,18668,402,EDAD,12,65,0,d2f6fd4e57b51c994cb6ede0396f6fb5,Single most frequently consumed beverage in last30days; not independent any-use by beverage,1beer;2wine/sparkling;3spirits/mixed;4other;88/99unknown,Ever no=0; ever yes and recency1=1; ever yes and recency2/3=0; unknown=NA,\"Last30days, subject to wave-specific holiday exclusion\",At least5 drinks men or4 women on one occasion in last30days; all beverages pooled; valid count>0,Usual frequency of6+ on one occasion; not an identified30day event; pastyear routing verified2012-2024,1male;2female,Not identified by single most-frequent item,Not identified: repeated cross-sectional surveys,Fiestas Patrias and New Year conditional exclusions; female4-drink examples repeat male volumes; full published UPM/ESTRATO design available,_enpg/enpg.tar.xz.enc::cuestionario 2024.pdf pp4-6; _enpg/enpg.tar.xz.enc::ENPG-2024.pdf p2,_enpg/enpg.tar.xz.enc::Base Publica ENPG 2024 (Stata 16).dta,UPM/ESTRATO/FACTOR_EXPANSION verified;2692 PSU;109 strata;no full-sample singleton,88;99;NA,1 last30days;2 more than1month/less than1year;3 more than1year\n", stringsAsFactors = FALSE)
eps_save(enpg_availability_audit, "enpg_availability_audit")
eps_table(enpg_wave_crosswalk[, c("year", "most_frequent_beverage", "HED_30d_count", "HED_missing_codes")], "ENPG wave crosswalk: variables are not interchangeable across years")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))