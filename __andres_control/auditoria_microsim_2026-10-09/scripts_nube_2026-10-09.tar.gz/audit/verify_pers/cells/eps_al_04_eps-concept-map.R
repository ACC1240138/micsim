#| label: eps-concept-map
.t0 <- Sys.time()
# A static, exportable concept map uses the plotting package already needed below.
map_nodes <- data.frame(
  x = rep(c(1, 4, 7), 3), y = rep(c(3, 2, 1), each = 3),
  text = c("EPS A + F + survey weights\nVI / VII face-to-face / VIII",
           "F13 use by beverage\nF14 frequency + F15 quantity",
           "Weighted age / sex / education\nJRT categories + beverage prevalence",
           "EPS linked respondents\nOfficial longitudinal weights",
           "Repeated abstention >=4 years\nPaired use for persistence",
           "Five-category proxy prevalence\nBinary transitions + conditional rho",
           "ENPG questionnaires + microdata\nCheck waves, ages and design",
           "Last-30-day use + direct HED\nKeep question-specific thresholds",
           "ENPG estimates within coverage\nAge 66+: EPS quantity proxy"))
map_edges <- data.frame(x = rep(c(2.18, 5.18), 3), xend = rep(c(2.80, 5.80), 3),
                        y = rep(c(3, 2, 1), each = 2))
eps_map <- ggplot2::ggplot() +
  ggplot2::geom_rect(data = map_nodes, ggplot2::aes(xmin = x - 1.18, xmax = x + 1.18, ymin = y - .28, ymax = y + .28),
    fill = rep(c("#e6f2f0", "#e9ecf7", "#fff2d9"), each = 3), colour = "#4c5866", linewidth = .5) +
  ggplot2::geom_text(data = map_nodes, ggplot2::aes(x, y, label = text), size = 3.4, lineheight = 1.12) +
  ggplot2::geom_segment(data = map_edges, ggplot2::aes(x = x, xend = xend, y = y, yend = y),
    arrow = grid::arrow(length = grid::unit(.14, "inches")), colour = "#4c5866") +
  ggplot2::coord_cartesian(xlim = c(-.3, 8.3), ylim = c(.45, 3.6), clip = "off") +
  ggplot2::theme_void(base_size = 12) + ggplot2::labs(title = "From measured responses to estimates",
    caption = "A proxy adds an explicit assumption. It does not add a question that the survey never asked.") +
  ggplot2::theme(plot.background = ggplot2::element_rect(fill = "white", colour = NA), plot.title = ggplot2::element_text(face = "bold"), plot.margin = ggplot2::margin(15, 15, 15, 15))
print(eps_map)
ggplot2::ggsave(file.path(eps_out, "analysis_concept_map.png"), eps_map, width = 13, height = 5.8, dpi = 180, bg = "white")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))