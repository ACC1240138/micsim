#| label: eps-calvo-proxy
.t0 <- Sys.time()
eps_calvo_labels <- c("Lifetime abstainer (>=4-year proxy)", "Current abstainer", "Occasional (proxy)",
                      "Moderate (proxy)", "Heavy (proxy)")
eps_calvo_codes <- c(1L, 2L, 3L, 4L, 0L)
eps_lifetime_proxy <- function(first, middle, last, good, minimum_years, strict = FALSE) {
  # No future look-ahead: this rule is evaluated only at the last observed wave.
  ans <- good & !is.na(first) & first == 0 & !is.na(last) & last == 0 & minimum_years >= 4 &
    (is.na(middle) | middle == 0)
  if (strict) ans <- ans & !is.na(middle) & middle == 0
  ans[is.na(ans)] <- FALSE
  ans
}
eps_calvo_classify <- function(d, lifetime = rep(FALSE, nrow(d)), quantity_proxy = FALSE, available_max = FALSE) {
  s <- as.matrix(d[paste0("f13_", 1:3)])
  f <- as.matrix(d[paste0("f14_", 1:3)])
  q <- as.matrix(d[paste0("f15_", 1:3)])
  # Remove missing codes before applying Calvo's top-code to the occasion quantity.
  q[q %in% c(88, 99, 888, 999, 8888, 9999) | !is.finite(q) | q <= 0] <- NA_real_
  # Reuse the tested EPS cleaning and volume derivation; grams=1 returns drinks/day.
  z <- eps_alcohol(s, f, pmin(q, 70), d$sex, grams = 1, aggregation = "max")
  daily <- z$grams_day
  s[!s %in% c(1, 2)] <- NA_real_; f[!f %in% 0:7] <- NA_real_
  yes <- !is.na(s) & s == 1; no <- !is.na(s) & s == 2
  fq <- f; fq[!is.na(fq) & fq == 0] <- .5
  if (available_max) {
    v <- fq * pmin(q, 70) / 7; v[!yes] <- NA_real_
    # A zero from another beverage's skip must not stand in for an unknown consumed quantity.
    daily <- apply(v, 1, function(x) if (all(is.na(x))) NA_real_ else max(x, na.rm = TRUE))
    daily[which(z$current == 0)] <- 0
    daily[z$contradiction] <- NA_real_
  }
  daily_cut <- ifelse(d$sex == "Men", 3, ifelse(d$sex == "Women", 2, NA_real_))
  quantity_cut <- ifelse(d$sex == "Men", 5, ifelse(d$sex == "Women", 4, NA_real_))
  positive_quantity <- rowSums(yes & !is.na(q) & q > quantity_cut, na.rm = TRUE) > 0
  quantity_known <- rowSums(no | (yes & !is.na(q))) == 3 & !is.na(quantity_cut)
  quantity_high <- ifelse(positive_quantity, 1, ifelse(quantity_known, 0, NA_real_))
  quantity_high[z$contradiction | is.na(quantity_cut)] <- NA_real_
  occasional <- rowSums(no | (yes & !is.na(f) & f == 0)) == 3
  regular <- rowSums(yes & !is.na(f) & f >= 1) > 0
  code <- rep(NA_integer_, nrow(d))
  abstainer <- which(z$current == 0 & !z$contradiction)
  code[abstainer] <- ifelse(lifetime[abstainer], 1L, 2L)
  low <- z$current == 1 & !is.na(daily) & daily <= daily_cut
  if (quantity_proxy) low <- low & !is.na(quantity_high) & quantity_high == 0
  code[which(low & regular)] <- 4L
  code[which(low & occasional)] <- 3L
  heavy <- z$current == 1 & !is.na(daily) & daily > daily_cut
  if (quantity_proxy) heavy <- heavy | (z$current == 1 & !is.na(quantity_high) & quantity_high == 1)
  code[which(heavy & !z$contradiction)] <- 0L
  data.frame(code, drinks_day = daily, typical_high_quantity = quantity_high)
}
eps_cp <- eps_history
ep <- eps_data$VIII[match(eps_cp$id, eps_data$VIII$id), ]
eps_cp$baseline_age <- eps_cp$age
eps_cp$age <- ep$age; eps_cp$age_group <- ep$age_group; eps_cp$education <- ep$education
eps_cp$sex <- ep$sex # Allocate coverage and missingness bounds to the endpoint-sex domain.
eps_cp$lifetime_proxy <- eps_lifetime_proxy(eps_cp$current0, eps_cp$current_mid, eps_cp$current1,
                                           eps_cp$good_link, 7.110)
eps_cp$lifetime_strict <- eps_lifetime_proxy(eps_cp$current0, eps_cp$current_mid, eps_cp$current1,
                                            eps_cp$good_link, 7.110, strict = TRUE)
eps_calvo_scenarios <- c("Calvo_volume_only_proxy", "Three_negative_interviews", "Typical_quantity_sensitivity", "Available_beverage_max")
eps_calvo_results <- lapply(seq_along(eps_calvo_scenarios), function(i) {
  z <- eps_calvo_classify(ep, if (i == 2) eps_cp$lifetime_strict else eps_cp$lifetime_proxy,
                        quantity_proxy = i == 3, available_max = i == 4)
  z$code[!eps_cp$good_link] <- NA_integer_
  z
})
names(eps_calvo_results) <- eps_calvo_scenarios
cp_design <- eps_design(eps_cp)
eps_calvo_prevalence <- do.call(rbind, lapply(eps_calvo_scenarios, function(sc) {
  codes <- eps_calvo_results[[sc]]$code
  indicators <- stats::setNames(lapply(eps_calvo_codes, function(k) ifelse(is.na(codes), NA_real_, as.numeric(codes == k))), eps_calvo_labels)
  do.call(rbind, lapply(c(FALSE, TRUE), function(edu) {
    out <- eps_indicator_table(cp_design, indicators, education = edu)
    out$code <- eps_calvo_codes[match(out$outcome, eps_calvo_labels)]
    cbind(wave = "VIII", population = "official_VI_VIII_panel", age_basis = "VIII_endpoint", scenario = sc, out)
  }))
}))
eps_cp_audit <- data.frame(n_panel = nrow(eps_cp), valid_link = sum(eps_cp$good_link),
  current_non_drinker = sum(eps_cp$current1 == 0, na.rm = TRUE),
  lifetime_proxy = sum(eps_cp$lifetime_proxy), three_negative_proxy = sum(eps_cp$lifetime_strict),
  intermediate_unknown_within_proxy = sum(eps_cp$lifetime_proxy & is.na(eps_cp$current_mid)),
  previous_positive_excluded = sum(eps_cp$current1 == 0 & (eps_cp$current0 == 1 | eps_cp$current_mid == 1), na.rm = TRUE))
# This separate EPS indicator is a typical-quantity proxy, not directly measured HED.
eps_quantity_prevalence <- do.call(rbind, lapply(names(eps_designs), function(w) {
  y <- eps_calvo_classify(eps_data[[w]])$typical_high_quantity
  cbind(wave = w, eps_indicator_table(eps_designs[[w]], list(Typical_high_quantity_proxy = y)))
}))
eps_save(eps_calvo_prevalence, "calvo_five_category_proxy_age_sex_education")
eps_save(eps_cp_audit, "calvo_lifetime_proxy_audit")
eps_save(eps_quantity_prevalence, "eps_typical_high_quantity_proxy_age_sex")
eps_table(eps_cp_audit, "Observed history supporting the Calvo lifetime approximation: unweighted counts")
eps_table(subset(eps_calvo_prevalence, scenario == "Calvo_volume_only_proxy" & education == "All" &
  age_group %in% c("66-70", "71-76"))[, c("age_group", "sex", "code", "outcome", "n_valid", "estimate", "lower", "upper", "coverage")],
  "Five-category Calvo volume proxy at VIII: official panel, endpoint age; HED unobserved")

eps_table(subset(eps_calvo_prevalence, education == "All" & age_group %in% c("66-70", "71-76") &
  code == 1 & scenario %in% c("Calvo_volume_only_proxy", "Three_negative_interviews"))[
  , c("scenario", "age_group", "sex", "estimate", "lower", "upper", "coverage")],
  "Lifetime proxy sensitivity: two negative endpoints versus three negative interviews")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))