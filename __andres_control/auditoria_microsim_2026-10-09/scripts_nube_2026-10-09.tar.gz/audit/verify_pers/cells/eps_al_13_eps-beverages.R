#| label: eps-beverages
.t0 <- Sys.time()
# Reuse the existing domain and proportion estimators for all additional binary outcomes.
eps_indicator_table <- function(des, indicators, education = FALSE) {
  stopifnot(all(lengths(indicators) == nrow(des$variables)), !is.null(names(indicators)))
  do.call(rbind, lapply(eps_domains(des$variables, education), function(g) {
    ix <- which(g$keep); ds <- des[ix, ]; wt <- ds$variables$weight
    do.call(rbind, lapply(names(indicators), function(nm) {
      y <- indicators[[nm]][ix]
      cbind(g$key, outcome = nm, eps_prop(ds, y),
        bound_lower = sum(wt[which(y == 1)]) / sum(wt),
        bound_upper = sum(wt[which(y == 1 | is.na(y))]) / sum(wt))
    }))
  }))
}
eps_beverage_names <- c("Beer", "Wine", "Spirits")
eps_beverage_use <- function(d) stats::setNames(lapply(1:3, function(j) {
  z <- d[[paste0("f13_", j)]]
  ifelse(z %in% c(1, 2), as.numeric(z == 1), NA_real_)
}), eps_beverage_names)
eps_beverage_prevalence <- do.call(rbind, lapply(names(eps_designs), function(w)
  cbind(wave = w, eps_indicator_table(eps_designs[[w]], eps_beverage_use(eps_data[[w]])))))
eps_beverage_education <- do.call(rbind, lapply(names(eps_designs), function(w)
  cbind(wave = w, eps_indicator_table(eps_designs[[w]], eps_beverage_use(eps_data[[w]]), education = TRUE))))
eps_save(eps_beverage_prevalence, "beverage_prevalence_age_sex")
eps_save(eps_beverage_education, "beverage_prevalence_age_sex_education")
eps_table(subset(eps_beverage_prevalence, wave == "VIII" & age_group %in% c("66-70", "71-76"))[
  , c("age_group", "sex", "outcome", "n_valid", "estimate", "lower", "upper", "coverage")],
  "VIII: beverage-specific declared use in the two added age groups")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))