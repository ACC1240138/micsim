#| label: eps-session
.t0 <- Sys.time()
eps_summary <- subset(eps_rho_table, age_group == "50+")
eps_save(eps_summary, "rho_summary_50plus")
# Export only aggregate estimates, diagnostics, provenance and figures, never person-level data.
eps_exports <- list.files(eps_out, pattern = "\\.(csv|png)$")
stopifnot(all(c("prevalence_age_sex.csv", "rho_summary_50plus.csv", "validation_checks.csv") %in% eps_exports))
writeLines(c(paste("Analysis date:", Sys.Date()), paste("Seed:", eps_seed),
  "No automatic update of the microsimulation; annual rho is conditional on homogeneous Gaussian AR(1).",
  "True lifetime abstinence is not identified; a separately labelled Calvo >=4-year history proxy is estimated.",
  "ENPG HED uses 5+/4+ thresholds and ends at age 65; EPS typical high quantity is a different proxy.",
  utils::capture.output(utils::sessionInfo())), file.path(eps_out, "session_info.txt"))
print(utils::sessionInfo())
cat("EPS_ALCOHOL_VALIDATION=PASS\n")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))