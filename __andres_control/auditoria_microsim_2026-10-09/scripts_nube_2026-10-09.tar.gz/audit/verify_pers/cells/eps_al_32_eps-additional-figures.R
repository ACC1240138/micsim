#| label: eps-additional-figures
.t0 <- Sys.time()
bp <- subset(eps_beverage_prevalence, wave == "VIII")
bp$age_group <- factor(bp$age_group, levels = eps_age_levels)
eps_beverage_plot <- ggplot2::ggplot(bp, ggplot2::aes(age_group, estimate * 100, colour = outcome)) +
  ggplot2::geom_point(position = ggplot2::position_dodge(.5), size = 2) +
  ggplot2::geom_errorbar(ggplot2::aes(ymin = lower * 100, ymax = upper * 100), width = .12,
    position = ggplot2::position_dodge(.5)) + ggplot2::facet_wrap(~sex) +
  ggplot2::scale_colour_manual(values = c(Beer = "#0072B2", Wine = "#CC79A7", Spirits = "#D55E00")) +
  ggplot2::theme_minimal(base_size = 12) + ggplot2::labs(x = "Age at interview", y = "Declared use (%)", colour = "Beverage",
    title = "EPS VIII: beer, wine and spirits",
    caption = "Consumers overlap across beverages; percentages do not sum to any-alcohol prevalence.\nSpirits = pisco or other liquor. Working 95% CIs use the available survey design.")
print(eps_beverage_plot)
ggplot2::ggsave(file.path(eps_out, "beverage_prevalence_VIII.png"), eps_beverage_plot, width = 11, height = 5.8, dpi = 180, bg = "white")
cp <- subset(eps_calvo_prevalence, scenario == "Calvo_volume_only_proxy" & education == "All" &
  age_group %in% c("60-65", "66-70", "71-76", "77+"))
cp$outcome <- factor(cp$outcome, levels = eps_calvo_labels)
eps_calvo_plot <- ggplot2::ggplot(cp, ggplot2::aes(age_group, estimate * 100, fill = outcome)) +
  ggplot2::geom_col(width = .72, position = ggplot2::position_stack(reverse = TRUE)) + ggplot2::facet_wrap(~sex) +
  ggplot2::scale_fill_manual(values = c("#576b99", "#bac5dd", "#76c5b4", "#eec369", "#c66a56"),
    labels = c("Lifetime proxy", "Current abstainer", "Occasional proxy", "Moderate proxy", "Heavy proxy")) +
  ggplot2::theme_minimal(base_size = 12) + ggplot2::labs(x = "Age at VIII", y = "Among classified panel respondents (%)", fill = "Calvo approximation",
    title = "Five categories: lifetime history is approximated, HED is unobserved",
    caption = "Official VI-VIII panel; endpoint age. Daily-volume thresholds >3 drinks in men / >2 in women.\nLifetime proxy: negative endpoints >=4 years apart and no observed intervening use. CIs and coverage are in the CSV.") +
  ggplot2::theme(legend.position = "bottom", legend.title = ggplot2::element_blank())
print(eps_calvo_plot)
ggplot2::ggsave(file.path(eps_out, "calvo_five_categories_VIII_panel.png"), eps_calvo_plot, width = 12, height = 6, dpi = 180, bg = "white")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))