#| label: enpg-figure
.t0 <- Sys.time()
np <- subset(enpg_prevalence, denominator == "Age-sex population" & age_group != "15-17")
np$age_group <- factor(np$age_group, levels = eps_age_levels)
enpg_plot <- ggplot2::ggplot(np, ggplot2::aes(age_group, estimate * 100, colour = outcome)) +
  ggplot2::annotate("rect", xmin = 4.5, xmax = 7.5, ymin = -Inf, ymax = Inf, fill = "#eeeeee", colour = NA) +
  ggplot2::geom_point(position = ggplot2::position_dodge(.4), size = 2, na.rm = TRUE) +
  ggplot2::geom_errorbar(ggplot2::aes(ymin = lower * 100, ymax = upper * 100), width = .12,
    position = ggplot2::position_dodge(.4), na.rm = TRUE) + ggplot2::facet_wrap(~sex) +
  ggplot2::scale_x_discrete(drop = FALSE) + ggplot2::scale_colour_manual(values = c("#0072B2", "#D55E00")) +
  ggplot2::annotate("text", x = 6, y = 30, label = "Outside ENPG\nage coverage", colour = "#555555", size = 3.4) +
  ggplot2::theme_minimal(base_size = 12) + ggplot2::labs(x = "Age at interview", y = "Population prevalence (%)", colour = "Outcome",
    title = "ENPG 2024: 30-day alcohol use and directly asked HED",
    caption = "HED: >=5 drinks per occasion in men / >=4 in women; at least one occasion in the question's 30-day window.\nBoth series use the age-sex population denominator among valid responses. Grey ages are unavailable, not abstainers.") +
  ggplot2::theme(legend.position = "bottom")
print(enpg_plot)
ggplot2::ggsave(file.path(eps_out, "enpg2024_current_HED_age_coverage.png"), enpg_plot, width = 12, height = 5.8, dpi = 180, bg = "white")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))