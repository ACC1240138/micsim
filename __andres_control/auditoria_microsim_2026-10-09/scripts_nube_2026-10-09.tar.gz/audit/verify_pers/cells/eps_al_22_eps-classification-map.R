#| label: eps-classification-map
.t0 <- Sys.time()
flow_nodes <- data.frame(x = c(0, 3, 6, 9, 0, 3, 6, 9), y = c(2, 2, 2, 2, 0, 0, 0, 0),
  text = c("F13: no current use", "VI and VIII negative\n>=4 years apart", "No positive at valid VII\nMissing VII allowed in main proxy",
    "1: Lifetime proxy\nOtherwise 2: Current abstainer",
    "F13: current use", "Max beverage mean drinks/day\n>3 men or >2 women?",
    "YES: 0 Heavy proxy\nNO: check frequency", "All consumed types <1 day/week:\n3 Occasional proxy\nOtherwise weekly: 4 Moderate proxy"))
flow_edges <- data.frame(x = rep(c(1.23, 4.23, 7.23), 2), xend = rep(c(1.75, 4.75, 7.75), 2), y = rep(c(2, 0), each = 3))
eps_flow <- ggplot2::ggplot() +
  ggplot2::geom_rect(data = flow_nodes, ggplot2::aes(xmin = x - 1.23, xmax = x + 1.23, ymin = y - .45, ymax = y + .45),
    fill = rep(c("#e9ecf7", "#e6f2f0"), each = 4), colour = "#4c5866") +
  ggplot2::geom_text(data = flow_nodes, ggplot2::aes(x, y, label = text), size = 3.05, lineheight = 1.12) +
  ggplot2::geom_segment(data = flow_edges, ggplot2::aes(x = x, xend = xend, y = y, yend = y),
    arrow = grid::arrow(length = grid::unit(.13, "inches"))) +
  ggplot2::coord_cartesian(xlim = c(-1.45, 10.45), ylim = c(-.7, 2.7), clip = "off") +
  ggplot2::theme_void(base_size = 12) + ggplot2::labs(title = "How the five-category proxy is constructed at VIII",
    caption = "Unknown/contradictory inputs stay unclassified. No future responses are used.\nHED is unobserved: the separate quantity sensitivity can promote additional respondents to Heavy.") +
  ggplot2::theme(plot.background = ggplot2::element_rect(fill = "white", colour = NA), plot.title = ggplot2::element_text(face = "bold"), plot.margin = ggplot2::margin(15, 15, 15, 15))
print(eps_flow)
ggplot2::ggsave(file.path(eps_out, "calvo_classification_map.png"), eps_flow, width = 15, height = 5.2, dpi = 180, bg = "white")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))