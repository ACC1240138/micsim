# Independent EPS check: same-people 50+ status correlations (own weighted tetrachoric), own PSU bootstrap of the
# AR(1) diagnostic r(VI-VIII) > r(VI-VII) r(VII-VIII), and amount persistence on a COMMON drinking sample.
# Data preparation reuses the project notebook's harmonisation cells (eps-inputs, eps-harmonize, eps_make_pair);
# all estimators below are my own code. Aggregated output only.
.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>/__andres_control")
source(file.path("<repo>", "_tools", "acc_data.R"))
V <- "<scratch>/audit/verify_pers"
eps_root <- acc_data("_eps/eps.tar.xz.enc"); eps_abs <- function(x) file.path(eps_root, sub("^_eps/", "", x))
scr <- file.path(V, "out", "eps_scratch"); dir.create(scr, showWarnings = FALSE)
eps_save <- function(x, name) utils::write.csv(x, file.path(scr, paste0(name, ".csv")), row.names = FALSE, na = "")
options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE); set.seed(1240138L)
eps_age_levels <- c("18-29", "30-44", "45-59", "60-65", "66-70", "71-76", "77+")
eps_edu_levels <- c("Primary completed or less", "Secondary completed or less", "Tertiary completed or higher")
eps_states <- c("Current abstainer (history unknown)", "Occasional (frequency proxy)", "Moderate", "Heavy")
eps_table <- function(...) invisible(NULL)
eps_read <- function(path) { x <- as.data.frame(haven::read_dta(eps_abs(path))); stopifnot(!anyDuplicated(x$folio_n20)); x }
ev <- function(f, only = NULL) { ex <- parse(file.path(V, "cells", f), keep.source = FALSE)
  for (e in ex) { lhs <- if (is.call(e) && identical(e[[1]], as.name("<-"))) deparse(e[[2]])[1] else ""
    if (is.null(only) || lhs %in% only) eval(e, envir = globalenv()) } }
ev("eps_al_07_eps-inputs.R"); ev("eps_al_09_eps-harmonize.R")
eps_design <- function(d, weights_only = FALSE) survey::svydesign(ids = ~psu, strata = ~strata, weights = ~weight, data = d, nest = TRUE)
ev("eps_al_19_eps-panel.R", c("eps_time", "eps_make_pair", "eps_pairs"))
# --- my own same-people panel ---
P <- eps_pairs$VI_VIII; M <- eps_data$VII_presencial[match(P$id, eps_data$VII_presencial$id), ]
okm <- !is.na(M$id) & M$sex == P$sex & (M$age - P$age) %in% 3:5 & (P$age_end - M$age) %in% 3:5
P$c0 <- P$current0; P$cm <- ifelse(okm, M$current, NA); P$c1 <- P$current1; P$gm <- ifelse(okm, M$grams_day, NA)
T3 <- P[P$good_link & okm & !is.na(P$c0) & !is.na(P$cm) & !is.na(P$c1), ]
cat("same-people triples, all ages:", nrow(T3), " 50+:", sum(T3$age >= 50), "\n")
tet <- function(x, y, w) { p11 <- sum(w * (x == 1 & y == 1)) / sum(w); px <- sum(w * x) / sum(w); py <- sum(w * y) / sum(w)
  f <- function(r) mvtnorm::pmvnorm(upper = qnorm(c(px, py)), corr = matrix(c(1, r, r, 1), 2))[1] - p11
  uniroot(f, c(-.995, .995), tol = 1e-8)$root }
r3 <- function(d, w = d$weight) c(r12 = tet(d$c0, d$cm, w), r23 = tet(d$cm, d$c1, w), r13 = tet(d$c0, d$c1, w))
S <- T3[T3$age >= 50, ]; est <- r3(S); print(round(est, 4))
pub <- read.csv("eps_alcohol_outputs/rho_same_people_three_interviews.csv"); pub <- pub[pub$sex == "All", ]
cmp <- data.frame(pair = c("VI_VII", "VII_VIII", "VI_VIII"), mine = unname(est), n_mine = nrow(S),
  published = pub$rho_interval[match(c("VI_VII_same_people", "VII_VIII_same_people", "VI_VIII_same_people"), pub$pair)], n_pub = pub$n[1])
print(cmp)
prev <- data.frame(p_VI = weighted.mean(S$c0, S$weight), p_VII = weighted.mean(S$cm, S$weight), p_VIII = weighted.mean(S$c1, S$weight), n = nrow(S), age_min = min(S$age), age_p50 = median(S$age), age_max = max(S$age)); print(prev); write.csv(prev, file.path(V, "out", "v4_eps_prev_50plus.csv"), row.names = FALSE)
# --- own PSU bootstrap (resample clusters with replacement, ignore strata) ---
B <- if (nzchar(Sys.getenv("V4_B"))) as.integer(Sys.getenv("V4_B")) else 400; cl <- split(seq_len(nrow(S)), S$psu); nc <- length(cl)
bt <- t(replicate(B, { i <- unlist(cl[sample.int(nc, nc, replace = TRUE)], use.names = FALSE); r3(S[i, ]) }))
rm <- function(l, p, d) l + (1 - l) * p^d; lags <- c(3.671, 4.022, 7.693)
se_z <- (atanh(pub$upper) - atanh(pub$lower)) / (2 * qnorm(.975))
se_z <- se_z[match(c("VI_VII_same_people", "VII_VIII_same_people", "VI_VIII_same_people"), pub$pair)]
fit <- function(r) { f <- function(q) sum(((atanh(r) - atanh(rm(plogis(q[1]), plogis(q[2]), lags))) / se_z)^2)
  st <- expand.grid(a = qlogis(c(.1, .4, .7)), b = qlogis(c(.3, .6, .9)))
  o <- lapply(seq_len(nrow(st)), function(j) optim(unlist(st[j, ]), f, control = list(reltol = 1e-10, maxit = 3000)))
  b <- o[[which.min(sapply(o, `[[`, "value"))]]; c(lambda = plogis(b$par[1]), phi = plogis(b$par[2])) }
bf <- t(apply(bt, 1, fit))
boot <- data.frame(B = B, clusters = nc, share_long_gt_product = mean(bt[, 3] > bt[, 1] * bt[, 2]),
  min_long_minus_product = min(bt[, 3] - bt[, 1] * bt[, 2]),
  lambda_lo = quantile(bf[, 1], .025), lambda_hi = quantile(bf[, 1], .975), phi_lo = quantile(bf[, 2], .025), phi_hi = quantile(bf[, 2], .975),
  r10_lo = quantile(rm(bf[, 1], bf[, 2], 10), .025), r10_hi = quantile(rm(bf[, 1], bf[, 2], 10), .975),
  r1_lo = quantile(rm(bf[, 1], bf[, 2], 1), .025), r1_hi = quantile(rm(bf[, 1], bf[, 2], 1), .975), row.names = NULL)
print(boot)
# --- amount: weighted normal-score correlation, people drinking with grams > 0 at ALL three interviews (common sample) ---
ns <- function(v, w) { o <- order(v); cw <- cumsum(w[o]) / sum(w); r <- numeric(length(v)); r[o] <- cw - w[o] / (2 * sum(w)); qnorm(r) }
wc <- function(a, b, w) cov.wt(cbind(ns(a, w), ns(b, w)), wt = w / sum(w), cor = TRUE)$cor[1, 2]
A <- T3[T3$c0 == 1 & T3$cm == 1 & T3$c1 == 1 & is.finite(T3$grams0) & is.finite(T3$gm) & is.finite(T3$grams1) &
        T3$grams0 > 0 & T3$gm > 0 & T3$grams1 > 0, ]
amt <- data.frame(sample = "common: drinking g>0 at VI, VII, VIII, all ages", n = nrow(A),
  r_VI_VII = wc(A$grams0, A$gm, A$weight), r_VII_VIII = wc(A$gm, A$grams1, A$weight), r_VI_VIII = wc(A$grams0, A$grams1, A$weight),
  spearman_unw_VI_VII = cor(A$grams0, A$gm, method = "spearman"), spearman_unw_VII_VIII = cor(A$gm, A$grams1, method = "spearman"),
  spearman_unw_VI_VIII = cor(A$grams0, A$grams1, method = "spearman"))
clA <- split(seq_len(nrow(A)), A$psu)
ab <- t(replicate(300, { i <- unlist(clA[sample.int(length(clA), length(clA), TRUE)], use.names = FALSE)
  c(wc(A$grams0[i], A$gm[i], A$weight[i]), wc(A$gm[i], A$grams1[i], A$weight[i]), wc(A$grams0[i], A$grams1[i], A$weight[i])) }))
amt$ci <- paste(apply(ab, 2, function(z) sprintf("%.2f-%.2f", quantile(z, .025), quantile(z, .975))), collapse = " / ")
print(amt)
write.csv(cmp, file.path(V, "out", "v4_eps_same_people_50plus.csv"), row.names = FALSE)
write.csv(boot, file.path(V, "out", "v4_eps_boot.csv"), row.names = FALSE)
write.csv(amt, file.path(V, "out", "v4_eps_amount_common.csv"), row.names = FALSE)
message(sprintf("v4_eps elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
