# Retrospective never-by-age (OH_3) vs cross-sectional never at single ages, 2014-2022 pooled (equal-wave weights).
.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>/__andres_control"); source(file.path("<repo>", "_tools", "acc_data.R"))
OUT <- "<scratch>/audit/verify_pers/out"
r <- as.data.frame(readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS")))
des <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/enpg_design_waves_2012_2024_list.RDS"))
wt <- do.call(rbind, lapply(names(des$waves), function(y) data.frame(year = as.integer(y), id = as.character(des$waves[[y]]$id_join), w = as.numeric(des$waves[[y]]$weight))))
r$w <- wt$w[match(paste(r$year, as.character(r$id)), paste(wt$year, wt$id))]; stopifnot(!anyNA(r$w))
raw <- list(`2014` = c("Base de datos ENPG 2014 (PG).DTA.dta", "idencuesta", "oh3"), `2016` = c("base ENPG 2016 publico general.dta", "idencuesta", "oh_3"),
  `2018` = c("Base de datos ENPG 2018 (PG).DTA", "SbjNum", "OH_3"), `2020` = c("enpg2020.RDS", "SbjNum", "OH_3"), `2022` = c("BD - ENPG 2022 (Stata 16).dta", "FOLIO", "OH_3"))
R <- do.call(rbind, lapply(names(raw), function(y) { f <- raw[[y]]; p <- acc_data("_enpg/enpg.tar.xz.enc", f[1])
  x <- if (grepl("RDS$", p)) as.data.frame(readRDS(p))[f[2:3]] else as.data.frame(haven::read_dta(p, col_select = dplyr::all_of(f[2:3])))
  data.frame(year = as.integer(y), id = as.character(as.numeric(x[[1]])), onset = as.numeric(x[[2]])) }))
e <- r[r$year %in% 2014:2022 & !is.na(r$oh1), ]; e$age <- as.integer(e$edad); e$sex <- ifelse(e$sexo == "Hombre", "M", "F")
e$never <- as.character(e$oh1) == "No"; e$onset <- R$onset[match(paste(e$year, as.character(e$id)), paste(R$year, R$id))]
e$onset[e$onset %in% c(88, 99, 888, 999) | e$onset > e$age] <- NA
e$wp <- e$w / ave(e$w, e$year, FUN = sum)
xs <- do.call(rbind, lapply(15:25, function(a) do.call(rbind, lapply(c("M", "F"), function(s) { x <- e[e$age == a & e$sex == s, ]
  data.frame(age = a, sex = s, n = nrow(x), cross_never = 100 * sum(x$wp * x$never) / sum(x$wp)) }))))
# retrospective: respondents aged 18-32 (born ~1982-2004), never-by-a = never or onset > a; ever-drinkers with unknown onset dropped
rt <- do.call(rbind, lapply(14:24, function(a) do.call(rbind, lapply(c("M", "F"), function(s) {
  x <- e[e$sex == s & e$age > a + 1 & e$age <= 32 & (e$never | !is.na(e$onset)), ]
  data.frame(age_end = a, sex = s, n = nrow(x), retro_never_by_end_of_age = 100 * sum(x$wp * (x$never | x$onset > a)) / sum(x$wp)) }))))
m <- merge(xs, transform(rt, age = age_end + 1)[c("age", "sex", "retro_never_by_end_of_age")], by = c("age", "sex"), all.x = TRUE)
print(m[order(m$sex, m$age), ]); write.csv(m, file.path(OUT, "v6_onset_retro_vs_cross.csv"), row.names = FALSE)
message(sprintf("v6 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
