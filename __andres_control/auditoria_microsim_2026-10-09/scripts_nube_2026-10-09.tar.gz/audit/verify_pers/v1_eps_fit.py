"""Independent re-fit of trait + AR(1) to the published EPS same-people correlations (no microdata).
Different optimiser (scipy L-BFGS-B on the box, dense grid) from the audited R code; adds a GLS check
using the bootstrap correlation of the three atanh(r) reported by the audited script."""
import time, numpy as np, pandas as pd
from scipy import optimize, stats
t0 = time.time()
EO = "<repo>/__andres_control/eps_alcohol_outputs"
AU = "<scratch>/audit"
sp = pd.read_csv(f"{EO}/rho_same_people_three_interviews.csv")
iv = pd.read_csv(f"{EO}/interview_interval_assumptions.csv")
lag = {"VI_VII_same_people": float(iv.delta[iv.pair == "VI_VII"].iloc[0]), "VII_VIII_same_people": 4.022,
       "VI_VIII_same_people": float(iv.delta[iv.pair == "VI_VIII"].iloc[0])}
rm = lambda l, p, d: l + (1 - l) * p ** d
out = []
for sex in ["All", "Men", "Women"]:
    x = sp[sp.sex == sex].set_index("pair").loc[list(lag)]
    r = x.rho_interval.values; d = np.array(list(lag.values()))
    se = (np.arctanh(x.upper.values) - np.arctanh(x.lower.values)) / (2 * stats.norm.ppf(.975))
    obj = lambda l, p, V=None: (lambda e: e @ np.linalg.solve(V, e) if V is not None else np.sum((e / se) ** 2))(np.arctanh(r) - np.arctanh(rm(l, p, d)))
    # dense grid then polish
    L, P = np.meshgrid(np.linspace(0, .95, 381), np.linspace(.001, .999, 500), indexing="ij")
    G = np.vectorize(lambda l, p: obj(l, p))(L, P)
    i = np.unravel_index(G.argmin(), G.shape)
    f = optimize.minimize(lambda v: obj(*v), [L[i], P[i]], bounds=[(0, .99), (1e-4, .9999)], method="L-BFGS-B")
    a1 = optimize.minimize_scalar(lambda p: obj(0, p), bounds=(1e-4, .9999), method="bounded")
    reg = G - G.min() <= 5.99
    row = dict(sex=sex, lam=f.x[0], phi=f.x[1], obj=f.fun, ar1_phi=a1.x, ar1_obj=a1.fun,
               obj_eng=obj(0, .8), obj_045_065=obj(.45, .65), r1=rm(*f.x, 1), r10=rm(*f.x, 10),
               eng_r10=.8 ** 10, long_minus_product=r[2] - r[0] * r[1],
               reg_lam=(L[reg].min(), L[reg].max()), reg_phi=(P[reg].min(), P[reg].max()),
               reg_r1=(rm(L[reg], P[reg], 1).min(), rm(L[reg], P[reg], 1).max()),
               reg_r10=(rm(L[reg], P[reg], 10).min(), rm(L[reg], P[reg], 10).max()))
    if sex == "All":
        # GLS with the audited bootstrap correlation among atanh r (12, 13, 23) = .10/.31/.19 (report §1)
        b = pd.read_csv(f"{AU}/out/p2_boot_lambda_phi_by_age_sex.csv")
        bb = b[(b.age == "50+") & (b.sex == "All")].iloc[0]
        C = np.array([[1, bb.corr_z_12, bb.corr_z_13], [bb.corr_z_12, 1, bb.corr_z_23], [bb.corr_z_13, bb.corr_z_23, 1]])
        V = np.outer(se, se) * C
        g = optimize.minimize(lambda v: obj(*v, V), f.x, bounds=[(0, .99), (1e-4, .9999)], method="L-BFGS-B")
        ga = optimize.minimize_scalar(lambda p: obj(0, p, V), bounds=(1e-4, .9999), method="bounded")
        row.update(gls_corr=(bb.corr_z_12, bb.corr_z_13, bb.corr_z_23), gls_lam=g.x[0], gls_phi=g.x[1], gls_obj=g.fun,
                   gls_ar1_obj=ga.fun, gls_eng=obj(0, .8, V),
                   gls_lr_p=stats.chi2.sf(ga.fun - g.fun, 1))
    out.append(row)
    # switching at p=.45 for an annual step: 2(p - P11)
    def sw(rho, p=.45):
        t = stats.norm.ppf(p); p11 = stats.multivariate_normal(cov=[[1, rho], [rho, 1]]).cdf([t, t]); return 2 * (p - p11)
    row.update(switch_engine=sw(.8), switch_fit=sw(rm(*f.x, 1)))
res = pd.DataFrame(out)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
print(res.T.to_string())
res.to_csv("<scratch>/audit/verify_pers/out/v1_eps_fit.csv", index=False)
print(f"v1_eps_fit elapsed minutes: {(time.time()-t0)/60:.2f}")
