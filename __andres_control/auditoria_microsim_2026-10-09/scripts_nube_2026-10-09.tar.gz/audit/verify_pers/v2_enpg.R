# Independent ENPG checks for persistence.md claims 7-9 and the circularity of claim 12.
# Own code (no reuse of p3_enpg_targets.R / nbsrc). Point estimates only (weights), aggregated output only.
.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>/__andres_control")
source(file.path("<repo>", "_tools", "acc_data.R"))
OUT <- "<scratch>/audit/verify_pers/out"
r <- as.data.frame(readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS")))
des <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/enpg_design_waves_2012_2024_list.RDS"))
wt <- do.call(rbind, lapply(names(des$waves), function(y) data.frame(year = as.integer(y),
  id = as.character(des$waves[[y]]$id_join), w = as.numeric(des$waves[[y]]$weight))))
k <- match(paste(r$year, as.character(r$id)), paste(wt$year, wt$id)); stopifnot(!anyNA(k))
e <- data.frame(year = as.integer(r$year), id = as.character(r$id), sex = ifelse(r$sexo == "Hombre", "M", "F"),
  age = as.integer(r$edad), w = wt$w[k], w_exp = as.numeric(r$exp), oh1 = as.character(r$oh1), rec = as.character(r$oh2))
e <- e[e$age >= 15 & e$age <= 65, ]
# Status: never = oh1 No; current = last use within 30 d; former = ever & not 30 d. Unknown otherwise.
e$st <- ifelse(e$oh1 %in% "No", "never", ifelse(e$oh1 %in% "Si" & e$rec %in% "30 dias", "current",
  ifelse(e$oh1 %in% "Si" & !is.na(e$rec), "former", "unknown")))
e$former12 <- e$oh1 %in% "Si" & e$rec %in% grep("^>1", unique(e$rec), value = TRUE)
wm <- function(x, w) sum(w * x) / sum(w)
# (a) whole-domain shares by wave, unknown excluded (two weight sources) and unknown share
A <- do.call(rbind, lapply(split(e, e$year), function(x) { k <- x$st != "unknown"; y <- x[k, ]
  data.frame(year = x$year[1], n_domain = nrow(x), n_known = nrow(y), unknown_pct = 100 * wm(!k, x$w),
    never = 100 * wm(y$st == "never", y$w), former_any = 100 * wm(y$st == "former", y$w),
    former12 = 100 * wm(y$former12, y$w), current = 100 * wm(y$st == "current", y$w),
    never_expwt = 100 * wm(y$st == "never", y$w_exp), former_expwt = 100 * wm(y$st == "former", y$w_exp)) }))
print(format(A, digits = 3)); write.csv(A, file.path(OUT, "v2_enpg_overall.csv"), row.names = FALSE)
# (b) pseudo-cohort never share (birth = year - age), all 5-year cohorts; jumps 2014-2012 and 2024-2022
e$birth <- e$year - e$age; e$coh <- 5 * floor(e$birth / 5)
kn <- e[e$st != "unknown", ]
B <- aggregate(cbind(nw = kn$w * (kn$st == "never"), w = kn$w, n = 1) ~ sex + coh + year, kn, sum)
B$never <- 100 * B$nw / B$w
print(B[(B$sex == "F" & B$coh == 1975) | (B$sex == "M" & B$coh == 1970), c("sex", "coh", "year", "n", "never")])
Bw <- reshape(B[c("sex", "coh", "year", "never", "n")], idvar = c("sex", "coh"), timevar = "year", direction = "wide")
Bw <- Bw[complete.cases(Bw[grep("never", names(Bw))]) & Bw$n.2012 >= 300 & Bw$n.2024 >= 300, ]
Bw$mid_mean <- rowMeans(Bw[paste0("never.", c(2014, 2016, 2018, 2020, 2022))])
Bw$jump12 <- Bw$never.2012 - Bw$never.2014; Bw$jump24 <- Bw$never.2024 - Bw$never.2022
Bw$dev12_mid <- Bw$never.2012 - Bw$mid_mean; Bw$dev24_mid <- Bw$never.2024 - Bw$mid_mean
print(format(Bw[c("sex", "coh", "n.2012", "n.2024", "never.2012", "mid_mean", "never.2024", "jump12", "jump24", "dev12_mid", "dev24_mid")], digits = 3))
write.csv(Bw, file.path(OUT, "v2_enpg_pseudocohort.csv"), row.names = FALSE)
# (c) raw onset items: first-time recency (OH_2 / p11), onset age (OH_3 / p12), last-time recency (OH_4 / p13)
raw <- list(`2012` = c("Base de datos ENPG 2012 (PG).DTA.dta", "idencuesta", "p11", "p12", "p13"),
  `2014` = c("Base de datos ENPG 2014 (PG).DTA.dta", "idencuesta", "oh2", "oh3", "oh4"),
  `2016` = c("base ENPG 2016 publico general.dta", "idencuesta", "oh_2", "oh_3", "oh_4"),
  `2018` = c("Base de datos ENPG 2018 (PG).DTA", "SbjNum", "OH_2", "OH_3", "OH_4"),
  `2020` = c("enpg2020.RDS", "SbjNum", "OH_2", "OH_3", "OH_4"),
  `2022` = c("BD - ENPG 2022 (Stata 16).dta", "FOLIO", "OH_2", "OH_3", "OH_4"),
  `2024` = c("Base Publica ENPG 2024 (Stata 16).dta", "RESPONDENT_SERIAL", "OH_2", "OH_3", "OH_4"))
R <- do.call(rbind, lapply(names(raw), function(y) { f <- raw[[y]]; p <- acc_data("_enpg/enpg.tar.xz.enc", f[1])
  x <- if (grepl("RDS$", p)) as.data.frame(readRDS(p))[f[2:5]] else as.data.frame(haven::read_dta(p, col_select = dplyr::all_of(f[2:5])))
  data.frame(year = as.integer(y), id = as.character(as.numeric(x[[1]])), first = as.numeric(x[[2]]),
    onset = as.numeric(x[[3]]), last = as.numeric(x[[4]])) }))
k <- match(paste(e$year, e$id), paste(R$year, R$id)); cat("unlinked:", sum(is.na(k)), "of", nrow(e), "\n")
e$first <- R$first[k]; e$onset <- R$onset[k]; e$last <- R$last[k]
# Which raw item is the derived recency? (derived '30 dias' should be raw code 1)
e$rec_code <- match(e$rec, c("30 dias", ">30", grep("^>1", unique(e$rec), value = TRUE)))
C <- do.call(rbind, lapply(split(e[e$oh1 %in% "Si", ], e$year[e$oh1 %in% "Si"]), function(x) data.frame(year = x$year[1], n_ever = nrow(x),
  derived_eq_rawlast = mean(x$rec_code == x$last, na.rm = TRUE), derived_eq_rawfirst = mean(x$rec_code == x$first, na.rm = TRUE),
  rawfirst_eq_rawlast = mean(x$first[x$first %in% 1:3] == x$last[x$first %in% 1:3] , na.rm = TRUE),
  first_in_12m_wpct = 100 * wm(x$first %in% 1:2, x$w), last_in_12m_wpct = 100 * wm(x$last %in% 1:2, x$w))))
print(format(C, digits = 3)); write.csv(C, file.path(OUT, "v2_enpg_item_identity.csv"), row.names = FALSE)
# OH_2 validity: first use within 12 months but onset age < age - 1 (onset 88/99/888/999 or >age -> unknown)
e$onset_ok <- ifelse(e$onset %in% c(88, 99, 888, 999) | e$onset < 5 | e$onset > e$age, NA, e$onset)
V <- do.call(rbind, lapply(split(e, e$year), function(x) { v <- x[x$oh1 %in% "Si" & x$first %in% 1:2, ]
  data.frame(year = x$year[1], n_first12 = nrow(v), n_onset_known = sum(!is.na(v$onset_ok)),
    n_inconsistent = sum(v$onset_ok < v$age - 1, na.rm = TRUE)) }))
V$pct_of_all <- 100 * V$n_inconsistent / V$n_first12; V$pct_of_known <- 100 * V$n_inconsistent / V$n_onset_known
print(V); write.csv(V, file.path(OUT, "v2_enpg_oh2_validity.csv"), row.names = FALSE)
# (d) circularity: pooled never by sex x age group (waves weighted equally, as the prototype's s_target)
e$ag <- findInterval(e$age, c(15, 30, 45, 60))
kn <- e[e$st != "unknown", ]; kn$wp <- kn$w / ave(kn$w, kn$year, FUN = sum)
cell <- aggregate(cbind(nv = kn$w * (kn$st == "never"), fo = kn$w * (kn$st == "former"), cu = kn$w * (kn$st == "current"), w = kn$w) ~ year + sex + ag, kn, sum)
cell[c("never", "former", "current")] <- 100 * cell[c("nv", "fo", "cu")] / cell$w
pl <- aggregate(cbind(nv = kn$wp * (kn$st == "never"), w = kn$wp) ~ sex + ag, kn, sum); pl$never_pooled <- 100 * pl$nv / pl$w
cell <- merge(cell, pl[c("sex", "ag", "never_pooled")])
mid <- cell[cell$year %in% c(2014, 2016, 2018, 2020, 2022), ]
mid$dev_never <- mid$never_pooled - mid$never
mid$dev_former <- (100 - mid$current - mid$never_pooled) - mid$former   # former implied by wave current + pooled never
D <- data.frame(cells = nrow(mid), never_mean_abs = mean(abs(mid$dev_never)), never_share_le5 = mean(abs(mid$dev_never) <= 5),
  former_mean_abs = mean(abs(mid$dev_former)), former_share_le5 = mean(abs(mid$dev_former) <= 5),
  never_mean_abs_ag234 = mean(abs(mid$dev_never[mid$ag > 1])), never_mean_abs_ag1 = mean(abs(mid$dev_never[mid$ag == 1])))
print(D); write.csv(D, file.path(OUT, "v2_enpg_pooled_plugin_vs_waves.csv"), row.names = FALSE)
write.csv(cell[c("year", "sex", "ag", "never", "former", "current", "never_pooled")], file.path(OUT, "v2_enpg_cells.csv"), row.names = FALSE)
message(sprintf("v2_enpg elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
