"""Independent mover-stayer refit: observed tetrachoric implied by a share s of never-drinking stayers plus movers
with latent corr lam + (1-lam) phi^d. Uses the OBSERVED VII margin (0.326, v4) instead of the audited midpoint 0.3025.
Grid search (own code). Reports best (lam, phi), engine (0, 0.8) and best pure AR(1) objectives, and Delta."""
import time, numpy as np, pandas as pd
from scipy.stats import norm, multivariate_normal
from scipy.optimize import brentq
t0 = time.time()
sp = pd.read_csv("<repo>/__andres_control/eps_alcohol_outputs/rho_same_people_three_interviews.csv")
sp = sp[sp.sex == "All"].set_index("pair").loc[["VI_VII_same_people", "VII_VIII_same_people", "VI_VIII_same_people"]]
r_obs = sp.rho_interval.values; se = (np.arctanh(sp.upper.values) - np.arctanh(sp.lower.values)) / (2 * norm.ppf(.975))
lags = np.array([3.671, 4.022, 7.693]); pairs = [(0, 1), (1, 2), (0, 2)]
prev = pd.read_csv("<scratch>/audit/verify_pers/out/v4_eps_prev_50plus.csv").iloc[0]
P = [prev.p_VI, prev.p_VII, prev.p_VIII]
F = lambda h, k, r: multivariate_normal(cov=[[1, r], [r, 1]]).cdf([h, k])
def tet(pa, pb, p11): return brentq(lambda r: F(norm.ppf(pa), norm.ppf(pb), r) - p11, -.999, .999, xtol=1e-8)
def obj(l, f, s):
    r = []
    for (i, j), d in zip(pairs, lags):
        rm = l + (1 - l) * f ** d
        r.append(tet(P[i], P[j], (1 - s) * F(norm.ppf(P[i] / (1 - s)), norm.ppf(P[j] / (1 - s)), rm)))
    return float((((np.arctanh(r_obs) - np.arctanh(np.array(r))) / se) ** 2).sum())
rows = []
for s in [0.0, 0.20, 0.25, 0.30]:
    G = [(l, f, obj(l, f, s)) for l in np.arange(0, .61, .02) for f in np.arange(.30, .96, .02)]
    b = min(G, key=lambda x: x[2]); a1 = min((g for g in G if g[0] == 0), key=lambda x: x[2])
    eng = obj(0, .8, s)
    rows.append(dict(s=s, lam=round(b[0], 2), phi=round(b[1], 2), obj=b[2], ar1_best_phi=round(a1[1], 2), ar1_best_obj=a1[2],
                     engine_obj=eng, delta_engine=eng - b[2], delta_ar1=a1[2] - b[2]))
    print(rows[-1], f"{time.time()-t0:.0f}s", flush=True)
pd.DataFrame(rows).to_csv("<scratch>/audit/verify_pers/out/v5_mover_stayer.csv", index=False)
print(f"v5 elapsed minutes: {(time.time()-t0)/60:.2f}")
