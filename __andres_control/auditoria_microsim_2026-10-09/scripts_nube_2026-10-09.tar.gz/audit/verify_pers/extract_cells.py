import json, sys, re, os
nb, outdir = sys.argv[1], sys.argv[2]
d = json.load(open(nb))
for i, c in enumerate(d["cells"]):
    if c["cell_type"] != "code": continue
    src = "".join(c["source"])
    m = re.search(r"#\|\s*label:\s*(\S+)", src)
    lab = m.group(1) if m else (c.get("metadata", {}).get("label") or c.get("id") or f"cell{i}")
    open(os.path.join(outdir, f"{os.path.basename(nb)[:6]}_{i:02d}_{lab}.R"), "w").write(src)
