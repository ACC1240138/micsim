# Rebuild ms_enpg / ms_targets / ms_mortality / engine functions from the notebook cells
# (__andres_control/microsim_recalib_ACC_2012_2024.ipynb), adapted for Rscript --vanilla:
#  - no arrow/knitr/IRdisplay/ggplot2 (not installed): parquet read via python3 into R tempdir() only;
#  - ms_table() prints instead of rendering HTML.
# Cells are extracted verbatim to audit/cells/*.R; only the substitutions below are applied.
.t0_load <- Sys.time()
AUDIT <- "<scratch>/audit"
setwd("<repo>/__andres_control")
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))

# Parquet reader: python writes the selected columns to a csv inside R's tempdir() (never the scratchpad).
py_read_parquet <- function(path, col_select) {
  out <- tempfile(tmpdir = tempdir(), fileext = ".csv")
  code <- sprintf("import pandas as pd; pd.read_parquet(r'%s', columns=%s).to_csv(r'%s', index=False)",
    path, paste0("[", paste0("'", col_select, "'", collapse = ","), "]"), out)
  st <- system2("python3", c("-I", "-c", shQuote(code)))
  stopifnot(st == 0)
  d <- utils::read.csv(out, stringsAsFactors = FALSE)
  unlink(out)
  d[col_select]
}

run_cell <- function(label, subs = list(), quiet = TRUE) {
  src <- paste(readLines(file.path(AUDIT, "hed_cells", paste0(label, ".R")), warn = FALSE), collapse = "\n")
  for (s in subs) {
    stopifnot(grepl(s[[1]], src, fixed = TRUE))
    src <- gsub(s[[1]], s[[2]], src, fixed = TRUE)
  }
  exprs <- parse(text = src)
  if (quiet) utils::capture.output(for (e in exprs) eval(e, envir = globalenv())) else
    for (e in exprs) eval(e, envir = globalenv())
  invisible(TRUE)
}

run_cell("ms-setup", list(
  list('"arrow", "knitr", "IRdisplay", "ggplot2", ', ''),
  list('IRdisplay::display_html(base::as.character(knitr::kable(x, format = "html", digits = 4,\n    row.names = FALSE, caption = caption)))',
       'base::invisible(NULL)')))
run_cell("ms-survey-inputs")
run_cell("ms-demography-inputs", list(
  list('base::as.data.frame(arrow::read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]),\n  col_select = base::c("year", "gender", "age")))',
       'py_read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]), base::c("year", "gender", "age"))')))
run_cell("ms-calibration-functions")
run_cell("ms-annual-engine")
stopifnot(nrow(ms_targets) == 56L, exists("ms_enpg"), exists("ms_mortality"), exists("ms_simulate"))
message(sprintf("00_load_engine elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0_load, units = "mins"))))
