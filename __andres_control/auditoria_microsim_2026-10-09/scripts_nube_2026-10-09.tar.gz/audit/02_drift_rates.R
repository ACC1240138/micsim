# 02_drift_rates.R -- item 1: reproduce the HMD x multiplier drift and build m/q = DEIS / INE mid-year.
# Inputs: agg/deaths_year_sex_age_cause.csv (aggregated by 01), INE ine_basedatos.xlsx, HMD 1x1 tables + raw deaths.
.t0 <- Sys.time()
library(data.table)
ROOT <- "<repo>"; AUD <- "<scratch>/audit"
INE  <- file.path(ROOT, "__andres_control", "ine_proyecciones_rebuild")
D <- fread(file.path(AUD, "agg", "deaths_year_sex_age_cause.csv"))[, .(deaths = sum(deaths)), by = .(year, sex, age)]

# INE population, base CPV 2024 (same file and sheet as ms-demography-inputs): January and June stocks, ages 0-100+.
p <- as.data.table(readxl::read_xlsx(file.path(INE, "ine_basedatos.xlsx"), sheet = "BBDD_EEPP-2024_0101"))
p[, date := as.Date(FECHA, "%d/%m/%Y")]
p <- p[, .(year = as.integer(format(date, "%Y")), md = format(date, "%m-%d"), sex = fifelse(SEXO == "H", "male", "female"),
           age = as.integer(EDAD), pop = POBLACION)]
pop <- dcast(p[year %in% 2012:2025], year + sex + age ~ md, value.var = "pop")
setnames(pop, c("01-01", "06-30"), c("pop_jan", "pop_mid"))
fwrite(pop, file.path(AUD, "agg", "ine_pop_2012_2025.csv"))

# HMD period life tables 1x1 (qx, mx) and HMD raw input deaths (Lexis RR, single ages).
hmd <- rbindlist(lapply(c(female = "fltper_1x1.txt", male = "mltper_1x1.txt"), function(f)
  fread(file.path(INE, f), skip = 2, header = TRUE)), idcol = "sex")
hmd <- hmd[Age != "110+", .(year = Year, sex, age = as.integer(Age), qx, mx)][year %in% 2012:2024]
hraw <- fread(file.path(INE, "CHLdeath.txt"))[Lexis == "RR" & AgeInterval == "1" & Age != "UNK" & Year %in% 2012:2024]
hraw <- hraw[, .(hmd_deaths = sum(Deaths)), by = .(year = Year, sex = fifelse(Sex == "m", "male", "female"), age = as.integer(Age))]
lex <- fread(file.path(INE, "Deaths_lexis.txt"), skip = 2, header = TRUE)
lex <- lex[Age != "110+", .(female = sum(Female), male = sum(Male)), by = .(year = Year, age = as.integer(Age))]
lex <- melt(lex, id.vars = c("year", "age"), variable.name = "sex", value.name = "hmd_lexis_deaths")[year %in% 2012:2024]
lex[, sex := as.character(sex)]

x <- Reduce(function(a, b) merge(a, b, by = c("year", "sex", "age"), all.x = TRUE),
            list(pop[year <= 2024 & age %in% 15:65], D, hmd, hraw, lex))
stopifnot(nrow(x) == 13 * 2 * 51, !anyNA(x))

# ---- A1. Reproduce the engine's sex multiplier (ms-calibration-functions) ----
# Same call as ms-calibration-functions (default uniroot tol, so the saved multipliers reproduce exactly).
scale_for <- function(d, total) exp(uniroot(function(ls) sum(d$pop_jan * -expm1(log1p(-d$qx) * exp(ls))) - total, c(-3, 3))$root)
old <- fread(file.path(ROOT, "__andres_control", "microsim_recalib_outputs", "mortality_concordance.csv"))
sc <- rbindlist(lapply(c("female", "male"), function(s) data.table(sex = s,
  scale_old_outputs_deis = scale_for(x[sex == s], sum(old[sex == s]$observed_deaths)),
  scale_corrected_deis   = scale_for(x[sex == s], sum(x[sex == s]$deaths)))))
sc[, notebook_saved := c(female = 0.969976905794678, male = 0.944948622365421)[sex]]  # microsim_recalib_outputs/model_parameters.csv
print(sc)
stopifnot(all(abs(sc$scale_old_outputs_deis / sc$notebook_saved - 1) < 1e-6))   # reproduction check
x[, q_engine := -expm1(log1p(-qx) * sc$scale_corrected_deis[match(sex, sc$sex)])]
drift <- x[, .(deis = sum(deaths), engine_expected = sum(pop_jan * q_engine), hmd_mx_x_ine_mid = sum(mx * pop_mid),
               hmd_raw_deaths = sum(hmd_deaths), hmd_lexis_deaths = sum(hmd_lexis_deaths),
               hmd_implied_exposure = sum(hmd_lexis_deaths / mx), ine_pop_mid = sum(pop_mid), ine_pop_jan = sum(pop_jan)),
           by = .(year, sex)]
drift <- merge(drift, old[, .(year, sex, deis_in_saved_outputs = observed_deaths, saved_expected = expected_deaths)], by = c("year", "sex"))
drift[, `:=`(engine_rel_err = engine_expected / deis - 1, hmd_mx_rel_err = hmd_mx_x_ine_mid / deis - 1,
             hmd_raw_vs_deis = hmd_raw_deaths / deis - 1, hmd_exposure_vs_ine_mid = hmd_implied_exposure / ine_pop_mid - 1)]
fwrite(drift, file.path(AUD, "out_A1_drift_year_sex.csv"))
slope <- drift[, as.list(coef(lm(engine_rel_err ~ I(year - 2012)))), by = sex]
setnames(slope, c("sex", "intercept_2012", "drift_per_year")); print(slope)
fwrite(sc, file.path(AUD, "out_A1_multiplier.csv"))

# ---- A2. m = DEIS / INE mid-year, q = m / (1 + m/2); stability by single age ----
x[, `:=`(m = deaths / pop_mid)][, q := m / (1 + 0.5 * m)]
x[, ratio_q_hmd := q / qx]
fwrite(x[, .(year, sex, age, deaths, pop_jan, pop_mid, m, q, hmd_qx = qx, hmd_mx = mx, ratio_q_hmd)], file.path(AUD, "out_A2_m_q_year_sex_age.csv"))
# Stability: CV across years of q per sex x age; Poisson-only CV = 1/sqrt(mean deaths); log-linear trend (2012-2019, pre-COVID).
stab <- x[, {
  pre <- year <= 2019
  b <- coef(glm(deaths ~ I(year - 2012), offset = log(pop_mid), family = poisson, subset = pre))[2]
  .(mean_deaths = mean(deaths), min_deaths = min(deaths), q_2012 = q[year == 2012], q_2019 = q[year == 2019], q_2024 = q[year == 2024],
    cv_q_2012_2019 = sd(q[pre]) / mean(q[pre]), cv_poisson = 1 / sqrt(mean(deaths[pre])),
    trend_pct_per_year_2012_2019 = 100 * (exp(b) - 1), q_2020_2022_vs_2019 = mean(q[year %in% 2020:2022]) / q[year == 2019],
    ratio_q_hmd_2012 = ratio_q_hmd[year == 2012], ratio_q_hmd_2024 = ratio_q_hmd[year == 2024])
}, by = .(sex, age)]
fwrite(stab, file.path(AUD, "out_A2_stability_sex_age.csv"))
x[, band := cut(age, c(14, 29, 44, 59, 65), labels = c("15-29", "30-44", "45-59", "60-65"))]
stab_band <- stab[, .(ages = .N, mean_deaths_per_age = mean(mean_deaths), min_deaths = min(min_deaths),
  median_cv_q = median(cv_q_2012_2019), median_cv_poisson = median(cv_poisson),
  median_trend_pct = median(trend_pct_per_year_2012_2019), median_covid_ratio = median(q_2020_2022_vs_2019)),
  by = .(sex, band = cut(age, c(14, 29, 44, 59, 65), labels = c("15-29", "30-44", "45-59", "60-65")))]
fwrite(stab_band, file.path(AUD, "out_A2_stability_band.csv")); print(stab_band)

# ---- A3. Lexis/edge: DEIS counts deaths by age AT DEATH; the engine applies q to age at 1 January ----
y <- merge(pop[year <= 2024 & age %in% 14:66], D, by = c("year", "sex", "age"), all.x = TRUE)
y[is.na(deaths), deaths := 0]; y[, m := deaths / pop_mid]
setorder(y, year, sex, age)
y[, m_next := shift(m, -1), by = .(year, sex)]
lexis <- y[age %in% 15:65, .(deis_15_65 = sum(deaths),
  naive_jan_x_q_age = sum(pop_jan * (m / (1 + 0.5 * m))),             # engine convention: q(age at death) on Jan age
  parallelogram_jan = sum(pop_jan * -expm1(-0.5 * (m + m_next)))),    # Jan-age cohort spans ages a..a+1
  by = .(year, sex)]
edge <- y[, .(d15 = deaths[age == 15], d66 = deaths[age == 66]), by = .(year, sex)]
lexis <- merge(lexis, edge, by = c("year", "sex"))
lexis[, `:=`(naive_rel = naive_jan_x_q_age / deis_15_65 - 1, parallelogram_rel = parallelogram_jan / deis_15_65 - 1,
             edge_target = deis_15_65 - 0.5 * d15 + 0.5 * d66)]
lexis[, parallelogram_vs_edge_target := parallelogram_jan / edge_target - 1]
fwrite(lexis, file.path(AUD, "out_A3_lexis_year_sex.csv")); print(lexis[, .(year, sex, naive_rel, parallelogram_rel, parallelogram_vs_edge_target)])
message(sprintf("02_drift_rates elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
