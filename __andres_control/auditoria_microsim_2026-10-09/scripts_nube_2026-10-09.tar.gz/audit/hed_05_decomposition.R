# Steps 2-4: exact additive decomposition of the HED reconstruction error per cell x wave.
#   S - T = (A - T) + (B - A) + (C - B) + (S - C)
#   T  target: design-weighted HED among current drinkers with HED observed (ms_targets$hed_mean)
#   A  observed HED in the glm sample only (current, finite gpd > 0, HED observed)    -> coverage/denominator
#   B  glm prediction averaged over the OBSERVED g/day of that wave's glm sample      -> no time term in glm
#   C  glm prediction averaged over the ENGINE g/day law (zero mass + Gamma, mu(year)) -> distribution mismatch
#   S  simulated mean(hed[current]), 5 seeds, rho = 0.8 (03_baseline_sim.R output)     -> dynamics / MC / age mix
# Writes only aggregated CSVs.
.t0 <- Sys.time()
source("<scratch>/audit/hed_00_load_engine.R")
model <- ms_fit(ms_cfg$observed_end, "interp_hold")
drv <- ms_drivers(model, ms_wave_years)
b_slope <- unname(stats::coef(model$hed)["base::log1p(gpd_survey)"])

x <- ms_enpg
x$cell <- factor(paste(x$sex, x$age_group, sep = ":"), levels = model$cells)
x$days <- ms_days[ms_enpg_all$in_domain]
x$drinks <- ms_drinks[ms_enpg_all$in_domain]
cur <- x[x$status == "current", ]
cur$glm_pop <- is.finite(cur$gpd_survey) & cur$gpd_survey > 0 & !is.na(cur$hed)
cur$pred <- NA_real_
cur$pred[cur$glm_pop] <- stats::predict(model$hed, newdata = cur[cur$glm_pop, ], type = "response")

engine_mean <- function(a, mu, shape, p0, b = b_slope) {
  sc <- mu / ((1 - p0) * shape)
  f <- function(g) stats::plogis(a + b * log1p(g)) * stats::dgamma(g, shape = shape, scale = sc)
  # Split at the mean: Gamma with shape < 1 has an integrable spike at 0.
  (1 - p0) * (stats::integrate(f, 0, mu, rel.tol = 1e-8)$value + stats::integrate(f, mu, Inf, rel.tol = 1e-8)$value)
}

sim <- utils::read.csv(file.path(AUDIT, "hed_sim_baseline_rho0-0.8-0.95_5seeds.csv"))
stored <- utils::read.csv("<repo>/__andres_control/microsim_recalib_outputs/reconstruction_comparison.csv")
stored <- stored[stored$metric == "hed", c("year", "sex", "age_group", "simulated", "in_working_interval", "se")]

dec <- do.call(rbind, lapply(seq_len(nrow(ms_targets)), function(i) {
  t <- ms_targets[i, ]
  z <- cur[cur$year == t$year & cur$sex == t$sex & cur$age_group == t$age_group, ]
  obs <- z[!is.na(z$hed), ]
  g <- z[z$glm_pop, ]
  nagpd <- obs[!is.finite(obs$gpd_survey), ]
  d <- drv[drv$year == t$year & drv$sex == t$sex & drv$age_group == t$age_group, ]
  s <- sim[sim$year == t$year & sim$sex == t$sex & sim$age_group == t$age_group, ]
  st <- stored[stored$year == t$year & stored$sex == t$sex & stored$age_group == t$age_group, ]
  data.frame(year = t$year, sex = t$sex, age_group = t$age_group,
    n_current = nrow(z), n_hed_observed = nrow(obs), n_glm = nrow(g), n_hed_obs_gpd_na = nrow(nagpd),
    n_hed_obs_gpd_na_days_na = sum(!is.finite(nagpd$days)), n_hed_obs_gpd_na_drinks_na = sum(!is.finite(nagpd$drinks)),
    w_share_denominator_gpd_na = sum(nagpd$weight) / sum(obs$weight),
    w_share_hed_cases_gpd_na = sum(nagpd$weight * nagpd$hed) / sum(obs$weight * obs$hed),
    hed_rate_gpd_na = if (nrow(nagpd)) stats::weighted.mean(nagpd$hed, nagpd$weight) else NA_real_,
    T = t$hed_mean, T_check = stats::weighted.mean(obs$hed, obs$weight),
    A = stats::weighted.mean(g$hed, g$weight), B = stats::weighted.mean(g$pred, g$weight),
    C = engine_mean(d$hed_intercept, d$mu_current, d$shape, d$p_zero),
    S = mean(s$hed_mean[s$rho == 0.8]), S_rho0 = mean(s$hed_mean[s$rho == 0]), S_rho095 = mean(s$hed_mean[s$rho == 0.95]),
    S_stored = st$simulated, se = t$hed_se, in_interval_stored = st$in_working_interval,
    obs_mean_log1p_gpd = stats::weighted.mean(log1p(g$gpd_survey), g$weight),
    engine_mean_log1p_gpd = (1 - d$p_zero) * stats::integrate(function(v) log1p(v) * stats::dgamma(v, d$shape,
      scale = d$mu_current / ((1 - d$p_zero) * d$shape)), 0, Inf)$value,
    obs_mean_gpd = stats::weighted.mean(g$gpd_survey, g$weight), engine_mu = d$mu_current, shape = d$shape)
}))
stopifnot(max(abs(dec$T - dec$T_check)) < 1e-10)
dec <- within(dec, {
  coverage = A - T; time_pooling = B - A; distribution = C - B; dynamics_mc = S - C; total = S - T
})
utils::write.csv(dec, file.path(AUDIT, "hed_decomposition_cells.csv"), row.names = FALSE)

comp <- c("coverage", "time_pooling", "distribution", "dynamics_mc", "total")
summ <- function(by) {
  a <- stats::aggregate(dec[comp], dec[by], function(v) round(100 * mean(v), 2))
  a
}
cat("\n== Mean over 56 cells, pp ==\n"); print(round(100 * colMeans(dec[comp]), 2))
cat("\n== By year ==\n"); print(summ("year"))
cat("\n== By sex ==\n"); print(summ("sex"))
cat("\n== By sex x age ==\n"); print(summ(c("sex", "age_group")))
cat("\n== Persistence check: mean S - T by rho (pp) ==\n")
print(round(100 * c(rho0 = mean(dec$S_rho0 - dec$T), rho08 = mean(dec$S - dec$T), rho095 = mean(dec$S_rho095 - dec$T)), 2))
cat("\n== Coverage descriptors (sum over cells) ==\n")
print(colSums(dec[c("n_current", "n_hed_observed", "n_glm", "n_hed_obs_gpd_na", "n_hed_obs_gpd_na_days_na", "n_hed_obs_gpd_na_drinks_na")]))
print(stats::aggregate(cbind(w_share_denominator_gpd_na, w_share_hed_cases_gpd_na, hed_rate_gpd_na, T) ~ year, dec, function(v) round(100 * mean(v), 1)))
cat("\n== g/day: observed vs engine (glm sample) ==\n")
print(stats::aggregate(cbind(obs_mean_log1p_gpd, engine_mean_log1p_gpd, obs_mean_gpd, engine_mu, shape) ~ sex + age_group, dec, mean))

# Distribution of g/day and HED by volume bin: observed (glm sample) vs engine law, pooled over waves (equal weight per wave).
bins <- c(0, 1, 2, 5, 10, 20, 40, Inf)
dist <- do.call(rbind, lapply(seq_len(nrow(ms_targets)), function(i) {
  t <- ms_targets[i, ]
  g <- cur[cur$glm_pop & cur$year == t$year & cur$sex == t$sex & cur$age_group == t$age_group, ]
  d <- drv[drv$year == t$year & drv$sex == t$sex & drv$age_group == t$age_group, ]
  sc <- d$mu_current / ((1 - d$p_zero) * d$shape)
  do.call(rbind, lapply(seq_len(length(bins) - 1), function(j) {
    lo <- bins[j]; hi <- bins[j + 1]
    inb <- g$gpd_survey >= lo & g$gpd_survey < hi
    m_eng <- (1 - d$p_zero) * (stats::pgamma(hi, d$shape, scale = sc) - stats::pgamma(lo, d$shape, scale = sc))
    h_eng <- (1 - d$p_zero) * stats::integrate(function(v) stats::plogis(d$hed_intercept + b_slope * log1p(v)) *
      stats::dgamma(v, d$shape, scale = sc), lo, hi)$value
    data.frame(year = t$year, sex = t$sex, age_group = t$age_group, bin = sprintf("[%g,%g)", lo, hi), j = j,
      share_obs = sum(g$weight[inb]) / sum(g$weight), hed_mass_obs = sum(g$weight[inb] * g$hed[inb]) / sum(g$weight),
      share_eng = m_eng, hed_mass_eng = h_eng)
  }))
}))
dsum <- stats::aggregate(cbind(share_obs, hed_mass_obs, share_eng, hed_mass_eng) ~ sex + j + bin, dist, mean)
dsum$hed_rate_obs <- dsum$hed_mass_obs / dsum$share_obs
dsum$hed_rate_eng <- dsum$hed_mass_eng / dsum$share_eng
dsum <- dsum[order(dsum$sex, dsum$j), ]
cat("\n== Volume-bin distribution, mean over 4 age groups x 7 waves ==\n")
print(dsum, digits = 3)
utils::write.csv(dsum, file.path(AUDIT, "hed_volume_bins.csv"), row.names = FALSE)

# Mechanical floor: in ENPG, one HED episode alone adds 5 (men) / 4 (women) drinks x 12 g / 30 days to g/day.
fl <- ifelse(cur$sex == "male", 2, 1.6)
cat("\nObserved HED cases with gpd below the floor (should be 0):", sum(cur$glm_pop & cur$hed == 1 & cur$gpd_survey < fl - 1e-9), "\n")
message(sprintf("05_hed_decomposition elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
