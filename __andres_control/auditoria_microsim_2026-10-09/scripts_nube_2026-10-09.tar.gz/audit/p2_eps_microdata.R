# Steps 1-2 on EPS microdata: reproduce the published same-people tetrachoric correlations, extend them to
# baseline ages < 50, and get a PSU bootstrap (joint covariance of the three correlations) for lambda, phi.
# Reuses notebook eps_alcohol_prevalencia_persistencia.ipynb cells verbatim (extracted to nbsrc/):
# eps-inputs, eps-harmonize (whole cells); eps_design (eps-prevalence); eps_time/eps_make_pair/eps_pairs (eps-panel);
# eps_bvn/eps_tetra/eps_rho (eps-persistence); td/triple_design/eps_triple_rho (eps-panel-diagnostics).
# Writes aggregated CSVs only, to scratchpad/audit/out/ (eps_save is redirected there too).
.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
audit <- "<scratch>/audit"
setwd("<repo>/__andres_control")
source(file.path("<repo>", "_tools", "acc_data.R"))
source(file.path(audit, "fit_lib.R"))
# --- setup equivalent to cell eps-setup, with outputs redirected away from the repo ---
eps_root <- acc_data("_eps/eps.tar.xz.enc")
eps_abs <- function(x) file.path(eps_root, sub("^_eps/", "", x))
eps_out <- file.path(audit, "out", "eps_rerun"); dir.create(eps_out, recursive = TRUE, showWarnings = FALSE)
options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE, scipen = 8)
set.seed(1240138L)
eps_age_levels <- c("18-29", "30-44", "45-59", "60-65", "66-70", "71-76", "77+")
eps_edu_levels <- c("Primary completed or less", "Secondary completed or less", "Tertiary completed or higher")
eps_states <- c("Current abstainer (history unknown)", "Occasional (frequency proxy)", "Moderate", "Heavy")
eps_table <- function(x, caption, digits = 3) invisible(NULL)
eps_read <- function(path) {
  x <- as.data.frame(haven::read_dta(eps_abs(path)))
  stopifnot("folio_n20" %in% names(x), !anyNA(x$folio_n20), !anyDuplicated(x$folio_n20))
  x
}
eps_save <- function(x, name) utils::write.csv(x, file.path(eps_out, paste0(name, ".csv")), row.names = FALSE, na = "")
run_exprs <- function(file, names = NULL, first_n = NULL) {
  ex <- parse(file.path(audit, "nbsrc", file), keep.source = FALSE)
  for (i in seq_along(ex)) {
    e <- ex[[i]]
    lhs <- if (is.call(e) && identical(e[[1]], as.name("<-"))) paste(deparse(e[[2]]), collapse = "") else ""
    if ((!is.null(names) && lhs %in% names) || (!is.null(first_n) && i <= first_n)) eval(e, envir = globalenv())
  }
}
run_exprs("eps_07_eps-inputs.R", first_n = 1e3)
run_exprs("eps_09_eps-harmonize.R", first_n = 1e3)
run_exprs("eps_11_eps-prevalence.R", names = c("eps_design", "eps_prop", "eps_domains"))
run_exprs("eps_19_eps-panel.R", names = c("eps_time", "eps_make_pair", "eps_pairs"))
run_exprs("eps_24_eps-persistence.R", names = c("eps_bvn", "eps_tetra", "eps_rho"))
run_exprs("eps_28_eps-panel-diagnostics.R", names = c("td", "mid_match", "mid_data", "td$current_mid", "mid_good",
  "td$triple_valid", "triple_design", "eps_triple_rho"))
# --- reproduction check against the published CSV ---
pub <- utils::read.csv("eps_alcohol_outputs/rho_same_people_three_interviews.csv")
chk <- merge(pub[c("sex", "pair", "n", "rho_interval")], eps_triple_rho[c("sex", "pair", "n", "rho_interval")],
             by = c("sex", "pair"), suffixes = c("_pub", "_rerun"))
print(chk); stopifnot(all(chk$n_pub == chk$n_rerun), max(abs(chk$rho_interval_pub - chk$rho_interval_rerun)) < 1e-6)
utils::write.csv(chk, file.path(audit, "out", "p2_reproduction_check.csv"), row.names = FALSE)

# --- same-people triples by baseline age group (adds ages < 50) ---
lags <- c(3.671, 4.022, 7.693)
triple_rho <- function(ds) {
  long <- eps_rho(ds, 7.693, 7.110, 8.277)
  first <- ds; first$variables$current1 <- first$variables$current_mid
  second <- ds; second$variables$current0 <- second$variables$current_mid
  rbind(cbind(pair = "VI_VII", eps_rho(first, 3.671, 3.285, 4.057)),
        cbind(pair = "VII_VIII", eps_rho(second, 4.022, 3.554, 4.490)), cbind(pair = "VI_VIII", long))
}
age_dom <- list(`18-29` = c(18, 30), `30-44` = c(30, 45), `45-59` = c(45, 60), `50+` = c(50, Inf), `60+` = c(60, Inf),
                `18-49` = c(18, 50), `All 18+` = c(18, Inf))
doms <- expand.grid(age = names(age_dom), sex = c("All", "Men", "Women"), stringsAsFactors = FALSE)
keep_of <- function(a, s) which(td$triple_valid & td$age >= age_dom[[a]][1] & td$age < age_dom[[a]][2] & (s == "All" | td$sex == s))
tri <- do.call(rbind, lapply(seq_len(nrow(doms)), function(i) {
  k <- keep_of(doms$age[i], doms$sex[i]); x <- triple_rho(triple_design[k, ])
  cbind(age = doms$age[i], sex = doms$sex[i], x,
        prevalence_VI = stats::weighted.mean(td$current0[k], td$weight[k]),
        prevalence_VIII = stats::weighted.mean(td$current1[k], td$weight[k]))
}))
tri$se_z <- (atanh(tri$upper) - atanh(tri$lower)) / (2 * stats::qnorm(.975))
utils::write.csv(tri, file.path(audit, "out", "p2_triple_rho_by_age_sex.csv"), row.names = FALSE)

# --- PSU bootstrap (survey subbootstrap on the VIII panel strata/clusters), refit lambda, phi per replicate ---
R <- 400
tv <- td[td$triple_valid, ]
# Singleton strata make the stratified subbootstrap undefined; resample PSUs ignoring strata (conservative).
print(table(table(unique(tv[c("strata", "psu")])$strata)))
rep_des <- survey::as.svrepdesign(survey::svydesign(ids = ~psu, weights = ~weight, data = tv), type = "bootstrap", replicates = R)
W <- stats::weights(rep_des, type = "analysis")   # rows = tv
tetra_w <- function(x0, x1, w) { cell <- 1L + x1 + 2L * x0; eps_tetra(vapply(1:4, function(j) sum(w[cell == j]), 0)) }
fits <- do.call(rbind, lapply(seq_len(nrow(doms)), function(i) {
  a <- doms$age[i]; s <- doms$sex[i]
  k <- which(tv$age >= age_dom[[a]][1] & tv$age < age_dom[[a]][2] & (s == "All" | tv$sex == s))
  est <- tri[tri$age == a & tri$sex == s, ]; est <- est[match(c("VI_VII", "VII_VIII", "VI_VIII"), est$pair), ]
  if (any(!is.finite(est$rho_interval)) || any(!is.finite(est$se_z))) return(NULL)
  f0 <- fit_trait_ar1(est$rho_interval, lags, est$se_z); a0 <- fit_ar1(est$rho_interval, lags, est$se_z)
  bt <- t(vapply(seq_len(R), function(b) {
    w <- W[k, b]; x0 <- tv$current0[k]; xm <- tv$current_mid[k]; x1 <- tv$current1[k]
    r <- c(tetra_w(x0, xm, w), tetra_w(xm, x1, w), tetra_w(x0, x1, w))
    if (any(!is.finite(r))) return(c(NA, NA, NA, NA, NA))
    f <- fit_trait_ar1(r, lags, est$se_z, starts = rbind(f0[1:2], c(.1, .8), c(.6, .3)))
    c(f[1:2], r)
  }, numeric(5)))
  ok <- stats::complete.cases(bt)
  cr <- stats::cor(atanh(bt[ok, 3:5]))
  data.frame(age = a, sex = s, n = est$n[1], r_VI_VII = est$rho_interval[1], r_VII_VIII = est$rho_interval[2],
    r_VI_VIII = est$rho_interval[3], lambda = f0[["lambda"]], phi = f0[["phi"]], obj_trait = f0[["obj"]],
    phi_ar1 = a0[["phi"]], obj_ar1 = a0[["obj"]], boot_ok = sum(ok),
    lambda_lo = stats::quantile(bt[ok, 1], .025), lambda_hi = stats::quantile(bt[ok, 1], .975),
    phi_lo = stats::quantile(bt[ok, 2], .025), phi_hi = stats::quantile(bt[ok, 2], .975),
    r1y = r_model(f0[["lambda"]], f0[["phi"]], 1),
    r1y_lo = stats::quantile(r_model(bt[ok, 1], bt[ok, 2], 1), .025), r1y_hi = stats::quantile(r_model(bt[ok, 1], bt[ok, 2], 1), .975),
    r10y = r_model(f0[["lambda"]], f0[["phi"]], 10),
    r10y_lo = stats::quantile(r_model(bt[ok, 1], bt[ok, 2], 10), .025), r10y_hi = stats::quantile(r_model(bt[ok, 1], bt[ok, 2], 10), .975),
    # Bootstrap check of the AR(1) restriction: share of replicates with r_long > r1 * r2.
    p_boot_long_gt_product = mean(bt[ok, 5] > bt[ok, 3] * bt[ok, 4]),
    corr_z_12 = cr[1, 2], corr_z_13 = cr[1, 3], corr_z_23 = cr[2, 3], row.names = NULL)
}))
utils::write.csv(fits, file.path(audit, "out", "p2_boot_lambda_phi_by_age_sex.csv"), row.names = FALSE)
print(format(fits[, c("age", "sex", "n", "r_VI_VII", "r_VII_VIII", "r_VI_VIII", "lambda", "lambda_lo", "lambda_hi",
  "phi", "phi_lo", "phi_hi", "r1y", "r1y_lo", "r1y_hi", "r10y", "p_boot_long_gt_product", "obj_ar1")], digits = 3))
message(sprintf("p2_eps_microdata elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
