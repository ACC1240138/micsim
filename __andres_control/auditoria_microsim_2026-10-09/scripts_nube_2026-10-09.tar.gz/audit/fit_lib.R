# Shared helpers: trait + AR(1) latent persistence fitted to tetrachoric correlations at several lags.
# Model: z_t = sqrt(lambda) u + sqrt(1 - lambda) a_t, a_t AR(1) with annual phi, u and a independent N(0,1)
#        => corr(z_t, z_{t+d}) = lambda + (1 - lambda) phi^d.
r_model <- function(lambda, phi, d) lambda + (1 - lambda) * phi^d

# Weighted least squares on the Fisher-z scale; se_z is the SE of atanh(r).
wls_obj <- function(lambda, phi, r, d, se_z) sum(((atanh(r) - atanh(r_model(lambda, phi, d))) / se_z)^2)

fit_trait_ar1 <- function(r, d, se_z, starts = expand.grid(lambda = c(.1, .4, .7), phi = c(.3, .6, .9))) {
  stopifnot(length(r) == length(d), length(d) == length(se_z), all(abs(r) < 1))
  f <- function(p) wls_obj(stats::plogis(p[1]), stats::plogis(p[2]), r, d, se_z)
  starts <- stats::qlogis(pmin(pmax(as.matrix(starts), 1e-3), 1 - 1e-3))
  fits <- lapply(seq_len(nrow(starts)), function(i) stats::optim(starts[i, ], f, method = "Nelder-Mead",
    control = list(reltol = 1e-10, maxit = 2000)))
  best <- fits[[which.min(vapply(fits, `[[`, 0, "value"))]]
  c(lambda = stats::plogis(unname(best$par[1])), phi = stats::plogis(unname(best$par[2])), obj = best$value)
}

fit_ar1 <- function(r, d, se_z) {
  o <- stats::optimize(function(phi) wls_obj(0, phi, r, d, se_z), c(1e-4, 1 - 1e-6), tol = 1e-10)
  c(lambda = 0, phi = o$minimum, obj = o$objective)
}

# Exactly identified solution from two lags (d1 < d2): solve r1, r2 for lambda, phi (NA if no admissible root).
solve_two <- function(r1, r2, d1, d2) {
  if (!is.finite(r1) || !is.finite(r2) || r1 <= 0 || r2 <= 0) return(c(lambda = NA, phi = NA))
  g <- function(phi) { x1 <- phi^d1; x2 <- phi^d2; lam <- (r1 - x1) / (1 - x1); lam + (1 - lam) * x2 - r2 }
  grid <- seq(1e-4, 1 - 1e-4, length.out = 2000); v <- vapply(grid, g, 0)
  k <- which(diff(sign(v)) != 0)
  sols <- lapply(k, function(i) { phi <- stats::uniroot(g, grid[c(i, i + 1)], tol = 1e-10)$root
    c(lambda = (r1 - phi^d1) / (1 - phi^d1), phi = phi) })
  sols <- Filter(function(s) s[["lambda"]] >= 0 && s[["lambda"]] < 1, sols)
  if (!length(sols)) {
    # Boundary: no interior root (r2 >= r1 => lambda -> r2 with phi -> 0; r2 <= r1^(d2/d1) => pure AR(1)).
    if (r2 >= r1) return(c(lambda = min(r1, r2), phi = 0))
    return(c(lambda = 0, phi = r1^(1 / d1)))
  }
  sols[[1]]
}

# Annual switching implied by the latent model for an annual step at prevalence p (needs mvtnorm).
switch_rate <- function(rho1, p) {
  t <- stats::qnorm(p)
  p11 <- mvtnorm::pmvnorm(upper = c(t, t), corr = matrix(c(1, rho1, rho1, 1), 2))[1]
  2 * (p - p11)
}
