.t0 <- Sys.time()
# Runs the (f) consistency-check sketch verbatim on a synthetic 2024 population (NHED/HED mixture draws).
audit_dir <- "<scratch>/audit"
source(file.path(audit_dir, "rr_bridge_lib.R")); spec <- bridge_load()
setwd("<repo>")
inp <- readRDS("__andres_control/aaf_engine_inputs_bundle_20261007.rds")$exposure_inputs
Y <- 2024L; f24 <- read.csv("__andres_control/oms_factor_by_year.csv"); f24 <- f24$factor_CH[f24$year == Y]
ms_age_group <- function(age) findInterval(age, c(15, 30, 45, 60))
set.seed(1); pop <- list()
for (sx in c("female", "male")) for (g in 1:4) {
  s <- if (sx == "female") "fem" else "male"; n <- 40000L
  pa <- inp[[paste0("p_abs_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]; pf <- inp[[paste0("p_form_list_", s)]][["2024"]][[paste0("edad_tramo_", g)]]
  ph <- inp[[paste0("p_hed_list_", s)]][[g]][[7]]; sp <- inp[[paste0("g_", s, "_hed_list")]][["2024"]][[g]]
  st <- sample(c("never", "former", "current"), n, TRUE, c(pa, pf, 1 - pa - pf)); h <- st == "current" & runif(n) < ph
  rt <- function(k, e) { x <- rgamma(k, e$estimate[["shape"]], e$estimate[["rate"]]); while (any(b <- x < 0.1 | x > 150)) x[b] <- rgamma(sum(b), e$estimate[["shape"]], e$estimate[["rate"]]); x }
  gpd <- numeric(n); gpd[st == "current" & !h] <- rt(sum(st == "current" & !h), sp$nhed); gpd[h] <- rt(sum(h), sp$hed)
  pop[[length(pop) + 1L]] <- data.frame(sex = sx, age = c(20, 35, 50, 62)[g], alc_status = st, gpd_survey = gpd / f24, hed = h, w = 1)
}
pop <- do.call(rbind, pop); tol <- 0.05
eval(parse(file.path(audit_dir, "sketch_check_body.R")))
cat(sprintf("sketch ran: %d cells, max|diff| %.4f, median |diff| %.4f\n", nrow(cmp), max(abs(cmp$aaf_micro - cmp$aaf_expand_pif)), median(abs(cmp$aaf_micro - cmp$aaf_expand_pif))))
cat(sprintf("test_sketch elapsed minutes: %.2f\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
