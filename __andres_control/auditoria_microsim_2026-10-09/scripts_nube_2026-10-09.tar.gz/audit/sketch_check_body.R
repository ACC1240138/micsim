fac  <- read.csv("__andres_control/oms_factor_by_year.csv")
pop$gpd_apc   <- pop$gpd_survey * fac$factor_CH[fac$year == Y]   # same factor in every arm
pop$status    <- pop$alc_status                                  # never / former / current
pop$age_group <- ms_age_group(pop$age)
aafs <- readRDS("__andres_control/aaf_nested_by_disease_20261007.rds")$by_disease
t5   <- readRDS("__andres_control/aaf_table5_result_20261007.rds")$by_age_scope[["15_64"]]$standard_tables
cmp <- do.call(rbind, lapply(unique(spec$cause[spec$principal]), function(cs) {
  e <- unique(spec[spec$cause == cs & spec$principal, c("sex", "output", "rr_source")])
  do.call(rbind, lapply(seq_len(nrow(e)), function(j) do.call(rbind, lapply(1:4, function(g) {
    p <- pop[pop$sex == e$sex[j] & pop$age_group == g, ]
    ref <- if (e$rr_source[j] == "table5_puc") { tb <- t5[[e$sex[j]]]; tb[tb$disease == cs & tb$Year == Y, paste0("AAF_ag", g)] } else {
      tb <- aafs[[cs]]$outputs[[e$output[j]]]$table; tb[tb$Year == Y, paste0(if (e$sex[j] == "female") "Fem" else "Male", g, "_point")] }
    data.frame(cause = cs, sex = e$sex[j], age_group = g, aaf_micro = aaf_from_people(rr_individual(p, cs, spec), p$w), aaf_expand_pif = ref)
  }))))
}))
stopifnot(max(abs(cmp$aaf_micro - cmp$aaf_expand_pif)) < tol)   # tol: MC error of N_sim; 5.8e-4 reached with exact inputs
