# Step 3: ENPG partial-longitudinal targets (never, former >12m, 12m vs 30d, initiation hazard, onset age).
# Reuses the notebook cell ms-survey-inputs verbatim (extracted to nbsrc/) for weights, PSU and strata.
# Output: aggregated CSVs only, in scratchpad/audit/out/. No microdata leave R's tempdir().
.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
audit <- "<scratch>/audit"
out <- file.path(audit, "out")
setwd("<repo>/__andres_control")
source(file.path("<repo>", "_tools", "acc_data.R"))
ms_cfg <- list(min_age = 15L, max_age = 65L)
ms_table <- function(x, caption = NULL) invisible(NULL)
source(file.path(audit, "nbsrc", "07_ms-survey-inputs.R"))   # defines ms_enpg_all, ms_targets
stopifnot(nrow(ms_targets) == 56L)

# ---- onset items from raw waves (id = design id_join) ----
onset_files <- list(`2012` = c("Base de datos ENPG 2012 (PG).DTA.dta", "idencuesta", "p11", "p12"),
  `2014` = c("Base de datos ENPG 2014 (PG).DTA.dta", "idencuesta", "oh2", "oh3"),
  `2016` = c("base ENPG 2016 publico general.dta", "idencuesta", "oh_2", "oh_3"),
  `2018` = c("Base de datos ENPG 2018 (PG).DTA", "SbjNum", "OH_2", "OH_3"),
  `2020` = c("enpg2020.RDS", "SbjNum", "OH_2", "OH_3"),
  `2022` = c("BD - ENPG 2022 (Stata 16).dta", "FOLIO", "OH_2", "OH_3"),
  `2024` = c("Base Publica ENPG 2024 (Stata 16).dta", "RESPONDENT_SERIAL", "OH_2", "OH_3"))
onset <- do.call(rbind, lapply(names(onset_files), function(y) {
  f <- onset_files[[y]]; p <- acc_data("_enpg/enpg.tar.xz.enc", f[1])
  x <- if (grepl("RDS$", p)) as.data.frame(readRDS(p))[f[2:4]] else
    as.data.frame(haven::read_dta(p, col_select = dplyr::all_of(f[2:4])))
  data.frame(year = as.integer(y), id = as.character(as.numeric(x[[1]])),
             first_when = as.numeric(x[[2]]), first_age = as.numeric(x[[3]]))
}))
stopifnot(!anyDuplicated(onset[c("year", "id")]))
k <- match(paste(ms_enpg_all$year, ms_enpg_all$id), paste(onset$year, onset$id))
link <- aggregate(is.na(k), list(year = ms_enpg_all$year), sum); names(link)[2] <- "unlinked"
print(link); stopifnot(all(link$unlinked == 0))
e <- ms_enpg_all
e$first_when <- onset$first_when[k]; e$first_age <- onset$first_age[k]
e$first_when[!e$first_when %in% 1:3] <- NA          # 88/99 and skips -> unknown
e$first_age[e$first_age %in% c(88, 99, 888, 999) | e$first_age < 5 | e$first_age > e$age] <- NA
rec <- as.character(ms_raw$oh2[match(paste(e$year, e$id), paste(ms_raw$year, as.character(ms_raw$id)))])
e$m12 <- ifelse(e$status == "unknown", NA, as.numeric(e$status == "current" | rec %in% ">30"))
e$cur30 <- e$current
e$never <- ifelse(e$status == "unknown", NA, as.numeric(e$status == "never"))
e$former12 <- ifelse(e$status == "unknown", NA, as.numeric(rec %in% ">1 a\u00f1o"))
e$former_any <- ifelse(e$status == "unknown", NA, as.numeric(e$status == "former"))
e$not30_given12 <- ifelse(e$m12 %in% 1, as.numeric(rec %in% ">30"), NA)
e$former12_given_ever <- ifelse(e$never %in% 0, e$former12, NA)
# Initiation in the last 12 months among those at risk 12 months ago (never now, or first use < 12 m ago).
e$init12 <- ifelse(e$never %in% 1, 0, ifelse(e$first_when %in% 1:2, 1, NA))
e$init12[e$never %in% 0 & e$first_when %in% 3] <- NA   # not at risk 12 months ago
e$birth <- e$year - e$age
cohort_brk <- seq(1945, 2010, 5)
e$cohort <- cut(e$birth, cohort_brk, right = FALSE, labels = paste0(head(cohort_brk, -1), "-", head(cohort_brk, -1) + 4))
e$age_fine <- cut(e$age, c(15, 18, 21, 25, 30, 35, 40, 45, 50, 55, 60, 66), right = FALSE,
  labels = c("15-17", "18-20", "21-24", "25-29", "30-34", "35-39", "40-44", "45-49", "50-54", "55-59", "60-65"))
e$age_grp <- factor(e$age_group, 1:4, c("15-29", "30-44", "45-59", "60-65"))
cat("status x year (unweighted):\n"); print(table(e$year, e$status))

# ---- design-based estimates, design built on the full wave, then domains (as ms_build_targets) ----
options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE)
des <- lapply(sort(unique(e$year)), function(y) {
  w <- e[e$year == y, ]
  if (y == 2020L) survey::svydesign(ids = ~1, weights = ~weight, data = w) else
    survey::svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, data = w, nest = TRUE)
}); names(des) <- sort(unique(e$year))
vars <- c("never", "former12", "former_any", "m12", "cur30", "not30_given12", "former12_given_ever", "init12")
est <- function(d, by, v) {
  dd <- subset(d, in_domain & !is.na(get(v)))
  r <- suppressWarnings(survey::svyby(stats::reformulate(v), stats::reformulate(by), dd, survey::svymean, na.rm = TRUE))
  nn <- stats::aggregate(dd$variables[[v]], dd$variables[by], length)
  r <- merge(as.data.frame(r), setNames(nn, c(by, "n")), by = by)
  names(r)[names(r) == v] <- "estimate"; names(r)[names(r) == paste0("se.", v)] <- "se"
  if (!"se" %in% names(r)) names(r)[ncol(r) - 1] <- "se"
  cbind(variable = v, r[c(by, "n", "estimate", "se")])
}
run <- function(by) do.call(rbind, lapply(names(des), function(y) cbind(year = as.integer(y),
  do.call(rbind, lapply(vars, function(v) est(des[[y]], by, v))))))
t_grp <- run(c("sex", "age_grp")); t_fine <- run(c("sex", "age_fine")); t_coh <- run(c("sex", "cohort"))
t_grp$lower <- pmax(0, t_grp$estimate - 1.96 * t_grp$se); t_grp$upper <- pmin(1, t_grp$estimate + 1.96 * t_grp$se)
write.csv(t_grp, file.path(out, "enpg_targets_wave_sex_agegroup.csv"), row.names = FALSE)
write.csv(t_fine, file.path(out, "enpg_targets_wave_sex_agefine.csv"), row.names = FALSE)
write.csv(t_coh[t_coh$variable %in% c("never", "former12", "m12", "cur30"), ], file.path(out, "enpg_pseudocohort_never.csv"), row.names = FALSE)

# Pooled 2012-2024 (each wave weight rescaled to sum 1 so waves count equally), for the step-4 profile.
e$w_pool <- e$weight / ave(e$weight * e$in_domain, e$year, FUN = sum)
pool <- function(by) {
  dd <- e[e$in_domain, ]
  do.call(rbind, lapply(vars, function(v) {
    x <- dd[!is.na(dd[[v]]), ]
    x$num <- x$w_pool * x[[v]]; x$one <- 1
    a <- stats::aggregate(x[c("num", "w_pool", "one")], x[by], sum)
    data.frame(variable = v, a[by], n = a$one, estimate = a$num / a$w_pool)
  }))
}
p_fine <- pool(c("sex", "age_fine")); p_grp <- pool(c("sex", "age_grp"))
write.csv(p_fine, file.path(out, "enpg_pooled_sex_agefine.csv"), row.names = FALSE)
write.csv(p_grp, file.path(out, "enpg_pooled_sex_agegroup.csv"), row.names = FALSE)

# Onset age among ever drinkers with known onset (weighted quantiles per wave x sex x age_grp) and
# retrospective cumulative ever-use by exact age a among respondents older than a (pooled waves).
wq <- function(x, w, p) { o <- order(x); x <- x[o]; w <- cumsum(w[o]) / sum(w); vapply(p, function(q) x[which(w >= q)[1]], 0) }
ons <- e[e$in_domain & e$never %in% 0 & !is.na(e$first_age), ]
q_on <- do.call(rbind, lapply(split(ons, list(ons$year, ons$sex), drop = TRUE), function(x)
  data.frame(year = x$year[1], sex = x$sex[1], n = nrow(x), p10 = wq(x$first_age, x$weight, .1),
    p25 = wq(x$first_age, x$weight, .25), median = wq(x$first_age, x$weight, .5), p75 = wq(x$first_age, x$weight, .75),
    p90 = wq(x$first_age, x$weight, .9), share_onset_after_25 = sum(x$weight * (x$first_age > 25)) / sum(x$weight))))
write.csv(q_on, file.path(out, "enpg_onset_age_quantiles.csv"), row.names = FALSE)
known <- e[e$in_domain & !is.na(e$never) & (e$never == 1 | !is.na(e$first_age)), ]
cum <- do.call(rbind, lapply(c(15, 18, 21, 25, 30, 40, 50), function(a) do.call(rbind, lapply(c("male", "female"), function(s) {
  x <- known[known$age > a & known$sex == s, ]
  do.call(rbind, lapply(levels(droplevels(x$cohort)), function(co) {
    z <- x[x$cohort %in% co, ]; if (nrow(z) < 100) return(NULL)
    data.frame(age = a, sex = s, cohort = co, n = nrow(z),
      ever_by_age = sum(z$w_pool * (z$never == 0 & z$first_age <= a)) / sum(z$w_pool))
  }))
}))))
write.csv(cum, file.path(out, "enpg_retrospective_ever_by_age_cohort.csv"), row.names = FALSE)
miss <- aggregate(cbind(ever = e$never %in% 0, onset_age_missing = e$never %in% 0 & is.na(e$first_age),
  first_when_missing = e$never %in% 0 & is.na(e$first_when)), list(year = e$year), sum)
write.csv(miss, file.path(out, "enpg_onset_missing_audit.csv"), row.names = FALSE)
print(miss)

# OH_2 ("first time ever") validity: a first use within 12 months should imply onset age >= age - 1.
v <- e[e$in_domain & e$first_when %in% 1:2, ]
oh2_check <- aggregate(cbind(n = 1, onset_age_known = !is.na(v$first_age),
  onset_age_lt_age_minus1 = !is.na(v$first_age) & v$first_age < v$age - 1), list(year = v$year), sum)
write.csv(oh2_check, file.path(out, "enpg_oh2_first_time_validity.csv"), row.names = FALSE)
print(oh2_check)
# Retrospective life-table hazard of first use at exact age a (OH_3), respondents with age > a,
# pooled waves with wave-normalised weights: h(a) = sum w[first_age == a] / sum w[never or first_age >= a].
haz <- do.call(rbind, lapply(10:50, function(a) do.call(rbind, lapply(c("male", "female"), function(s) {
  x <- known[known$age > a & known$sex == s, ]
  risk <- x$never == 1 | x$first_age >= a
  data.frame(age = a, sex = s, n_at_risk = sum(risk), events = sum(x$never == 0 & x$first_age %in% a),
    hazard = sum(x$w_pool * (x$never == 0 & x$first_age %in% a)) / sum(x$w_pool * risk),
    never_share_at_age = sum(x$w_pool * (x$never == 1 | x$first_age > a)) / sum(x$w_pool))
}))))
write.csv(haz, file.path(out, "enpg_retrospective_onset_hazard.csv"), row.names = FALSE)

# Whole 15-65 domain by wave (compare with engine persistence_sensitivity.csv never_2024 / former_2024).
t_all <- do.call(rbind, lapply(names(des), function(y) do.call(rbind, lapply(c("never", "former_any", "former12", "cur30", "m12"), function(v) {
  dd <- subset(des[[y]], in_domain & !is.na(get(v)))
  m <- survey::svymean(stats::reformulate(v), dd)
  data.frame(year = as.integer(y), variable = v, n = nrow(dd$variables), estimate = as.numeric(stats::coef(m)), se = as.numeric(survey::SE(m)))
}))))
write.csv(t_all, file.path(out, "enpg_targets_wave_overall.csv"), row.names = FALSE)
message(sprintf("p3_enpg_targets elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
