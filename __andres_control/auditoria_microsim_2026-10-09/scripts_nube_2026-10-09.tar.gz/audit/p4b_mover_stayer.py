"""Step 4b: mover-stayer + trait-AR(1). A share s of each sex never drinks (lifetime abstainers, absorbing);
movers follow the latent model with threshold Phi^-1(p / (1 - s)), so the 30-day margin is unchanged.
(1) Refit movers' (lambda_m, phi_m) to the EPS same-people correlations, using the EXACT tetrachoric
    correlation the mixture implies for the observed binary status (stayers inflate it).
(2) Re-simulate the ENPG quantities (never, former > 12 m, intermittency) with p4_grid.simulate(stayer=s).
"""
import time, sys
import numpy as np, pandas as pd
from scipy.stats import norm, multivariate_normal
from scipy.optimize import brentq
sys.path.insert(0, "<scratch>/audit")
from p4_grid import simulate, summarise, targets, OUT

t0 = time.time()
eo = "<repo>/__andres_control/eps_alcohol_outputs"
sp = pd.read_csv(f"{eo}/rho_same_people_three_interviews.csv")
sp = sp[sp.sex == "All"].set_index("pair").loc[["VI_VII_same_people", "VII_VIII_same_people", "VI_VIII_same_people"]]
r_obs = sp.rho_interval.values
se_z = (np.arctanh(sp.upper.values) - np.arctanh(sp.lower.values)) / (2 * norm.ppf(.975))
lags = np.array([3.671, 4.022, 7.693])
# Margins of the 50+ same-people panel (p2_triple_rho_by_age_sex.csv: VI 0.349, VIII 0.256); VII ~ midpoint (assumption).
p = {0: 0.349, 1: 0.3025, 2: 0.256}
pairs = [(0, 1), (1, 2), (0, 2)]

def bvn(h, k, r):
    return multivariate_normal.cdf([h, k], mean=[0, 0], cov=[[1, r], [r, 1]])

def tetra(pa, pb, p11):
    f = lambda r: bvn(norm.ppf(pa), norm.ppf(pb), r) - p11
    return brentq(f, -0.999, 0.999, xtol=1e-7)

def implied(lam, phi, s):
    out = []
    for (i, j), d in zip(pairs, lags):
        rm = lam + (1 - lam) * phi ** d
        p11 = (1 - s) * bvn(norm.ppf(p[i] / (1 - s)), norm.ppf(p[j] / (1 - s)), rm)
        out.append(tetra(p[i], p[j], p11))
    return np.array(out)

def obj(lam, phi, s):
    return float((((np.arctanh(r_obs) - np.arctanh(implied(lam, phi, s))) / se_z) ** 2).sum())

rows = []
for s in [0.0, 0.10, 0.15, 0.20, 0.25, 0.30]:
    best = None
    for lam in np.arange(0.0, 0.62, 0.04):
        for phi in np.arange(0.40, 0.96, 0.05):
            o = obj(lam, phi, s)
            if best is None or o < best[2]: best = (lam, phi, o)
    # local refinement around the coarse optimum
    for lam in np.clip(best[0] + np.arange(-0.04, 0.041, 0.01), 0, 0.95):
        for phi in np.clip(best[1] + np.arange(-0.05, 0.051, 0.01), 0.05, 0.99):
            o = obj(lam, phi, s)
            if o < best[2]: best = (lam, phi, o)
    rows.append(dict(s=s, lambda_m=round(best[0], 2), phi_m=round(best[1], 2), wls_obj=best[2],
                     obj_engine_0_08=obj(0.0, 0.8, s), obj_lam0_bestphi=min(obj(0.0, f, s) for f in np.arange(0.5, 0.99, 0.01))))
    print(rows[-1], round(time.time() - t0), "s", flush=True)
fit = pd.DataFrame(rows)
fit.to_csv(f"{OUT}/p4b_eps_fit_mover_stayer.csv", index=False)

# (2) ENPG quantities under mover-stayer, sex-specific s, movers' (lambda_m, phi_m) from the EPS refit.
res = []
for sex, ss in [("male", [0.08, 0.10, 0.12]), ("female", [0.14, 0.16, 0.18, 0.20])]:
    for s in ss:
        f = fit.iloc[(fit.s - s).abs().argmin()]
        for lam, phi, tag in [(f.lambda_m, f.phi_m, "eps_refit"), (0.0, 0.8, "engine_rho0.8"), (0.45, 0.68, "trait_no_stayer_params")]:
            res.append(dict(tag=tag, **summarise(simulate(lam, phi, sex, init="latent", stayer=s), lam, phi, sex, "latent", s)))
res = pd.DataFrame(res)
for sex in ["male", "female"]:
    for k, v in targets(sex).items(): res.loc[res.sex == sex, "target_" + k] = v
res.to_csv(f"{OUT}/p4b_grid_mover_stayer.csv", index=False)
print(f"p4b elapsed minutes: {(time.time() - t0) / 60:.2f}")
