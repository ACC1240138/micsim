# Independent recomputation of the engine-side HED claims (own code; notebook cells via own loader).
#  1 coefficients vs stored model_parameters.csv; mortality multipliers (DEIS vintage)
#  2 engine law expectation by quasi-MC u-grid (not integrate()); B over observed; nonparametric HED(g) on the engine law
#  3 simulations: rho 0/0.8/0.95 (seeds 2125-2129) and rho 0.8 (seeds 3125-3129); unweighted and population-weighted bias
#  4 B_wave fix re-solved on the grid and simulated; 5 holdout (fit <= 2020) for base; 6 rho_hed persistence for base
# Writes ONLY aggregated CSVs.
.t0 <- Sys.time()
source("<scratch>/audit/verify_hed/v0_loader.R")
library(data.table)
OUT <- VDIR
## 1 ---------------------------------------------------------------------------------------------
model <- ms_fit(2024L, "interp_hold")
st <- utils::read.csv("microsim_recalib_outputs/model_parameters.csv")
st <- st[st$fit == "reconstruction2024_interp_hold", ]
h_st <- st[st$component == "hed", ]
cf <- stats::coef(model$hed)
cat("max |HED coef - stored|:", max(abs(cf[h_st$parameter] - h_st$value)), "\n")
ms_st <- st[st$component == "all_cause_mortality", ]
cat("mortality_scale now:", round(model$mortality_scale, 6), " stored:", round(ms_st$value[match(names(model$mortality_scale), ms_st$parameter)], 6), "\n")

## 2 ---------------------------------------------------------------------------------------------
N <- 200000L; ugrid <- (seq_len(N) - 0.5) / N
drv <- ms_drivers(model, ms_wave_years)
b <- unname(cf["base::log1p(gpd_survey)"])
eng_g <- function(dr) { # engine g/day at each u grid point, as in ms_exposure (u <= p0 -> 0)
  g <- numeric(N); pos <- ugrid > dr$p_zero
  g[pos] <- stats::qgamma(pmin(1 - 1e-12, pmax(1e-12, (ugrid[pos] - dr$p_zero) / (1 - dr$p_zero))),
    shape = dr$shape, scale = dr$mu_current / ((1 - dr$p_zero) * dr$shape)); list(g = g, pos = pos)
}
x <- as.data.table(ms_enpg)[status == "current"]
x[, cell := paste(sex, age_group, sep = ":")]
glm_s <- x[is.finite(gpd_survey) & gpd_survey > 0 & !is.na(hed)]
glm_s[, pred := stats::predict(model$hed, newdata = as.data.frame(glm_s), type = "response")]
# Nonparametric observed HED(g): fine g/day bins, by cell, pooled waves (weights normalised within wave).
brk <- c(0, 1, 1.6, 2, 3, 4, 5, 7.5, 10, 15, 20, 30, 40, 60, Inf)
glm_s[, wn := weight / sum(weight), by = year]
glm_s[, gb := findInterval(gpd_survey, brk)]
np <- glm_s[, .(r = sum(wn * hed) / sum(wn)), by = .(cell, gb)]
bins <- c(0, 1, 2, 5, 10, 20, 40, Inf)
res <- rbindlist(lapply(seq_len(nrow(ms_targets)), function(i) {
  t <- ms_targets[i, ]; cl <- paste(t$sex, t$age_group, sep = ":")
  dr <- drv[drv$year == t$year & drv$sex == t$sex & drv$age_group == t$age_group, ]
  e <- eng_g(dr)
  p <- e$pos * stats::plogis(dr$hed_intercept + b * log1p(e$g))
  npl <- np[cell == cl]; rnp <- npl$r[match(findInterval(e$g, brk), npl$gb)]; rnp[is.na(rnp)] <- 0
  o <- glm_s[year == t$year & cell == cl]
  sh <- sapply(seq_len(length(bins) - 1), function(j) mean(e$pos & e$g >= bins[j] & e$g < bins[j + 1]))
  hb <- sapply(seq_len(length(bins) - 1), function(j) mean(p * (e$pos & e$g >= bins[j] & e$g < bins[j + 1])))
  data.table(year = t$year, sex = t$sex, age_group = t$age_group, se = t$hed_se, T = t$hed_mean,
    A = o[, weighted.mean(hed, weight)], B = o[, weighted.mean(pred, weight)],
    C = mean(p), C_np = mean(e$pos * rnp), mean_g_engine = mean(e$g), mu = dr$mu_current,
    sh1 = sh[1], sh6 = sh[6], hr1 = hb[1] / sh[1], hr3 = hb[3] / sh[3], hr6 = hb[6] / sh[6])
}))
cat("check grid mean g/day == mu (max rel err):", max(abs(res$mean_g_engine / res$mu - 1)), "\n")
cat(sprintf("Mean over 56 cells (pp): A-T %.3f | B-A %.3f | C-B %.3f | C-T %.3f | C_np-T %.3f | C_np-A %.3f\n",
  100 * mean(res$A - res$T), 100 * mean(res$B - res$A), 100 * mean(res$C - res$B), 100 * mean(res$C - res$T),
  100 * mean(res$C_np - res$T), 100 * mean(res$C_np - res$A)))
cat("cells with C-B < 0:", sum(res$C - res$B < 0), "of", nrow(res), "\n")
print(res[, .(dist_pp = round(100 * mean(C - B), 2), total_analytic_pp = round(100 * mean(C - T), 2)), by = sex])
print(res[, .(time_pp = round(100 * mean(B - A), 2), dist_pp = round(100 * mean(C - B), 2)), by = year])
print(res[, .(eng_share_lt1 = round(mean(sh1), 3), eng_share_20_40 = round(mean(sh6), 3),
  eng_hedrate_lt1 = round(mean(hr1), 3), eng_hedrate_2_5 = round(mean(hr3), 3)), by = sex])
fwrite(res, file.path(OUT, "v2_decomposition_grid.csv"))

## 3 ---------------------------------------------------------------------------------------------
simrun <- function(seeds, rho, tag) rbindlist(lapply(seeds, function(s) {
  r <- ms_simulate(model, 2012:2024, ms_cfg$n_sim, s, rho)$summary
  as.data.table(r)[, .(year, sex, age_group, n, current_mean, hed_mean, seed = s, rho = rho, tag = tag)]
}))
sims <- rbindlist(list(simrun(2125:2129, 0.8, "rho0.8_s2125"), simrun(2125:2129, 0, "rho0_s2125"),
  simrun(2125:2129, 0.95, "rho0.95_s2125"), simrun(3125:3129, 0.8, "rho0.8_s3125")))
fwrite(sims, file.path(OUT, "v2_sims.csv"))
tgt <- as.data.table(ms_targets)[, .(year, sex, age_group, T = hed_mean, se = hed_se)]
metr <- function(s) {
  cm <- s[, .(S = mean(hed_mean), cur = mean(current_mean), n = mean(n)), by = .(tag, year, sex, age_group)]
  cm <- merge(cm, tgt, by = c("year", "sex", "age_group"))
  cm[, err := S - T][, inside := fifelse(year == 2020L, NA, abs(err) <= stats::qnorm(0.975) * se)]
  pw <- cm[, .(Spool = sum(n * cur * S) / sum(n * cur), Tpool = sum(n * cur * T) / sum(n * cur)), by = .(tag, year)]
  m <- cm[, .(bias_pp = 100 * mean(err), rmse_pp = 100 * sqrt(mean(err^2)), cov_in = sum(inside, na.rm = TRUE),
    cov_n = sum(!is.na(inside))), by = tag]
  merge(m, pw[, .(popw_bias_pp = 100 * mean(Spool - Tpool)), by = tag], by = "tag")
}
mm <- metr(sims); print(mm, digits = 4)
fwrite(mm, file.path(OUT, "v2_sim_metrics.csv"))
s08 <- sims[tag == "rho0.8_s2125", .(S = mean(hed_mean)), by = .(year, sex, age_group)]
res2 <- merge(res, s08, by = c("year", "sex", "age_group"))
cat(sprintf("S - C (rho 0.8, 5 seeds) mean %.3f pp, range %.2f..%.2f\n", 100 * mean(res2$S - res2$C), 100 * min(res2$S - res2$C), 100 * max(res2$S - res2$C)))
# Survey-weighted pooled target (current-drinker weight totals) vs simulated pooled, per wave
cw <- x[!is.na(hed), .(Wc = sum(weight)), by = .(year, sex, age_group)]
pp <- merge(merge(s08, tgt, by = c("year", "sex", "age_group")), cw, by = c("year", "sex", "age_group"))
print(pp[, .(Tpool_pct = round(100 * sum(Wc * T) / sum(Wc), 2), Spool_pct = round(100 * sum(Wc * S) / sum(Wc), 2)), by = year][
  , diff_pp := Spool_pct - Tpool_pct][])

## 4 B_wave -------------------------------------------------------------------------------------
tabB <- rbindlist(lapply(seq_len(nrow(ms_targets)), function(i) {
  t <- ms_targets[i, ]; dr <- drv[drv$year == t$year & drv$sex == t$sex & drv$age_group == t$age_group, ]
  e <- eng_g(dr); lg <- log1p(e$g)
  a <- stats::uniroot(function(a) mean(e$pos * stats::plogis(a + b * lg)) - t$hed_mean, c(-30, 30), tol = 1e-10)$root
  data.table(cell = paste(t$sex, t$age_group, sep = ":"), year = t$year, a = a)
}))
ms_drivers_orig <- ms_drivers
ms_drivers <- function(model, years) {
  g <- ms_drivers_orig(model, years)
  g$hed_intercept <- vapply(seq_len(nrow(g)), function(i) { tb <- tabB[cell == as.character(g$cell[i])]
    stats::approx(tb$year, tb$a, xout = g$year[i], rule = 2)$y }, numeric(1))
  g
}
sB <- simrun(2125:2129, 0.8, "B_wave_s2125"); sB2 <- simrun(3125:3129, 0.8, "B_wave_s3125")
mB <- metr(rbindlist(list(sB, sB2))); print(mB, digits = 4)
ms_drivers <- ms_drivers_orig
fwrite(mB, file.path(OUT, "v2_bwave_metrics.csv"))

## 5 holdout base (fit <= 2020; interp_hold holds drivers at 2020) ---------------------------------
m20 <- ms_fit(2020L, "interp_hold"); d20 <- ms_drivers(m20, c(2022L, 2024L)); b20 <- unname(stats::coef(m20$hed)["base::log1p(gpd_survey)"])
ho <- rbindlist(lapply(which(ms_targets$year %in% c(2022L, 2024L)), function(i) {
  t <- ms_targets[i, ]; dr <- d20[d20$year == t$year & d20$sex == t$sex & d20$age_group == t$age_group, ]
  e <- eng_g(dr); t20 <- ms_targets$hed_mean[ms_targets$year == 2020L & ms_targets$sex == t$sex & ms_targets$age_group == t$age_group]
  data.table(year = t$year, T = t$hed_mean, se = t$hed_se, base = mean(e$pos * stats::plogis(dr$hed_intercept + b20 * log1p(e$g))), hold2020 = t20)
}))
print(ho[, .(variant = c("base", "hold2020"), bias_pp = 100 * c(mean(base - T), mean(hold2020 - T)),
  rmse_pp = 100 * c(sqrt(mean((base - T)^2)), sqrt(mean((hold2020 - T)^2))),
  cov = c(sum(abs(base - T) <= 1.96 * se), sum(abs(hold2020 - T) <= 1.96 * se)))], digits = 4)

## 6 rho_hed persistence, base, fixed 2024 cohort ----------------------------------------------------
set.seed(7); sk <- ms_population[ms_population$year == 2024L, ]
sk$n <- pmax(1L, as.integer(round(200000 * sk$pop_jan / sum(sk$pop_jan))))
p0 <- dplyr::bind_rows(lapply(seq_len(nrow(sk)), function(i) ms_new_people(sk$sex[i], sk$age[i], sk$n[i], 1e7 * i)))
d24 <- ms_drivers(model, 2024L)
for (rh in c(0, 0.8, 1)) {
  set.seed(11); p <- ms_exposure(p0, 2024L, d24); num <- den <- 0
  for (k in 1:5) {
    h0 <- p$hed; c0 <- p$current; n <- nrow(p)
    p$z_current <- 0.8 * p$z_current + 0.6 * stats::rnorm(n); p$z_amount <- 0.8 * p$z_amount + 0.6 * stats::rnorm(n)
    p$z_hed <- rh * p$z_hed + sqrt(1 - rh^2) * stats::rnorm(n)
    p <- ms_exposure(p, 2024L, d24)
    num <- num + sum(h0 & p$hed & c0 & p$current); den <- den + sum(h0 & c0 & p$current)
  }
  cat(sprintf("rho_hed %.2f: P(HED next | HED, current both) = %.3f ; HED margin = %.4f\n", rh, num / den, mean(p$hed[p$current])))
}
message(sprintf("v2 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
