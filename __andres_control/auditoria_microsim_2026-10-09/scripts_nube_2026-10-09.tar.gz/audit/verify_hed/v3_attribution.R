# Path-dependence of the "assignment by volume" attribution, and an alternative fix (empirical g/day law).
#  C_np      : ENPG's own HED-by-g/day curve (fine bins, by cell, pooled waves) applied to the engine Gamma law
#  C_emp     : notebook glm applied to an EMPIRICAL g/day law (weighted quantiles by cell, pooled waves, rescaled to mu(year))
#  share_lt04: engine share of drinkers below 0.4 g/day (the minimum g/day ENPG can produce: 1 day x 1 drink x 12 g / 30)
.t0 <- Sys.time()
source("<scratch>/audit/verify_hed/v0_loader.R")
library(data.table)
model <- ms_fit(2024L, "interp_hold"); drv <- ms_drivers(model, ms_wave_years)
b <- unname(stats::coef(model$hed)["base::log1p(gpd_survey)"])
N <- 200000L; ugrid <- (seq_len(N) - 0.5) / N
x <- as.data.table(ms_enpg)[status == "current" & is.finite(gpd_survey) & gpd_survey > 0]
x[, cell := paste(sex, age_group, sep = ":")][, wn := weight / sum(weight), by = year]
cat("min observed g/day among current drinkers:", min(x$gpd_survey), "\n")
brk <- c(0, 1, 1.6, 2, 3, 4, 5, 7.5, 10, 15, 20, 30, 40, 60, Inf)
xh <- x[!is.na(hed)][, gb := findInterval(gpd_survey, brk)]
np <- xh[, .(r = sum(wn * hed) / sum(wn)), by = .(cell, gb)]
wq <- function(g, w, p) { o <- order(g); cw <- cumsum(w[o]) / sum(w); g[o][pmin(length(g), findInterval(p, cw) + 1L)] }
res <- rbindlist(lapply(seq_len(nrow(ms_targets)), function(i) {
  t <- ms_targets[i, ]; cl <- paste(t$sex, t$age_group, sep = ":")
  dr <- drv[drv$year == t$year & drv$cell == cl, ]
  pos <- ugrid > dr$p_zero; v <- pmin(1 - 1e-12, pmax(1e-12, (ugrid - dr$p_zero) / (1 - dr$p_zero)))
  g <- ifelse(pos, stats::qgamma(v, dr$shape, scale = dr$mu_current / ((1 - dr$p_zero) * dr$shape)), 0)
  npl <- np[cell == cl][order(gb)]; idx <- findInterval(g, brk)
  r_lo <- npl$r[match(idx, npl$gb)]
  # empty fine bins: carry nearest observed bin (both directions) instead of 0
  r_nn <- vapply(seq_len(length(brk) - 1L), function(k) npl$r[which.min(abs(npl$gb - k))], numeric(1))[idx]
  xc <- x[cell == cl]; q <- wq(xc$gpd_survey, xc$wn, v)
  q <- q * dr$mu_current / ((1 - dr$p_zero) * mean(q))
  data.table(year = t$year, sex = t$sex, age_group = t$age_group, T = t$hed_mean,
    C = mean(pos * stats::plogis(dr$hed_intercept + b * log1p(g))),
    C_np_na0 = mean(pos * ifelse(is.na(r_lo), 0, r_lo)), C_np_nn = mean(pos * r_nn),
    C_emp = mean(pos * stats::plogis(dr$hed_intercept + b * log1p(q))),
    share_lt04 = mean(pos & g < 0.4), empty_bin_mass = mean(pos & is.na(r_lo)))
}))
cat(sprintf("mean over 56 cells (pp): C-T %.2f | C_np(NA->0)-T %.2f | C_np(nearest)-T %.2f | C_emp-T %.2f | empty-bin mass %.4f\n",
  100 * mean(res$C - res$T), 100 * mean(res$C_np_na0 - res$T), 100 * mean(res$C_np_nn - res$T), 100 * mean(res$C_emp - res$T), mean(res$empty_bin_mass)))
print(res[, .(share_below_0.4gpd = round(mean(share_lt04), 3), C_emp_minus_T_pp = round(100 * mean(C_emp - T), 2),
  C_np_minus_T_pp = round(100 * mean(C_np_nn - T), 2)), by = sex])
print(res[, .(C_emp_minus_T_pp = round(100 * mean(C_emp - T), 2)), by = year])
fwrite(res, file.path(VDIR, "v3_attribution.csv"))
message(sprintf("v3 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
