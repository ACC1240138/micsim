# Own loader: runs the notebook cells extracted by THIS verifier (verify_hed/cells, byte-identical to the notebook source).
# Substitutions: no arrow/knitr/IRdisplay/ggplot2 (not installed); DEIS 2012-2023 parquet read by python into R tempdir().
.t0_load <- Sys.time()
VDIR <- "<scratch>/audit/verify_hed"
setwd("<repo>/__andres_control")
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
pq <- function(path, cols) {
  out <- tempfile(fileext = ".csv")  # R tempdir(), never the scratchpad
  code <- sprintf("import pandas as pd; pd.read_parquet(r'%s', columns=%s).to_csv(r'%s', index=False)",
    path, paste0("[", paste0("'", cols, "'", collapse = ","), "]"), out)
  stopifnot(system2("python3", c("-I", "-c", shQuote(code))) == 0)
  x <- utils::read.csv(out, stringsAsFactors = FALSE); unlink(out); x[cols]
}
cell <- function(label, subs = list()) {
  src <- paste(readLines(file.path(VDIR, "cells", paste0(label, ".R")), warn = FALSE), collapse = "\n")
  for (s in subs) { stopifnot(grepl(s[1], src, fixed = TRUE)); src <- gsub(s[1], s[2], src, fixed = TRUE) }
  invisible(utils::capture.output(eval(parse(text = src), envir = globalenv())))
}
cell("ms-setup", list(c('"arrow", "knitr", "IRdisplay", "ggplot2", ', ''),
  c('IRdisplay::display_html(base::as.character(knitr::kable(x, format = "html", digits = 4,\n    row.names = FALSE, caption = caption)))', 'invisible(NULL)')))
cell("ms-survey-inputs")
cell("ms-demography-inputs", list(c('base::as.data.frame(arrow::read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]),\n  col_select = base::c("year", "gender", "age")))',
  'pq(ms_path(ms_demography_files[["deaths_2012_2023"]]), base::c("year", "gender", "age"))')))
cell("ms-calibration-functions")
cell("ms-annual-engine")
stopifnot(nrow(ms_targets) == 56L)
message(sprintf("loader minutes: %.2f | DEIS 2024 file: %s", as.numeric(difftime(Sys.time(), .t0_load, units = "mins")), ms_deis_enc))
