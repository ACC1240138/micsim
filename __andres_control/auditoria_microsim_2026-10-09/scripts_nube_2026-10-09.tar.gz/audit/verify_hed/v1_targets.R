# Independent rebuild of the ENPG HED target from the raw derived file (not via the notebook cells or hed_* scripts).
# Checks: cell targets T, pooled complete-case vs unknown-as-no (vs SENDA), NA-g/day coverage, observed g/day bins.
# Writes ONLY aggregated CSVs to verify_hed/.
.t0 <- Sys.time()
OUT <- "<scratch>/audit/verify_hed"
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
setwd("<repo>")
source(file.path("<repo>", "_tools", "acc_data.R"))
library(data.table)
raw <- as.data.table(readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS")))
des <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "derived/enpg_design_waves_2012_2024_list.RDS"))
w <- rbindlist(lapply(names(des$waves), function(y) data.table(year = as.integer(y), id = as.character(des$waves[[y]]$id_join),
  wt = des$waves[[y]]$weight)))
raw[, id := as.character(id)]
d <- merge(raw[, .(id, year = as.integer(year), sexo = as.character(sexo), edad = as.numeric(edad),
  oh1 = as.character(oh1), oh2 = as.character(oh2), oh3 = as.numeric(oh3), db = as.numeric(db), audit2 = as.character(audit2))],
  w, by = c("year", "id"), all.x = TRUE)
stopifnot(!anyNA(d$wt), nrow(d) == nrow(raw))
d[, sex := fifelse(sexo == "Hombre", "male", "female")]
d[, status := fcase(oh1 == "No" & is.na(oh2), "never",
                    oh1 == "Si" & oh2 == "30 dias", "current",
                    oh1 == "Si" & oh2 %in% c(">30", ">1 año"), "former", default = "unknown")]
d[, ep := fifelse(is.finite(db) & db >= 0 & db < 88, db, NA_real_)]
d[, days := fifelse(is.finite(oh3) & oh3 >= 0 & oh3 <= 30, oh3, NA_real_)]
d[, drinks := c("0-2" = 1, "3-4" = 3.5, "5-6" = 5.5, "7-8" = 7.5, "9 o mas" = 9)[audit2]]
d[, gpd := (pmax(days - ep, 0) * drinks + ep * fifelse(sex == "male", 5, 4)) * 12 / 30]
d[, hed := as.numeric(ep > 0)]
d[, ag := findInterval(edad, c(15, 30, 45, 60))]
d[, dom := edad >= 15 & edad <= 65]
cur <- d[status == "current"]
cat("age range in file:", range(d$edad), "\n")

# (1) Cell targets T: weighted HED among current drinkers with HED known, 15-65.
T <- cur[dom == TRUE & !is.na(hed), .(T = weighted.mean(hed, wt), n_cur_hedobs = .N), by = .(year, sex, ag)]
cur_n <- cur[dom == TRUE, .(n_current = .N), by = .(year, sex, ag)]
T <- merge(T, cur_n, by = c("year", "sex", "ag"))
setorder(T, year, sex, ag)
fwrite(T, file.path(OUT, "v1_cell_targets.csv"))

# (2) Pooled HED among current drinkers: complete case vs unknown-as-no, 15-65 and all ages (12-65).
senda <- c(`2012` = 52.1, `2014` = 43.7, `2016` = 51.1, `2018` = 56.3, `2020` = 50.2, `2022` = 50.7, `2024` = 47.2)
pool <- rbindlist(lapply(c(TRUE, FALSE), function(only15) cur[if (only15) dom == TRUE else rep(TRUE, .N),
  .(cc = 100 * weighted.mean(hed, wt, na.rm = TRUE), uan = 100 * sum(wt * (hed %in% 1)) / sum(wt),
    unk_w = 100 * sum(wt * is.na(hed)) / sum(wt), n = .N), by = year][, ages := if (only15) "15-65" else "all(12-65)"]))
pool[, senda := senda[as.character(year)]][, cc_minus_senda := cc - senda][, uan_minus_senda := uan - senda]
setorder(pool, ages, year)
print(pool, digits = 3)
fwrite(pool, file.path(OUT, "v1_pooled_vs_senda.csv"))

# (3) Coverage: current 15-65 with HED known but g/day NA.
cv <- cur[dom == TRUE & !is.na(hed)]
cat(sprintf("current 15-65 HED known: %d ; of which gpd NA: %d ; gpd NA & days NA: %d ; gpd NA & drinks NA (days ok): %d ; gpd == 0: %d\n",
  nrow(cv), sum(!is.finite(cv$gpd)), sum(!is.finite(cv$gpd) & is.na(cv$days)), sum(!is.finite(cv$gpd) & !is.na(cv$days) & is.na(cv$drinks)),
  sum(cv$gpd == 0, na.rm = TRUE)))
cov_cell <- cv[, .(share_den = sum(wt[!is.finite(gpd)]) / sum(wt), share_hed = sum(wt[!is.finite(gpd)] * hed[!is.finite(gpd)]) / sum(wt * hed),
  T = weighted.mean(hed, wt), A = weighted.mean(hed[is.finite(gpd) & gpd > 0], wt[is.finite(gpd) & gpd > 0])), by = .(year, sex, ag)]
cat(sprintf("mean over 56 cells: share of weighted denominator %.2f%%, share of weighted HED cases %.2f%%, A-T %.3f pp (min %.2f, max %.2f)\n",
  100 * mean(cov_cell$share_den), 100 * mean(cov_cell$share_hed), 100 * mean(cov_cell$A - cov_cell$T),
  100 * min(cov_cell$A - cov_cell$T), 100 * max(cov_cell$A - cov_cell$T)))
cat(sprintf("POOLED (all waves, weights as given, waves not normalised): share den %.2f%%, share HED %.2f%%\n",
  100 * cv[, sum(wt[!is.finite(gpd)]) / sum(wt)], 100 * cv[, sum((wt * hed)[!is.finite(gpd)]) / sum(wt * hed)]))
fwrite(cov_cell, file.path(OUT, "v1_coverage_cells.csv"))
# HED floor: any HED episode forces gpd >= 2.0 (men) / 1.6 (women)
cat("HED cases below floor:", cv[is.finite(gpd) & hed == 1 & gpd < fifelse(sex == "male", 2, 1.6) - 1e-9, .N], "\n")

# (4) Observed g/day bins among glm sample (current, gpd>0 finite, HED known), mean of cell shares over 4 ages x 7 waves.
g <- cv[is.finite(gpd) & gpd > 0]
g[, bin := cut(gpd, c(0, 1, 2, 5, 10, 20, 40, Inf), right = FALSE)]
tot <- g[, .(W = sum(wt)), by = .(year, sex, ag)]
b <- g[, .(m = sum(wt), h = sum(wt * hed)), by = .(year, sex, ag, bin)]
b <- merge(CJ(year = unique(g$year), sex = c("female", "male"), ag = 1:4, bin = levels(g$bin)), b, by = c("year", "sex", "ag", "bin"), all.x = TRUE)
b[is.na(m), `:=`(m = 0, h = 0)]
b <- merge(b, tot, by = c("year", "sex", "ag"))
bs <- b[, .(share_obs = mean(m / W), hedmass_obs = mean(h / W)), by = .(sex, bin)][, hed_rate_obs := hedmass_obs / share_obs]
print(bs, digits = 3)
fwrite(bs, file.path(OUT, "v1_obs_bins.csv"))
# Population-weighted alternative (pooled weights within sex, each wave normalised to equal total)
g[, wn := wt / sum(wt), by = year]
print(g[, .(share = sum(wn)), by = .(sex, bin)][, share := share / sum(share), by = sex][order(sex, bin)], digits = 3)
message(sprintf("v1 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
