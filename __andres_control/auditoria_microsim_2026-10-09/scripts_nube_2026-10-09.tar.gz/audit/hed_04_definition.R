# Step 1: HED definition by wave. (a) raw questionnaire item vs ENPG_BINGE$db used by the notebook;
# (b) design-weighted HED among current drinkers, pooled 15-65 and by cell, vs SENDA's published series.
# Writes only aggregated CSVs.
.t0 <- Sys.time()
source("<scratch>/audit/hed_00_load_engine.R")
root <- dirname(dirname(acc_data("_enpg/enpg.tar.xz.enc", "derived/ENPG_BINGE.RDS")))
spec <- list(
  "2012" = list(f = "Base de datos ENPG 2012 (PG).DTA.dta", id = "idencuesta", hed = "p16"),
  "2014" = list(f = "Base de datos ENPG 2014 (PG).DTA.dta", id = "idencuesta", hed = "oh7"),
  "2016" = list(f = "base ENPG 2016 publico general.dta", id = "idencuesta", hed = c("oh_7a", "oh_7b")),
  "2018" = list(f = "Base de datos ENPG 2018 (PG).DTA", id = "SbjNum", hed = c("OH_7H", "OH_7M")),
  "2020" = list(f = "enpg2020.RDS", id = "SbjNum", hed = "OH_7"),
  "2022" = list(f = "BD - ENPG 2022 (Stata 16).dta", id = "FOLIO", hed = "OH_7"),
  "2024" = list(f = "Base Publica ENPG 2024 (Stata 16).dta", id = "RESPONDENT_SERIAL", hed = "OH_7"))
raw_check <- do.call(rbind, lapply(names(spec), function(y) {
  s <- spec[[y]]
  p <- file.path(root, s$f)
  d <- if (grepl("RDS$", p)) readRDS(p)[c(s$id, s$hed)] else haven::read_dta(p, col_select = tidyselect::all_of(c(s$id, s$hed)))
  d <- as.data.frame(lapply(d, function(v) as.numeric(haven::zap_labels(v))))
  # Sex-specific items are mutually exclusive; take whichever is non-missing.
  cnt <- if (length(s$hed) == 2) ifelse(is.na(d[[2]]), d[[3]], d[[2]]) else d[[2]]
  both <- if (length(s$hed) == 2) sum(!is.na(d[[2]]) & !is.na(d[[3]])) else NA_integer_
  x <- ms_enpg[ms_enpg$year == as.integer(y) & ms_enpg$status == "current", ]
  k <- match(x$id, as.character(d[[1]]))
  raw <- cnt[k]
  raw_clean <- ifelse(raw >= 88 | raw < 0, NA, raw)
  data.frame(year = as.integer(y), item = paste(s$hed, collapse = "/"), current_n = nrow(x),
    id_matched = sum(!is.na(k)), raw_both_sex_items = both,
    raw_code_88_99 = sum(raw %in% c(88, 99)), raw_code_888_999 = sum(raw %in% c(888, 999)),
    raw_31_87 = sum(raw > 30 & raw < 88, na.rm = TRUE), raw_ge_100_not_code = sum(raw >= 100 & !raw %in% c(888, 999), na.rm = TRUE),
    raw_na = sum(is.na(raw)),
    hed_na_notebook = sum(is.na(x$hed)),
    agree_hed_indicator = sum((raw_clean > 0) == (x$hed == 1), na.rm = TRUE),
    disagree_hed_indicator = sum((raw_clean > 0) != (x$hed == 1), na.rm = TRUE),
    na_mismatch = sum(is.na(raw_clean) != is.na(x$hed)))
}))
print(raw_check)
utils::write.csv(raw_check, file.path(AUDIT, "hed_def_raw_vs_db.csv"), row.names = FALSE)

# Pooled design-weighted HED among current drinkers, 15-65 (model domain) and all ages in the file (SENDA uses 12-65).
senda <- c(`2012` = 52.1, `2014` = 43.7, `2016` = 51.1, `2018` = 56.3, `2020` = 50.2, `2022` = 50.7, `2024` = 47.2)
pooled <- do.call(rbind, lapply(ms_wave_years, function(y) {
  a <- ms_enpg_all[ms_enpg_all$year == y & ms_enpg_all$status == "current", ]
  b <- a[a$in_domain, ]
  f <- function(z) 100 * stats::weighted.mean(z$hed, z$weight, na.rm = TRUE)
  data.frame(year = y, hed_pct_current_15_65 = f(b), hed_pct_current_all_ages_in_file = f(a),
    min_age_in_file = min(ms_enpg_all$age[ms_enpg_all$year == y]),
    senda_published_12_65 = senda[[as.character(y)]],
    n_current_15_65 = nrow(b), n_hed_observed_15_65 = sum(!is.na(b$hed)))
}))
pooled$diff_all_ages_vs_senda_pp <- pooled$hed_pct_current_all_ages_in_file - pooled$senda_published_12_65
print(pooled)
utils::write.csv(pooled, file.path(AUDIT, "hed_def_pooled_vs_senda.csv"), row.names = FALSE)

# Cell-level targets (design-weighted, from ms_targets) in wide form for the report.
cell <- ms_targets[c("year", "sex", "age_group", "n_current", "n_hed", "hed_mean", "hed_se")]
utils::write.csv(cell, file.path(AUDIT, "hed_def_cell_targets.csv"), row.names = FALSE)
print(stats::xtabs(round(100 * hed_mean, 1) ~ paste(sex, age_group) + year, cell))
message(sprintf("04_hed_definition elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
