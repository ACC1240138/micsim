# Step 1 (published aggregates only): fit trait + AR(1) to the three same-people EPS tetrachoric correlations.
# Inputs: __andres_control/eps_alcohol_outputs/rho_same_people_three_interviews.csv (+ interval assumptions).
.t0 <- Sys.time()
audit <- "<scratch>/audit"
source(file.path(audit, "fit_lib.R"))
eo <- "<repo>/__andres_control/eps_alcohol_outputs"
sp <- utils::read.csv(file.path(eo, "rho_same_people_three_interviews.csv"))
iv <- utils::read.csv(file.path(eo, "interview_interval_assumptions.csv"))
# Lags: VI-VII and VI-VIII from the file; VII-VIII = 4.022 (3.554-4.490) as coded in cell eps-panel-diagnostics.
lag <- c(VI_VII_same_people = iv$delta[iv$pair == "VI_VII"], VII_VIII_same_people = 4.022,
         VI_VIII_same_people = iv$delta[iv$pair == "VI_VIII"])
lag_min <- c(iv$delta_min[iv$pair == "VI_VII"], 3.554, iv$delta_min[iv$pair == "VI_VIII"])
lag_max <- c(iv$delta_max[iv$pair == "VI_VII"], 4.490, iv$delta_max[iv$pair == "VI_VIII"])
sp$d <- lag[sp$pair]
# SE on the Fisher-z scale from the published 95% CI (normal approximation; the notebook used qt with design df).
sp$se_z <- (atanh(sp$upper) - atanh(sp$lower)) / (2 * stats::qnorm(.975))
set.seed(1240138)
B <- 4000
res <- do.call(rbind, lapply(c("All", "Men", "Women"), function(s) {
  x <- sp[sp$sex == s, ]; x <- x[match(names(lag), x$pair), ]
  f2 <- fit_trait_ar1(x$rho_interval, x$d, x$se_z); f1 <- fit_ar1(x$rho_interval, x$d, x$se_z)
  # Parametric bootstrap, independent normal errors on atanh(r) (ignores the positive covariance of same-people estimates).
  bt <- t(replicate(B, { rs <- tanh(stats::rnorm(3, atanh(x$rho_interval), x$se_z)); fit_trait_ar1(rs, x$d, x$se_z)[1:2] }))
  # Timing sensitivity: fieldwork-date envelopes for the lags.
  fmin <- fit_trait_ar1(x$rho_interval, lag_min, x$se_z); fmax <- fit_trait_ar1(x$rho_interval, lag_max, x$se_z)
  data.frame(sex = s, n = x$n[1], lambda = f2[["lambda"]], phi = f2[["phi"]], wls_obj_trait = f2[["obj"]],
    phi_ar1_only = f1[["phi"]], wls_obj_ar1 = f1[["obj"]],
    lambda_boot_lo = stats::quantile(bt[, 1], .025), lambda_boot_hi = stats::quantile(bt[, 1], .975),
    phi_boot_lo = stats::quantile(bt[, 2], .025), phi_boot_hi = stats::quantile(bt[, 2], .975),
    share_boot_lambda_lt_0.05 = mean(bt[, 1] < .05),
    lambda_lagmin = fmin[["lambda"]], phi_lagmin = fmin[["phi"]], lambda_lagmax = fmax[["lambda"]], phi_lagmax = fmax[["phi"]],
    r1y = r_model(f2[["lambda"]], f2[["phi"]], 1), r10y = r_model(f2[["lambda"]], f2[["phi"]], 10),
    obj_at_0.45_0.65 = wls_obj(.45, .65, x$rho_interval, x$d, x$se_z),
    obj_at_engine_0_0.8 = wls_obj(0, .8, x$rho_interval, x$d, x$se_z), row.names = NULL)
}))
utils::write.csv(res, file.path(audit, "out", "p1_fit_same_people_csv.csv"), row.names = FALSE)
print(format(res, digits = 3))

# Fitted vs observed correlations (All).
x <- sp[sp$sex == "All", ]; x <- x[match(names(lag), x$pair), ]
f2 <- fit_trait_ar1(x$rho_interval, x$d, x$se_z); f1 <- fit_ar1(x$rho_interval, x$d, x$se_z)
fv <- data.frame(pair = x$pair, lag = x$d, observed = x$rho_interval, lower = x$lower, upper = x$upper,
  fit_trait_ar1 = r_model(f2[["lambda"]], f2[["phi"]], x$d), fit_ar1 = r_model(0, f1[["phi"]], x$d),
  proposal_0.45_0.65 = r_model(.45, .65, x$d), engine_ar1_0.8 = .8^x$d)
utils::write.csv(fv, file.path(audit, "out", "p1_fitted_vs_observed_all.csv"), row.names = FALSE)
print(format(fv, digits = 3))

# Profile of the WLS objective (All): grid over lambda x phi; profile minima; joint 95% region (delta <= 5.99).
g <- expand.grid(lambda = seq(0, .9, .01), phi = seq(.05, .99, .01))
g$obj <- mapply(wls_obj, g$lambda, g$phi, MoreArgs = list(r = x$rho_interval, d = x$d, se_z = x$se_z))
g$delta <- g$obj - min(g$obj)
prof_l <- stats::aggregate(delta ~ lambda, g, min); prof_p <- stats::aggregate(delta ~ phi, g, min)
utils::write.csv(g, file.path(audit, "out", "p1_profile_grid_all.csv"), row.names = FALSE)
cat("Profile 95% (delta<=3.84) lambda range:", range(prof_l$lambda[prof_l$delta <= 3.84]), "\n")
cat("Profile 95% (delta<=3.84) phi range:", range(prof_p$phi[prof_p$delta <= 3.84]), "\n")
cat("Profile lambda (every 0.05):\n"); print(prof_l[prof_l$lambda %in% round(seq(0, .9, .05), 2), ])
reg <- g[g$delta <= 5.99, ]
cat("Joint 95% region: lambda", range(reg$lambda), " phi", range(reg$phi), "\n")
# Ridge: within the joint region, implied 1-year and 10-year correlations are tightly linked.
reg$r1 <- r_model(reg$lambda, reg$phi, 1); reg$r10 <- r_model(reg$lambda, reg$phi, 10)
cat("Joint region implied r(1y):", round(range(reg$r1), 3), " r(10y):", round(range(reg$r10), 3), "\n")

# Same model on the full (not same-people) 50+ pairs VI-VII, VI-VIII: exactly identified.
s50 <- utils::read.csv(file.path(eo, "rho_summary_50plus.csv"))
full <- do.call(rbind, lapply(c("All", "Men", "Women"), function(s) {
  a <- s50[s50$sex == s & s50$pair == "VI_VII", ]; b <- s50[s50$sex == s & s50$pair == "VI_VIII", ]
  cbind(sex = s, as.data.frame(t(solve_two(a$rho_interval, b$rho_interval, 3.671, 7.693))))
}))
print(full)
utils::write.csv(full, file.path(audit, "out", "p1_fit_full_pairs_50plus.csv"), row.names = FALSE)
message(sprintf("p1_fit_csv elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
