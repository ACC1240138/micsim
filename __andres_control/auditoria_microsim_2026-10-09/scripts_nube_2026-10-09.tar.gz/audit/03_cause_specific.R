# 03_cause_specific.R -- item 2: deaths and rates by year x sex x age band x cause (expand_pif map, mutually exclusive),
# small-cell counts, year-to-year CV, and a leave-one-year-out (LOYO) test of smoothing rules for engine hazards.
.t0 <- Sys.time()
library(data.table)
AUD <- "<scratch>/audit"
d <- fread(file.path(AUD, "agg", "deaths_year_sex_age_cause.csv"))
pop <- fread(file.path(AUD, "agg", "ine_pop_2012_2025.csv"))[year <= 2024]
d[sex == "male" & cause == "Breast Cancer", cause := "All other causes"]   # expand_pif: breast cancer is female-only
bands <- c(14, 29, 44, 59, 65, 79, Inf); labs <- c("15-29", "30-44", "45-59", "60-65", "66-79", "80+")
d[, band := cut(age, bands, labels = labs)]; pop[, band := cut(age, bands, labels = labs)]
causes <- setdiff(unique(d$cause), character())
grid <- CJ(year = 2012:2024, sex = c("female", "male"), band = factor(labs, labs), cause = causes)
grid <- grid[!(sex == "male" & cause == "Breast Cancer")]
cell <- merge(grid, d[, .(deaths = sum(deaths)), by = .(year, sex, band, cause)], all.x = TRUE)
cell[is.na(deaths), deaths := 0L]
cell <- merge(cell, pop[!is.na(band), .(pop_mid = sum(pop_mid)), by = .(year, sex, band)], by = c("year", "sex", "band"))
cell[, rate100k := 1e5 * deaths / pop_mid]
stopifnot(sum(cell$deaths) == sum(d$deaths))
fwrite(cell, file.path(AUD, "out_B1_cells_year_sex_band_cause.csv"))

# ---- summary per cause x sex x band over 13 years ----
sm <- cell[, .(mean_deaths = mean(deaths), min_deaths = min(deaths), max_deaths = max(deaths),
  rate100k = 1e5 * sum(deaths) / sum(pop_mid), years_lt10 = sum(deaths < 10), years_zero = sum(deaths == 0),
  cv_rate = sd(rate100k) / mean(rate100k), cv_poisson = 1 / sqrt(mean(deaths)),
  cv_rate_pre_covid = sd(rate100k[year <= 2019]) / mean(rate100k[year <= 2019])), by = .(cause, sex, band)]
fwrite(sm, file.path(AUD, "out_B2_summary_cause_sex_band.csv"))
small <- cell[, .(cells = .N, cells_lt10 = sum(deaths < 10), cells_zero = sum(deaths == 0)), by = .(scope = fifelse(band %in% labs[1:4], "15-65 (engine)", "66+"))]
print(small); fwrite(small, file.path(AUD, "out_B2_small_cells.csv"))

# ---- LOYO smoothing test on engine cells (15-65, 4 bands), held-out years 2013-2023 ----
# Methods use no data from the held-out year t:
#  S1 neighbours: (D[t-1]+D[t+1])/(P[t-1]+P[t+1]);  S2 mean of all other years;  S3 Poisson log-linear trend on other years;
#  S4 = S3 fitted without 2020-2021;  S5 = S3 on cause x sex with band effects (pooled trend across bands, fewer parameters).
pdev <- function(y, mu) 2 * sum(ifelse(y > 0, y * log(y / mu), 0) - (y - mu))
eng <- cell[band %in% labs[1:4]]; eng[, band := droplevels(band)]
loyo <- rbindlist(lapply(2013:2023, function(t) {
  tr <- eng[year != t]; te <- eng[year == t]
  s1 <- eng[year %in% c(t - 1, t + 1), .(mu_rate = sum(deaths) / sum(pop_mid)), by = .(cause, sex, band)]
  s2 <- tr[, .(mu_rate = sum(deaths) / sum(pop_mid)), by = .(cause, sex, band)]
  fit_tr <- function(dd, form) dd[, {
    f <- suppressWarnings(glm(form, family = poisson, offset = log(pop_mid), data = .SD))
    nd <- te[cause == .BY$cause & sex == .BY$sex]
    .(band = nd$band, mu_rate = predict(f, newdata = nd, type = "response") / nd$pop_mid)
  }, by = .(cause, sex)]
  s3 <- tr[, {
    f <- suppressWarnings(glm(deaths ~ I(year - 2018), family = poisson, offset = log(pop_mid)))
    .(mu_rate = exp(coef(f)[1] + coef(f)[2] * (t - 2018)))
  }, by = .(cause, sex, band)]
  s4 <- tr[!year %in% 2020:2021, {
    f <- suppressWarnings(glm(deaths ~ I(year - 2018), family = poisson, offset = log(pop_mid)))
    .(mu_rate = exp(coef(f)[1] + coef(f)[2] * (t - 2018)))
  }, by = .(cause, sex, band)]
  s5 <- fit_tr(tr, deaths ~ band + I(year - 2018))
  out <- rbindlist(list(S1_neighbours = s1, S2_mean_other_years = s2, S3_trend_by_band = s3,
                        S4_trend_excl_2020_21 = s4, S5_trend_shared_across_bands = s5), idcol = "method")
  out <- merge(out, te[, .(cause, sex, band, deaths, pop_mid)], by = c("cause", "sex", "band"))
  out[, `:=`(year = t, mu = mu_rate * pop_mid)]
}))
stopifnot(!anyNA(loyo$mu))
# A zero pooled rate cannot predict a positive count (infinite deviance): floor at 0.1 expected deaths and count it.
loyo[, floored := mu < 0.1][floored == TRUE, mu := 0.1]
res_all <- loyo[, .(poisson_deviance = pdev(deaths, mu), mae_deaths = mean(abs(deaths - mu)), cells = .N, floored = sum(floored)), by = method]
res_pre <- loyo[!year %in% 2020:2022, .(poisson_deviance_excl_2020_22 = pdev(deaths, mu)), by = method]
res_nc <- loyo[!year %in% 2020:2022 & !grepl("COVID", cause), .(deviance_excl_2020_22_and_covid_cause = pdev(deaths, mu), cells_excl_covid = .N), by = method]
res <- Reduce(function(a, b) merge(a, b, by = "method"), list(res_all, res_pre, res_nc))
res[, deviance_per_cell_excl_covid := deviance_excl_2020_22_and_covid_cause / cells_excl_covid]
print(res[order(deviance_excl_2020_22_and_covid_cause)])
fwrite(res, file.path(AUD, "out_B3_loyo_overall.csv"))
by_cause <- loyo[!year %in% 2020:2022, .(dev = pdev(deaths, mu)), by = .(cause, method)]
by_cause <- dcast(by_cause, cause ~ method, value.var = "dev")
by_cause[, best := names(.SD)[apply(.SD, 1, which.min)], .SDcols = -1]
print(by_cause[, .(cause, best)]); fwrite(by_cause, file.path(AUD, "out_B3_loyo_by_cause.csv"))
# Reference: expected deviance under pure Poisson noise is ~ number of cells (df); report the ratio.
res[, cells_excl := loyo[!year %in% 2020:2022, .N, by = method][match(res$method, method), N]]
res[, deviance_per_cell_excl_2020_22 := poisson_deviance_excl_2020_22 / cells_excl]
fwrite(res, file.path(AUD, "out_B3_loyo_overall.csv"))

# ---- Single-age shape: within-band flat (S5) vs Poisson GLM ns(age,4)+year per cause x sex, LOYO at single age ----
sa <- merge(CJ(year = 2012:2024, sex = c("female", "male"), age = 15:65, cause = causes)[!(sex == "male" & cause == "Breast Cancer")],
            d[age <= 65, .(deaths = sum(deaths)), by = .(year, sex, age, cause)], all.x = TRUE)
sa[is.na(deaths), deaths := 0L]
sa <- merge(sa, pop[, .(year, sex, age, pop_mid)], by = c("year", "sex", "age"))
sa[, band := cut(age, bands[1:5], labels = labs[1:4])]
loyo_sa <- rbindlist(lapply(2013:2023, function(t) {
  tr <- sa[year != t & !year %in% 2020:2021]; te <- sa[year == t]
  out <- tr[, {
    f1 <- suppressWarnings(glm(deaths ~ band + I(year - 2018), family = poisson, offset = log(pop_mid)))
    f2 <- suppressWarnings(glm(deaths ~ splines::ns(age, knots = c(29.5, 44.5, 59.5), Boundary.knots = c(15, 65)) + I(year - 2018),
                               family = poisson, offset = log(pop_mid)))
    nd <- te[cause == .BY$cause & sex == .BY$sex]
    .(age = nd$age, deaths = nd$deaths, flat_band = exp(predict(f1, nd)), spline_age = exp(predict(f2, nd)))
  }, by = .(cause, sex)]
  out[, year := t]
}))
sa_res <- loyo_sa[!year %in% 2020:2022, .(flat_band_trend = pdev(deaths, flat_band), spline_age_trend = pdev(deaths, spline_age), cells = .N), by = cause]
sa_res <- rbind(sa_res, sa_res[, .(cause = "TOTAL", flat_band_trend = sum(flat_band_trend), spline_age_trend = sum(spline_age_trend), cells = sum(cells))])
print(sa_res); fwrite(sa_res, file.path(AUD, "out_B4_loyo_single_age.csv"))

# ---- Microsim granularity: expected deaths per year in the simulated 15-65 population ----
tot <- cell[band %in% labs[1:4] & year %in% 2022:2024, .(deaths_per_year = sum(deaths) / 3), by = cause]
P <- pop[year == 2024 & age %in% 15:65, sum(pop_jan)]
for (n in c(25000, 100000)) tot[, paste0("sim_deaths_per_year_n", n / 1000, "k") := deaths_per_year * n / P]
tot[, mc_rel_se_n100k_realized := 1 / sqrt(sim_deaths_per_year_n100k)]
setorder(tot, -deaths_per_year); print(tot); fwrite(tot, file.path(AUD, "out_B5_sim_granularity.csv"))
cat("INE 2024 January 15-65 population:", P, "\n")
message(sprintf("03_cause_specific elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
