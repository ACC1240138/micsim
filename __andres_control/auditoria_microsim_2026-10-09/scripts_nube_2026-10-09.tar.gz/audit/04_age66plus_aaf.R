# 04_age66plus_aaf.R -- item 3: what the 66 cut loses. Shares of deaths at 66+ (all-cause, alcohol-related, AAF=1),
# reconciliation of our ICD map against the expand_pif pipeline (n = mort / aaf), and a crude extrapolation of
# attributable deaths at 66+ with the 60-65 AAF (the expand_pif tables stop at 65).
.t0 <- Sys.time()
library(data.table)
ROOT <- "<repo>"; AUD <- "<scratch>/audit"
source(file.path(ROOT, "_tools", "acc_data.R")); setwd(ROOT)
suppressMessages(source(file.path(ROOT, "__andres_control", "ypll_icd_defs.R")))   # ypll_pipeline_deaths(), newest dated export + bundle
cat("pipeline files:", basename(YPLL_MORTALITY_XLSX), "|", basename(YPLL_AAF_BUNDLE), "\n")
d <- fread(file.path(AUD, "agg", "deaths_year_sex_age_cause.csv"))
fl <- fread(file.path(AUD, "agg", "flags_year_sex_age6.csv"))
d[, older := age >= 66]
alc <- setdiff(unique(fl$disease), character())

# ---- C1. Shares at 66+ among deaths aged 15+ ----
d[, grp := fifelse(cause == "Fully attributable (AAF=1)", "AAF=1 causes",
           fifelse(cause %in% c("All other causes", "COVID-19 (U07/U09/U10)") | (sex == "male" & cause == "Breast Cancer"),
                   "Non-alcohol causes", "Partially attributable causes (23 expand_pif diseases)"))]
sh <- rbind(d[, .(group = "All causes", d15_65 = sum(deaths[!older]), d66_79 = sum(deaths[older & age < 80]), d80p = sum(deaths[age >= 80])), by = .(sex)],
            d[, .(d15_65 = sum(deaths[!older]), d66_79 = sum(deaths[older & age < 80]), d80p = sum(deaths[age >= 80])), by = .(sex, group = grp)])
sh[, `:=`(share_66plus = (d66_79 + d80p) / (d15_65 + d66_79 + d80p), share_66_79 = d66_79 / (d15_65 + d66_79 + d80p))]
setorder(sh, group, sex); print(sh); fwrite(sh, file.path(AUD, "out_C1_share66_pooled.csv"))
shy <- d[, .(share_66plus_all = sum(deaths[older]) / sum(deaths),
             share_66plus_aaf1 = sum(deaths[older & grp == "AAF=1 causes"]) / sum(deaths[grp == "AAF=1 causes"]),
             share_66plus_partial = sum(deaths[older & grp == "Partially attributable causes (23 expand_pif diseases)"]) /
               sum(deaths[grp == "Partially attributable causes (23 expand_pif diseases)"])), by = .(year, sex)]
fwrite(shy, file.path(AUD, "out_C1_share66_year_sex.csv"))
byc <- d[!(sex == "male" & cause == "Breast Cancer"), .(d15_65 = sum(deaths[!older]), d66p = sum(deaths[older])), by = .(cause, sex)][, share_66plus := d66p / (d15_65 + d66p)]
fwrite(byc, file.path(AUD, "out_C1_share66_cause_sex.csv"))

# ---- C2. Reconcile our counts with the pipeline's n = mort / aaf (15-65, wave years) ----
pp <- as.data.table(ypll_pipeline_deaths())
pp[, sex := fifelse(gender == "Hombre", "male", "female")][, age6 := c("15-29", "30-44", "45-59", "60-65")[age_group]]
ours <- fl[disease != "Fully attributable (AAF=1)" & age6 %in% c("15-29", "30-44", "45-59", "60-65")]
rec <- merge(pp[, .(year, sex, age6, disease, aaf, n)], ours, by = c("year", "sex", "age6", "disease"), all.x = TRUE)
rec[is.na(deaths), deaths := 0]
cat(sprintf("reconciliation: %d pipeline cells, max |n - ours| = %.3g, cells differing by >0.5: %d\n",
            nrow(rec), max(abs(rec$n - rec$deaths)), sum(abs(rec$n - rec$deaths) > 0.5)))
fwrite(rec[abs(n - deaths) > 0.5], file.path(AUD, "out_C2_reconciliation_mismatches.csv"))
x <- readxl::read_xlsx(YPLL_MORTALITY_XLSX); setDT(x)
aaf1_pipe <- x[disease == "Fully attributable to alcohol", .(pipe = sum(mort)), by = .(year, sex = fifelse(gender == "Hombre", "male", "female"))]
aaf1_ours <- fl[disease == "Fully attributable (AAF=1)" & age6 %in% c("15-29", "30-44", "45-59", "60-65"), .(ours = sum(deaths)), by = .(year, sex)]
a1 <- merge(aaf1_pipe, aaf1_ours, by = c("year", "sex")); print(a1[, .(max_abs_diff = max(abs(pipe - ours)))])

# ---- C3. Crude attributable deaths at 66+ with the 60-65 AAF (wave years) ----
a4 <- pp[age_group == 4, .(year, sex, disease, aaf)]
old <- fl[age6 %in% c("66-79", "80+") & disease != "Fully attributable (AAF=1)"]
ex <- merge(old, a4, by = c("year", "sex", "disease"))   # inner: wave years and causes with an AAF only
ex[, attr := aaf * deaths]
att_old <- ex[, .(attr_net = sum(attr), attr_harm_only = sum(attr[aaf > 0])), by = .(year, sex, age6)]
young <- x[, .(attr_15_65 = sum(mort), attr_15_65_harm_only = sum(mort[mort > 0])), by = .(year, sex = fifelse(gender == "Hombre", "male", "female"))]
aaf1_old <- merge(CJ(year = unique(att_old$year), sex = c("female", "male"), age6 = c("66-79", "80+")),
                  fl[disease == "Fully attributable (AAF=1)" & age6 %in% c("66-79", "80+"), .(aaf1 = sum(deaths)), by = .(year, sex, age6)], all.x = TRUE)
aaf1_old[is.na(aaf1), aaf1 := 0L]   # zero AAF=1 deaths in a cell must stay a zero, not drop the cell
c3 <- merge(dcast(merge(att_old, aaf1_old, by = c("year", "sex", "age6")), year + sex ~ age6, value.var = c("attr_net", "attr_harm_only", "aaf1")),
            young, by = c("year", "sex"))
setnames(c3, gsub("-", "_", gsub("\\+", "p", names(c3))))
c3[, attr66p_net := attr_net_66_79 + attr_net_80p + aaf1_66_79 + aaf1_80p]
c3[, attr66p_harm := attr_harm_only_66_79 + attr_harm_only_80p + aaf1_66_79 + aaf1_80p]
c3[, `:=`(share_attr_66p_net = attr66p_net / (attr66p_net + attr_15_65), share_attr_66p_harm = attr66p_harm / (attr66p_harm + attr_15_65_harm_only),
          share_attr_66_79_net = (attr_net_66_79 + aaf1_66_79) / (attr66p_net + attr_15_65))]
print(c3[, .(year, sex, attr_15_65, attr66p_net, share_attr_66p_net, share_attr_66_79_net, share_attr_66p_harm)])
fwrite(c3, file.path(AUD, "out_C3_attr66plus_extrapolated.csv"))
bycause <- ex[, .(attr_66_79 = sum(attr[age6 == "66-79"]), attr_80p = sum(attr[age6 == "80+"]), deaths_66p = sum(deaths), aaf_60_65_mean = mean(aaf)), by = .(disease, sex)][order(sex, -(attr_66_79 + attr_80p))]
print(bycause[, head(.SD, 6), by = sex])
fwrite(bycause, file.path(AUD, "out_C3_attr66plus_by_cause.csv"))
pooled <- c3[, lapply(.SD, sum), by = sex, .SDcols = c("attr_15_65", "attr66p_net", "aaf1_66_79", "aaf1_80p", "attr_15_65_harm_only", "attr66p_harm")]
pooled[, `:=`(share_net = attr66p_net / (attr66p_net + attr_15_65), share_harm = attr66p_harm / (attr66p_harm + attr_15_65_harm_only))]
print(pooled); fwrite(pooled, file.path(AUD, "out_C3_attr66plus_pooled.csv"))
# Sensitivity: drop causes whose RR is age-attenuated or J-shaped (IHD, ischaemic stroke, ICH, HHD, diabetes) on both sides.
cvd <- c("Ischaemic Heart Disease", "Ischaemic Stroke", "Intracerebral Haemorrhage", "Hypertensive Heart Disease", "DM2")
sens <- merge(ex[!disease %in% cvd, .(attr66p_partial = sum(attr)), by = sex],
              x[!disease %in% cvd, .(attr_15_65 = sum(mort)), by = .(sex = fifelse(gender == "Hombre", "male", "female"))], by = "sex")
sens <- merge(sens, aaf1_old[, .(aaf1_66p = sum(aaf1)), by = sex], by = "sex")
sens[, share_66p := (attr66p_partial + aaf1_66p) / (attr66p_partial + aaf1_66p + attr_15_65)]
print(sens); fwrite(sens, file.path(AUD, "out_C3_attr66plus_excl_cvd_dm.csv"))
message(sprintf("04_age66plus_aaf elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
