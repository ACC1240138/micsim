# 01_extract_deis.R -- decrypt DEIS (2012-2023 parquet + newest 2024+ weekly CSV) into R's tempdir(),
# classify ICD-10 with the project's own expand_pif map, and write ONLY aggregated counts to agg/.
# Run: Rscript --vanilla 01_extract_deis.R   (renv cannot be restored here; system R packages)
.t0 <- Sys.time()
ROOT <- "<repo>"
AUD  <- "<scratch>/audit"
source(file.path(ROOT, "_tools", "acc_data.R"))
setwd(ROOT)
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
# Partial-cause code lists: sourced from the project's own duplicate of the expand_pif map.
suppressMessages(source(file.path(ROOT, "__andres_control", "ypll_icd_defs.R")))
# AAF = 1 code lists: copied verbatim from expand_pif.ipynb cell mort-trends-age-sex-chile11-mortalidad-etiqueta.
aaf1_diag1 <- c(icd_stems_s6("F10"), "G312", "G621", "G721", "Q860", "I426", "K860", "K292")
aaf1_diag2 <- c(icd_stems_s6("X45"), icd_stems_s6("X65"), icd_stems_s6("Y15"))

# ---- 2012-2023: parquet -> csv inside tempdir (python; R here has no arrow) ----
pq  <- acc_data("_deis/DEFUNCIONES_DEIS_2012_2023_15plus.tar.xz.enc")
csv <- file.path(tempdir(), "deis1223.csv")
py  <- "import sys,pyarrow.parquet as pq,pyarrow.csv as pc; pc.write_csv(pq.read_table(sys.argv[1]), sys.argv[2])"
stopifnot(system2("python3", c("-I", "-c", shQuote(py), shQuote(pq), shQuote(csv))) == 0)
m21 <- data.table::fread(csv, colClasses = "character", na.strings = c("", "NA"), showProgress = FALSE)
unlink(csv)
stopifnot(nrow(m21) == 1328981L)   # README expected rows
m21[, `:=`(year = as.integer(year), age = as.integer(age))]
q21 <- data.table::data.table(check = c("rows", "gender values", "identical rows (year,gender,age,comuna,region,diag1,diag2)",
                                        "diag1 missing", "diag2 non-missing"),
  value = c(nrow(m21), paste(names(table(m21$gender)), table(m21$gender), collapse = "; "),
            sum(duplicated(m21[, .(year, gender, age, comuna, region, diag1, diag2)])),
            sum(is.na(m21$diag1) | m21$diag1 == ""), sum(!is.na(m21$diag2))))

# ---- 2024: newest weekly file (provisional) ----
d24 <- data.table::as.data.table(acc_deis())
deis_file <- sub("^.*_(\\d{8})\\.tar.*$", "\\1", basename(acc_latest(file.path(ROOT, "_deis"))))
data.table::setnames(d24, 1, "ANO")
q24 <- data.table::data.table(check = c("source version", "rows 2024", "2024 EDAD_TIPO counts",
  "2024 sex counts", "2024 exact duplicate rows (all 27 columns)", "2024 EDAD_CANT missing (EDAD_TIPO==1)",
  "2024 diag1 missing"),
  value = c(deis_file, sum(d24$ANO == 2024),
    paste(names(table(d24[ANO == 2024]$EDAD_TIPO)), table(d24[ANO == 2024]$EDAD_TIPO), collapse = "; "),
    paste(names(table(d24[ANO == 2024]$SEXO_NOMBRE)), table(d24[ANO == 2024]$SEXO_NOMBRE), collapse = "; "),
    sum(duplicated(d24[ANO == 2024])), sum(is.na(d24[ANO == 2024 & EDAD_TIPO == 1]$EDAD_CANT)),
    sum(is.na(d24[ANO == 2024]$DIAG1) | d24[ANO == 2024]$DIAG1 == "")))
m24 <- d24[ANO == 2024 & EDAD_TIPO == 1 & EDAD_CANT >= 15,
           .(year = 2024L, gender = SEXO_NOMBRE, age = as.integer(EDAD_CANT), diag1 = DIAG1,
             diag2 = data.table::fifelse(DIAG2 == "", NA_character_, DIAG2))]
rm(d24)
m <- data.table::rbindlist(list(m21[, .(year, gender, age, diag1, diag2)], m24))
rm(m21, m24)
data.table::fwrite(rbind(q21, q24), file.path(AUD, "agg", "quality_records.csv"))

# ---- classification ----
m[, `:=`(d1 = clean_icd10(diag1), d2 = clean_icd10(data.table::fifelse(is.na(diag2), "", diag2)))]
m[, sex := data.table::fcase(gender == "Hombre", "male", gender == "Mujer", "female", default = NA_character_)]
m[, age_c := pmin(age, 100L)]   # INE top age is 100 (100+)
m[, age6 := cut(age, c(14, 29, 44, 59, 65, 79, Inf), labels = c("15-29", "30-44", "45-59", "60-65", "66-79", "80+"))]
inj <- function(codes) m$d1 %in% codes | m$d2 %in% codes
flags <- list(  # expand_pif disease_filters (non-exclusive, as in the pipeline)
  "Fully attributable (AAF=1)" = m$d1 %in% aaf1_diag1 | m$d2 %in% aaf1_diag2,
  "Breast Cancer" = m$d1 %in% brcan_codes, "Liver Cancer" = m$d1 %in% lican_codes,
  "Larynx Cancer" = m$d1 %in% lxcan_codes, "Oesophagus Cancer" = m$d1 %in% oescan_codes,
  "Oral Cavity and Pharynx Cancer" = m$d1 %in% locan_codes, "Other Pharyngeal Cancer" = m$d1 %in% opcan_codes,
  "Colon and rectum Cancer" = m$d1 %in% crcan_codes, "Stomach Cancer" = m$d1 %in% stom_codes,
  "Pancreatic Cancer" = m$d1 %in% panccan_codes, "Acute Pancreatitis" = m$d1 %in% panc_codes,
  "Epilepsy" = m$d1 %in% epilepsy_codes, "DM2" = m$d1 %in% dm2_codes, "HIV" = m$d1 %in% hiv_codes,
  "Hypertensive Heart Disease" = m$d1 %in% hhd_codes, "Intracerebral Haemorrhage" = m$d1 %in% ich_codes,
  "Ischaemic Heart Disease" = m$d1 %in% ihd_codes, "Ischaemic Stroke" = m$d1 %in% is_codes,
  "Liver Cirrhosis" = m$d1 %in% lc_codes, "Lower Respiratory Infection" = m$d1 %in% lri_codes,
  "Tuberculosis" = m$d1 %in% tb_codes,
  "Road Injuries" = inj(ri_codes), "Intentional Injuries" = inj(int_inj_codes),
  "Unintentional Injuries" = inj(unint_inj_codes) & !inj(ri_codes))
fl <- do.call(cbind, flags)
m[, n_flags := rowSums(fl)]
# Mutually exclusive engine cause: first matching flag in the order above (AAF=1 > chronic DIAG1 > injuries).
first <- max.col(cbind(fl, TRUE), ties.method = "first")
m[, cause := c(names(flags), "All other causes")[first]]
m[cause == "All other causes" & substr(d1, 1, 3) %in% c("U07", "U09", "U10"), cause := "COVID-19 (U07/U09/U10)"]
m[, illdef := substr(d1, 1, 1) == "R"]

# Overlap audit: pairs of expand_pif flags that fire on the same death (15-65 and all ages).
ov <- data.table::rbindlist(lapply(c("15-65", "15+"), function(sc) {
  keep <- if (sc == "15-65") m$age <= 65 else rep(TRUE, nrow(m))
  x <- crossprod(fl[keep, , drop = FALSE] * 1)
  idx <- which(upper.tri(x) & x > 0, arr.ind = TRUE)
  data.table::data.table(scope = sc, flag_a = colnames(x)[idx[, 1]], flag_b = colnames(x)[idx[, 2]], deaths = x[idx])
}))
data.table::fwrite(ov, file.path(AUD, "agg", "flag_overlaps.csv"))
# Non-exclusive expand_pif counts by year x sex x 6 age bands (for reconciliation with the pipeline's n = mort/aaf).
fl_long <- data.table::rbindlist(lapply(names(flags), function(f)
  m[flags[[f]] & !is.na(sex), .(deaths = .N), by = .(year, sex, age6)][, disease := f]))
data.table::fwrite(fl_long, file.path(AUD, "agg", "flags_year_sex_age6.csv"))
# Exclusive counts by single age (15..100+), the base for every rate table.
agg <- m[!is.na(sex), .(deaths = .N, illdef = sum(illdef)), by = .(year, sex, age = age_c, cause)]
data.table::fwrite(agg, file.path(AUD, "agg", "deaths_year_sex_age_cause.csv"))
# Ill-defined (R00-R99) and sex-missing records.
qa <- m[, .(deaths = .N, illdef = sum(illdef), sex_missing = sum(is.na(sex))), by = .(year, age6)]
data.table::fwrite(qa, file.path(AUD, "agg", "quality_illdef_year_age6.csv"))
# Ill-defined codes (R00-R99) by 3-character code, year and engine scope (R99 = unknown cause, often pending medico-legal).
rc <- m[illdef == TRUE, .(deaths = .N), by = .(year, scope = data.table::fifelse(age <= 65, "15-65", "66+"), code3 = substr(d1, 1, 3))]
data.table::fwrite(rc, file.path(AUD, "agg", "illdef_codes_year.csv"))
# How DEIS codes external causes: DIAG1 chapter letter by whether DIAG2 is filled (all years, 15+).
dx <- m[, .(deaths = .N), by = .(diag2_filled = d2 != "", d1_letter = substr(d1, 1, 1), d2_letter = substr(d2, 1, 1))]
data.table::fwrite(dx, file.path(AUD, "agg", "diag1_diag2_letters.csv"))
cat("records:", nrow(m), " sex missing:", sum(is.na(m$sex)), " multi-flag deaths:", sum(m$n_flags > 1), "\n")
print(m[age <= 65 & !is.na(sex), .N, by = year][order(year)])
message(sprintf("01_extract_deis elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
