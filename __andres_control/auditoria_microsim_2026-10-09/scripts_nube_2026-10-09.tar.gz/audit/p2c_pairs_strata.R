# Step 2 (published aggregates): exactly identified lambda, phi from the two full-panel pair correlations
# (VI-VII at 3.671 y, VI-VIII at 7.693 y) by baseline age x sex (x education). Different panels, overlapping people.
.t0 <- Sys.time()
audit <- "<scratch>/audit"
source(file.path(audit, "fit_lib.R"))
eo <- "<repo>/__andres_control/eps_alcohol_outputs"
go <- function(f, keys) {
  x <- utils::read.csv(file.path(eo, f))
  a <- x[x$pair == "VI_VII", ]; b <- x[x$pair == "VI_VIII", ]
  m <- merge(a, b, by = keys, suffixes = c("_37", "_77"))
  s <- t(mapply(solve_two, m$rho_interval_37, m$rho_interval_77, MoreArgs = list(d1 = 3.671, d2 = 7.693)))
  cbind(m[c(keys, "n_37", "n_77", "rho_interval_37", "lower_37", "upper_37", "rho_interval_77", "lower_77", "upper_77", "flag_37", "flag_77")],
        lambda = s[, "lambda"], phi = s[, "phi"], r1y = r_model(s[, "lambda"], s[, "phi"], 1))
}
r1 <- go("rho_age_sex.csv", c("age_group", "sex", "education"))
r2 <- go("rho_age_sex_education.csv", c("age_group", "sex", "education"))
utils::write.csv(r1, file.path(audit, "out", "p2c_pairs_lambda_phi_age_sex.csv"), row.names = FALSE)
utils::write.csv(r2, file.path(audit, "out", "p2c_pairs_lambda_phi_age_sex_edu.csv"), row.names = FALSE)
print(format(r1[order(r1$sex, r1$age_group), c("age_group", "sex", "n_37", "n_77", "rho_interval_37", "rho_interval_77", "lambda", "phi", "r1y", "flag_77")], digits = 3))
# Education: pool over age by averaging Fisher-z of the published cells with inverse-variance weights (descriptive).
r2$z37 <- atanh(r2$rho_interval_37); r2$z77 <- atanh(r2$rho_interval_77)
r2$w37 <- (2 * 1.96 / (atanh(r2$upper_37) - atanh(r2$lower_37)))^2; r2$w77 <- (2 * 1.96 / (atanh(r2$upper_77) - atanh(r2$lower_77)))^2
ok <- is.finite(r2$z37) & is.finite(r2$z77) & is.finite(r2$w37) & is.finite(r2$w77)
ed <- do.call(rbind, lapply(split(r2[ok, ], r2$education[ok]), function(x) {
  a <- tanh(sum(x$w37 * x$z37) / sum(x$w37)); b <- tanh(sum(x$w77 * x$z77) / sum(x$w77))
  s <- solve_two(a, b, 3.671, 7.693)
  data.frame(education = x$education[1], cells = nrow(x), r37 = a, se37_z = 1 / sqrt(sum(x$w37)), r77 = b, se77_z = 1 / sqrt(sum(x$w77)),
             lambda = s[["lambda"]], phi = s[["phi"]])
}))
print(format(ed, digits = 3)); utils::write.csv(ed, file.path(audit, "out", "p2c_education_pooled.csv"), row.names = FALSE)
message(sprintf("p2c elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
