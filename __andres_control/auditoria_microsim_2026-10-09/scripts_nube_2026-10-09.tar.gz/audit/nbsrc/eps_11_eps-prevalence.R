#| label: eps-prevalence
.t0 <- Sys.time()
eps_design <- function(d, weights_only = FALSE) {
  if (weights_only) survey::svydesign(ids = ~1, weights = ~weight, data = d)
  else survey::svydesign(ids = ~psu, strata = ~strata, weights = ~weight, data = d, nest = TRUE)
}
eps_designs <- lapply(names(eps_data), function(w) eps_design(eps_data[[w]], w == "VI")); names(eps_designs) <- names(eps_data)
eps_prop <- function(des, indicator) {
  stopifnot(length(indicator) == nrow(des$variables))
  des$variables$.y <- indicator
  valid <- !is.na(indicator)
  wt <- des$variables$weight
  total <- sum(wt); n_valid <- sum(valid)
  if (!n_valid) return(data.frame(n_valid = 0, n_eff = 0, coverage = 0, estimate = NA, se = NA, lower = NA, upper = NA, df = NA, flag = "no_valid_response"))
  ds <- des[valid, ]; singleton_domain <- FALSE
  # Record the expected domain-PSU warning in each result instead of flooding the notebook.
  # Other warnings remain visible; the chosen survey adjustment is unchanged.
  v <- withCallingHandlers(survey::svymean(~.y, ds), warning = function(w) {
    if (grepl("has only one PSU at stage", conditionMessage(w), fixed = TRUE)) {
      singleton_domain <<- TRUE
      invokeRestart("muffleWarning")
    }
  })
  p <- unname(stats::coef(v)[1]); se <- sqrt(stats::vcov(v)[1, 1]); df <- survey::degf(ds)
  ne <- sum(wt[valid])^2 / sum(wt[valid]^2)
  ci <- c(NA_real_, NA_real_)
  if (p > 0 && p < 1 && is.finite(se) && se > 0 && df > 0)
    ci <- stats::plogis(stats::qlogis(p) + c(-1, 1) * stats::qt(.975, df) * se / (p * (1 - p)))
  events <- sum(indicator[valid]); non_events <- n_valid - events
  flag <- if (p %in% c(0, 1)) "boundary_no_CI" else if (ne < 30 || min(events, non_events) < 5 || df < 8) "sparse_or_low_df" else "ok"
  if (singleton_domain) flag <- paste(flag, "singleton_domain_adjusted", sep = ";")
  data.frame(n_valid, n_eff = ne, coverage = sum(wt[valid]) / total, estimate = p, se,
             lower = ci[1], upper = ci[2], df, flag)
}
eps_domains <- function(d, education = FALSE, older = FALSE) {
  age <- d$age_group
  if (older) age[d$age >= 50 & d$age < 60] <- "50-59"
  use <- !is.na(d$sex) & (!older | d$age >= 50)
  edu <- if (education) d$education else rep("All", nrow(d))
  use <- use & !is.na(edu)
  keys <- unique(data.frame(age_group = age[use], sex = d$sex[use], education = edu[use]))
  lapply(seq_len(nrow(keys)), function(i) list(key = keys[i, ], keep = use & age == keys$age_group[i] & d$sex == keys$sex[i] & edu == keys$education[i]))
}
eps_prevalence <- function(des, education = FALSE, older = FALSE) {
  rows <- lapply(eps_domains(des$variables, education, older), function(g) {
    s <- des[which(g$keep), ]; d <- s$variables; W <- sum(d$weight)
    current <- cbind(g$key, outcome = "Declared current use", eps_prop(s, d$current), bound_lower = sum(d$weight[which(d$current == 1)]) / W,
       bound_upper = sum(d$weight[which(d$current == 1 | is.na(d$current))]) / W)
    cats <- lapply(eps_states, function(st) {
      y <- ifelse(is.na(d$state), NA_real_, as.numeric(d$state == st))
      cbind(g$key, outcome = st, eps_prop(s, y), bound_lower = sum(d$weight[which(y == 1)]) / W,
            bound_upper = sum(d$weight[which(y == 1 | is.na(y))]) / W)
    })
    do.call(rbind, c(list(current), cats))
  })
  do.call(rbind, rows)
}
eps_prevalence_main <- do.call(rbind, lapply(names(eps_designs), function(w)
  cbind(wave = w, eps_prevalence(eps_designs[[w]]), precision = if (w == "VI") "weights_only_working_CI" else "PSU_strata_lonely_adjust_working_CI")))
eps_prevalence_education <- do.call(rbind, lapply(names(eps_designs), function(w)
  cbind(wave = w, eps_prevalence(eps_designs[[w]], education = TRUE))))
eps_prevalence_50plus <- do.call(rbind, lapply(names(eps_designs), function(w)
  cbind(wave = w, eps_prevalence(eps_designs[[w]], older = TRUE))))
eps_requested <- eps_prevalence_main[eps_prevalence_main$outcome != "Declared current use", ]
lt <- eps_requested[eps_requested$outcome == eps_states[1], ]; lt$outcome <- "Lifetime abstainer (not identified)"
cur <- eps_prevalence_main[eps_prevalence_main$outcome == "Declared current use", ]
stopifnot(identical(paste(lt$wave, lt$age_group, lt$sex), paste(cur$wave, cur$age_group, cur$sex)))
lt$bound_lower <- 0; lt$bound_upper <- 1 - cur$bound_lower
lt[, c("estimate", "se", "lower", "upper")] <- NA_real_; lt$flag <- "not_identified_no_lifetime_question"
lt$n_valid <- 0; lt$n_eff <- 0; lt$coverage <- 0; lt$df <- NA_real_
eps_requested <- rbind(eps_requested, lt)
eps_save(eps_prevalence_main, "prevalence_age_sex"); eps_save(eps_prevalence_education, "prevalence_age_sex_education")
eps_save(eps_prevalence_50plus, "prevalence_50plus"); eps_save(eps_requested, "requested_five_categories_identification")
eps_recent_old <- subset(eps_prevalence_main, wave == "VIII" & age_group %in% c("66-70", "71-76") & outcome == "Declared current use")
eps_table(eps_recent_old[, c("age_group", "sex", "n_valid", "n_eff", "estimate", "lower", "upper", "coverage", "flag")],
          "VIII: reported use in the requested age groups; proportions from 0 to 1")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))