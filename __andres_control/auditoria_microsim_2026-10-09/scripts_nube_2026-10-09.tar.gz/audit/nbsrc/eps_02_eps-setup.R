#| label: eps-setup
.t0 <- Sys.time()
# Project-relative paths; microdata come only from the encrypted bundles through _tools/acc_data.R.
eps_required <- c("here", "haven", "survey", "mvtnorm", "ggplot2", "knitr", "htmltools")
eps_missing <- eps_required[!vapply(eps_required, requireNamespace, logical(1), quietly = TRUE)]
if (length(eps_missing)) stop("Install the missing packages before running: ", paste(eps_missing, collapse = ", "))
suppressMessages(here::i_am("__andres_control/eps_alcohol_prevalencia_persistencia.ipynb"))
source(here::here("_tools", "acc_data.R"))
eps_root <- acc_data("_eps/eps.tar.xz.enc")   # decrypted once per session into tempdir()
eps_abs <- function(x) file.path(eps_root, sub("^_eps/", "", x))   # "_eps/<path>" label -> readable file
eps_out <- here::here("__andres_control", "eps_alcohol_outputs")
dir.create(eps_out, recursive = TRUE, showWarnings = FALSE)
options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE, scipen = 8)
# Use the system's native character locale; this also avoids C-locale glyph escapes on Windows.
invisible(Sys.setlocale("LC_CTYPE", ""))
eps_seed <- 1240138L
set.seed(eps_seed)
eps_age_levels <- c("18-29", "30-44", "45-59", "60-65", "66-70", "71-76", "77+")
eps_edu_levels <- c("Primary completed or less", "Secondary completed or less", "Tertiary completed or higher")
eps_states <- c("Current abstainer (history unknown)", "Occasional (frequency proxy)", "Moderate", "Heavy")
eps_table <- function(x, caption, digits = 3) {
  htmltools::browsable(htmltools::div(class = "eps-table",
    htmltools::HTML(knitr::kable(x, format = "html", digits = digits, caption = caption, row.names = FALSE))))
}
eps_read <- function(path) {
  x <- as.data.frame(haven::read_dta(eps_abs(path)))
  stopifnot("folio_n20" %in% names(x), !anyNA(x$folio_n20), !anyDuplicated(x$folio_n20))
  x
}
eps_save <- function(x, name) utils::write.csv(x, file.path(eps_out, paste0(name, ".csv")), row.names = FALSE, na = "")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))