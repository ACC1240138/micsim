#| label: eps-panel
.t0 <- Sys.time()
eps_time <- data.frame(pair = c("VI_VII", "VI_VIII"), from = "VI", to = c("VII_presencial", "VIII"),
  delta = c(3.671, 7.693), delta_min = c(3.285, 7.110), delta_max = c(4.057, 8.277))
eps_make_pair <- function(to, weight_file = NULL, baseline_weights = FALSE) {
  a <- eps_data$VI; b <- eps_data[[to]]
  if (baseline_weights) {
    ids <- intersect(a$id, b$id); w <- a[match(ids, a$id), c("id", "weight", "strata", "psu")]
  } else {
    x <- eps_panel_weights[[weight_file]]
    w <- data.frame(id = as.character(x$folio_n20), weight = as.numeric(x$factor_Panel_2015), strata = as.numeric(x$strata_ID), psu = as.numeric(x$cluster_ID))
    stopifnot(all(w$id %in% a$id), all(w$id %in% b$id))
  }
  a <- a[match(w$id, a$id), ]; b <- b[match(w$id, b$id), ]
  tm <- eps_time[eps_time$to == to, ]; diff_age <- b$age - a$age
  good_link <- a$sex == b$sex & diff_age >= floor(tm$delta_min) & diff_age <= ceiling(tm$delta_max)
  good_link[is.na(good_link)] <- FALSE
  data.frame(w, age = a$age, age_end = b$age, age_group = a$age_group, sex = a$sex, education = a$education,
     good_link, current0 = ifelse(good_link, a$current, NA), current1 = ifelse(good_link, b$current, NA),
     state0 = ifelse(good_link, a$state, NA), state1 = ifelse(good_link, b$state, NA),
     grams0 = a$grams_day, grams1 = b$grams_day)
}
eps_pairs <- list(VI_VII = eps_make_pair("VII_presencial", "VI_VII"), VI_VIII = eps_make_pair("VIII", "VI_VIII"))
eps_pair_designs <- lapply(eps_pairs, eps_design)
eps_pair_audit <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  d <- eps_pairs[[p]]; t <- eps_time[eps_time$pair == p, ]
  data.frame(pair = p, endpoints_linked = length(intersect(eps_data$VI$id, eps_data[[t$to]]$id)),
    official_panel_n = nrow(d), link_flag = sum(!d$good_link),
    valid_status_pairs = sum(stats::complete.cases(d[c("current0", "current1")])),
    baseline_50plus = sum(d$age >= 50), delta_mid = t$delta, delta_min = t$delta_min, delta_max = t$delta_max)
}))
# Attrition diagnostics use the original baseline design and do not treat disappearance as abstinence.
eps_retention <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  ds <- eps_designs$VI; d <- ds$variables; to <- eps_time$to[eps_time$pair == p]
  do.call(rbind, lapply(c(0, 1), function(st) {
    s <- ds[which(d$current == st & d$age >= 50), ]; x <- s$variables
    rbind(cbind(pair = p, baseline_status = st, inclusion = "endpoint_reinterview", eps_prop(s, as.numeric(x$id %in% eps_data[[to]]$id))),
          cbind(pair = p, baseline_status = st, inclusion = "official_panel_weight", eps_prop(s, as.numeric(x$id %in% eps_pairs[[p]]$id))))
  }))
}))
eps_history <- eps_pairs$VI_VIII
mid_data <- eps_data$VII_presencial[match(eps_history$id, eps_data$VII_presencial$id), ]
mid_valid <- eps_history$good_link & mid_data$sex == eps_history$sex &
  mid_data$age - eps_history$age >= 3 & mid_data$age - eps_history$age <= 5 &
  eps_history$age_end - mid_data$age >= 3 & eps_history$age_end - mid_data$age <= 5
mid <- ifelse(!is.na(mid_valid) & mid_valid, mid_data$current, NA_real_)
eps_history$current_mid <- mid
eps_history$observed_history <- ifelse(eps_history$current1 == 1, "Current use",
  ifelse(eps_history$current1 == 0 & (eps_history$current0 == 1 | (!is.na(mid) & mid == 1)), "Current abstainer; prior use observed",
  ifelse(eps_history$current1 == 0 & eps_history$current0 == 0 & !is.na(mid) & mid == 0, "No use at three interviews",
  ifelse(eps_history$current1 == 0 & eps_history$current0 == 0 & is.na(mid), "No use at two endpoints; intermediate unknown",
         "History unresolved"))))
eps_history$observed_history[is.na(eps_history$observed_history)] <- "History unresolved"
hd <- eps_design(eps_history)
eps_history_table <- do.call(rbind, lapply(c("Men", "Women"), function(sx) {
  ds <- hd[which(hd$variables$sex == sx & hd$variables$age >= 50), ]
  do.call(rbind, lapply(unique(eps_history$observed_history), function(st)
    cbind(sex = sx, history = st, eps_prop(ds, as.numeric(ds$variables$observed_history == st)))))
}))
eps_panel_membership <- data.frame(group = c("official_2023_panel2015", "with_VII_presencial", "with_VII_continuidad"),
  n = c(nrow(eps_history), sum(eps_history$id %in% eps_data$VII_presencial$id), sum(eps_history$id %in% as.character(eps_phone$continuidad$folio_n20))))
eps_mid_audit <- data.frame(matched_VII_presencial = sum(!is.na(mid_data$id)),
  accepted_intermediate_history = sum(!is.na(mid_valid) & mid_valid),
  unmatched_or_incompatible = sum(is.na(mid_valid) | !mid_valid))
eps_save(eps_pair_audit, "panel_audit"); eps_save(eps_retention, "retention_by_baseline_status")
eps_save(eps_history_table, "observed_abstention_history"); eps_save(eps_panel_membership, "panel_membership")
eps_save(eps_mid_audit, "intermediate_link_audit")
eps_save(eps_time, "interview_interval_assumptions")
eps_table(eps_pair_audit, "Longitudinal population and elapsed time: fieldwork years rather than file labels")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))