#| label: eps-persistence
.t0 <- Sys.time()
eps_bvn <- function(p0, p1, rho) as.numeric(mvtnorm::pmvnorm(upper = stats::qnorm(c(p0, p1)),
    corr = matrix(c(1, rho, rho, 1), 2), algorithm = mvtnorm::Miwa(steps = 128L)))
eps_tetra <- function(p) {
  p <- p / sum(p) # Order: 00, 01, 10, 11; normalize also for numerical derivatives.
  if (any(!is.finite(p)) || any(p <= 0)) return(NA_real_)
  p0 <- p[3] + p[4]; p1 <- p[2] + p[4]
  fn <- function(r) eps_bvn(p0, p1, r) - p[4]
  if (fn(-.999) * fn(.999) >= 0) return(NA_real_)
  stats::uniroot(fn, c(-.999, .999), tol = 1e-7)$root
}
eps_rho <- function(ds, delta, delta_min, delta_max) {
  d <- ds$variables; ok <- stats::complete.cases(d[c("current0", "current1")])
  ds <- ds[ok, ]; d <- ds$variables
  empty <- data.frame(n = nrow(d), n_eff = NA_real_, phi = NA_real_, rho_interval = NA_real_, lower = NA_real_, upper = NA_real_,
    rho_annual = NA_real_, annual_lower = NA_real_, annual_upper = NA_real_, annual_time_min = NA_real_, annual_time_max = NA_real_, flag = "empty_or_zero_cell")
  if (!nrow(d)) return(empty)
  cell <- 1L + d$current1 + 2L * d$current0
  for (j in 1:4) ds$variables[[paste0("p", j)]] <- as.numeric(cell == j)
  stat <- survey::svymean(~p1 + p2 + p3 + p4, ds)
  p <- unname(stats::coef(stat)); V <- stats::vcov(stat); ne <- sum(d$weight)^2 / sum(d$weight^2)
  r <- eps_tetra(p); empty$n_eff <- ne
  p0 <- p[3] + p[4]; p1 <- p[2] + p[4]
  phi <- (p[4] - p0 * p1) / sqrt(p0 * (1 - p0) * p1 * (1 - p1))
  empty$phi <- phi
  if (!is.finite(r)) return(empty)
  h <- min(1e-5, min(p) / 4)
  grad <- vapply(1:4, function(j) { a <- b <- p; a[j] <- a[j] + h; b[j] <- b[j] - h; (eps_tetra(a) - eps_tetra(b)) / (2 * h) }, numeric(1))
  se <- sqrt(max(0, as.numeric(t(grad) %*% V %*% grad)))
  df <- survey::degf(ds)
  ci <- if (df > 0 && is.finite(se)) tanh(atanh(r) + c(-1, 1) * stats::qt(.975, df) * se / (1 - r^2)) else c(NA_real_, NA_real_)
  ann <- function(x, dt) ifelse(is.finite(x) & x > 0, pmax(x, 0)^(1 / dt), NA_real_)
  flag <- if (ne < 50 || min(table(factor(cell, levels = 1:4))) < 5 || df < 8) "sparse_or_low_df" else if (r <= 0) "nonpositive_no_annual_AR1" else "conditional_AR1_only"
  data.frame(n = nrow(d), n_eff = ne, phi, rho_interval = r, lower = ci[1], upper = ci[2], rho_annual = ann(r, delta),
    annual_lower = ann(ci[1], delta), annual_upper = ann(ci[2], delta),
    annual_time_min = ann(r, delta_min), annual_time_max = ann(r, delta_max), flag)
}
eps_panel_groups <- function(d, education = FALSE) {
  # Main pooled estimates are for 50+ at baseline, matching the Calvo target domain.
  groups <- list(list(key = data.frame(age_group = "50+", sex = "All", education = "All"), keep = d$age >= 50))
  for (sx in c("Men", "Women")) groups[[length(groups) + 1L]] <- list(key = data.frame(age_group = "50+", sex = sx, education = "All"), keep = d$age >= 50 & d$sex == sx)
  c(groups, eps_domains(d, education = education))
}
eps_rho_table <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  ds <- eps_pair_designs[[p]]; tm <- eps_time[eps_time$pair == p, ]
  do.call(rbind, lapply(eps_panel_groups(ds$variables), function(g) cbind(pair = p, g$key,
    eps_rho(ds[which(g$keep), ], tm$delta, tm$delta_min, tm$delta_max))))
}))
eps_rho_education <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  ds <- eps_pair_designs[[p]]; tm <- eps_time[eps_time$pair == p, ]
  do.call(rbind, lapply(eps_domains(ds$variables, education = TRUE), function(g) cbind(pair = p, g$key,
    eps_rho(ds[which(g$keep), ], tm$delta, tm$delta_min, tm$delta_max))))
}))
eps_transitions <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  ds <- eps_pair_designs[[p]]
  do.call(rbind, lapply(eps_panel_groups(ds$variables), function(g) {
    s <- ds[which(g$keep), ]; d <- s$variables; ok <- stats::complete.cases(d[c("current0", "current1")])
    rows <- lapply(c(0, 1), function(origin) lapply(c(0, 1), function(destination) {
      ss <- s[which(ok & d$current0 == origin), ]
      cbind(pair = p, g$key, origin, destination, eps_prop(ss, as.numeric(ss$variables$current1 == destination)))
    }))
    do.call(rbind, unlist(rows, recursive = FALSE))
  }))
}))
eps_baseline_pair <- eps_make_pair("VIII", baseline_weights = TRUE)
eps_baseline_pair_design <- eps_design(eps_baseline_pair, weights_only = TRUE)
bp <- eps_baseline_pair_design[eps_baseline_pair_design$variables$age >= 50, ]
eps_rho_weight_sensitivity <- cbind(weighting = "baseline_weight_endpoint_respondents_not_attrition_corrected",
  eps_rho(bp, 7.693, 7.110, 8.277))
eps_save(eps_rho_table, "rho_age_sex"); eps_save(eps_rho_education, "rho_age_sex_education")
eps_save(eps_transitions, "binary_transitions"); eps_save(eps_rho_weight_sensitivity, "rho_weight_sensitivity")
eps_table(subset(eps_rho_table, age_group == "50+")[, c("pair", "sex", "n", "rho_interval", "lower", "upper", "rho_annual", "annual_time_min", "annual_time_max", "flag")],
          "Rho: observed latent association and annual transformation conditional on AR(1)")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))