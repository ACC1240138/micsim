#| label: eps-panel-diagnostics
.t0 <- Sys.time()
td <- eps_pairs$VI_VIII
mid_match <- match(td$id, eps_data$VII_presencial$id)
mid_data <- eps_data$VII_presencial[mid_match, ]
td$current_mid <- mid_data$current
mid_good <- !is.na(mid_match) & mid_data$sex == td$sex &
  mid_data$age - td$age >= 3 & mid_data$age - td$age <= 5 &
  td$age_end - mid_data$age >= 3 & td$age_end - mid_data$age <= 5
td$triple_valid <- td$good_link & !is.na(mid_good) & mid_good &
  stats::complete.cases(td[c("current0", "current_mid", "current1")])
triple_design <- eps_design(td)
eps_triple_rho <- do.call(rbind, lapply(c("All", "Men", "Women"), function(sx) {
  ds <- triple_design[which(td$triple_valid & td$age >= 50 & (sx == "All" | td$sex == sx)), ]
  long <- eps_rho(ds, 7.693, 7.110, 8.277)
  first <- ds; first$variables$current1 <- first$variables$current_mid
  second <- ds; second$variables$current0 <- second$variables$current_mid
  rbind(cbind(sex = sx, pair = "VI_VII_same_people", eps_rho(first, 3.671, 3.285, 4.057)),
        cbind(sex = sx, pair = "VII_VIII_same_people", eps_rho(second, 4.022, 3.554, 4.490)),
        cbind(sex = sx, pair = "VI_VIII_same_people", long))
}))
eps_ar1_diagnostic <- do.call(rbind, lapply(split(eps_triple_rho, eps_triple_rho$sex), function(d) {
  first <- d$rho_interval[d$pair == "VI_VII_same_people"]
  second <- d$rho_interval[d$pair == "VII_VIII_same_people"]
  long <- d$rho_interval[d$pair == "VI_VIII_same_people"]
  data.frame(sex = d$sex[1], n = d$n[1], interval_first = first, interval_second = second,
    long_observed = long, long_implied_product = first * second, discrepancy = long - first * second,
    interpretation = "descriptive_same_people_not_a_formal_test")
}))
eps_state_transitions <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  ds <- eps_pair_designs[[p]]; d <- ds$variables
  do.call(rbind, lapply(c("Men", "Women"), function(sx) do.call(rbind, lapply(eps_states, function(origin) {
    ss <- ds[which(d$age >= 50 & d$sex == sx & d$state0 == origin), ]
    do.call(rbind, lapply(eps_states, function(destination) {
      z <- ss$variables$state1
      cbind(pair = p, sex = sx, origin, destination, eps_prop(ss, ifelse(is.na(z), NA_real_, as.numeric(z == destination))))
    }))
  }))))
}))
eps_stay <- do.call(rbind, lapply(names(eps_pairs), function(p) {
  ds <- eps_pair_designs[[p]]; d <- ds$variables
  do.call(rbind, lapply(c("All", "Men", "Women"), function(sx) {
    ss <- ds[which(d$age >= 50 & (sx == "All" | d$sex == sx)), ]; v <- ss$variables
    cbind(pair = p, sex = sx, eps_prop(ss, as.numeric(v$current0 == v$current1)))
  }))
}))
eps_lifetime_bounds <- do.call(rbind, lapply(c("Men", "Women"), function(sx) {
  ds <- hd[which(hd$variables$sex == sx & hd$variables$age >= 50), ]; d <- ds$variables
  mm <- d$current_mid
  prior_positive <- (!is.na(d$current0) & d$current0 == 1) | (!is.na(mm) & mm == 1)
  known_former <- !is.na(d$current1) & d$current1 == 0 & prior_positive
  possible_lifetime <- (is.na(d$current1) | d$current1 == 0) & !prior_positive
  data.frame(sex = sx, domain = "50plus_at_VI_official_panel", n = nrow(d), lifetime_lower = 0,
    lifetime_upper = stats::weighted.mean(as.numeric(possible_lifetime), d$weight),
    observed_former_lower = stats::weighted.mean(as.numeric(known_former), d$weight),
    note = "identification_bounds_not_confidence_intervals")
}))
eps_save(eps_triple_rho, "rho_same_people_three_interviews"); eps_save(eps_ar1_diagnostic, "ar1_same_people_diagnostic")
eps_save(eps_state_transitions, "category_transitions_50plus"); eps_save(eps_stay, "unchanged_status_50plus")
eps_save(eps_lifetime_bounds, "lifetime_identification_bounds_panel")
eps_table(eps_ar1_diagnostic[, 1:7], "AR(1) diagnostic: the same subpanel, age 50+ at baseline; not a formal test")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))