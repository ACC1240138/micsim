#| label: eps-harmonize
.t0 <- Sys.time()
eps_education <- function(n, e, d, wave, attended = FALSE) {
  ans <- rep(NA_character_, length(n))
  ans[n %in% c(1:4, 13)] <- eps_edu_levels[1]
  if (attended) {
    ans[n %in% 5:8] <- eps_edu_levels[2]
    ans[n %in% 9:12] <- eps_edu_levels[3]
  } else {
    ans[n %in% 5:8 & e %in% 2] <- eps_edu_levels[1]
    ans[n %in% 5:8 & e %in% 1] <- eps_edu_levels[2]
    complete <- if (wave == "VI") c(1, 2) else c(1, 2, 3)
    incomplete <- if (wave == "VI") 3 else c(4, 5)
    ans[n %in% 9:11 & d %in% incomplete] <- eps_edu_levels[2]
    ans[n %in% 9:11 & d %in% complete] <- eps_edu_levels[3]
    ans[n %in% 12] <- eps_edu_levels[3] # Postgraduate attendance implies prior tertiary completion.
  }
  ans
}
eps_alcohol <- function(s, f, q, sex, grams = 12, less_week = .5, aggregation = "sum") {
  stopifnot(ncol(s) == 3L, all(dim(s) == dim(f)), all(dim(s) == dim(q)), grams > 0, less_week > 0, less_week < 1)
  s[!s %in% c(1, 2)] <- NA_real_
  f[!f %in% 0:7] <- NA_real_
  q[q %in% c(88, 99, 888, 999, 8888, 9999) | !is.finite(q) | q <= 0] <- NA_real_
  no <- !is.na(s) & s == 2
  yes <- !is.na(s) & s == 1
  current <- ifelse(rowSums(yes) > 0, 1, ifelse(rowSums(no) == 3, 0, NA_real_))
  contradiction <- rowSums(no & ((!is.na(f) & f > 0) | (!is.na(q) & q > 0))) > 0
  zero_frequency <- rowSums(yes & !is.na(f) & f == 0) > 0
  fq <- f
  fq[!is.na(fq) & fq == 0] <- less_week
  volume <- grams * fq * q / 7
  volume[no] <- 0
  volume[is.na(s)] <- NA_real_
  g <- if (aggregation == "sum") rowSums(volume) else apply(volume, 1, max)
  # Missing beverage quantities remain unknown in both rules, including Calvo-max sensitivity.
  g[contradiction] <- NA_real_
  occasional <- current == 1 & rowSums(no | (yes & !is.na(f) & f == 0)) == 3
  threshold <- ifelse(sex == "Women", 40, ifelse(sex == "Men", 60, NA_real_))
  state <- rep(NA_character_, nrow(s))
  state[which(current == 0 & !contradiction)] <- eps_states[1]
  state[which(current == 1 & is.finite(g) & g < threshold)] <- eps_states[3]
  state[which(occasional & is.finite(g) & g < threshold)] <- eps_states[2]
  state[which(current == 1 & is.finite(g) & g >= threshold)] <- eps_states[4]
  low_cut <- ifelse(sex == "Women", 20, 40)
  jrt <- ifelse(current == 0, "Abstainer", ifelse(is.na(g), NA_character_,
      ifelse(g < low_cut, "JRT_low", ifelse(g < threshold, "JRT_medium", "JRT_high"))))
  data.frame(current, grams_day = g, state, jrt, zero_frequency, contradiction,
             current_volume_missing = current == 1 & is.na(g))
}
eps_wave <- function(wave) {
  z <- eps_raw[[wave]]; a <- z$a; f <- z$f; w <- z$w
  stopifnot(setequal(a$folio_n20, f$folio_n20), setequal(a$folio_n20, w$folio_n20))
  f <- f[match(a$folio_n20, f$folio_n20), ]; w <- w[match(a$folio_n20, w$folio_n20), ]
  n <- if (wave == "VI") a$a12n else a$a12_n
  e <- if (wave == "VI") a$a12e else a$a12_e
  d <- if (wave == "VI") a$a12d else a$a12_d
  out <- data.frame(id = as.character(a$folio_n20), wave, age = as.numeric(a$a9),
    sex = ifelse(a$a8 == 1, "Men", ifelse(a$a8 == 2, "Women", NA_character_)),
    education = eps_education(n, e, d, wave), education_attended = eps_education(n, e, d, wave, TRUE),
    weight = as.numeric(if (wave == "VI") w$factor_EPS2015 else w$factor_XS),
    strata = if (wave == "VI") 1 else as.numeric(w$strata_ID),
    psu = if (wave == "VI") seq_len(nrow(a)) else as.numeric(w$cluster_ID))
  stopifnot(all(out$weight > 0), all(is.finite(out$weight)), all(out$age >= 18 & out$age <= 115))
  out$age_group <- as.character(cut(out$age, c(18, 30, 45, 60, 66, 71, 77, Inf), right = FALSE, labels = eps_age_levels))
  # Keep raw alcohol codes in memory for transparent scenario recalculation, never export person records.
  for (prefix in c("f13_", "f14_", "f15_")) for (j in 1:3) out[[paste0(prefix, j)]] <- as.numeric(f[[paste0(prefix, j)]])
  cbind(out, eps_alcohol(as.matrix(out[paste0("f13_", 1:3)]), as.matrix(out[paste0("f14_", 1:3)]),
                         as.matrix(out[paste0("f15_", 1:3)]), out$sex))
}
eps_data <- lapply(names(eps_raw), eps_wave); names(eps_data) <- names(eps_raw)
eps_audit <- do.call(rbind, lapply(eps_data, function(d) data.frame(wave = d$wave[1], n = nrow(d),
  age_min = min(d$age), age_max = max(d$age), status_missing = sum(is.na(d$current)),
  volume_missing_current = sum(d$current_volume_missing, na.rm = TRUE),
  quantity_zero_current = sum(d$current == 1 & rowSums(d[paste0("f15_", 1:3)] == 0, na.rm = TRUE) > 0, na.rm = TRUE),
  frequency_less_than_one = sum(d$zero_frequency), contradictions = sum(d$contradiction),
  education_missing = sum(is.na(d$education)),
  education_mapping_changed = sum(d$education != d$education_attended, na.rm = TRUE))))
eps_phone_audit <- do.call(rbind, lapply(names(eps_phone), function(mode) {
  z <- eps_phone[[mode]]; tt <- as.data.frame(table(z$fc101_1, useNA = "ifany"))
  data.frame(mode, code = as.character(tt$Var1), n = tt$Freq,
             overlapping_presencial = sum(z$folio_n20 %in% eps_raw$VII_presencial$a$folio_n20))
}))
eps_save(eps_audit, "harmonization_audit"); eps_save(eps_phone_audit, "telephone_audit")
eps_table(eps_audit, "Harmonization audit: unweighted counts")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))