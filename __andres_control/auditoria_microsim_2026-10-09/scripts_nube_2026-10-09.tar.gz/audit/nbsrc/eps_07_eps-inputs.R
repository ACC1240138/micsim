#| label: eps-inputs
.t0 <- Sys.time()
eps_vii <- "_eps/Bases y Documentos EPS 2020"
eps_viii <- "_eps/Bases de datos EPS VIII Ronda"
eps_paths <- list(
  VI = c(a = "_eps/2015/2015/MODULOA_entrevistado.dta", f = "_eps/2015/2015/MODULOF_entrevistado.dta",
         w = "_eps/2015/2015/FactoresExpansionVIRondaEPS.dta"),
  VII_presencial = c(a = paste0(eps_vii, "/2020/Bases_EPS2020_presencial/01_Vivos presencial/MODULO_A_Entrevistado_in.dta"),
                    f = paste0(eps_vii, "/2020/Bases_EPS2020_presencial/01_Vivos presencial/MODULO_F_Entrevistado_in.dta"),
                    w = paste0(eps_vii, "/Factores de Expansion EPS 2020/Factor_XS_EPS_PRES_in.dta")),
  VIII = c(a = paste0(eps_viii, "/BBDD_VIVOS/MODULO_A_ENTREVISTADO.dta"),
           f = paste0(eps_viii, "/BBDD_VIVOS/MODULO_F_ENTREVISTADO.dta"),
           w = paste0(eps_viii, "/FACT_EXP/Factor_XS_EPS_2023.dta")))
eps_raw <- lapply(eps_paths, function(z) lapply(z, eps_read))
eps_panel_paths <- c(VI_VII = paste0(eps_vii, "/Factores de Expansion EPS 2020/Factor_Panel_EPS_PRES_2015_in.dta"),
                    VI_VIII = paste0(eps_viii, "/FACT_EXP/Factor_Panel_EPS_2023_2015.dta"))
eps_panel_weights <- lapply(eps_panel_paths, eps_read)
eps_phone_paths <- c(continuidad = paste0(eps_vii, "/2020/Bases_EPS2020_continuidad/01_Vivos_continuidad/MODULO_Entrevistado_VIVOS_in.dta"),
                     reentrevista = paste0(eps_vii, "/2020/Bases_EPS2020_reentrevista/01_Vivos reentrevista/MODULO_Entrevistado_VIVOS_in.dta"))
eps_phone <- lapply(eps_phone_paths, eps_read)
eps_input_paths <- unique(c(unlist(eps_paths), eps_panel_paths, eps_phone_paths))
eps_manifest <- data.frame(file = eps_input_paths, md5 = unname(tools::md5sum(eps_abs(eps_input_paths))))
eps_save(eps_manifest, "input_manifest")
# Preserve original codes and labels as an auditable crosswalk before converting to numbers.
eps_dictionary <- do.call(rbind, lapply(names(eps_raw), function(wave) do.call(rbind, lapply(c("a", "f", "w"), function(block) {
  z <- eps_raw[[wave]][[block]]
  keep <- grep("^a8$|^a9$|^a12|^f1[345]_|folio|factor|strata|cluster", names(z), value = TRUE)
  do.call(rbind, lapply(keep, function(v) data.frame(wave, block, variable = v,
    label = if (is.null(attr(z[[v]], "label"))) "" else attr(z[[v]], "label"),
    codes = paste(names(attr(z[[v]], "labels")), attr(z[[v]], "labels"), sep = "=", collapse = "; "))))
}))))
eps_save(eps_dictionary, "variable_dictionary")
eps_table(data.frame(wave = names(eps_raw), n = vapply(eps_raw, function(z) nrow(z$a), integer(1))), "Living respondents before excluding missing responses")
cat(sprintf("Elapsed: %.2f minutes\n", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))