.t0 <- Sys.time()
stopifnot(nzchar(Sys.getenv("ACC_DATA_KEY")))
source(file.path("<repo>", "_tools", "acc_data.R"))
setwd("<repo>")
f <- list(`2012` = c("Base de datos ENPG 2012 (PG).DTA.dta", "idencuesta", "p11", "p12"),
          `2014` = c("Base de datos ENPG 2014 (PG).DTA.dta", "idencuesta", "oh2", "oh3"),
          `2016` = c("base ENPG 2016 publico general.dta", "idencuesta", "oh_2", "oh_3"),
          `2018` = c("Base de datos ENPG 2018 (PG).DTA", "SbjNum", "OH_2", "OH_3"),
          `2022` = c("BD - ENPG 2022 (Stata 16).dta", "FOLIO", "OH_2", "OH_3"),
          `2024` = c("Base Publica ENPG 2024 (Stata 16).dta", "RESPONDENT_SERIAL", "OH_2", "OH_3"))
for (y in names(f)) {
  x <- haven::read_dta(acc_data("_enpg/enpg.tar.xz.enc", f[[y]][1]), col_select = dplyr::all_of(f[[y]][2:4]))
  cat("==", y, nrow(x), "\n")
  print(table(haven::as_factor(x[[2]]), useNA = "ifany"))
  a <- as.numeric(x[[3]]); cat("age-first summary:\n"); print(summary(a)); print(head(sort(table(a[a > 60]), decreasing = TRUE)))
}
r20 <- readRDS(acc_data("_enpg/enpg.tar.xz.enc", "enpg2020.RDS"))
cat("2020 RDS dim", dim(r20), "\n"); print(grep("^OH|SbjNum|EDAD|S0", names(r20), value = TRUE))
message(sprintf("elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
