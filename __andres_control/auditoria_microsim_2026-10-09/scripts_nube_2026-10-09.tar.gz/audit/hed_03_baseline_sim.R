# Re-run the 7-wave interp_hold reconstruction (engine as in the notebook) and save AGGREGATED cell summaries.
.t0 <- Sys.time()
source("<scratch>/audit/hed_00_load_engine.R")
args <- commandArgs(TRUE)
seeds <- if (length(args)) as.integer(strsplit(args[1], ",")[[1]]) else ms_cfg$seeds
rhos <- if (length(args) > 1) as.numeric(strsplit(args[2], ",")[[1]]) else ms_cfg$rho
model <- ms_fit(ms_cfg$observed_end, "interp_hold")
out <- list()
for (rho in rhos) for (s in seeds) {
  t1 <- Sys.time()
  r <- ms_simulate(model, 2012:2024, ms_cfg$n_sim, s, rho)
  out[[length(out) + 1]] <- r$summary[c("year","sex","age_group","n","current_mean","gpd_mean","hed_mean","seed","rho")]
  message(sprintf("seed %d rho %.2f: %.2f min", s, rho, as.numeric(difftime(Sys.time(), t1, units = "mins"))))
}
res <- dplyr::bind_rows(out)
utils::write.csv(res, file.path(AUDIT, sprintf("hed_sim_baseline_rho%s_%dseeds.csv", paste(rhos, collapse = "-"), length(seeds))), row.names = FALSE)
message(sprintf("03_baseline_sim elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
