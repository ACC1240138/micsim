"""Step 4d: compatibility table for the lambda x phi grid: EPS fit (delta WLS objective) and ENPG deviations."""
import numpy as np, pandas as pd
OUT = "<scratch>/audit/out"
lags = np.array([3.671, 4.022, 7.693])
def wobj(lam, phi, r, se):
    m = lam + (1 - lam) * phi ** lags
    return float((((np.arctanh(r) - np.arctanh(m)) / se) ** 2).sum())
tri = pd.read_csv(f"{OUT}/p2_triple_rho_by_age_sex.csv")
eps = {}
for age in ["50+", "All 18+"]:
    x = tri[(tri.age == age) & (tri.sex == "All")].set_index("pair").loc[["VI_VII", "VII_VIII", "VI_VIII"]]
    eps[age] = (x.rho_interval.values, x.se_z.values)
grid_l = np.arange(0, 0.951, 0.005); grid_p = np.arange(0.01, 0.991, 0.005)
best = {a: min(wobj(l, p, *eps[a]) for l in grid_l for p in grid_p) for a in eps}
g = pd.read_csv(f"{OUT}/p4_grid.csv"); g = g[g.init == "latent"]
rows = []
for (lam, phi), d in g.groupby(["lam", "phi"]):
    r = dict(lam=lam, phi=phi, r1y=lam + (1 - lam) * phi,
             eps50_delta=wobj(lam, phi, *eps["50+"]) - best["50+"], eps18_delta=wobj(lam, phi, *eps["All 18+"]) - best["All 18+"])
    for v in ["never", "former12", "not30_given12"]:
        dev = [abs(row[f"{v}_{b}"] - row[f"target_{v}_{b}"]) for _, row in d.iterrows() for b in ["30-34", "45-49", "60-65"]]
        r[f"{v}_maxdev_pp"] = 100 * max(dev)
    r["eps_ok"] = r["eps50_delta"] <= 5.99 and r["eps18_delta"] <= 5.99
    r["enpg_never_ok_5pp"] = r["never_maxdev_pp"] <= 5; r["enpg_former_ok_5pp"] = r["former12_maxdev_pp"] <= 5
    r["compatible_all"] = r["eps_ok"] and r["enpg_never_ok_5pp"] and r["enpg_former_ok_5pp"]
    rows.append(r)
c = pd.DataFrame(rows); c.to_csv(f"{OUT}/p4d_compatibility.csv", index=False)
pd.set_option("display.width", 250); print(c.round(2).to_string()); print("best obj", best)
print("compatible cells:", int(c.compatible_all.sum()), "of", len(c))
