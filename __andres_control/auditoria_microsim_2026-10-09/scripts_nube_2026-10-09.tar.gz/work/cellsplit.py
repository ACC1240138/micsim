import json, sys, os
nb = json.load(open(sys.argv[1])); d = sys.argv[2]; os.makedirs(d, exist_ok=True)
for c in nb['cells']:
    if c['cell_type'] != 'code': continue
    src = ''.join(c['source'])
    lab = [l.split(':',1)[1].strip() for l in src.splitlines()[:3] if l.startswith('#| label:')]
    open(os.path.join(d, (lab[0] if lab else c['id'])+'.R'),'w').write(src+'\n')
