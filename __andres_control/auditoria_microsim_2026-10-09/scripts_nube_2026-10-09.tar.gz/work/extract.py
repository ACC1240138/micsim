import json, sys
nb = json.load(open(sys.argv[1]))
out = open(sys.argv[2], 'w')
for i, c in enumerate(nb['cells']):
    src = ''.join(c['source'])
    md = c.get('metadata', {})
    label = md.get('label') or md.get('name') or ''
    # try quarto label
    for line in src.splitlines()[:5]:
        if line.startswith('#| label:'):
            label = line.split(':',1)[1].strip()
    out.write(f"\n######## CELL {i} [{c['cell_type']}] label={label} id={c.get('id','')}\n")
    for j, l in enumerate(src.splitlines(), 1):
        out.write(f"{j:4d}| {l}\n")
out.close()
print(len(nb['cells']))
