#| label: ms-demography-inputs
#| results: "hold"
.t0 <- base::Sys.time()
# January stocks drive population accounting; June stocks approximate annual exposure.
# The full INE workbook contains BOTH dates despite its sheet name ending in 0101.
# DEIS 2024+ weekly file: newest version by the DDMMYYYY in its name (ACC_DEIS_VERSION pins one), the same rule as acc_deis().
ms_deis_enc <- if (base::nzchar(base::Sys.getenv("ACC_DEIS_VERSION"))) {
  base::sprintf("DEFUNCIONES_FUENTE_DEIS_2024_2026_%s.tar.xz.enc", base::Sys.getenv("ACC_DEIS_VERSION"))
} else {
  base::basename(acc_latest(base::file.path(acc_root(), "_deis")))
}
ms_deis_date <- base::format(base::as.Date(base::sub(".*_([0-9]{8})\\.tar\\.xz\\.enc$", "\\1", ms_deis_enc), "%d%m%Y"), "%Y-%m-%d")
ms_demography_files <- base::c(
  population = "__andres_control/ine_proyecciones_rebuild/ine_basedatos.xlsx",
  hmd_male = "__andres_control/ine_proyecciones_rebuild/mltper_1x1.txt",
  hmd_female = "__andres_control/ine_proyecciones_rebuild/fltper_1x1.txt",
  deaths_2012_2023 = "_deis/DEFUNCIONES_DEIS_2012_2023_15plus.tar.xz.enc",
  deaths_2024 = base::file.path("_deis", ms_deis_enc)
)
base::stopifnot(base::all(base::file.exists(ms_path(ms_demography_files))))
.ms_pop <- readxl::read_xlsx(ms_path(ms_demography_files[["population"]]), sheet = "BBDD_EEPP-2024_0101")
base::stopifnot(base::identical(base::names(.ms_pop), base::c("NIVEL", "SEXO", "FECHA", "EDAD", "POBLACION")),
  base::setequal(base::unique(.ms_pop$SEXO), base::c("H", "M")), base::length(base::unique(.ms_pop$NIVEL)) == 1L)
.ms_date <- base::as.Date(.ms_pop$FECHA, format = "%d/%m/%Y")
base::stopifnot(!base::anyNA(.ms_date))
.ms_pop <- base::data.frame(year = base::as.integer(base::format(.ms_date, "%Y")),
  sex = base::ifelse(.ms_pop$SEXO == "H", "male", "female"), age = base::as.integer(.ms_pop$EDAD),
  date = base::format(.ms_date, "%m-%d"), population = .ms_pop$POBLACION)
.ms_pop <- .ms_pop[.ms_pop$year %in% 2012:2034 & .ms_pop$age %in% 15:65, ]
base::stopifnot(base::setequal(base::unique(.ms_pop$date), base::c("01-01", "06-30")),
  base::all(base::is.finite(.ms_pop$population) & .ms_pop$population > 0),
  !base::anyDuplicated(.ms_pop[base::c("year", "sex", "age", "date")]))
.ms_keys <- base::c("year", "sex", "age")
.ms_jan <- .ms_pop[.ms_pop$date == "01-01", base::c(.ms_keys, "population")]
.ms_mid <- .ms_pop[.ms_pop$date == "06-30", base::c(.ms_keys, "population")]
base::names(.ms_jan)[4L] <- "pop_jan"
base::names(.ms_mid)[4L] <- "pop_mid"
ms_population <- base::merge(.ms_jan, .ms_mid, by = .ms_keys, all = TRUE)
base::stopifnot(base::nrow(ms_population) == 23L * 2L * 51L, !base::anyNA(ms_population),
  !base::anyDuplicated(ms_population[.ms_keys]))
# Keep the published qx probability AND mx central rate; ex is not a death probability.
# HMD dx and lx describe a synthetic life-table cohort, not observed DEIS death counts.
.ms_hmd <- base::lapply(base::c("male", "female"), function(sx) {
  z <- utils::read.table(ms_path(ms_demography_files[[base::paste0("hmd_", sx)]]),
    header = TRUE, skip = 2L, stringsAsFactors = FALSE)
  base::stopifnot(base::identical(base::names(z), base::c("Year", "Age", "mx", "qx", "ax", "lx", "dx", "Lx", "Tx", "ex")))
  z <- z[z$Year %in% 2012:2024 & z$Age %in% base::as.character(15:65), ]
  base::data.frame(year = base::as.integer(z$Year), sex = sx,
    age = base::as.integer(z$Age), qx = z$qx, mx = z$mx)
})
.ms_hmd <- base::do.call(base::rbind, .ms_hmd)
base::stopifnot(base::nrow(.ms_hmd) == 13L * 2L * 51L, !base::anyNA(.ms_hmd),
  !base::anyDuplicated(.ms_hmd[.ms_keys]), base::all(.ms_hmd$qx >= 0 & .ms_hmd$qx < 1),
  base::all(base::is.finite(.ms_hmd$mx) & .ms_hmd$mx >= 0))
# Read only the demographic columns from the existing DEIS parquet inputs.
.ms_old <- base::as.data.frame(arrow::read_parquet(ms_path(ms_demography_files[["deaths_2012_2023"]]),
  col_select = base::c("year", "gender", "age")))
base::stopifnot(base::identical(base::names(.ms_old), base::c("year", "gender", "age")))
.ms_old <- .ms_old[.ms_old$year %in% 2012:2023 & .ms_old$age %in% 15:65 &
  .ms_old$gender %in% base::c("Hombre", "Mujer"), ]
# acc_deis() returns the weekly DEIS CSV with a valid UTF-8 header ("AÑO"), so the columns can be selected by name.
.ms_new <- acc_deis()[base::c("AÑO", "SEXO_NOMBRE", "EDAD_TIPO", "EDAD_CANT")]
base::stopifnot(base::identical(base::names(.ms_new)[2:4], base::c("SEXO_NOMBRE", "EDAD_TIPO", "EDAD_CANT")))
base::names(.ms_new) <- base::c("year", "gender", "age_type", "age")
.ms_new <- base::as.data.frame(.ms_new)
base::stopifnot(base::all(.ms_new$year %in% 2024:2026))
# The file also contains provisional 2025/2026 records: they are NOT historical targets.
# age_type == 1 means completed years; infants recorded in days/hours must not enter.
.ms_new <- .ms_new[.ms_new$year == 2024L & .ms_new$age_type == 1L &
  .ms_new$age %in% 15:65 & .ms_new$gender %in% base::c("Hombre", "Mujer"), ]
base::stopifnot(base::nrow(.ms_new) > 0L, base::all(.ms_new$year == 2024L),
  base::all(.ms_new$age_type == 1L))
.ms_death_rows <- base::rbind(.ms_old, .ms_new[base::c("year", "gender", "age")])
.ms_death_rows$sex <- base::ifelse(.ms_death_rows$gender == "Hombre", "male", "female")
.ms_death_rows$deaths <- 1L
.ms_deaths <- stats::aggregate(deaths ~ year + sex + age, data = .ms_death_rows, FUN = base::sum)
# All 1,326 exact-age cells have observed deaths in these source vintages.
# A missing target fails here instead of silently becoming zero mortality.
base::stopifnot(base::nrow(.ms_deaths) == 13L * 2L * 51L,
  !base::anyDuplicated(.ms_deaths[.ms_keys]), base::all(.ms_deaths$deaths >= 0L))
ms_mortality <- base::merge(.ms_hmd, .ms_deaths, by = .ms_keys, all = TRUE)
ms_mortality <- base::merge(ms_mortality, ms_population[ms_population$year <= 2024L, ], by = .ms_keys, all = TRUE)
base::stopifnot(base::nrow(ms_mortality) == 13L * 2L * 51L, !base::anyNA(ms_mortality),
  !base::anyDuplicated(ms_mortality[.ms_keys]),
  base::sum(ms_mortality$deaths) == base::nrow(.ms_death_rows))
ms_demography_audit <- base::data.frame(
  source = base::c("INE population", "HMD period life tables", "DEIS all-cause deaths", "Historical interpretation"),
  detail = base::c("Base CPV 2024; January/June stocks; 2012-2024 estimates, 2025-2034 projections.",
    "Chile 1x1; modified 12 January 2026; observed input years 2012-2024; qx and mx retained.",
    base::sprintf("%s deaths at ages 15-65 in 2012-2024; 2024 source dated %s; %s cells.",
      base::format(base::sum(ms_mortality$deaths), big.mark = ","), ms_deis_date, base::nrow(ms_mortality)),
    "HMD/DEIS concordance is not independent external validation; population vintages and stock/exposure definitions differ.")
)
ms_table(ms_demography_audit, caption = "Demographic inputs and source vintages")
ms_table(stats::aggregate(deaths ~ year + sex, data = ms_mortality, FUN = base::sum),
  caption = "Observed all-cause DEIS deaths in the modeled 15-65 age window")
base::rm(.ms_pop, .ms_date, .ms_keys, .ms_jan, .ms_mid, .ms_hmd, .ms_old, .ms_new, .ms_death_rows, .ms_deaths)
base::message(base::sprintf("demography-inputs elapsed minutes: %.2f",
  base::as.numeric(base::difftime(base::Sys.time(), .t0, units = "mins"))))

