#| label: ms-rolling-origin
.t0 <- Sys.time()
ms_rolling_grid <- base::expand.grid(cutoff = ms_cfg$cutoffs, spec = ms_cfg$specs,
  drop_2020 = base::c(FALSE, TRUE), stringsAsFactors = FALSE)
ms_rolling_grid <- ms_rolling_grid[!ms_rolling_grid$drop_2020 | ms_rolling_grid$cutoff >= 2020L, ]
ms_rolling <- dplyr::bind_rows(base::lapply(base::seq_len(base::nrow(ms_rolling_grid)), function(i) {
  g <- ms_rolling_grid[i, ]
  model <- ms_fit(g$cutoff, g$spec, g$drop_2020)
  eval_years <- ms_wave_years[ms_wave_years > g$cutoff & ms_wave_years <= g$cutoff + 4L]
  d <- ms_drivers(model, eval_years)
  obs <- ms_targets[ms_targets$year %in% eval_years, ]
  k <- base::match(base::paste(obs$year, obs$sex, obs$age_group, sep = ":"), d$key)
  base::stopifnot(!base::anyNA(k))
  base::data.frame(cutoff = g$cutoff, spec = g$spec, drop_2020 = g$drop_2020, year = obs$year,
    horizon_waves = (obs$year - g$cutoff) %/% 2L, sex = obs$sex, age_group = obs$age_group,
    current_observed = obs$current_mean, current_predicted = d$p_current[k], current_se = obs$current_se,
    gpd_observed = obs$gpd_mean, gpd_predicted = d$mu_current[k], gpd_se = obs$gpd_se)
}))
ms_rolling$current_error <- ms_rolling$current_predicted - ms_rolling$current_observed
ms_rolling$gpd_error <- ms_rolling$gpd_predicted - ms_rolling$gpd_observed
ms_rolling$current_in_interval <- base::ifelse(ms_rolling$year == 2020L, NA,
  base::abs(ms_rolling$current_error) <= stats::qnorm(0.975) * ms_rolling$current_se)
base::stopifnot(base::nrow(ms_rolling) == 8L * (3L * 2L + 1L) * 4L + 8L * (2L + 1L) * 4L)
ms_rolling_metrics <- ms_rolling |>
  dplyr::group_by(spec, drop_2020, horizon_waves) |>
  dplyr::summarise(cutoffs = dplyr::n_distinct(cutoff), cells = dplyr::n(),
    current_bias = base::mean(current_error), current_rmse = base::sqrt(base::mean(current_error^2)),
    current_working_coverage = base::mean(current_in_interval, na.rm = TRUE),
    gpd_bias = base::mean(gpd_error), gpd_rmse = base::sqrt(base::mean(gpd_error^2)), .groups = "drop") |>
  dplyr::arrange(drop_2020, horizon_waves, current_rmse)
ms_rolling_by_cutoff <- ms_rolling |>
  dplyr::filter(!drop_2020, horizon_waves == 1L) |>
  dplyr::group_by(spec, cutoff, target_year = year) |>
  dplyr::summarise(current_rmse_pp = 100 * base::sqrt(base::mean(current_error^2)),
    current_bias_pp = 100 * base::mean(current_error),
    gpd_rmse = base::sqrt(base::mean(gpd_error^2)), .groups = "drop")
ms_rolling_wide <- ms_rolling_by_cutoff |>
  dplyr::select(spec, target_year, current_rmse_pp) |>
  tidyr::pivot_wider(names_from = target_year, values_from = current_rmse_pp, names_prefix = "predict_")
ms_table(ms_rolling_metrics, "Rolling-origin summary across cutoffs; proportions for prevalence, g/day for intensity")
ms_table(ms_rolling_wide, "One-wave-ahead prevalence RMSE in percentage points by cutoff (all waves retained)")
ms_fig_rolling <- ggplot2::ggplot(ms_rolling_by_cutoff, ggplot2::aes(target_year, current_rmse_pp, colour = spec)) +
  ggplot2::geom_line() + ggplot2::geom_point(size = 2) +
  ggplot2::scale_x_continuous(breaks = base::unique(ms_rolling_by_cutoff$target_year)) +
  ggplot2::labs(title = "One-wave-ahead prevalence error by projection rule", x = "Predicted wave",
    y = "RMSE over 8 sex x age cells (percentage points)", colour = "Specification",
    caption = "Each point: fit through the previous wave, predict this wave. Driver-level, deterministic.") +
  ggplot2::theme_minimal(base_size = 11) + ggplot2::theme(legend.position = "bottom")
base::print(ms_fig_rolling)
base::message(base::sprintf("ms-rolling-origin elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))

