#| label: ms-calibration-functions
.t0 <- Sys.time()

# spec governs ONLY the prevalence and intensity time curves. Everything else is estimated on training waves.
ms_curve <- function(target, y, w, spec) {
  fit_data <- if (spec == "static2012") target[target$year == ms_cfg$start_year, ] else target
  if (spec == "interp_hold") {
    # Piecewise-linear interpolation between observed waves; rule = 2 carries the last (and first) value forward.
    pts <- base::split(fit_data[base::c("time", y)], fit_data$cell)
    base::stopifnot(base::all(base::vapply(pts, base::nrow, base::integer(1)) >= 1L))
    predict_fn <- function(grid) {
      out <- base::rep(NA_real_, base::nrow(grid))
      for (cl in base::names(pts)) {
        k <- base::as.character(grid$cell) == cl
        if (base::any(k)) out[k] <- if (base::nrow(pts[[cl]]) == 1L) pts[[cl]][[y]] else
          stats::approx(pts[[cl]]$time, pts[[cl]][[y]], xout = grid$time[k], rule = 2)$y
      }
      out
    }
    return(base::list(fit = pts, predict = predict_fn))
  }
  rhs <- base::switch(spec, static2012 = "0 + cell", linear_all = "0 + cell + cell:time",
    spline_shared = "0 + cell + splines::ns(time, df = 2)")
  m <- stats::lm(stats::as.formula(base::paste(y, "~", rhs)), data = fit_data, weights = fit_data[[w]])
  base::stopifnot(!base::anyNA(stats::coef(m)))
  base::list(fit = m, predict = function(grid) base::unname(stats::predict(m, newdata = grid)))
}

ms_fit <- function(last_year, spec = "interp_hold", drop_2020 = FALSE) {
  base::stopifnot(spec %in% ms_cfg$specs, last_year %in% ms_wave_years)
  keep_wave <- function(y) y <= last_year & !(drop_2020 & y == 2020L)
  train <- ms_enpg[keep_wave(ms_enpg$year), ]
  target <- ms_targets[keep_wave(ms_targets$year), ]
  target$cell <- base::factor(base::paste(target$sex, target$age_group, sep = ":"))
  target$time <- (target$year - ms_cfg$start_year) / 10
  base::stopifnot(base::all(target$current_mean > 0 & target$current_mean < 1),
                  base::all(target$gpd_mean > 0))
  # Delta-method inverse variances are working calibration weights, not a full joint likelihood.
  target$y_current <- stats::qlogis(target$current_mean)
  target$y_amount <- base::log(target$gpd_mean)
  target$w_current <- (target$current_mean * (1 - target$current_mean) / target$current_se)^2
  target$w_amount <- (target$gpd_mean / target$gpd_se)^2
  base::stopifnot(base::all(base::is.finite(target$w_current) & target$w_current > 0),
                  base::all(base::is.finite(target$w_amount) & target$w_amount > 0))
  prevalence <- ms_curve(target, "y_current", "w_current", spec)
  amount <- ms_curve(target, "y_amount", "w_amount", spec)

  # The Gamma shape reuses the project's survey-weighted moment estimator on RAW g/day.
  shape <- train |>
    dplyr::filter(current == 1, base::is.finite(gpd_survey), gpd_survey > 0) |>
    dplyr::group_by(sex, age_group) |>
    dplyr::summarise(mu = stats::weighted.mean(gpd_survey, weight),
      variance = stats::weighted.mean((gpd_survey - mu)^2, weight),
      shape = mu^2 / variance, .groups = "drop")
  zero <- train |>
    dplyr::filter(current == 1, base::is.finite(gpd_survey)) |>
    dplyr::group_by(sex, age_group) |>
    dplyr::summarise(p_zero = stats::weighted.mean(gpd_survey == 0, weight), .groups = "drop")
  former <- train |>
    dplyr::filter(current == 0, !base::is.na(ever)) |>
    dplyr::group_by(sex, age_group) |>
    dplyr::summarise(p_ever_noncurrent = stats::weighted.mean(ever, weight), .groups = "drop")
  shape <- shape |>
    dplyr::left_join(zero, by = base::c("sex", "age_group")) |>
    dplyr::left_join(former, by = base::c("sex", "age_group"))
  base::stopifnot(base::nrow(shape) == 8L, base::all(base::is.finite(shape$shape)),
                  base::all(shape$shape > 0), base::all(shape$p_zero < 1))

  # HED is conditional on current drinking and intensity; questionnaire harmonization remains a caveat.
  hed_data <- train[train$current %in% 1 & base::is.finite(train$gpd_survey) &
                     train$gpd_survey > 0 & !base::is.na(train$hed), ]
  hed_data$cell <- base::factor(base::paste(hed_data$sex, hed_data$age_group, sep = ":"))
  hed_data$w_fit <- hed_data$weight / base::mean(hed_data$weight)
  hed <- stats::glm(hed ~ 0 + cell + base::log1p(gpd_survey), data = hed_data,
                    weights = w_fit, family = stats::quasibinomial())
  base::stopifnot(hed$converged, !base::anyNA(stats::coef(hed)))

  # One all-cause hazard multiplier per sex from DEIS deaths <= last_year; DEIS is not a survey wave.
  death_train <- ms_mortality[ms_mortality$year <= last_year, ]
  mortality_scale <- base::vapply(base::c("female", "male"), function(s) {
    d <- death_train[death_train$sex == s, ]
    f <- function(log_scale) base::sum(d$pop_jan *
      (-base::expm1(base::log1p(-d$qx) * base::exp(log_scale)))) - base::sum(d$deaths)
    base::exp(stats::uniroot(f, interval = base::c(-3, 3))$root)
  }, base::numeric(1))
  base::list(prevalence = prevalence, amount = amount, shape = shape, hed = hed,
    mortality_scale = mortality_scale, last_year = last_year, spec = spec, drop_2020 = drop_2020,
    cells = base::levels(target$cell), training_years = base::sort(base::unique(target$year)))
}

ms_drivers <- function(model, years) {
  grid <- base::expand.grid(year = years, sex = base::c("female", "male"), age_group = 1:4,
                           stringsAsFactors = FALSE)
  grid$cell <- base::factor(base::paste(grid$sex, grid$age_group, sep = ":"), levels = model$cells)
  # Time is NOT frozen here: each spec defines its own behaviour beyond the last training wave.
  grid$time <- (grid$year - ms_cfg$start_year) / 10
  grid$p_current <- stats::plogis(model$prevalence$predict(grid))
  grid$mu_current <- base::exp(model$amount$predict(grid))
  grid <- dplyr::left_join(grid, model$shape, by = base::c("sex", "age_group"))
  grid$hed_intercept <- stats::coef(model$hed)[base::paste0("cell", base::as.character(grid$cell))]
  grid$hed_slope <- base::unname(stats::coef(model$hed)["base::log1p(gpd_survey)"])
  base::stopifnot(!base::anyNA(grid), base::all(grid$p_current > 0 & grid$p_current < 1),
                  base::all(grid$mu_current > 0))
  grid$key <- base::paste(grid$year, grid$sex, grid$age_group, sep = ":")
  grid
}
base::message(base::sprintf("ms-calibration-functions elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))

