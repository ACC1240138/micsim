#| label: ms-projection-rules
.t0 <- Sys.time()
ms_projection_specs <- base::c("interp_hold", "linear_all", "spline_shared")
ms_projection_runs <- base::lapply(ms_projection_specs, function(spec)
  ms_simulate(ms_fit(ms_cfg$observed_end, spec), ms_cfg$start_year:ms_cfg$end_year,
    ms_cfg$n_sim, ms_cfg$seeds[1], ms_cfg$rho))
base::names(ms_projection_runs) <- ms_projection_specs
ms_projection <- dplyr::bind_rows(base::lapply(ms_projection_specs, function(spec) {
  run <- ms_projection_runs[[spec]]
  run$summary |>
    dplyr::group_by(year) |>
    dplyr::summarise(current_prevalence = stats::weighted.mean(current_mean, population),
      gpd_current = stats::weighted.mean(gpd_mean, current_mean * population),
      gpd_population = stats::weighted.mean(gpd_population, population),
      population = base::sum(population), .groups = "drop") |>
    dplyr::left_join(run$deaths |>
      dplyr::group_by(year) |>
      dplyr::summarise(expected_deaths = base::sum(expected_deaths), realized_deaths = base::sum(deaths),
        .groups = "drop"), by = "year") |>
    dplyr::mutate(spec = spec, period = base::ifelse(year <= 2024, "Historical", "Conditional projection"))
}))
base::stopifnot(base::nrow(ms_projection) == 23L * 3L, !base::anyNA(ms_projection))
ms_projection_2034 <- ms_projection |>
  dplyr::filter(year %in% base::c(2024L, 2029L, 2034L)) |>
  dplyr::select(spec, year, current_prevalence, gpd_current, gpd_population, expected_deaths)
ms_table(ms_projection_2034, "National 15-65 prevalence, intensity and expected all-cause deaths by projection rule")
ms_fig_projection <- ggplot2::ggplot(ms_projection, ggplot2::aes(year, current_prevalence, colour = spec)) +
  ggplot2::geom_vline(xintercept = 2024, linetype = 3, colour = "grey50") +
  ggplot2::geom_line(linewidth = 0.7) +
  ggplot2::labs(title = "Past-30-day drinking prevalence, ages 15-65, by projection rule",
    x = "Year", y = "Proportion", colour = "Rule",
    caption = "Left of the line: seven-wave reconstruction. Right: rule-specific extrapolation; INE stocks evolve, mortality frozen at 2024.") +
  ggplot2::theme_minimal(base_size = 11) + ggplot2::theme(legend.position = "bottom")
base::print(ms_fig_projection)
ms_table(ms_projection_runs$interp_hold$flows, "Person accounting for the interp_hold projection run")
base::message(base::sprintf("ms-projection-rules elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))

