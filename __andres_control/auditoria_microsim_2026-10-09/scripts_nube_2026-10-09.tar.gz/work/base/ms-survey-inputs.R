#| label: ms-survey-inputs
#| results: "hold"
.t0 <- Sys.time()
# Keep IDs and exact ages; the saved PIF exposure cache discards both.
# Resolve a label to a readable path: "bundle.tar.xz.enc::member" or "bundle.tar.xz.enc" -> decrypted file (acc_data()); anything else -> repo-relative path.
ms_path <- function(label) base::vapply(label, function(z) {
  if (base::grepl("::", z, fixed = TRUE)) {
    p <- base::strsplit(z, "::", fixed = TRUE)[[1L]]
    acc_data(p[[1L]], p[[2L]])
  } else if (base::grepl("\\.tar\\.xz\\.enc$", z)) {
    acc_data(z)
  } else {
    here::here(z)
  }
}, base::character(1), USE.NAMES = FALSE)
ms_exposure_files <- base::c(
  binge = "_enpg/enpg.tar.xz.enc::derived/ENPG_BINGE.RDS",
  design = "_enpg/enpg.tar.xz.enc::derived/enpg_design_waves_2012_2024_list.RDS",
  psu2016 = "_enpg/enpg.tar.xz.enc::base ENPG 2016 publico general.dta")
base::stopifnot(base::all(base::file.exists(ms_path(ms_exposure_files))),
  base::all(base::file.info(ms_path(ms_exposure_files))$size > 2))
ms_exposure_provenance <- base::data.frame(input = base::names(ms_exposure_files),
  file = base::unname(ms_exposure_files), bytes = base::file.info(ms_path(ms_exposure_files))$size,
  md5 = base::unname(tools::md5sum(ms_path(ms_exposure_files))))
ms_raw <- base::readRDS(ms_path(ms_exposure_files[["binge"]]))
ms_design_cache <- base::readRDS(ms_path(ms_exposure_files[["design"]]))
ms_wave_years <- base::seq(2012L, 2024L, 2L)
base::stopifnot(base::all(base::c("id", "year", "sexo", "edad", "exp", "oh1", "oh2", "oh3", "db", "audit2") %in% base::names(ms_raw)),
  base::setequal(ms_raw$year, ms_wave_years),
  base::setequal(base::names(ms_design_cache$waves), base::as.character(ms_wave_years)),
  !base::anyDuplicated(ms_raw[base::c("year", "id")]))
# The short 2016 key merges distinct blocks; retain district and zone as well.
ms_psu16 <- base::as.data.frame(haven::read_dta(ms_path(ms_exposure_files[["psu2016"]]),
  col_select = base::c("idencuesta", "comuna", "distrito", "zona", "manzana")))
base::stopifnot(!base::anyDuplicated(ms_psu16$idencuesta), base::all(stats::complete.cases(ms_psu16)))
ms_design_lookup <- base::do.call(base::rbind, base::lapply(ms_wave_years, function(ms_y) {
  ms_d <- ms_design_cache$waves[[base::as.character(ms_y)]]
  base::stopifnot(base::all(base::c("year", "id_join", "weight", "region", "commune", "psu") %in% base::names(ms_d)),
    !base::anyDuplicated(ms_d$id_join))
  ms_psu <- if (ms_y == 2020L) base::rep(NA_character_, base::nrow(ms_d)) else
    base::paste(ms_d$commune, ms_d$psu, sep = "|")
  if (ms_y == 2016L) {
    ms_j <- base::match(ms_d$id_join, base::as.character(ms_psu16$idencuesta))
    base::stopifnot(!base::anyNA(ms_j))
    ms_psu <- base::do.call(base::paste, base::c(ms_psu16[ms_j,
      base::c("comuna", "distrito", "zona", "manzana")], sep = "|"))
  }
  if (ms_y != 2020L) base::stopifnot(!base::anyNA(ms_d$psu))
  if (ms_y == 2024L) base::stopifnot("ESTRATO" %in% base::names(ms_d))
  base::data.frame(year = ms_y, id = ms_d$id_join, weight = ms_d$weight, psu = ms_psu,
    stratum = base::as.character(if (ms_y == 2024L) ms_d$ESTRATO else ms_d$region),
    design_status = if (ms_y == 2020L) "Weights only; no validated clustering SE" else
      if (ms_y == 2024L) "PSU + supplied ESTRATO" else "PSU + region proxy strata")
}))
base::stopifnot(!base::anyDuplicated(ms_design_lookup[base::c("year", "id")]))
ms_match <- base::match(base::paste(ms_raw$year, ms_raw$id, sep = "|"),
  base::paste(ms_design_lookup$year, ms_design_lookup$id, sep = "|"))
base::stopifnot(!base::anyNA(ms_match))
ms_d <- ms_design_lookup[ms_match, ]
base::stopifnot(base::all(base::is.finite(ms_d$weight) & ms_d$weight > 0),
  !base::anyNA(ms_d$stratum), base::all(ms_raw$sexo %in% base::c("Hombre", "Mujer")),
  base::all(base::is.finite(ms_raw$edad)))
# Use the unrounded public design weight (2014 exp contains rounded weights).
ms_enpg_all <- base::data.frame(id = base::as.character(ms_raw$id), year = base::as.integer(ms_raw$year),
  sex = base::ifelse(ms_raw$sexo == "Hombre", "male", "female"), age = base::as.integer(ms_raw$edad),
  weight = ms_d$weight, psu = ms_d$psu, stratum = ms_d$stratum, design_status = ms_d$design_status)
ms_ever <- base::as.character(ms_raw$oh1)
ms_recency <- base::as.character(ms_raw$oh2)
ms_enpg_all$status <- base::ifelse(ms_ever == "No" & base::is.na(ms_recency), "never",
  base::ifelse(ms_ever == "Si" & ms_recency == "30 dias", "current",
    base::ifelse(ms_ever == "Si" & ms_recency %in% base::c(">30", ">1 a\u00f1o"), "former", NA_character_)))
ms_enpg_all$status[base::is.na(ms_enpg_all$status)] <- "unknown"
ms_enpg_all$current <- base::ifelse(ms_enpg_all$status == "unknown", NA_real_,
  base::as.numeric(ms_enpg_all$status == "current"))
ms_enpg_all$ever <- base::ifelse(ms_ever == "Si", TRUE, base::ifelse(ms_ever == "No", FALSE, NA))
ms_days <- base::as.numeric(ms_raw$oh3)
ms_days[!base::is.finite(ms_days) | ms_days < 0 | ms_days > 30] <- NA_real_
ms_episodes <- base::as.numeric(ms_raw$db)
ms_episodes[!base::is.finite(ms_episodes) | ms_episodes < 0 | ms_episodes >= 88] <- NA_real_
ms_midpoints <- base::c("0-2" = 1, "3-4" = 3.5, "5-6" = 5.5, "7-8" = 7.5, "9 o mas" = 9)
ms_drinks <- base::unname(ms_midpoints[base::as.character(ms_raw$audit2)])
# Inherit the 12-g drink convention; this survey scale has no WHO multiplier.
# Episode counts can exceed drinking days; pmax preserves the existing approximation.
ms_enpg_all$gpd_survey <- (base::pmax(ms_days - ms_episodes, 0) * ms_drinks +
  ms_episodes * base::ifelse(ms_enpg_all$sex == "male", 5, 4)) * 12 / 30
ms_enpg_all$hed <- base::as.numeric(ms_episodes > 0)
ms_noncurrent <- ms_enpg_all$status %in% base::c("never", "former")
ms_enpg_all$gpd_survey[ms_noncurrent] <- 0
ms_enpg_all$hed[ms_noncurrent] <- 0
ms_enpg_all$gpd_survey[ms_enpg_all$status == "unknown"] <- NA_real_
ms_enpg_all$hed[ms_enpg_all$status == "unknown"] <- NA_real_
ms_enpg_all$age_group <- base::findInterval(ms_enpg_all$age, base::c(15, 30, 45, 60))
ms_enpg_all$in_domain <- ms_enpg_all$age >= ms_cfg$min_age & ms_enpg_all$age <= ms_cfg$max_age
ms_enpg <- ms_enpg_all[ms_enpg_all$in_domain, ]
base::stopifnot(base::all(ms_enpg$age_group %in% 1:4),
  base::all(ms_enpg$gpd_survey[ms_enpg$status %in% base::c("never", "former")] == 0))
ms_data_audit <- base::do.call(base::rbind, base::lapply(ms_wave_years, function(ms_y) {
  ms_x <- ms_enpg[ms_enpg$year == ms_y, ]
  ms_c <- ms_x$status == "current"
  base::data.frame(year = ms_y, raw_n = base::sum(ms_raw$year == ms_y), domain_n = base::nrow(ms_x),
    never_n = base::sum(ms_x$status == "never"), former_n = base::sum(ms_x$status == "former"),
    current_n = base::sum(ms_c), unknown_status = base::sum(ms_x$status == "unknown"),
    current_gpd_missing = base::sum(ms_c & base::is.na(ms_x$gpd_survey)),
    current_gpd_zero = base::sum(ms_c & ms_x$gpd_survey == 0, na.rm = TRUE),
    current_hed_missing = base::sum(ms_c & base::is.na(ms_x$hed)),
    design_status = base::unique(ms_x$design_status))
}))
# Form the full wave design before subsetting domains so that survey design information is retained.
# ponytail: region is a proxy stratum before 2024; replace when verified full design variables are available.
ms_build_targets <- function() {
  ms_old_options <- base::options(survey.lonely.psu = "adjust", survey.adjust.domain.lonely = TRUE)
  base::on.exit(base::options(ms_old_options), add = TRUE)
  base::do.call(base::rbind, base::lapply(ms_wave_years, function(ms_y) {
    ms_wave <- ms_enpg_all[ms_enpg_all$year == ms_y, ]
    ms_design <- if (ms_y == 2020L) survey::svydesign(ids = ~1, weights = ~weight, data = ms_wave) else
      survey::svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, data = ms_wave, nest = TRUE)
    ms_grid <- base::expand.grid(sex = base::c("male", "female"), age_group = 1:4, stringsAsFactors = FALSE)
    base::do.call(base::rbind, base::lapply(base::seq_len(base::nrow(ms_grid)), function(ms_i) {
      ms_select <- ms_wave$in_domain & ms_wave$sex == ms_grid$sex[ms_i] & ms_wave$age_group == ms_grid$age_group[ms_i]
      ms_cell <- ms_design[ms_select, ]
      ms_v <- ms_cell$variables
      ms_current <- !base::is.na(ms_v$current) & ms_v$current == 1
      ms_lonely <- 0L
      ms_estimates <- base::lapply(base::c("current", "gpd_survey", "hed"), function(ms_variable) {
        ms_part <- if (ms_variable == "current") ms_cell else ms_cell[ms_current, ]
        # Report known domain singleton adjustments as a count instead of repeated warnings.
        ms_est <- base::withCallingHandlers(
          survey::svymean(stats::reformulate(ms_variable), ms_part, na.rm = TRUE), warning = function(ms_warning) {
            if (base::grepl("has only one PSU at stage 1", base::conditionMessage(ms_warning), fixed = TRUE)) {
              ms_lonely <<- ms_lonely + 1L
              base::invokeRestart("muffleWarning")
            }
          })
        base::c(mean = base::as.numeric(stats::coef(ms_est)), se = base::as.numeric(survey::SE(ms_est)))
      })
      ms_w <- ms_v$weight[!base::is.na(ms_v$current)]
      base::data.frame(year = ms_y, sex = ms_grid$sex[ms_i], age_group = ms_grid$age_group[ms_i],
        n = base::nrow(ms_v), n_current_observed = base::sum(!base::is.na(ms_v$current)),
        n_current = base::sum(ms_current), n_gpd = base::sum(ms_current & base::is.finite(ms_v$gpd_survey)),
        n_hed = base::sum(ms_current & !base::is.na(ms_v$hed)), n_eff = base::sum(ms_w)^2 / base::sum(ms_w^2),
        current_mean = ms_estimates[[1]][["mean"]], current_se = ms_estimates[[1]][["se"]],
        gpd_mean = ms_estimates[[2]][["mean"]], gpd_se = ms_estimates[[2]][["se"]],
        hed_mean = ms_estimates[[3]][["mean"]], hed_se = ms_estimates[[3]][["se"]],
        design_status = base::unique(ms_v$design_status), lonely_psu_adjustment_warnings = ms_lonely)
    }))
  }))
}
ms_targets <- ms_build_targets()
base::stopifnot(base::nrow(ms_targets) == 56L, !base::anyDuplicated(ms_targets[base::c("year", "sex", "age_group")]),
  base::all(base::is.finite(base::as.matrix(ms_targets[base::c("current_mean", "current_se", "gpd_mean", "gpd_se", "hed_mean", "hed_se")]))),
  base::all(ms_targets$current_mean > 0 & ms_targets$current_mean < 1), base::all(ms_targets$gpd_mean > 0),
  base::all(ms_targets$hed_mean >= 0 & ms_targets$hed_mean <= 1))
ms_table(ms_exposure_provenance)
ms_table(ms_data_audit)
ms_table(ms_targets[base::seq_len(8), ])
base::message(base::sprintf("Exposure inputs and design targets elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))

