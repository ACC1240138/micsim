#| label: ms-apc-audit
#| results: "hold"
.t0 <- Sys.time()
ms_legacy <- base::readRDS(acc_data("_enpg/data_binge_sensitivity.rds.tar.xz.enc"))
ms_apc_audit <- ms_legacy |>
  dplyr::group_by(year) |>
  dplyr::summarise(rows = dplyr::n(), volume_observed = base::sum(base::is.finite(volajohdia)),
    noncurrent_rows = base::sum(cvolaj %in% base::c("ltabs", "fd")),
    noncurrent_missing_volume = base::sum(cvolaj %in% base::c("ltabs", "fd") & !base::is.finite(volajohdia)),
    corrected_mean_among_finite = stats::weighted.mean(volajohdia[base::is.finite(volajohdia)],
      exp[base::is.finite(volajohdia)]), .groups = "drop")
ms_table(ms_apc_audit, "Legacy corrected-volume denominator audit; no APC correction applied here")
base::message(base::sprintf("ms-apc-audit elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))

