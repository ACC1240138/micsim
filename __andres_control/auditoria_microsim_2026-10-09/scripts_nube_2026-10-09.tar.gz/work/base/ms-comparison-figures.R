#| label: ms-comparison-figures
.t0 <- Sys.time()
ms_plot <- function(metric, title, y_label) {
  d <- ms_comparison[ms_comparison$metric == metric, ]
  d$age_band <- base::factor(d$age_group, levels = 1:4, labels = base::c("15-29", "30-44", "45-59", "60-65"))
  ggplot2::ggplot(d, ggplot2::aes(year)) +
    ggplot2::geom_vline(xintercept = 2020, linetype = 3, colour = "grey50") +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = observed - 1.96 * se, ymax = observed + 1.96 * se),
      data = d[d$year != 2020L, ], width = 0.15, colour = "grey50") +
    ggplot2::geom_point(ggplot2::aes(y = observed, colour = "ENPG"), size = 1.6) +
    ggplot2::geom_line(ggplot2::aes(y = simulated, colour = "Simulation"), linewidth = 0.6) +
    ggplot2::facet_grid(age_band ~ sex, scales = "free_y") +
    ggplot2::scale_colour_manual(values = base::c(ENPG = "#222222", Simulation = "#0072B2")) +
    ggplot2::labs(title = title, x = "Year", y = y_label, colour = NULL,
      caption = "Training through 2020; 2022/2024 held out. Bars: working-design 95% intervals, omitted for 2020.") +
    ggplot2::theme_minimal(base_size = 11) + ggplot2::theme(legend.position = "bottom")
}
ms_fig_prevalence <- ms_plot("current", "Past-30-day drinking prevalence", "Proportion")
ms_fig_intensity <- ms_plot("gpd", "Survey-scale intensity among current drinkers", "Grams/day")
ms_fig_hed <- ms_plot("hed", "HED among current drinkers: secondary diagnostic", "Proportion")
base::print(ms_fig_prevalence)
base::print(ms_fig_intensity)
base::print(ms_fig_hed)
base::message(base::sprintf("ms-comparison-figures elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))

