#| label: ms-full-refit-projection
.t0 <- Sys.time()
# Refit AFTER evaluating the frozen training model. This run has no remaining holdout.
ms_full_model <- ms_fit(ms_cfg$observed_end, trend = TRUE)
ms_full_run <- ms_simulate(ms_full_model, ms_cfg$start_year:ms_cfg$end_year,
  ms_cfg$n_sim, ms_cfg$seeds[1], ms_cfg$rho)
ms_refit_comparison <- dplyr::inner_join(ms_targets, ms_full_run$summary,
  by = base::c("year", "sex", "age_group"), suffix = base::c("_observed", "_simulated"))
base::stopifnot(base::nrow(ms_refit_comparison) == 56L)
ms_refit_metrics <- base::do.call(base::rbind, base::lapply(base::c("current", "gpd", "hed"), function(m) {
  error <- ms_refit_comparison[[base::paste0(m, "_mean_simulated")]] -
    ms_refit_comparison[[base::paste0(m, "_mean_observed")]]
  base::data.frame(metric = m, cells = base::length(error), bias = base::mean(error),
    rmse = base::sqrt(base::mean(error^2)), interpretation = "In-sample all-wave refit; one seed")
}))
ms_table(ms_refit_metrics, "All-wave historical refit diagnostics; not held-out validation")
ms_projection <- ms_full_run$summary |>
  dplyr::group_by(year) |>
  dplyr::summarise(current_prevalence = stats::weighted.mean(current_mean, population),
    gpd_population = stats::weighted.mean(gpd_population, population),
    population = base::sum(population),
    .groups = "drop") |>
  dplyr::mutate(period = base::ifelse(year <= 2024, "Historical refit", "Conditional projection"))
ms_projection <- dplyr::left_join(ms_projection, ms_full_run$deaths |>
  dplyr::group_by(year) |>
  dplyr::summarise(expected_deaths = base::sum(expected_deaths),
    realized_deaths = base::sum(deaths), .groups = "drop"), by = "year")
ms_terminal <- utils::tail(ms_full_run$flows, 1)
base::stopifnot(base::nrow(ms_projection) == 23L, !base::anyNA(ms_projection),
  base::abs(base::sum(ms_full_run$deaths$deaths) -
    base::sum(ms_full_run$flows$deaths * ms_full_run$flows$unit_weight)) < 1e-6,
  ms_terminal$end_definition == "Terminal-year survivors",
  ms_terminal$age_exits + ms_terminal$age_entries + ms_terminal$residual_inflow +
    ms_terminal$residual_outflow == 0)
ms_table(ms_projection, "All-wave refit and frozen-2024 exposure/mortality scenario with INE projected stocks")
ms_table(ms_full_run$flows, "Person accounting: unweighted synthetic counts, constant expansion weight")
# A few synthetic IDs demonstrate paths; these are generated people, not survey participants.
ms_table(utils::head(ms_full_run$histories, 24), "Illustrative synthetic trajectories; not observed person histories")
base::message(base::sprintf("ms-full-refit-projection elapsed minutes: %.2f",
  base::as.numeric(base::difftime(Sys.time(), .t0, units = "mins"))))

