.t0 <- Sys.time()
src <- readLines("<scratch>/work/run/proto_integration.R")
stop_at <- grep("^ms_mortality\\$year <- ", src)
src[grep("^for \\(f in", src)] <- "ms_path <- function(label) base::vapply(label, function(z) if (base::grepl(\"::\", z, fixed = TRUE)) { p <- base::strsplit(z, \"::\", fixed = TRUE)[[1L]]; acc_data(p[[1L]], p[[2L]]) } else if (base::grepl(\"\\\\.tar\\\\.xz\\\\.enc$\", z)) acc_data(z) else here_stub(z), base::character(1), USE.NAMES = FALSE); run_cell(\"ms-demography-inputs.R\")"
eval(parse(text = src[1:stop_at]))
obs <- stats::aggregate(deaths ~ year + sex, ms_mortality, sum)
old <- utils::read.csv("<repo>/__andres_control/microsim_recalib_outputs/mortality_concordance.csv")
m <- merge(obs, old[c("year", "sex", "observed_deaths")], by = c("year", "sex"))
m$diff <- m$deaths - m$observed_deaths
print(m, row.names = FALSE)
cat("total diff", sum(m$diff), "\n")
hmd_old <- utils::read.csv("<repo>/__andres_control/microsim_recalib_outputs/mortality_concordance.csv")
hm <- stats::aggregate(cbind(hmd = mx * pop_mid) ~ year + sex, ms_mortality, sum)
m2 <- merge(hm, hmd_old[c("year", "sex", "hmd_mx_expected")], by = c("year", "sex")); m2$diff <- m2$hmd - m2$hmd_mx_expected
print(head(m2, 6), row.names = FALSE)
message(sprintf("demo_check elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
