.t0 <- Sys.time()
# Re-run only: engine load + definitions + DEIS shares + RR link (sections A, defs, D, E) of proto_integration.R,
# then H (AAF after a simulated 2012-2024 history) and G (dual-arm BI, fixed once-per-year BI placement).
W <- "<scratch>/work"
src <- readLines(file.path(W, "run", "proto_integration.R"))
cut <- function(from, to) { a <- grep(from, src, fixed = TRUE)[1]; b <- grep(to, src, fixed = TRUE)[1] - 1L; stopifnot(!is.na(a), !is.na(b), b >= a); src[a:b] }
blk <- c(src[1:(grep('say("A2.', src, fixed = TRUE) - 1L)],
  cut("hed_bias <- function(run)", "base::print(base::round(hed_bias(base_run), 3))"),
  cut("# ================= PROPOSED CHANGES", "# ---------- B. HED recalibration"),
  cut("ms_simulate_verbatim <- ms_simulate", "hist_check <- function(lab)"),
  cut("# ---------- D. cause shares", "# ---------- F. compatibility"),
  cut("pif2 <- readRDS(", "compat <- function(lab)"),
  cut("# ---------- G. Monday deliverable", "base::message(base::sprintf(\"proto_integration elapsed"))
eval(parse(text = blk[seq_len(grep("# ---------- G. Monday deliverable", blk, fixed = TRUE) - 1L)]))
say("H. AAF after a SIMULATED 2012-2024 history (seed 2125, 25k): verbatim ever rule vs never stayers + trait")
aaf_sim <- function(lab) {
  r <- ms_simulate_dual(model, 2012:2024, 25000L, 2125L, 0.8, NULL)
  pop <- attr(r, "pop"); pop$age_group <- ms_age_group(pop$age)
  x <- do.call(rbind, ms_rel_risk(pop, 2024L, link, rr_scale = 0.9)$rr)
  a <- stats::aggregate(cbind(rr0, rr1) ~ cause + cell, x, mean)
  a$sex <- sub(" .*", "", a$cell); a$age_group <- as.integer(sub(".* ", "", a$cell))
  a$aaf_micro <- 1 - 1 / a$rr0; a$pif10_micro <- 1 - a$rr1 / a$rr0
  a <- merge(merge(a, aaf_long, by.x = c("cause", "sex", "age_group"), by.y = c("disease", "sex", "age_group")),
    pif2, by.x = c("cause", "sex", "age_group"), by.y = c("disease", "sex", "age_group"))
  st <- c(never = mean(pop$alc_status == "never"), former = mean(pop$alc_status == "former"))
  cat(lab, "| 2024 survivors never/former:", round(st, 3), "\n")
  a$spec <- lab; a[c("spec", "cause", "sex", "age_group", "aaf_micro", "aaf_expand_pif", "pif10_micro", "pif")]
}
ms_opt$hed_calibrate <- TRUE
h1 <- { ms_opt$never_fix <- FALSE; ms_opt$lambda <- 0; ms_opt$phi <- 0.8; aaf_sim("verbatim history") }
h2 <- { ms_opt$never_fix <- TRUE; ms_opt$lambda <- 0.45; ms_opt$phi <- 0.65; aaf_sim("never stayers + trait") }
print(rbind(h1, h2), digits = 3, row.names = FALSE)
saveRDS(rbind(h1, h2), file.path(W, "run", "aaf_simulated_history.rds"))
eval(parse(text = blk[grep("# ---------- G. Monday deliverable", blk, fixed = TRUE):length(blk)]))
say("G4. BI delivered per year vs target (weighted), mean over seeds")
print(as.data.frame(res |> dplyr::filter(scenario != "none", year %in% c(2025L, 2026L, 2030L, 2034L)) |>
  dplyr::group_by(n_sim, scenario, year) |> dplyr::summarise(bi_new = mean(bi_new), bi_active = mean(bi_active),
  gpd_control = mean(gpd_control), gpd_bi = mean(gpd_bi), hed_control = mean(hed_control), hed_bi = mean(hed_bi), .groups = "drop")), digits = 4, row.names = FALSE)
message(sprintf("proto2 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
