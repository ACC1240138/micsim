.t0 <- Sys.time()
# Scratch prototype (NOT a repo file): runs the verbatim recalib engine cells on real data, then the
# proposed minimal changes: HED intercept recalibration, never-drinker stayers + trait latent,
# dual-arm brief intervention with RR-scaled all-cause hazard, expand_pif compatibility checks.
base::invisible(base::Sys.setlocale("LC_CTYPE", "C.utf8"))
root <- "<repo>"; W <- "<scratch>/work"
base::setwd(root)
source(base::file.path(root, "_tools", "acc_data.R"))
here_stub <- function(...) base::file.path(root, ...)
# arrow is not installed in this sandbox: read the parquet columns through pyarrow into R's tempdir.
arrow_rp <- function(path, col_select) {
  out <- base::tempfile(fileext = ".csv")
  py <- base::sprintf("import pyarrow.parquet as pq; pq.read_table('%s', columns=[%s]).to_pandas().to_csv('%s', index=False)",
    path, base::paste0("'", col_select, "'", collapse = ","), out)
  base::stopifnot(base::system2("python3", base::c("-I", "-c", base::shQuote(py))) == 0L)
  utils::read.csv(out, stringsAsFactors = FALSE)
}
ms_table <- function(x, caption = NULL) base::invisible(NULL)
ms_cfg <- base::list(start_year = 2012L, train_end = 2020L, observed_end = 2024L, end_year = 2034L,
  min_age = 15L, max_age = 65L, n_sim = 25000L, seeds = 2125L + 0:4, rho = 0.8,
  cutoffs = base::c(2016L, 2018L, 2020L, 2022L),
  specs = base::c("static2012", "interp_hold", "linear_all", "spline_shared"), export = FALSE)
run_cell <- function(f) {
  s <- base::readLines(base::file.path(W, "recal", f), encoding = "UTF-8")
  s <- base::gsub("here::here(", "here_stub(", s, fixed = TRUE)
  s <- base::gsub("arrow::read_parquet(", "arrow_rp(", s, fixed = TRUE)
  base::eval(base::parse(text = s, encoding = "UTF-8"), envir = base::globalenv())
}
for (f in base::c("ms-survey-inputs.R", "ms-demography-inputs.R", "ms-calibration-functions.R", "ms-annual-engine.R")) run_cell(f)
ms_mortality$year <- base::as.integer(ms_mortality$year); ms_mortality$age <- base::as.integer(ms_mortality$age)

say <- function(...) base::cat("\n####", ..., "\n")
model <- ms_fit(2024L, "interp_hold")
say("A. Replication: reconstruction multipliers (notebook reports F 0.970 / M 0.945)")
base::print(base::round(model$mortality_scale, 4))

# ---------- verbatim engine run, one seed, for later identity checks ----------
base_run <- ms_simulate(model, 2012:2024, ms_cfg$n_sim, 2125L, 0.8)
say("A2. Verbatim engine, seed 2125: 2024 never/former/current (pop-weighted) and HED bias vs targets")
l24 <- base_run$summary[base_run$summary$year == 2024L, ]
base::print(base::round(base::c(never = stats::weighted.mean(l24$never, l24$n), former = stats::weighted.mean(l24$former, l24$n),
  current = stats::weighted.mean(l24$current_mean, l24$n)), 4))
hed_bias <- function(run) {
  m <- base::merge(run$summary, ms_targets, by = base::c("year", "sex", "age_group"), suffixes = base::c("_sim", "_obs"))
  base::c(hed_bias_pp = 100 * base::mean(m$hed_mean_sim - m$hed_mean_obs),
    hed_rmse_pp = 100 * base::sqrt(base::mean((m$hed_mean_sim - m$hed_mean_obs)^2)),
    cur_rmse_pp = 100 * base::sqrt(base::mean((m$current_mean_sim - m$current_mean_obs)^2)),
    gpd_rmse = base::sqrt(base::mean((m$gpd_mean_sim - m$gpd_mean_obs)^2)))
}
base::print(base::round(hed_bias(base_run), 3))

# ================= PROPOSED CHANGES (sketch under test) =================
ms_opt <- base::list(hed_calibrate = FALSE, never_fix = FALSE, lambda = 0, phi = 0.8)
# --- logit-interpolated cell targets (same rule as interp_hold) for HED and never share ---
ms_interp_target <- function(tab, value, years) {
  g <- base::expand.grid(year = years, sex = base::c("female", "male"), age_group = 1:4, stringsAsFactors = FALSE)
  g$value <- NA_real_
  for (s in base::c("female", "male")) for (a in 1:4) {
    t <- tab[tab$sex == s & tab$age_group == a, ]; k <- g$sex == s & g$age_group == a
    g$value[k] <- stats::plogis(stats::approx(t$year, stats::qlogis(t[[value]]), xout = g$year[k], rule = 2)$y)
  }
  g$key <- base::paste(g$year, g$sex, g$age_group, sep = ":"); g
}
never_tab <- base::do.call(base::rbind, base::lapply(base::split(ms_enpg[ms_enpg$status != "unknown", ],
  ~ year + sex + age_group, drop = TRUE), function(d) base::data.frame(year = d$year[1], sex = d$sex[1],
  age_group = d$age_group[1], p_never = stats::weighted.mean(d$status == "never", d$weight))))
# --- CHANGE in ms_drivers: HED intercept offset solved so that E_Gamma[p_hed] hits the ENPG HED margin; p_never column ---
ms_drivers_verbatim <- ms_drivers
ms_drivers <- function(model, years) {
  g <- ms_drivers_verbatim(model, years)
  g$p_never <- ms_interp_target(never_tab, "p_never", years)$value[base::match(g$key, ms_interp_target(never_tab, "p_never", years)$key)]
  if (ms_opt$hed_calibrate) {
    h <- ms_interp_target(ms_targets[ms_targets$year <= model$last_year, ], "hed_mean", years)
    tgt <- h$value[base::match(g$key, h$key)]
    g$hed_intercept <- g$hed_intercept + base::vapply(base::seq_len(base::nrow(g)), function(i) {
      sc <- g$mu_current[i] / ((1 - g$p_zero[i]) * g$shape[i])
      e_hed <- function(dl) (1 - g$p_zero[i]) * stats::integrate(function(x) stats::dgamma(x, g$shape[i], scale = sc) *
        stats::plogis(g$hed_intercept[i] + dl + g$hed_slope[i] * base::log1p(x)), 0, Inf)$value
      stats::uniroot(function(dl) e_hed(dl) - tgt[i], base::c(-5, 5), tol = 1e-8)$root
    }, base::numeric(1))
  }
  g
}
ms_new_people <- function(sex, age, n, first_id) {
  base::data.frame(id = first_id + base::seq_len(n), sex = sex, age = age,
    z_current = stats::rnorm(n), z_amount = stats::rnorm(n), z_hed = stats::rnorm(n),
    trait_current = stats::rnorm(n), u_never = stats::runif(n),          # CHANGE item 1
    bi_year = NA_integer_, ever = base::rep(NA, n), stringsAsFactors = FALSE)  # CHANGE item 4
}
ms_exposure_verbatim <- ms_exposure
ms_exposure <- function(pop, year, drivers) {
  if (!ms_opt$never_fix && ms_opt$lambda == 0) return(ms_exposure_verbatim(pop, year, drivers))
  pop$age_group <- ms_age_group(pop$age)
  k <- base::match(base::paste(year, pop$sex, pop$age_group, sep = ":"), drivers$key)
  base::stopifnot(!base::anyNA(k)); d <- drivers[k, ]
  zc <- base::sqrt(ms_opt$lambda) * pop$trait_current + base::sqrt(1 - ms_opt$lambda) * pop$z_current
  if (ms_opt$never_fix) {
    # Never-drinkers are stayers: a person stays never while their fixed rank is below the cell's ENPG never share.
    was_never <- base::is.na(pop$ever) | !pop$ever
    pop$ever <- !(was_never & pop$u_never < d$p_never)
    ever_share <- stats::ave(base::as.numeric(pop$ever), pop$sex, pop$age_group)
    pop$current <- pop$ever & stats::pnorm(zc) < base::pmin(1, d$p_current / ever_share)
  } else {
    pop$current <- stats::pnorm(zc) < d$p_current
  }
  u <- stats::pnorm(pop$z_amount); positive <- pop$current & u > d$p_zero
  pop$gpd_survey <- 0
  pop$gpd_survey[positive] <- stats::qgamma(base::pmin(1 - 1e-12, base::pmax(1e-12,
    (u[positive] - d$p_zero[positive]) / (1 - d$p_zero[positive]))), shape = d$shape[positive],
    scale = d$mu_current[positive] / ((1 - d$p_zero[positive]) * d$shape[positive]))
  pop$hed <- positive & stats::pnorm(pop$z_hed) < stats::plogis(d$hed_intercept + d$hed_slope * base::log1p(pop$gpd_survey))
  if (!ms_opt$never_fix) {
    fresh <- base::is.na(pop$ever)
    pop$ever[fresh] <- pop$current[fresh] | stats::runif(base::sum(fresh)) < d$p_ever_noncurrent[fresh]
    pop$ever <- pop$ever | pop$current
  }
  pop$alc_status <- base::ifelse(pop$current, "current", base::ifelse(pop$ever, "former", "never"))
  low <- base::ifelse(pop$sex == "female", 20, 40); high <- base::ifelse(pop$sex == "female", 40, 60)
  pop$alc_cat <- base::ifelse(!pop$current, "noncurrent", base::ifelse(pop$gpd_survey < low, "cat1",
    base::ifelse(pop$gpd_survey < high, "cat2", "cat3")))
  base::stopifnot(!base::any(pop$hed & !pop$current), !base::any(pop$current & !pop$ever))
  pop
}

# ---------- B. HED recalibration test (3 seeds, reconstruction) ----------
say("B. HED margin: verbatim vs intercept-offset recalibration (seeds 2125-2127, 2012-2024)")
for (cal in base::c(FALSE, TRUE)) {
  ms_opt$hed_calibrate <- cal
  r <- base::sapply(2125:2127, function(s) hed_bias(ms_simulate(model, 2012:2024, ms_cfg$n_sim, s, 0.8)))
  base::cat("hed_calibrate =", cal, "\n"); base::print(base::round(base::rowMeans(r), 3))
}

# ---------- C. never-drinker stayers and trait + AR(1) ----------
say("C. Synthetic history: 2024 never/former/current and annual status change (seed 2125)")
ms_simulate_verbatim <- ms_simulate
# CHANGE in ms_simulate: separate carry-over for z_current (phi) vs z_amount/z_hed (rho). Text patch of the verbatim body.
ms_body <- base::deparse(base::body(ms_simulate_verbatim), width.cutoff = 500L)
ms_body <- base::sub("pop[[z]] <- rho * pop[[z]] + base::sqrt(1 - rho^2) * stats::rnorm(transition_n)",
  "pop[[z]] <- rho_z[[z]] * pop[[z]] + base::sqrt(1 - rho_z[[z]]^2) * stats::rnorm(transition_n)", ms_body, fixed = TRUE)
base::stopifnot(base::any(base::grepl("rho_z[[z]]", ms_body, fixed = TRUE)))
ms_simulate <- ms_simulate_verbatim
base::body(ms_simulate) <- base::parse(text = base::c("{", "rho_z <- base::c(z_current = ms_opt$phi, z_amount = rho, z_hed = rho)", ms_body, "}"))[[1]]
hist_check <- function(lab) {
  r <- ms_simulate(model, 2012:2024, ms_cfg$n_sim, 2125L, 0.8)
  l <- r$summary[r$summary$year == 2024L, ]
  m <- base::merge(r$summary, ms_targets, by = base::c("year", "sex", "age_group"), suffixes = base::c("_sim", "_obs"))
  base::data.frame(spec = lab, never_2024 = stats::weighted.mean(l$never, l$n), former_2024 = stats::weighted.mean(l$former, l$n),
    current_2024 = stats::weighted.mean(l$current_mean, l$n),
    status_change = base::sum(r$flows$status_changes) / base::sum(r$flows$transition_n),
    cur_rmse_pp = 100 * base::sqrt(base::mean((m$current_mean_sim - m$current_mean_obs)^2)))
}
ms_opt$hed_calibrate <- TRUE
hc <- base::rbind(
  { ms_opt$never_fix <- FALSE; ms_opt$lambda <- 0; ms_opt$phi <- 0.8; hist_check("verbatim AR1 rho .8") },
  { ms_opt$lambda <- 0.45; ms_opt$phi <- 0.65; hist_check("trait .45 + AR1 .65") },
  { ms_opt$never_fix <- TRUE; ms_opt$lambda <- 0; ms_opt$phi <- 0.8; hist_check("never stayers + AR1 .8") },
  { ms_opt$lambda <- 0.45; ms_opt$phi <- 0.65; hist_check("never stayers + trait .45/.65") })
base::print(hc, digits = 3, row.names = FALSE)
base::cat("ENPG 2024 observed (15-65, weighted): never 0.258, former 0.383, current 0.359\n")

# ---------- D. cause shares from DEIS (Liver Cirrhosis, Road Injuries) ----------
icd <- base::readLines(base::file.path(root, "__andres_control", "ypll_icd_defs.R"))
base::eval(base::parse(text = icd[40:98]))   # ICD helpers and code lists only (no path side effects)
d12 <- arrow_rp(acc_data("_deis/DEFUNCIONES_DEIS_2012_2023_15plus.tar.xz.enc"), base::c("year", "gender", "age", "diag1", "diag2"))
d24 <- acc_deis()
d24 <- d24[d24[[1]] == 2024L & d24$EDAD_TIPO == 1L, base::c(1, base::match(base::c("SEXO_NOMBRE", "EDAD_CANT", "DIAG1", "DIAG2"), base::names(d24)))]
base::names(d24) <- base::c("year", "gender", "age", "diag1", "diag2")
dd <- base::rbind(d12, d24)
dd$year <- base::as.integer(dd$year); dd$age <- base::as.integer(dd$age)
dd <- dd[dd$year %in% 2012:2024 & dd$age %in% 15:65 & dd$gender %in% base::c("Hombre", "Mujer"), ]
dd$sex <- base::ifelse(dd$gender == "Hombre", "male", "female"); dd$age_group <- ms_age_group(dd$age)
d1 <- clean_icd10(dd$diag1); d2 <- clean_icd10(dd$diag2)
dd$lc <- d1 %in% lc_codes
dd$ri <- (d1 %in% ri_codes | d2 %in% ri_codes) & !dd$lc   # injury DIAG1|DIAG2 rule; made exclusive of LC for the hazard split
base::stopifnot(base::sum(dd$year <= 2024) == base::sum(ms_mortality$deaths))
share <- stats::aggregate(base::cbind(lc, ri, all = 1) ~ year + sex + age_group, dd, base::sum)
share$`Liver Cirrhosis` <- share$lc / share$all; share$`Road Injuries` <- share$ri / share$all
share$key <- base::paste(share$year, base::paste(share$sex, share$age_group))
say("D. DEIS cause shares 2024 (15-65 all-cause = denominator)")
base::print(share[share$year == 2024L, base::c("sex", "age_group", "all", "lc", "ri")], row.names = FALSE)

# ---------- E. RR records and the alcohol link ----------
source(base::file.path(root, "__andres_control", "rr_registry_adam.R"))
reg_g <- load_adam_rr_registry("general", control_dir = base::file.path(root, "__andres_control"), verbose = FALSE)
reg_i <- load_adam_rr_registry("injuries", control_dir = base::file.path(root, "__andres_control"), verbose = FALSE)
pick <- function(reg, disease, sex) { r <- base::Filter(function(z) z$pipeline_disease == disease && z$sex == sex, reg); base::stopifnot(base::length(r) == 1L); r[[1]] }
oms <- utils::read.csv(base::file.path(root, "__andres_control", "oms_factor_by_year.csv"))
link <- base::list(
  records = base::list(`Liver Cirrhosis` = base::list(female = pick(reg_g, "Liver Cirrhosis", "female"), male = pick(reg_g, "Liver Cirrhosis", "male")),
                       `Road Injuries` = base::list(female = pick(reg_i, "Road Injuries", "female"), male = pick(reg_i, "Road Injuries", "male"))),
  # Survey-to-risk scale (expand_pif V1, 12 g/drink): odd years take the previous wave; >2024 holds 2024.
  factor = stats::setNames(oms$factor_CH[base::findInterval(2012:2034, oms$year)], 2012:2034),
  share = share)
ms_rr <- function(rec, status, g, hed) {
  rr <- base::rep(1, base::length(g))
  rr[status == "former"] <- base::exp(rec$lnRRFormer)
  cur <- status == "current"
  nh <- cur & !hed; if (base::any(nh)) rr[nh] <- rec$RRCurrent(g[nh], rec$betaCurrent)
  h <- cur & hed
  if (base::any(h)) rr[h] <- if (base::is.null(rec$RRCurrent_binge)) rec$RRCurrent(g[h], rec$betaCurrent) else
    rec$RRCurrent_binge(g[h], rec$betaCurrent_binge)
  rr
}
# Person-level all-cause hazard multiplier. rel0 averages exactly 1 within sex x age group (control arm keeps the
# DEIS-calibrated level); the BI arm reuses the CONTROL normaliser, otherwise its benefit is normalised away.
ms_rel_risk <- function(pop, year, link, gpd1 = pop$gpd_survey, hed1 = pop$hed, rr_scale = 1) {
  y <- base::as.character(base::min(year, 2024L)); f <- link$factor[[base::as.character(year)]]
  cell <- base::paste(pop$sex, pop$age_group)
  rel0 <- rel1 <- base::rep(1, base::nrow(pop)); out <- base::list()
  for (cz in base::names(link$records)) {
    rr0 <- rr1 <- base::rep(1, base::nrow(pop))
    for (sx in base::c("female", "male")) {
      i <- pop$sex == sx; rec <- link$records[[cz]][[sx]]
      rr0[i] <- ms_rr(rec, pop$alc_status[i], base::pmin(150, pop$gpd_survey[i] * f), pop$hed[i])
      rr1[i] <- ms_rr(rec, pop$alc_status[i], base::pmin(150, gpd1[i] * f * rr_scale), hed1[i])
    }
    rrbar <- stats::ave(rr0, cell)
    s <- link$share[[cz]][base::match(base::paste(y, cell), link$share$key)]
    base::stopifnot(!base::anyNA(s))
    rel0 <- rel0 + s * (rr0 / rrbar - 1); rel1 <- rel1 + s * (rr1 / rrbar - 1)
    out[[cz]] <- base::data.frame(cause = cz, cell = cell, rr0 = rr0, rr1 = rr1)
  }
  base::stopifnot(base::max(base::abs(stats::ave(rel0, cell) - 1)) < 1e-10)
  base::list(rel0 = rel0, rel1 = rel1, rr = out)
}
# Brief intervention (incremental recipients only, Lemp 2026 logic): eligibility on the RISK scale, Sheffield-type
# proportional effect with linear decay; HED responds only through the calibrated volume link.
ms_bi <- function(pop, year, drivers, bi, unit_weight) {
  u <- stats::runif(base::nrow(pop))                         # drawn every year in every run: keeps RNG streams aligned
  pop$gpd1 <- pop$gpd_survey; pop$hed1 <- pop$hed
  if (base::is.null(bi)) return(pop)
  g_risk <- pop$gpd_survey * link$factor[[base::as.character(year)]]
  eligible <- pop$current & g_risk > base::ifelse(pop$sex == "female", 20, 40)
  p <- if (year >= bi$start) base::min(1, bi$n_target / (base::sum(eligible) * unit_weight)) else 0
  new <- eligible & u < p & (base::is.na(pop$bi_year) | year - pop$bi_year >= bi$repeat_after)
  pop$bi_year[new] <- year
  tau <- year - pop$bi_year
  m <- base::ifelse(base::is.na(tau), 1, 1 - bi$effect * base::pmax(0, 1 - tau / bi$duration))
  pop$gpd1 <- pop$gpd_survey * m
  k <- base::match(base::paste(year, pop$sex, pop$age_group, sep = ":"), drivers$key)
  pop$hed1 <- pop$hed & stats::pnorm(pop$z_hed) < stats::plogis(drivers$hed_intercept[k] + drivers$hed_slope[k] * base::log1p(pop$gpd1))
  pop$bi_new <- new
  pop
}
# Dual-arm annual engine: copy of ms_simulate with the three hooks marked CHANGE. One population, one survival path
# (deaths drawn from the CONTROL hazard), two expected-death columns: avoided = E0 - E1 with no death-draw noise.
ms_simulate_dual <- function(model, years, n_sim, seed, rho = 0.8, bi = NULL) {
  base::set.seed(seed)
  rho_z <- base::c(z_current = ms_opt$phi, z_amount = rho, z_hed = rho)
  drivers <- ms_drivers(model, years)
  stocks <- ms_population[ms_population$year %in% years, ]
  unit_weight <- base::sum(stocks$pop_jan[stocks$year == years[1]]) / n_sim
  stocks$n_target <- base::as.integer(base::round(stocks$pop_jan / unit_weight))
  initial <- stocks[stocks$year == years[1], ]
  ids <- base::c(0L, base::cumsum(initial$n_target))
  pop <- dplyr::bind_rows(base::lapply(base::seq_len(base::nrow(initial)), function(i)
    ms_new_people(initial$sex[i], initial$age[i], initial$n_target[i], ids[i])))
  last_id <- base::max(pop$id)
  pop <- ms_bi(ms_exposure(pop, years[1], drivers), years[1], drivers, bi, unit_weight)   # CHANGE: BI after exposure
  mortality <- ms_mortality; mortality$key <- base::paste(mortality$year, mortality$sex, mortality$age, sep = ":")
  out <- base::vector("list", base::length(years))
  for (i in base::seq_along(years)) {
    year <- years[i]; start_n <- base::nrow(pop)
    k <- base::match(base::paste(base::min(year, ms_cfg$observed_end), pop$sex, pop$age, sep = ":"), mortality$key)
    log_s <- base::log1p(-mortality$qx[k]) * model$mortality_scale[pop$sex]
    rr <- ms_rel_risk(pop, year, link, pop$gpd1, pop$hed1)                                   # CHANGE: alcohol link
    q0 <- -base::expm1(log_s * rr$rel0); q1 <- -base::expm1(log_s * rr$rel1); q_old <- -base::expm1(log_s)
    dead <- stats::runif(start_n) < q0
    out[[i]] <- base::data.frame(year = year, seed = seed, n = start_n, unit_weight = unit_weight,
      expected_verbatim = base::sum(q_old) * unit_weight, expected_control = base::sum(q0) * unit_weight,
      expected_bi = base::sum(q1) * unit_weight, realized = base::sum(dead) * unit_weight,
      mc_sd_realized = base::sqrt(base::sum(q0 * (1 - q0))) * unit_weight,
      bi_new = base::sum(pop$bi_new %in% TRUE) * unit_weight, bi_active = base::sum(!base::is.na(pop$bi_year) & year - pop$bi_year < 7) * unit_weight,
      eligible = base::sum(pop$current & pop$gpd_survey * link$factor[[base::as.character(year)]] > base::ifelse(pop$sex == "female", 20, 40)) * unit_weight,
      gpd_control = base::mean(pop$gpd_survey[pop$current]), gpd_bi = base::mean(pop$gpd1[pop$current]),
      hed_control = base::mean(pop$hed[pop$current]), hed_bi = base::mean(pop$hed1[pop$current]))
    pop <- pop[!dead, ]
    if (i < base::length(years)) {
      pop$age <- pop$age + 1L
      pop <- pop[pop$age <= ms_cfg$max_age, ]
      next_stock <- stocks[stocks$year == year + 1L, ]
      keep <- base::rep(TRUE, base::nrow(pop)); additions <- base::vector("list", base::nrow(next_stock))
      for (j in base::seq_len(base::nrow(next_stock))) {
        ix <- base::which(pop$sex == next_stock$sex[j] & pop$age == next_stock$age[j])
        delta <- next_stock$n_target[j] - base::length(ix)
        if (delta < 0) keep[ix[base::sample.int(base::length(ix), -delta)]] <- FALSE else if (delta > 0) {
          additions[[j]] <- ms_new_people(next_stock$sex[j], next_stock$age[j], delta, last_id); last_id <- last_id + delta }
      }
      pop <- pop[keep, ]
      for (z in base::c("z_current", "z_amount", "z_hed"))
        pop[[z]] <- rho_z[[z]] * pop[[z]] + base::sqrt(1 - rho_z[[z]]^2) * stats::rnorm(base::nrow(pop))
      pop <- ms_exposure(pop, year + 1L, drivers)
      new <- dplyr::bind_rows(additions)
      if (base::nrow(new)) pop <- dplyr::bind_rows(pop, ms_exposure(new, year + 1L, drivers))
      pop <- ms_bi(pop, year + 1L, drivers, bi, unit_weight)   # CHANGE: once per year on the reconciled population
    }
  }
  res <- dplyr::bind_rows(out); base::attr(res, "pop") <- pop; res
}

# ---------- F. compatibility with expand_pif (2024 cells): AAF and volume -10% PIF ----------
say("F. expand_pif compatibility, 2024 cells, seed 2125, n 100k (history spec as labelled)")
pif2 <- readRDS(base::file.path(root, "__andres_control", "pif2_pif_results_full_20261008.rds"))
pif2 <- pif2[pif2$year == 2024 & pif2$scenario_id == "volume_reduction_10" & pif2$disease %in% base::names(link$records),
  base::c("disease", "sex", "age_group", "pif")]
aaf_tab <- utils::read.csv(base::file.path(root, "__andres_control", "tabla_aaf_who2024_sexo_causa_ano.csv"), check.names = FALSE)
aaf_tab <- aaf_tab[aaf_tab$Year == 2024 & aaf_tab$Cause %in% base::names(link$records), ]
aaf_long <- base::do.call(base::rbind, base::lapply(base::names(aaf_tab)[-(1:2)], function(cn) base::data.frame(
  disease = aaf_tab$Cause, sex = base::ifelse(base::grepl("^Women", cn), "female", "male"),
  age_group = base::match(base::sub("^(Women|Men) ", "", cn), base::c("15-29", "30-44", "45-59", "60-65")),
  aaf_expand_pif = base::as.numeric(base::sub(" .*", "", aaf_tab[[cn]])))))
compat <- function(lab) {
  base::set.seed(2125L)
  dr <- ms_drivers(model, 2012:2024)
  stocks <- ms_population[ms_population$year == 2024L, ]
  pop <- dplyr::bind_rows(base::lapply(base::seq_len(base::nrow(stocks)), function(i)
    ms_new_people(stocks$sex[i], stocks$age[i], base::round(stocks$pop_jan[i] / base::sum(stocks$pop_jan) * 1e5), 1e6 * i)))
  pop <- ms_exposure(pop, 2024L, dr)
  r <- ms_rel_risk(pop, 2024L, link, rr_scale = 0.9)
  x <- base::do.call(base::rbind, r$rr)
  a <- stats::aggregate(base::cbind(rr0, rr1) ~ cause + cell, x, base::mean)
  a$sex <- base::sub(" .*", "", a$cell); a$age_group <- base::as.integer(base::sub(".* ", "", a$cell))
  a$aaf_micro <- 1 - 1 / a$rr0; a$pif10_micro <- 1 - a$rr1 / a$rr0
  a <- base::merge(a, aaf_long, by.x = base::c("cause", "sex", "age_group"), by.y = base::c("disease", "sex", "age_group"))
  a <- base::merge(a, pif2, by.x = base::c("cause", "sex", "age_group"), by.y = base::c("disease", "sex", "age_group"))
  base::names(a)[base::names(a) == "pif"] <- "pif10_expand_pif"
  a$spec <- lab
  a[base::c("spec", "cause", "sex", "age_group", "aaf_micro", "aaf_expand_pif", "pif10_micro", "pif10_expand_pif")]
}
ms_opt$never_fix <- FALSE; ms_opt$lambda <- 0; ms_opt$phi <- 0.8
cp <- base::rbind(compat("fresh 2024 pop, engine ever rule"), { ms_opt$never_fix <- TRUE; compat("fresh 2024 pop, never stayers") })
base::print(cp, digits = 3, row.names = FALSE)
base::saveRDS(cp, base::file.path(W, "run", "compat.rds"))

# ---------- G. Monday deliverable: dual-arm runs 2024-2034 ----------
say("G. Dual-arm BI runs, 2024-2034, never stayers + trait .45/.65 + HED calibrated, 5 seeds")
ms_opt$never_fix <- TRUE; ms_opt$lambda <- 0.45; ms_opt$phi <- 0.65; ms_opt$hed_calibrate <- TRUE
bi_sq <- base::list(start = 2025L, n_target = 35000, effect = 0.123, duration = 7, repeat_after = 7)
bi_x10 <- utils::modifyList(bi_sq, base::list(n_target = 350000))
res <- base::list()
for (n in base::c(25000L, 100000L)) for (sc in base::c("none", "sq35k", "x10_350k")) for (s in 2125:2129) {
  b <- base::switch(sc, none = NULL, sq35k = bi_sq, x10_350k = bi_x10)
  r <- ms_simulate_dual(model, 2024:2034, n, s, 0.8, b); r$scenario <- sc; r$n_sim <- n
  res[[base::length(res) + 1L]] <- r
}
res <- dplyr::bind_rows(res); res$avoided <- res$expected_control - res$expected_bi
base::saveRDS(res, base::file.path(W, "run", "dual_runs.rds"))
tab <- res |> dplyr::group_by(n_sim, scenario, year) |>
  dplyr::summarise(sd_expected_control_seed = stats::sd(expected_control), expected_control = base::mean(expected_control),
    expected_verbatim = base::mean(expected_verbatim), mc_sd_realized = base::mean(mc_sd_realized),
    avoided_mean = base::mean(avoided), avoided_sd_seed = stats::sd(avoided), bi_new = base::mean(bi_new),
    eligible = base::mean(eligible), .groups = "drop")
base::print(as.data.frame(tab[tab$year %in% base::c(2024L, 2025L, 2029L, 2034L), ]), digits = 4, row.names = FALSE)
cum <- res |> dplyr::filter(year >= 2025L) |> dplyr::group_by(n_sim, scenario, seed) |>
  dplyr::summarise(avoided_2025_2034 = base::sum(avoided), .groups = "drop") |> dplyr::group_by(n_sim, scenario) |>
  dplyr::summarise(mean = base::mean(avoided_2025_2034), sd_seed = stats::sd(avoided_2025_2034), .groups = "drop")
say("G2. Cumulative expected deaths avoided 2025-2034 (2 causes only: liver cirrhosis + road injuries)")
base::print(as.data.frame(cum), digits = 4, row.names = FALSE)
say("G3. Null check: scenario none must give avoided == 0 exactly")
base::print(base::range(res$avoided[res$scenario == "none"]))
base::message(base::sprintf("proto_integration elapsed minutes: %.2f", base::as.numeric(base::difftime(base::Sys.time(), .t0, units = "mins"))))
