.t0 <- Sys.time()
root <- "<repo>"; setwd(root)
source(file.path(root, "_tools", "acc_data.R"))
here_stub <- function(...) file.path(root, ...)
ms_cfg <- list(start_year = 2012L, min_age = 15L, max_age = 65L)
ms_table <- function(x, caption = NULL) invisible(NULL)
src <- readLines("<scratch>/work/recal/ms-survey-inputs.R")
eval(parse(text = gsub("here::here(", "here_stub(", src, fixed = TRUE)))
k <- ms_enpg$status != "unknown"
s <- ms_enpg[k, ]
out <- do.call(rbind, lapply(split(s, s$year), function(d) data.frame(year = d$year[1],
  never = weighted.mean(d$status == "never", d$weight), former = weighted.mean(d$status == "former", d$weight),
  current = weighted.mean(d$status == "current", d$weight))))
print(out, digits = 3, row.names = FALSE)
# 2024 by sex x age group
d <- s[s$year == 2024, ]
print(aggregate(cbind(never = status == "never", former = status == "former") ~ sex + age_group, d,
  FUN = mean), digits = 3)
print(do.call(rbind, lapply(split(d, list(d$sex, d$age_group)), function(z) data.frame(sex = z$sex[1], ag = z$age_group[1],
  never_w = weighted.mean(z$status == "never", z$weight), former_w = weighted.mean(z$status == "former", z$weight)))), digits = 3, row.names = FALSE)
message(sprintf("never_share elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
