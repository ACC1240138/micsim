.t0 <- Sys.time()
# Test: does expand_pif's truncation of the exposure density to [0.1, 150] g/day explain the LC PIF gap?
W <- "<scratch>/work"
p2 <- readLines(file.path(W, "run", "proto2.R"))
eval(parse(text = p2[1:(grep("^eval\\(parse\\(text = blk\\[seq_len", p2) - 1L)]))
eval(parse(text = blk[seq_len(grep("# ---------- G. Monday deliverable", blk, fixed = TRUE) - 1L)]))
ms_opt$hed_calibrate <- TRUE; ms_opt$never_fix <- TRUE; ms_opt$lambda <- 0; ms_opt$phi <- 0.8
set.seed(2125L)
dr <- ms_drivers(model, 2012:2024)
stocks <- ms_population[ms_population$year == 2024L, ]
pop <- dplyr::bind_rows(lapply(seq_len(nrow(stocks)), function(i)
  ms_new_people(stocks$sex[i], stocks$age[i], round(stocks$pop_jan[i] / sum(stocks$pop_jan) * 2e5), 1e6 * i)))
pop <- ms_exposure(pop, 2024L, dr)
g <- pop$gpd_survey * link$factor[["2024"]]
cat("share of current drinkers above 150 g/day (risk scale), by sex:\n"); print(tapply(g[pop$current] > 150, pop$sex[pop$current], mean))
res <- lapply(c(cap = FALSE, truncate = TRUE), function(trunc) {
  keep <- if (trunc) !(pop$current & (g > 150 | g < 0.1)) else rep(TRUE, nrow(pop))
  x <- do.call(rbind, ms_rel_risk(pop[keep, ], 2024L, link, rr_scale = 0.9)$rr)
  a <- stats::aggregate(cbind(rr0, rr1) ~ cause + cell, x, mean)
  a$pif10 <- 1 - a$rr1 / a$rr0; a$aaf <- 1 - 1 / a$rr0; a
})
out <- merge(res$cap[c("cause", "cell", "aaf", "pif10")], res$truncate[c("cause", "cell", "aaf", "pif10")], by = c("cause", "cell"), suffixes = c("_cap150", "_trunc150"))
out$sex <- sub(" .*", "", out$cell); out$age_group <- as.integer(sub(".* ", "", out$cell))
out <- merge(merge(out, aaf_long, by.x = c("cause", "sex", "age_group"), by.y = c("disease", "sex", "age_group")), pif2, by.x = c("cause", "sex", "age_group"), by.y = c("disease", "sex", "age_group"))
print(out[c("cause", "sex", "age_group", "aaf_cap150", "aaf_trunc150", "aaf_expand_pif", "pif10_cap150", "pif10_trunc150", "pif")], digits = 3, row.names = FALSE)
saveRDS(out, file.path(W, "run", "compat_trunc.rds"))
message(sprintf("proto3 elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
