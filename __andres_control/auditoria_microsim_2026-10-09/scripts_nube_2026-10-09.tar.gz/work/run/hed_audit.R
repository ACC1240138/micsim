.t0 <- Sys.time()
# Scratch audit: reproduces ms-survey-inputs verbatim (sourced from extracted cell) and decomposes the HED reconstruction bias.
root <- "<repo>"
setwd(root)
source(file.path(root, "_tools", "acc_data.R"))
here_stub <- function(...) file.path(root, ...)
ms_cfg <- list(start_year = 2012L, min_age = 15L, max_age = 65L)
ms_table <- function(x, caption = NULL) invisible(NULL)
src <- readLines("<scratch>/work/recal/ms-survey-inputs.R")
src <- gsub("here::here(", "here_stub(", src, fixed = TRUE)
eval(parse(text = src))
cat("targets rows", nrow(ms_targets), "\n")
e <- ms_enpg
cur <- e$current %in% 1
cat("\n== Current drinkers by gpd status and HED observed (all waves, weighted) ==\n")
grp <- ifelse(!cur, NA, ifelse(is.na(e$gpd_survey), "gpd_NA", ifelse(e$gpd_survey == 0, "gpd_0", "gpd_pos")))
tab <- do.call(rbind, lapply(split(seq_len(nrow(e))[cur], list(e$year[cur], grp[cur])), function(ix) {
  if (!length(ix)) return(NULL)
  h <- !is.na(e$hed[ix])
  data.frame(year = e$year[ix[1]], grp = grp[ix[1]], n = length(ix), n_hed_obs = sum(h),
    w_share = sum(e$weight[ix]), hed_w = if (any(h)) weighted.mean(e$hed[ix][h], e$weight[ix][h]) else NA)
}))
tot <- tapply(tab$w_share, tab$year, sum); tab$w_share <- tab$w_share / tot[as.character(tab$year)]
print(tab[order(tab$year, tab$grp), ], digits = 3, row.names = FALSE)
# HED glm exactly as ms_fit (all seven waves = reconstruction model)
hd <- e[cur & is.finite(e$gpd_survey) & e$gpd_survey > 0 & !is.na(e$hed), ]
hd$cell <- factor(paste(hd$sex, hd$age_group, sep = ":"))
hd$w_fit <- hd$weight / mean(hd$weight)
hed <- glm(hed ~ 0 + cell + log1p(gpd_survey), data = hd, weights = w_fit, family = quasibinomial())
print(coef(hed))
# Gamma shape, p_zero exactly as ms_fit
sh <- do.call(rbind, lapply(split(e[cur & is.finite(e$gpd_survey), ], list(e$sex[cur & is.finite(e$gpd_survey)], e$age_group[cur & is.finite(e$gpd_survey)])), function(d) {
  p <- d[d$gpd_survey > 0, ]
  mu <- weighted.mean(p$gpd_survey, p$weight); v <- weighted.mean((p$gpd_survey - mu)^2, p$weight)
  data.frame(sex = d$sex[1], age_group = d$age_group[1], shape = mu^2 / v, p_zero = weighted.mean(d$gpd_survey == 0, d$weight))
}))
print(sh, digits = 3)
# Decomposition per year x cell:
# T = ENPG target (all current with HED observed); A = glm population (gpd>0 finite, HED observed);
# F = mean fitted p over observed glm population (pooled-year model applied to that year's people);
# G = engine expectation: (1 - p_zero) * E_Gamma[p_hed], Gamma mean = target gpd_mean / (1 - p_zero)
set.seed(1)
out <- do.call(rbind, lapply(split(ms_targets, seq_len(nrow(ms_targets))), function(t) {
  k <- e$year == t$year & e$sex == t$sex & e$age_group == t$age_group
  a <- k & cur & is.finite(e$gpd_survey) & e$gpd_survey > 0 & !is.na(e$hed)
  cl <- paste0("cell", t$sex, ":", t$age_group)
  b0 <- coef(hed)[[cl]]; b1 <- coef(hed)[["log1p(gpd_survey)"]]
  s <- sh[sh$sex == t$sex & sh$age_group == t$age_group, ]
  x <- rgamma(2e5, shape = s$shape, scale = t$gpd_mean / ((1 - s$p_zero) * s$shape))
  data.frame(year = t$year, sex = t$sex, age_group = t$age_group,
    T_target = t$hed_mean,
    A_glm_pop = weighted.mean(e$hed[a], e$weight[a]),
    F_fitted_obs = weighted.mean(plogis(b0 + b1 * log1p(e$gpd_survey[a])), e$weight[a]),
    G_engine = (1 - s$p_zero) * mean(plogis(b0 + b1 * log1p(x))))
}))
out$def_gap <- out$A_glm_pop - out$T_target
out$time_gap <- out$F_fitted_obs - out$A_glm_pop
out$gamma_gap <- out$G_engine - out$F_fitted_obs
out$total <- out$G_engine - out$T_target
cat("\n== Mean gaps (percentage points) over 56 cells ==\n")
print(round(100 * colMeans(out[c("def_gap", "time_gap", "gamma_gap", "total")]), 2))
cat("\n== By year ==\n")
print(round(100 * aggregate(cbind(def_gap, time_gap, gamma_gap, total) ~ year, out, mean)[, -1], 2), row.names = FALSE)
print(aggregate(cbind(def_gap, time_gap, gamma_gap, total) ~ year, out, function(z) round(100 * mean(z), 2)))
cat("\n== By sex x age ==\n")
print(aggregate(cbind(def_gap, time_gap, gamma_gap, total) ~ sex + age_group, out, function(z) round(100 * mean(z), 2)))
# Empirical vs Gamma: share of positive drinkers below 5 g/day
cat("\n== Observed vs Gamma tail check (2024, male:1) ==\n")
z <- e[e$year == 2024 & e$sex == "male" & e$age_group == 1 & cur & is.finite(e$gpd_survey) & e$gpd_survey > 0, ]
s <- sh[sh$sex == "male" & sh$age_group == 1, ]; mu <- ms_targets$gpd_mean[ms_targets$year == 2024 & ms_targets$sex == "male" & ms_targets$age_group == 1]
x <- rgamma(2e5, shape = s$shape, scale = mu / ((1 - s$p_zero) * s$shape))
qs <- c(.1, .25, .5, .75, .9)
print(rbind(observed = sapply(qs, function(q) { o <- order(z$gpd_survey); cw <- cumsum(z$weight[o]) / sum(z$weight); z$gpd_survey[o][which(cw >= q)[1]] }), gamma = quantile(x, qs)), digits = 3)
# HED by observed gpd band (pooled), to see the step created by the formula (hed => gpd >= episodes*4or5*12/30)
e2 <- hd; e2$band <- cut(e2$gpd_survey, c(0, 1, 2, 4, 8, 16, 32, Inf))
print(aggregate(hed ~ band, e2, mean))
saveRDS(out, "<scratch>/work/run/hed_decomp.rds")
message(sprintf("hed_audit elapsed minutes: %.2f", as.numeric(difftime(Sys.time(), .t0, units = "mins"))))
